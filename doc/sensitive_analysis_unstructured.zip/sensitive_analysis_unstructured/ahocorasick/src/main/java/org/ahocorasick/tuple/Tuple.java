package org.ahocorasick.tuple;


public abstract class Tuple {


}
