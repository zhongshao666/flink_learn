package org.ahocorasick.tuple;

import java.util.Optional;

public class Tuple2<T0,T1> extends Tuple implements Comparable<Tuple2<T0, T1>>{
    public T0 f0;
    public T1 f1;

    public Tuple2() {
    }

    public Tuple2(T0 f0, T1 f1) {
        this.f0 = f0;
        this.f1 = f1;
    }

    public static <T0, T1> Tuple2<T0, T1> of(T0 f0, T1 f1) {
        return new Tuple2<>(f0, f1);
    }

    @Override
    public int compareTo(Tuple2<T0, T1> tuple2) {
        int i;
        if ((i=this.f0.toString().compareTo(tuple2.f0.toString())) == 0) {
            return this.f1.toString().compareTo(tuple2.f1.toString());
        } else return i;
    }

    @Override
    public String toString() {
        return "Tuple2{" +
                "f0=" + f0 +
                ", f1=" + f1 +
                '}';
    }
}
