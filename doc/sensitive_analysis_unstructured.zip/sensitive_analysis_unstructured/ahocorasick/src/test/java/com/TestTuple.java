package com;

import org.ahocorasick.tuple.Tuple;
import org.ahocorasick.tuple.Tuple2;
import org.junit.Test;

public class TestTuple {
    @Test
    public void test(){

    }
}
