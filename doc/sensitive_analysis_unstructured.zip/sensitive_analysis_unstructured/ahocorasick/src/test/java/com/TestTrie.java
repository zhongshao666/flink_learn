package com;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.ahocorasick.trie.Emit;
import org.ahocorasick.trie.Trie;
import org.ahocorasick.trie.TrieConfig;
import org.ahocorasick.tuple.Tuple2;
import org.apache.commons.io.IOUtils;
import org.junit.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class TestTrie {
    static String input = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaab提1问,传讯, LOGIN a% 责难我还是10国家1973长叹一声啊,疲乏生肉你国家1972-01-22不好啊有没有未来好玩我要充一亿灰白质,123智力";

    @Test
    public void test() {
        Trie trie = new Trie(new TrieConfig(), false);


        trie.addKeyword(new Tuple2<>("杭州市", "地名"));
        trie.addKeyword(new Tuple2<>("单元", "地名"));

        Collection<Emit> emits = trie.parseText("我住杭州市幸福小区1幢1单元801室。");
        emits.forEach(s -> {
            System.out.println(s);
        });
    }

    @Test
    public void testSpeed() {
        HashMap<String, String> enumDataMap = new HashMap<>(131072);
        ArrayList<String> dictList = new ArrayList<>();
        String[] names = {"area_code", "bank_account", "bank_card", "bank_code", "brand_drugs", "chemical_element", "china_city", "china_nation", "china_province", "color", "county_administrative_district", "currency_code", "degree_code", "education_status", "edu_major", "email_code", "fitness", "gender", "icd10_disease_code", "international_telephone", "marriage_status", "nationality", "religious_belief", "taxpayer_credit_rating"};
        dictList.addAll(Arrays.asList(names));

        try (InputStream in = new FileInputStream(new File("C:\\Users\\admin\\IdeaProjects\\sensitive_analysis\\sensitive\\src\\main\\resources\\enum_dict.json"))) {
            Map<String, Object> obj = JSON.parseObject(IOUtils.toString(in, StandardCharsets.UTF_8));
            for (String s : dictList) {
                Arrays.asList(((JSONObject) obj).getJSONArray(s).toArray(new String[0]))
                        .forEach(value -> {
                            enumDataMap.put(value, s);
                        });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        Trie trie = new Trie(false);
        enumDataMap.remove(" ");
        enumDataMap.remove("-");
        enumDataMap.forEach((k, v) -> {
            trie.addKeyword(new Tuple2<>(k, v));
        });

        StringBuilder input111 = new StringBuilder();
        for (int i = 0; i < 10000; i++) {
            input111.append(input);
        }
        System.out.println("input length : " + input111.length());

        String str = "我来自浙江省杭州市余杭区杭州师范大学";

        long beginTime = System.currentTimeMillis();
        Collection<Emit> emits = trie.parseText(str);
        long endTime = System.currentTimeMillis();

        System.out.println("cost time " + (endTime - beginTime) + "ms");
        emits.forEach(s -> {
            System.out.println(s);
        });

    }


    @Test
    public void testEnumMap(){
        HashMap<String, String> enumDataMap = new HashMap<>(131072);
        ArrayList<String> dictList = new ArrayList<>();
        String[] names = {"area_code", "bank_account", "bank_card", "bank_code", "brand_drugs", "chemical_element", "china_city", "china_nation", "china_province", "color", "county_administrative_district", "currency_code", "degree_code", "education_status", "edu_major", "email_code", "fitness", "gender", "icd10_disease_code", "international_telephone", "marriage_status", "nationality", "religious_belief", "taxpayer_credit_rating"};
        dictList.addAll(Arrays.asList(names));

        try (InputStream in = getClass().getResourceAsStream("/enum_dict.json")) {
            Map<String, Object> obj = JSON.parseObject(IOUtils.toString(in, StandardCharsets.UTF_8));
            for (String s : dictList) {
                Arrays.asList(((JSONObject) obj).getJSONArray(s).toArray(new String[0]))
                        .forEach(value -> {
                            enumDataMap.put(value, s);
                        });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (enumDataMap.containsKey("")) {
            System.out.println("空字符串");
        }
        if (enumDataMap.containsKey(" ")) {
            System.out.println("空格");
        }
        if (enumDataMap.containsKey("-")) {
            System.out.println("-");
        }
        if (enumDataMap.containsKey("，")) {
            System.out.println("，");
        }
        if (enumDataMap.containsKey(",")) {
            System.out.println(",");
        }

    }


    @Test
    public void testTrie(){
        TrieConfig trieConfig = new TrieConfig();
        trieConfig.setAllowOverlaps(false);
        Trie trie = new Trie(trieConfig,false);
        trie.addKeyword(new Tuple2<>("你","人称"));
        trie.addKeyword(new Tuple2<>("浙江","人称"));
        trie.addKeyword(new Tuple2<>("江苏","人称"));
        trie.addKeyword(new Tuple2<>("苏乞儿","人称"));
        Collection<Emit> coll = trie.parseText("我听见了你的声音");
        Collection<Emit> res = trie.parseText("浙江苏乞儿");
        System.out.println(res);

    }

    @Test
    public void testT(){
        Trie trie = new Trie();
        trie.addKeyword(new Tuple2<>("hers","s"));
        trie.addKeyword(new Tuple2<>("his","s"));
        trie.addKeyword(new Tuple2<>("she","s"));
        trie.addKeyword(new Tuple2<>("he","s"));
        Collection<Emit> ushers = trie.parseText("ushers");
    }
}
