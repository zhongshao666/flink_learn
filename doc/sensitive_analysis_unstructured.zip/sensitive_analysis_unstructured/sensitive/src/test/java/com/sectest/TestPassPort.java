package com.sectest;

import com.secsmart.discover.MultiRegexMatchImpl;
import com.secsmart.utils.OrgCodeUtil;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

/**
 * （1）因私护照：
 * 传统护照：G+8位数字 或 14/15+7位数；
 * 电子护照：E+8位数字 或 E+1位字母(排除I和O)+7位数字
 * （2）因公护照：
 * 传统护照：D/P/S+7位数字；
 * 电子护照：DE/SE/PE+7位数字
 * 整体时间90多秒
 */
public class TestPassPort {
    @Test
    public void match(){
        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        long beginTime = System.currentTimeMillis();

        for (int i = 0; i < 100000; i++) {
            multiRegexMatch.match("G12345678");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");
        String match = multiRegexMatch.match("G12345678");
        System.out.println(match);
        multiRegexMatch.match("141234567");
        multiRegexMatch.match("141234567");
        String s = "141234567,"+
                "141234567," +
                "157894561," +
                "E12345678," +
                "EA1234567," +
                "D1234567," +
                "P1234567," +
                "S1234567," +
                "DE1234567," +
                "SE1234567," +
                "PE1234567,";
        List<String> lst = Arrays.asList(s.split(","));
        for (String s1 : lst) {
            System.out.println(s1+" = " + multiRegexMatch.match(s1));
        }
        Pattern p  = Pattern.compile("^[GgEe]\\d{8}|(14|15|E[A-Ha-hJ-Nj-nP-Zp-z]|[Dd]|[Pp]|[Ss]|[DdPpSs][Ee])\\d{7}$");
        System.out.println(p.matcher("SE1234567").matches());
        System.out.println("p.matcher(\"SE1234567\").matches() = " + p.matcher("SE1234567").matches());
        //SE1234567 识别为组织机构码
        System.out.println("OccModeUtil.check(\"SE1234567\") = " + OrgCodeUtil.isOrganizationCertificate("SE1234567"));

    }


}
