package com.sectest.load;

import org.junit.Test;

import static com.secsmart.discover.RegexRead.regexList;
import static com.secsmart.discover.RegexRead.ruleMap;

public class TestRegexRead {
    @Test
    public void testRegexRead() {
        regexList.forEach(System.out::println);
        System.out.println("==============");
        ruleMap.forEach((k,v)->{
            System.out.println(k+":"+v);
        });
    }
}
