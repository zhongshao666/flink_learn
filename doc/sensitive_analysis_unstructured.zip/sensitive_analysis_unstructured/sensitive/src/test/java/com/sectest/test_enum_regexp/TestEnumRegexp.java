package com.sectest.test_enum_regexp;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fulmicoton.multiregexp.MultiPatternMatcher;

import org.apache.commons.io.IOUtils;
import org.junit.Test;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

import static com.secsmart.discover.EnumDictMap.enumDataMap;

public class TestEnumRegexp {
    @Test
    public void test() {
        List<String> list = new ArrayList<>();
//        enumDataMap.forEach((k, v) -> {
//            if (!k.equals("")) {
//                System.out.println(k);
//                list.add(k);
//            }
//        });
        Set<Map.Entry<String, String>> entries = enumDataMap.entrySet();
        int i = 0;
        for (Map.Entry<String,String> entry:
                entries) {
            String key = entry.getKey();
//            System.out.println(key);
            list.add(key);
//            i++;
//            if (i == 666) {
//                break;
//            }
        }
        MultiPatternMatcher multiPatternMatcher;
        multiPatternMatcher = com.fulmicoton.multiregexp.MultiPattern.of(
                list
        ).matcher();

        int[] arr = multiPatternMatcher.match("余杭区");
        System.out.println(Arrays.toString(arr));


    }
}
