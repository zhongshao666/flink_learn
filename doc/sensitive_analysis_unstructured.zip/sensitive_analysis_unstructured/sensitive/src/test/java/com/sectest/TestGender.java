package com.sectest;

//import com.secsmart.enumerations.impl.Gender;
import org.junit.Test;

public class TestGender {
    @Test
    public void enumTest() throws InterruptedException {

//        Gender enumCheck = new Gender();
//        long beginTime = System.currentTimeMillis();
//
//        for (int i = 0; i < 1000000; i++) {
//            String match = enumCheck.match("男性");
//        }
//        long endTime = System.currentTimeMillis();
//        System.out.println("cost time " + (endTime - beginTime) + "ms");
//
//        String match = enumCheck.match("男性");
//        System.out.println(match);


    }
}
