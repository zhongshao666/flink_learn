package com.sectest;

import com.secsmart.check.impl.IPv6Check;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;


public class TestIPV6 {
    @Test
    public void match() {
        IPv6Check iPv6 = new IPv6Check();
        long beginTime = System.currentTimeMillis();

        for (int i = 0; i < 1000000; i++) {
            Boolean match = iPv6.check("1234:abce:1234:7161:9021:2a18:12ff:ffff");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");
        Boolean match = iPv6.check("[::6]");
        Boolean match1 = iPv6.check("1234:abce:1234:7161:9021:2a18:12ff:ffff");
        Boolean match2 = iPv6.check("fe80::3096:7161:9021:2a18%10000000");
        Boolean match3 = iPv6.check("::192.168.44.58");
        System.out.println("match = " + match+"\nmatch1 = "+match1+"\nmatch2 = "+match2+"\nmatch3 = "+match3);


    }
    @Test
    public void regularTest() {

        Pattern pattern = Pattern.compile("\\[?([A-Fa-f\\d]{0,4}:[A-Fa-f\\d:.]{0,45}(%([1-9]\\d{0,23}|[A-Za-z\\d_]{0,13}))?(/\\d{0,3})?)]?");

        List<String> list = new ArrayList<>();
        list.add("6::");
        list.add("::");
        list.add("::6");
        list.add("[::6]");
        list.add("[[::6]]");
        list.add("13::3096:7161:9021:2a18");
        list.add("13::2997:fc97:a5af::162a");
        list.add("13::2997:fc97:a5af");
        list.add("::2997:fc97:a5af::162a");
        list.add("2997:fc97:a5af:::162a:");
        list.add("2997:fc97:a5af162a:::");
        list.add("fe80::3096:7161:9021:2a18%11");
        list.add("fe80:3096:7161:9021:2%11:9021:9021:9021");
        list.add("fe80::3096:7161:9021:2a18%100000000000000000000000");
        list.add("fe80::3096:7161:9021:2a18%1000000000000000000000000");
        list.add("1234:abce:1234:7161:9021:2a18:12ff:ffff");
        list.add("1234:abce:1234:7161:9021:2a18:12ff:fffg");
        list.add("1234:abce:1234:7161:9021:2a18:12fg:ffff:1234");
        list.add("0:0:0:0:0:ffff:192.1.56.10");
        list.add("::ffff:192.1.56.10");
        list.add("0:0:0:0:0:0:192.1.56.10");
        list.add("[::192.1.56.10");
        list.add("::192.1.56");
        list.add("1234:abce:1234:7161:9021:2a18:12ff::");
        list.add("123445:abce:1234:7161:9021:2a18:12ff::");
        list.add("fe80::3096:7161:9021:2a18%10/999");
        list.add("fe80::3096:7161:9021:2a18%10/19");
        list.add("0:0:0:0:0:0:0:192.1.56.10");
        list.add("fe80.3096716190212a18");

        list.forEach(item->{
            boolean matcher = pattern.matcher(item).matches();
            System.out.println(item + "  是否匹配  "  + matcher);
        });


    }
}
