package com.sectest;

import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

public class TestOfficeNumber {
    @Test
    public void test(){
        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        System.out.println(multiRegexMatch.match("政字第123456号"));
        long begin = System.currentTimeMillis();
        for (int i = 0; i < 1000000; i++) {
            multiRegexMatch.match("政字第123456号");
        }
        long end = System.currentTimeMillis();
        System.out.println("cost time " + (end - begin) + "ms");
    }
}
