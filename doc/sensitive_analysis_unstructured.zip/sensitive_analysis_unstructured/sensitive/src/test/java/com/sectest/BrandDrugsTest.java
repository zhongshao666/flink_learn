package com.sectest;


import org.junit.Test;

public class BrandDrugsTest {
    @Test
    public void match(){

//        BrandDrugs brandDrugs = new BrandDrugs();
//        long beginTime = System.currentTimeMillis();
//
//        for (int i = 0; i < 1000000; i++) {
//            String match = brandDrugs.match("三九999");
//        }
//        long endTime = System.currentTimeMillis();
//        System.out.println("cost time " + (endTime - beginTime) + "ms");
//
//        String match = brandDrugs.match("复星医药");
//        System.out.println(match);
//        System.out.println("match = " + brandDrugs.match("哈药"));
    }
}
