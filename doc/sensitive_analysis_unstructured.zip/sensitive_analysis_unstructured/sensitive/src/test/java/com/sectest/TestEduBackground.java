package com.sectest;

//import com.secsmart.enumerations.impl.EduBackground;
import org.junit.Test;

public class TestEduBackground {
    @Test
    public void test(){
//        EduBackground eduBackground = new EduBackground();
//        long beginTime = System.currentTimeMillis();
//
//        for (int i = 0; i < 1000000; i++) {
//            String match = eduBackground.match("研究生教育");
//        }
//        long endTime = System.currentTimeMillis();
//        System.out.println("cost time " + (endTime - beginTime) + "ms");
//        System.out.println(eduBackground.match("研究生教育"));
    }
}
