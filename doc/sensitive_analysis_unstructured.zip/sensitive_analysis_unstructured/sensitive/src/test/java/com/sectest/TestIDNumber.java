package com.sectest;

import com.secsmart.check.impl.IDNumberCheck;
import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

public class TestIDNumber {
    @Test
    public void MultiRegexp() throws InterruptedException {

        String s = "150523200201221207,"
                + "350602199411013313,"
                + "65432219460930175X,"
                + "371727193708093238,"
                + "330110201803036417,"
                + "370322196401264740,"
                + "632500196603157140,"
                + "350800200802285766,"
                + "310112198810129181,"
                + "150701190907148685,"
                + "370801197804117331,"
                + "211404191311236371,"
                + "450924201407056781,"
                + "440983196710086000,"
                + "140931200104086875,"
                + "12000015621212369X,"
                + "130000202001051268,"
                + "140000195602035286,"
                + "15000016951226697X,"
                + "440983196710086000,"
                + "61090019280911646,"
                + "440881201708157325";

        List<String> list = Arrays.asList(s.split(","));

        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        long beginTime = System.currentTimeMillis();

        for (int i = 0; i < 1000000; i++) {
//            list.forEach(multiRegexMatch::match);
            multiRegexMatch.match("15000016951226697X");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");

        String match = multiRegexMatch.match("110101199003071655");
        System.out.println(match);

        IDNumberCheck idNumberCheck = new IDNumberCheck();
        System.out.println(idNumberCheck.check("110101199003071655"));
    }
}
