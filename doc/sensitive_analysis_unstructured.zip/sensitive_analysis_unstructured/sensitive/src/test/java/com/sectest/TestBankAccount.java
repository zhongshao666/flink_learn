package com.sectest;

import com.secsmart.check.impl.BankAccountCheck;
import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

public class TestBankAccount {
    private static final String DATE_TIME_FORMATTER = "yyyyMMdd";
    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMATTER);
    @Test
    public void match() {
        String s = "622700026000107242,"
                + "35682700260001074,"
                + "37024800260001076,"
                + "60118700260001078,"
                + "62836800260001079,"
                + "68580000260001079,"
                + "65060000260001078,"
                + "40265800260001070,"
                + "42216000260001077,"
                + "51941200260001076,"
                + "52019400260001075,"
                + "53098000260001074,"
                + "54561900260001073,"
                + "102000000260001072,"
                + "6210951728741810000,"
                + "6210955400648530000,"
                + "6210956339045040000,"
                + "6210952088039150000,"
                + "6200621038955868779,"
                + "6200627811758484333,"
                + "6200621019381158921,"
                + "6200622744613873127,"
                + "6221898123371388872,"
                + "6221891189049194151,"
                + "6210961866672900113,"
                + "6210967903740277838,"
                + "6210964056468261472,"
                + "6210969097787851391,"
                + "6210964271780915263,"
                + "620200413143461323,"
                + "620200827564397742,"
                + "620200870442831219,"
                + "620200648251861928,"
                + "620200660641123554,"
                + "6229114736933566,"
                + "6229114663354638,"
                + "6229122317063141,"
                + "6229128835623811,"
                + "6229123629679996,"
                + "6229128610038375,"
                + "6229127630001595,"
                + "6229130547604337,"
                + "6200588154049572528,"
                + "6200584011529917203,"
                + "6200580278603384795,"
                + "6200589985596936577,"
                + "6200584062039813722,"
                + "6216603273269223992,"
                + "6216683930476592038,"
                + "40966609779551110,"
                + "4096664752951583,"
                + "6216634910257061399,"
                + "6216632615224226339,"
                + "6216678314011279128,"
                + "6216677500802070804,"
                + "4367425139697888183,"
                + "4367421719281138956,"
                + "6210811698326152827,"
                + "6210815254748813386,"
                + "6229883009538721,"
                + "6229889176685352,"
                + "6229883009538721,"
                + "6229889176685352,"
                + "917000000260001075,"
                + "140931200104086875";

        List<String> lst = Arrays.asList(s.split(","));

        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        long beginTime = System.currentTimeMillis();

        for (int i = 0; i < 100000; i++) {
            lst.forEach(multiRegexMatch::match);
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");


        String match = multiRegexMatch.match("623061541504967067");
        System.out.println(match);
        BankAccountCheck check = new BankAccountCheck();
        System.out.println(check.check("629062571509965069"));

    }
    @Test
    public void isLuhnCheck(){
        long beginTime = System.currentTimeMillis();

        for (int i = 0; i < 100000; i++) {
            Boolean luhn = isLuhn("623061571804965097");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");
        System.out.println("isLuhn(\"623061571504965067\") = " + isLuhn("623061572504965067"));
    }
    /**
     * 使用luhn算法进行校验
     **/
    public Boolean isLuhn(String data) {
        int[] num = new int[data.length()];
        for (int i = 0; i < data.length(); i++) {
            num[i] = data.charAt(i) - 48;
        }

        for (int i = num.length - 2; i >= 0; i -= 2) {
            num[i] <<= 1;
            num[i] = num[i] / 10 + num[i] % 10;
        }
        int sum = 0;
        for (int value : num) {
            sum += value;
        }
        return sum % 10 == 0;
    }
}
