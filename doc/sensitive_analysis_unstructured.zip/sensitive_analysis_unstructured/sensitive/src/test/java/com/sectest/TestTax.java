package com.sectest;

import com.secsmart.check.impl.TaxNumberCheck;
import org.junit.Test;

public class TestTax {
    @Test
    public void match() {
        TaxNumberCheck taxCheck = new TaxNumberCheck();
        long beginTime = System.currentTimeMillis();

        for (int i = 0; i < 1000000; i++) {
            Boolean check = taxCheck.check("2118229609189061000");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");

        //共15位前6位行政区划分码   后九位组织机构代码
        System.out.println("----"+taxCheck.check("411422312192611"));
        System.out.println(taxCheck.check("41142296011210700000"));
        System.out.println(taxCheck.check("2118229609189061000"));
        System.out.println(taxCheck.check("2118112009081161000"));

    }
}
