package com.sectest;

//import com.secsmart.enumerations.impl.CurrencyCode;
import org.junit.Test;

public class TestCurrencyCode {
    @Test
    public void test(){
//        CurrencyCode currencyCode = new CurrencyCode();
//        long beginTime = System.currentTimeMillis();
//
//        for (int i = 0; i < 1000000; i++) {
//            String match = currencyCode.match("AED");
//        }
//        long endTime = System.currentTimeMillis();
//        System.out.println("cost time " + (endTime - beginTime) + "ms");
//        System.out.println(currencyCode.match("AED"));
    }
}
