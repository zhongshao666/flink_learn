package com.sectest;

//import com.secsmart.enumerations.impl.ChinaCity;
//import com.secsmart.enumerations.impl.UniversityDegree;
import org.junit.Test;

public class TestDegree {
    @Test
    public void match(){
//        UniversityDegree degree = new UniversityDegree();
//        long beginTime = System.currentTimeMillis();
//
//        for (int i = 0; i < 1000000; i++) {
//            String match = degree.match("博士");
//        }
//        long endTime = System.currentTimeMillis();
//        System.out.println("cost time " + (endTime - beginTime) + "ms");
//
//        String match = degree.match("学士");
//        System.out.println(match);
//        System.out.println("match = " + degree.match("学生"));


    }
}
