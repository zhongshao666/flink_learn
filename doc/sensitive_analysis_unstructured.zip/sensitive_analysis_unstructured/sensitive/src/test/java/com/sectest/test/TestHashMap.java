package com.sectest.test;

import org.junit.Test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class TestHashMap {
    @Test
    public void test() throws Exception {
        HashMap<String, String> hashMap = new HashMap<>(262144,0.8f);
        HashSet<String> hashSet = new HashSet<>();
        ArrayList<String> arrayList = new ArrayList<>();
        ArrayList<String> arrayListSet = new ArrayList<>();
        File file = new File("C:\\Users\\admin\\IdeaProjects\\sensitive_analysis\\sensitive\\src\\main\\resources\\enum_dict\\brand_drugs");
        BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
        int i = 0;
        while (bufferedReader.ready()) {
            i++;
            String s = bufferedReader.readLine();
            hashMap.put(s, "brand_drugs");
            hashSet.add(s);
            arrayList.add(s);
            if (!arrayListSet.contains(s)) {
                arrayListSet.add(s);
            }
        }
        System.out.println(hashMap.size());
        System.out.println(hashSet.size());
        System.out.println(arrayList.size());
        System.out.println(arrayListSet.size());

    }
}
