package com.sectest.speed;

import com.fulmicoton.multiregexp.MultiPatternSearcher;
import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.secsmart.discover.RegexRead.regexList;

public class TestEnumSpeed {
    @Test
    public void test() throws Exception{
        File file = new File("test_data/enum.txt");
        BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
        ArrayList<String> arr = new ArrayList<>();
        ArrayList<String> arrAll = new ArrayList<>();
        while (bufferedReader.ready()) {
            arr.add(bufferedReader.readLine());
        }
        for (int i = 0; i < 500; i++) {
            arrAll.addAll(arr);
        }

        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        long beginTime = System.currentTimeMillis();
        for (String s:
             arrAll) {
            multiRegexMatch.match(s);
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");
    }
    static String input = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaab提1问,传讯, LOGIN a% 责难我还是10国家1973长叹一声啊,疲乏生肉你国家1972-01-22不好啊有没有未来好玩我要充一亿灰白质,123智力";

    @Test
    public void testRegexpSpeed(){

        StringBuilder input111 = new StringBuilder();
        for (int i = 0; i < 10000; i++) {
            input111.append(input);
        }

        List<String> simplifiedPatterns = new ArrayList<>();
        //不能使用lambda,会乱序
        for (String pattern : regexList) {
            //简化正则
            if (Optional.ofNullable(pattern).isPresent() && !pattern.equals("")) {
                String simplifiedPattern = pattern.replaceAll("\\?:", "");
                simplifiedPatterns.add(simplifiedPattern);
            }
        }
        MultiPatternSearcher multiPatternMatcher = com.fulmicoton.multiregexp.MultiPattern.of(
                simplifiedPatterns
        ).searcher();
        long beginTime = System.currentTimeMillis();
        MultiPatternSearcher.Cursor search = multiPatternMatcher.search("哈哈哈");
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");

    }
}
