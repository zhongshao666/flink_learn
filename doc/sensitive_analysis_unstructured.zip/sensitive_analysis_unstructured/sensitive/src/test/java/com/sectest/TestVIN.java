package com.sectest;

import com.google.common.collect.Lists;
import com.secsmart.check.impl.VINCheck;
import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

import java.util.ArrayList;

public class TestVIN {
    @Test
    public void vin() {
        VINCheck vinCheck = new VINCheck();


        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        String s = multiRegexMatch.match("LSVG449J472059134");
        System.out.println(s);
        System.out.println(vinCheck.check("LSVG449J472059134"));

        long beginTime = System.currentTimeMillis();

        for (int i = 0; i < 1000000; i++) {
            String match = multiRegexMatch.match("LSVG449J472059134");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");
    }
}
