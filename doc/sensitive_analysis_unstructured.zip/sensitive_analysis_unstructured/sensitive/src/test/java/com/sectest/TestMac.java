package com.sectest;

import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

public class TestMac {
    @Test
    public void mac() {
        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();

        System.out.println(multiRegexMatch.match("00:0c:29:01:3e:2b"));
        System.out.println(multiRegexMatch.match("00-0c-29-01-3e-2b"));
        long beginTime = System.currentTimeMillis();
        for (int i = 0; i < 1000000; i++) {
            multiRegexMatch.match("00:0c:29:01:3e:2b");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");


    }
}
