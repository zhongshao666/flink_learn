package com.sectest;

import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

public class TestBaseStation {
    @Test
    public void match() {
        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        long beginTime = System.currentTimeMillis();

        for (int i = 0; i < 100000; i++) {
            multiRegexMatch.match("1048575");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");


        String match = multiRegexMatch.match("1048575");
        System.out.println(match);
    }
}
