package com.sectest;


import org.junit.Test;

public class TestEducationStatus {
    @Test
    public void enumTest() throws InterruptedException {

//        EducationStatus enumCheck = new EducationStatus();
//        long beginTime = System.currentTimeMillis();
//
//        for (int i = 0; i < 1000000; i++) {
//            String match = enumCheck.match("博土研究生肄业");
//        }
//        long endTime = System.currentTimeMillis();
//        System.out.println("cost time " + (endTime - beginTime) + "ms");
//
//        String match = enumCheck.match("博土研究生肄业");
//        System.out.println(match);


    }
}
