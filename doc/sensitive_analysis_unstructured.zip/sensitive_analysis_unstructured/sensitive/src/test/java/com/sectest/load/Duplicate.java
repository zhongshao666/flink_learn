package com.sectest.load;

import org.junit.Test;

public class Duplicate {
    @Test
    public void test(){

    }
}
