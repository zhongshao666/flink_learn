package com.sectest;


import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

public class TestChinaNation {
    @Test
    public void match(){
//        ChinaNation chinaNation = new ChinaNation();
//        long beginTime = System.currentTimeMillis();
//
//        for (int i = 0; i < 1000000; i++) {
//            String match = chinaNation.match("乌孜别克");
//        }
//        long endTime = System.currentTimeMillis();
//        System.out.println("cost time " + (endTime - beginTime) + "ms");
//
//        String match = chinaNation.match("乌兹别克");
//        System.out.println(match);
//        System.out.println("match = " + chinaNation.match("阿昌族"));

        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        System.out.println(multiRegexMatch.match("6997E-@str.gd.idv.cy.ne"));
    }
}
