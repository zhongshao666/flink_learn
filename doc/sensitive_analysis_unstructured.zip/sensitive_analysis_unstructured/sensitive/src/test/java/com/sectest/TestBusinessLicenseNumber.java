package com.sectest;

import com.secsmart.check.impl.BusinessLicenseNumberCheck;
import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

import java.util.concurrent.CountDownLatch;

public class TestBusinessLicenseNumber {
    @Test
    public void MultiRegexp() throws InterruptedException {

        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        long beginTime = System.currentTimeMillis();

        for (int i = 0; i < 1000000; i++) {
            String match = multiRegexMatch.match("330184000352775");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");

        CountDownLatch countDownLatch = new CountDownLatch(10);
        long begin = System.currentTimeMillis();
        for (int i = 0; i < 10; i++) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    MultiRegexMatchImpl multi = new MultiRegexMatchImpl();
                    for (int j = 0; j < 100000; j++) {
                        String match = multi.match("330184000352775");
                    }
                    countDownLatch.countDown();
                }
            }).start();
        }
        countDownLatch.await();
        long end = System.currentTimeMillis();
        System.out.println("cost time " + (end - begin) + "ms");

        String match = multiRegexMatch.match("330184000352775");
        System.out.println(match);

        BusinessLicenseNumberCheck check = new BusinessLicenseNumberCheck();
        System.out.println(check.check("330184000352775"));

    }
}
