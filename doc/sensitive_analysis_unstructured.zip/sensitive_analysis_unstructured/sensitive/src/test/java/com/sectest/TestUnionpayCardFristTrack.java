package com.sectest;

import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

import java.util.regex.Pattern;

/**
 * 银联卡第一磁道
 * 1、国内卡最多78位，国际卡最多73位；
 * 2、
 * 起始标志（1位）：百分号(%)
 * 格式代码（2位或1位）：99(国内)或B(国际)
 * 主账号（13-19位）：实际银行卡号
 * 字段分隔符（1位）：山形字符(∧)
 * 姓名（2-26位）：可取大小写字母
 * 字段分隔符（1位）：山形字符(∧)
 * 失效日期（4位）：两位年份+两位月份，注意0000表示无失效日期
 * 服务代码（3位）：第一位可取125679，第二位可取024，第三位可取0-7
 * 附加数据（可变）：20位(国内)或16位(国际)
 * 结束标志（1位）：问号(?)
 */
public class TestUnionpayCardFristTrack {
    @Test
    public void match(){
        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        long beginTime = System.currentTimeMillis();

        for (int i = 0; i < 100000; i++) {
            multiRegexMatch.match("%99623061571504965067∧CJJ∧221010712345678912345678912?");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");


        String match = multiRegexMatch.match("13938478469");
        System.out.println(match);
        //System.out.println("multiRegexMatch.match(\"18549918109\") = " + multiRegexMatch.match("18549918109"));
        Pattern cellPhonePatten =Pattern.compile( "^%(99|B)\\d{13,19}∧[a-zA-Z]{2,26}∧(\\d{2}(0[1-9]|1[0-2])|0000)[125679][024][0-7](\\d{20}|\\d{16})\\?$");

        boolean matches = cellPhonePatten.matcher("%99623061571504965067∧CJJ∧221010712345678912345678912?").matches();
        System.out.println("matches = " + matches);
        boolean matches1 = cellPhonePatten.matcher("%B623061571504965067∧CJJ∧22101071234567891234567?").matches();
        System.out.println("matches1 = " + matches1);


    }

    @Test
    public void test2(){
        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        System.out.println(multiRegexMatch.match(";60118963493924289=2501 2459282233159?"));
        Pattern compile = Pattern.compile("^;\\d{13,19}=(\\d{2}(0[1-9]|1[0-2])|0000)[125679][024][0-7]\\d{10}\\?$");
        System.out.println(compile.matcher(";60118963493924289=25012459282233159?").matches());
        Pattern compile1 = Pattern.compile("^;\\d{13,19}=(\\d{2}(0[1-9]|1[0-2])|0000)[125679][024][0-7]\\d{8}\\?$");
        System.out.println(compile1.matcher(";60118963493924289=25012459282233159?").matches());


    }
}
