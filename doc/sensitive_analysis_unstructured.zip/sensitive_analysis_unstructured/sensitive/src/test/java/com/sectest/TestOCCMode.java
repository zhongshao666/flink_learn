package com.sectest;

import com.secsmart.utils.OrgCodeUtil;
import org.junit.Test;

public class TestOCCMode {
    @Test
    public void match(){
        long beginTime = System.currentTimeMillis();

        for (int i = 0; i < 1000000; i++) {
            Boolean check = OrgCodeUtil.isOrganizationCertificate("411422312192611");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");
        Boolean check = OrgCodeUtil.isOrganizationCertificate("411422312192611");
        System.out.println("check = " + check);

    }
}
