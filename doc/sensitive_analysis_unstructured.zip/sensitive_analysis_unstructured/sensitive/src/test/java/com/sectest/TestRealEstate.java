package com.sectest;


import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestRealEstate {
    @Test
    public void real() {
        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();

        System.out.println(multiRegexMatch.match("鄂(2015)武汉市江汉不动产权第0000001号"));
        System.out.println(multiRegexMatch.match("鄂（2015）武汉市江汉不动产权第0000001号"));

        Pattern compile = Pattern.compile("^([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼]（\\d{4}）.{2,8}|国（\\d{4}）[林海])不动产(权|证明)第\\d{7}号$");
        Matcher matcher = compile.matcher("鄂（2015）武汉市江汉不动产权第0000001号");
        System.out.println(matcher.matches());
    }
}
