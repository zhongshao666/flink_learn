package com.sectest;

import org.junit.Test;

public class TestBankCard {
    @Test
    public void test(){
//        BankCard bankCard = new BankCard();
//        long beginTime = System.currentTimeMillis();
//
//        for (int i = 0; i < 1000000; i++) {
//            String match = bankCard.match("信用卡");
//        }
//        long endTime = System.currentTimeMillis();
//        System.out.println("cost time " + (endTime - beginTime) + "ms");
//        System.out.println(bankCard.match("信用卡"));
    }
}
