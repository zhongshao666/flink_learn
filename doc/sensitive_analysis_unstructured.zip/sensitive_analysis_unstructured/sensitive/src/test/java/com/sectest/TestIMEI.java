package com.sectest;

import com.secsmart.check.impl.IMEICheck;
import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

public class TestIMEI {
    @Test
    public void MultiRegexp() throws InterruptedException {

        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        long beginTime = System.currentTimeMillis();

        for (int i = 0; i < 1000000; i++) {
            String match = multiRegexMatch.match("356701119817008");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");

        String match = multiRegexMatch.match("356701119817008");
        System.out.println(match);

        IMEICheck check = new IMEICheck();
        System.out.println(check.check("356701119817008"));

    }
}
