package com.sectest.speed;

import com.secsmart.discover.SensitiveRecord;
import com.secsmart.discover.TextMultiRegexMatchImpl;
import com.secsmart.utils.Util;
import org.junit.Test;

import java.util.List;

public class TestCheck {
    @Test
    public void test() {
        long beginTime = System.currentTimeMillis();
        for (int i = 0; i < 1000000; i++) {
            Util.isEnChar(',');
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");
        System.out.println(Util.isEnChar(','));
    }
    @Test
    public void checkTest() {
        TextMultiRegexMatchImpl textMatch = new TextMultiRegexMatchImpl();
        List<SensitiveRecord> sensitiveRecords = textMatch.matchRegexp("160531@qq.com你好啊啊啊");
        System.out.println(sensitiveRecords);
        System.out.println(textMatch.matchRegexp("160619@qq.com1334"));
        System.out.println(textMatch.matchRegexp("qqqadadaf160619@qq.com1334"));
        System.out.println(textMatch.matchRegexp("923@qq.com"));

        System.out.println(textMatch.matchTrie("AUD"));
        System.out.println(textMatch.matchTrie("aBGBc"));

        System.out.println(textMatch.matchTrie("你的成绩身状况良好"));
        System.out.println(textMatch.matchTrie("aaaaa你的成绩身体状况良好"));
        System.out.println(textMatch.matchTrie("吗医生诊断的a身体状况a慢性消化系统病"));
        System.out.println(textMatch.matchTrie("吗医生诊断的a状况aaa慢性消化系统病"));

    }
}
