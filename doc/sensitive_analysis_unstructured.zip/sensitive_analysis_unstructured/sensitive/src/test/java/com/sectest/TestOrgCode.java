package com.sectest;

import com.secsmart.check.impl.OrgCodeCheck;
import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestOrgCode {
    @Test
    public void orgCode() {
//        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
//
//        System.out.println(multiRegexMatch.match("31219261-1"));
//        OrgCodeCheck orgCodeCheck1 = new OrgCodeCheck();
//        long beginTime = System.currentTimeMillis();
//        for (int i = 0; i < 1000000; i++) {
//            multiRegexMatch.match("SE1234567");
////            orgCodeCheck1.check("SE1234567");
//        }
//        long endTime = System.currentTimeMillis();
//        System.out.println("cost time " + (endTime - beginTime) + "ms");

        OrgCodeCheck orgCodeCheck = new OrgCodeCheck();
        System.out.println(orgCodeCheck.check("UI345SD34"));
        System.out.println(orgCodeCheck.check("68DMK2S3-4"));

    }
}
