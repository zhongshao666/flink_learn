package com.sectest;


import com.secsmart.check.impl.EmailCheck;
import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

public class TestEmail {
    @Test
    public void match(){

//        Assert.assertTrue(pattern.matcher("123@12.com").matches());
//        Assert.assertTrue(pattern.matcher("123@12.io").matches());
//        Assert.assertFalse(pattern.matcher("123*ss@12.io").matches());
//        Assert.assertFalse(pattern.matcher("@12.io").matches());
//        Assert.assertTrue(pattern.matcher("123@12.png").matches());
//        Assert.assertFalse(pattern.matcher("123@12").matches());
//        Assert.assertTrue(pattern.matcher("c160619305@163.com").matches());


        String s = "123@12.com,"+
                "123@12.io," +
                "123*ss@12.io," +
                "@12.io," +
                "123@12.png," +
                "123@12," +
                "123@12.com,"+
                "123@12.io," +
                "123*ss@12.io," +
                "@12.io," +
                "123@12.png," +
                "123@12," +
                "123@12.com,"+
                "123@12.io," +
                "123*ss@12.io," +
                "@12.io," +
                "123@12.png," +
                "123@12," +
                "123@12.com,"+
                "123@12.io," +
                "123*ss@12.io," +
                "@12.io," +
                "123@12.png," +
                "123@12,";
        List<String> lst = Arrays.asList(s.split(","));

        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        long beginTime = System.currentTimeMillis();

        for (int i = 0; i < 1000000; i++) {
            lst.forEach(multiRegexMatch::match);
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");

        String match = multiRegexMatch.match("12_3@12.io");
        System.out.println(match);

        EmailCheck check = new EmailCheck();
        System.out.println(check.check("1606193057@qq.com"));

    }

}
