package com.sectest;

//import com.secsmart.enumerations.impl.ChinaProvince;
//import com.secsmart.enumerations.impl.Fitness;
import org.junit.Test;

public class TestFitness {
    @Test
    public void test(){
//        Fitness fitness = new Fitness();
//        long beginTime = System.currentTimeMillis();
//
//        for (int i = 0; i < 1000000; i++) {
//            String match = fitness.match("脑血管病");
//        }
//        long endTime = System.currentTimeMillis();
//        System.out.println("cost time " + (endTime - beginTime) + "ms");
//        System.out.println(fitness.match("脑血管病"));
    }
}
