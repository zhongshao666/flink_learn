package com.sectest;


import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

import java.util.regex.Pattern;


/**
 * @author 常娟杰
 * @date 2021-12-01
 * 共15位 MCC+MNC+MSIN (3+2+10)  目前识别国内
 * MCC移动国家码  中国460 | MSIN    10位数字
 * MNC 移动 00 02 04 07 08 13 联通 01 06 09 10 电信 03 05 11 12  铁路 20
 **/
public class TestIMSI  {
    private static final Pattern PATTERN = Pattern.compile("^460(0\\d|1[0-3]|20)\\d{10}$");
    @Test
    public void match() {
        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        long beginTime = System.currentTimeMillis();

        for (int i = 0; i < 100000; i++) {
            multiRegexMatch.match("460001234567891");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");
       //识别成  其他信息类-IMEI国际移动电话设备识别码
        String match = multiRegexMatch.match("460001234567891");
        System.out.println(match);

        String match1 = multiRegexMatch.match("460021234567891");
        System.out.println(match1);
        System.out.println("multiRegexMatch.match(\"460041234567891\") = " + multiRegexMatch.match("460041234567891"));
        System.out.println("multiRegexMatch.match(\"460071234567891\") = " + multiRegexMatch.match("460071234567891"));
        System.out.println("multiRegexMatch.match(\"460081234567891\") = " + multiRegexMatch.match("460081234567891"));
        System.out.println("multiRegexMatch.match(\"460131234567891\") = " + multiRegexMatch.match("460131234567891"));
        System.out.println("multiRegexMatch.match(\"460011234567891\") = " + multiRegexMatch.match("460011234567891"));
        System.out.println("multiRegexMatch.match(\"460061234567891\") = " + multiRegexMatch.match("460061234567891"));
        System.out.println("multiRegexMatch.match(\"460091234567891\") = " + multiRegexMatch.match("460091234567891"));
        System.out.println("multiRegexMatch.match(\"460101234567891\") = " + multiRegexMatch.match("460101234567891"));
        System.out.println("multiRegexMatch.match(\"460031234567891\") = " + multiRegexMatch.match("460031234567891"));
        System.out.println("multiRegexMatch.match(\"460051234567891\") = " + multiRegexMatch.match("460051234567891"));
        System.out.println("multiRegexMatch.match(\"460111234567891\") = " + multiRegexMatch.match("460111234567891"));
        System.out.println("multiRegexMatch.match(\"460121234567891\") = " + multiRegexMatch.match("460121234567891"));
        System.out.println("multiRegexMatch.match(\"460201234567892\") = " + multiRegexMatch.match("460201234567892"));


        System.out.println("PATTERN.matcher) = " + PATTERN.matcher("460001234567891").matches());

    }
}
