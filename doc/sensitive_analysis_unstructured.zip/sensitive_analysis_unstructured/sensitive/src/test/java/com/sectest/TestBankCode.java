package com.sectest;

import com.secsmart.check.impl.BankAccountCheck;
import com.secsmart.check.impl.EmailCheck;
import org.junit.Test;

public class TestBankCode {
    @Test
    public void enumTest() throws InterruptedException {

//        BankCode bankCode = new BankCode();
//        long beginTime = System.currentTimeMillis();
//
//        for (int i = 0; i < 1000000; i++) {
//            String match = bankCode.match("YBCCB");
//        }
//        long endTime = System.currentTimeMillis();
//        System.out.println("cost time " + (endTime - beginTime) + "ms");
//
//        String match = bankCode.match("YBCCB");
//        System.out.println(match);

        EmailCheck emailCheck = new EmailCheck();
        System.out.println(emailCheck.check("111@qq.com"));


    }
}
