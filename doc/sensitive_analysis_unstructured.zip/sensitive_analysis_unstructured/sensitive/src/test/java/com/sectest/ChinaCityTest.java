package com.sectest;

import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

public class ChinaCityTest {
    @Test
    public void match(){
//        ChinaCity chinaCity = new ChinaCity();
//        long beginTime = System.currentTimeMillis();
//
//        for (int i = 0; i < 1000000; i++) {
//            String match = chinaCity.match("杭州市");
//        }
//        long endTime = System.currentTimeMillis();
//        System.out.println("cost time " + (endTime - beginTime) + "ms");
//
//        String match = chinaCity.match("杭州");
//        System.out.println(match);
//        System.out.println("match = " + chinaCity.match("郑州"));

        System.out.println("----------------");
        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        System.out.println(multiRegexMatch.match("中非"));
        long begin = System.currentTimeMillis();
        for (int i = 0; i < 1000000; i++) {
            multiRegexMatch.match("杭州市");
        }
        long end = System.currentTimeMillis();
        System.out.println("cost time " + (end - begin) + "ms");
    }

}
