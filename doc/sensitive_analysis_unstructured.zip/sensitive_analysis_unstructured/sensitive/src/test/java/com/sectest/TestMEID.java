package com.sectest;

import com.secsmart.check.impl.MEIDCheck;
import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

public class TestMEID {
    @Test
    public void MEID() {
//        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();

//        System.out.println(multiRegexMatch.match("353218107068288"));
        MEIDCheck meidCheck = new MEIDCheck();
//        System.out.println(meidCheck.check("353218107068288"));
//        long beginTime = System.currentTimeMillis();
//        for (int i = 0; i < 1000000; i++) {
//            meidCheck.check("353218107068288");
//        }
//        long endTime = System.currentTimeMillis();
//        System.out.println("cost time " + (endTime - beginTime) + "ms");
//        System.out.println(meidCheck.check("353218107068288"));
        System.out.println(meidCheck.check("B7f0Aac9C9C4F7a"));
        System.out.println(meidCheck.check("12d34c1bc9D75F5"));

    }
}
