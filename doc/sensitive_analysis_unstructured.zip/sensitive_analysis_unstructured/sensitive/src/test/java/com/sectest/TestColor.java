package com.sectest;

import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

public class TestColor {
    @Test
    public void test(){
        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        String res = multiRegexMatch.match("白白白白色");
        System.out.println(res);
        long beginTime = System.currentTimeMillis();

        for (int i = 0; i < 1000000; i++) {
            String match = multiRegexMatch.match("白色");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");
    }
}
