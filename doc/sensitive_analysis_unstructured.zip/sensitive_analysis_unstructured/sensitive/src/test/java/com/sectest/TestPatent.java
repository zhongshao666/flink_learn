package com.sectest;

import com.secsmart.check.impl.PatentCheck;
import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

import java.util.concurrent.CountDownLatch;

public class TestPatent {
    @Test
    public void MultiRegexp() throws InterruptedException {

        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        long beginTime = System.currentTimeMillis();

//        for (int i = 0; i < 1000000; i++) {
//            String match = multiRegexMatch.match("ZL201610032112.4");
//        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");
        System.out.println(multiRegexMatch.match("ZL 201610032112.4"));
//        CountDownLatch countDownLatch = new CountDownLatch(10);
//        long begin = System.currentTimeMillis();
//        for (int i = 0; i < 10; i++) {
//            new Thread(new Runnable() {
//                @Override
//                public void run() {
//                    MultiRegexMatchImpl multi = new MultiRegexMatchImpl();
//                    for (int j = 0; j < 100000; j++) {
//                        String match = multi.match("ZL201610032112.4");
//                    }
//                    countDownLatch.countDown();
//                }
//            }).start();
//        }
//        countDownLatch.await();
//        long end = System.currentTimeMillis();
//        System.out.println("cost time " + (end - begin) + "ms");

        //cell_id=([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])
        //age=[1-9][0-9]?|1[01][0-9]|120
//        String match = multiRegexMatch.match("ZL201610032112.4"); //H1023451012 军字第142153号
//        System.out.println(match);
//
//        PatentCheck patentCheck = new PatentCheck();
//        System.out.println(patentCheck.check("ZL95115608.X"));//ZL95115608.X ZL201610032112.4
//        String s = "ZL97101765.4";
//        char c = s.charAt(11);
//        System.out.println(4==((int)c-(int)'0'));

    }
}
