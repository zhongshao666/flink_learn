package com.sectest;

//import com.secsmart.enumerations.impl.InternationalTelephone;
import org.junit.Test;

public class TestInterTelephone {
    @Test
    public void match(){
//        InternationalTelephone interPhone = new InternationalTelephone();
//        long beginTime = System.currentTimeMillis();
//
//        for (int i = 0; i < 1000000; i++) {
//            String match = interPhone.match("973");
//        }
//        long endTime = System.currentTimeMillis();
//        System.out.println("cost time " + (endTime - beginTime) + "ms");
//
//        String match = interPhone.match("973");
//        System.out.println(match);
//        System.out.println("match = " + interPhone.match("123"));
    }
}
