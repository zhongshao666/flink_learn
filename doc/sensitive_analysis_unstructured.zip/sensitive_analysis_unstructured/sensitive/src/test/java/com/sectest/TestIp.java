package com.sectest;

//import com.secsmart.check.impl.cjj.IPCheck;
//import com.secsmart.check.impl.cjj.IPv6;
//import com.secsmart.check.impl.cjj.SecuritiesAccount;
import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

import java.util.regex.Pattern;

//import static com.secsmart.check.impl.cjj.IPCheck.match_IPv4;

public class TestIp {
    private static final Pattern ipv4Pattern = Pattern.compile("^(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|[1-9])(\\.(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)){3}$");

    @Test
    public void match() {
        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        long beginTime = System.currentTimeMillis();

        for (int i = 0; i < 1000000; i++) {
            String check = multiRegexMatch.match("192.168.45.60");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");
        String checkIp = multiRegexMatch.match("192.168.45.60");
        System.out.println("check = " + checkIp);
        String checkIPV6 = multiRegexMatch.match("2031:0000:1F1F:0000:0000:0100:11A0:ADDF");
        System.out.println("check = " + checkIPV6);

    }

    /**
     * 时间太长效率低
     */
    @Test
    public void IpCheckTest() {
//        String data = "2031:0000:1F1F:0000:0000:0100:11A0:ADDF";
//        IPCheck ipCheck = new IPCheck();
//
//        long beginTime = System.currentTimeMillis();
//
//        for (int i = 0; i < 1000000; i++) {
//            boolean check = ipCheck.check("192.168.45.60");
//        }
//        long endTime = System.currentTimeMillis();
//        System.out.println("cost time " + (endTime - beginTime) + "ms");
//        System.out.println("ipCheck.check(data) = " + ipCheck.check(data));
    }
}
