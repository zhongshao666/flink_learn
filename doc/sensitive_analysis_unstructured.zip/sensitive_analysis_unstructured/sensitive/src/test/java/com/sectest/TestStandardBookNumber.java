package com.sectest;

import com.secsmart.check.impl.StandardBookNumber;
import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

public class TestStandardBookNumber {
    @Test
    public void test(){
//        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
//
//        System.out.println(multiRegexMatch.match("7-5600-3879-4"));
//        System.out.println(multiRegexMatch.match("7560038794"));
//        System.out.println(multiRegexMatch.match("978-7-115-47258-8"));
//        System.out.println(multiRegexMatch.match("9787115472588"));
//        long beginTime = System.currentTimeMillis();
//        for (int i = 0; i < 1000000; i++) {
//            multiRegexMatch.match("7-5600-3879-4");
//        }
//        long endTime = System.currentTimeMillis();
//        System.out.println("cost time " + (endTime - beginTime) + "ms");

        StandardBookNumber standardBookNumber = new StandardBookNumber();
        System.out.println(standardBookNumber.check("978055901330X"));
        System.out.println(standardBookNumber.check("973958473X"));
        System.out.println(standardBookNumber.check("917521573X"));
        System.out.println(standardBookNumber.check("230203869X"));
        System.out.println(standardBookNumber.check("978724180286X"));
        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        System.out.println(multiRegexMatch.match("978055901330X"));
    }
}
