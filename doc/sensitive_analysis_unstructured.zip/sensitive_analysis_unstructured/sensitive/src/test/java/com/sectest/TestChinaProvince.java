package com.sectest;


import com.secsmart.discover.MultiRegexMatchImpl;

import org.junit.Test;

import java.util.*;

import static com.secsmart.discover.RuleId.*;

public class TestChinaProvince {
    @Test
    public void test(){

        long beginTime = System.currentTimeMillis();

        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        long endTime = System.currentTimeMillis();
        System.out.println("load time " + (endTime - beginTime) + "ms");

        beginTime = System.currentTimeMillis();
//
        for (int i = 0; i < 1000000; i++) {
            multiRegexMatch.match("五仁醇软胶囊");
        }

        System.out.println(multiRegexMatch.match("溃疡恶变"));
        System.out.println(com.secsmart.discover.EnumDictMap.enumDataMap.size());
        endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");
//        System.out.println(chinaProvince.match("江西省"));

        String s1 = "江西省";
        String s2 = "江西";
        System.out.println(s1.startsWith(s2));
        System.out.println(s2.startsWith(s1));
        System.out.println(multiRegexMatch.match("253816"));
    }

    @Test
    public void testSpeed(){
//        HashMap<String, EnumMatch> stringEnumMatchHashMap = new HashMap<>();
//        stringEnumMatchHashMap.put(AREA_CODE, new AreaCode());
//        stringEnumMatchHashMap.put(BANK_CARD, new BankCard());
//        stringEnumMatchHashMap.put(BANK_CODE, new BankCode());
//        stringEnumMatchHashMap.put(BRAND_DRUGS, new BrandDrugs());
//        stringEnumMatchHashMap.put(CHEMICAL_ELEMENT, new ChemicalElement());
//        stringEnumMatchHashMap.put(CHINA_CITY, new ChinaCity());
//        stringEnumMatchHashMap.put(CHINA_NATION, new ChinaNation());
//        stringEnumMatchHashMap.put(CHINA_PROVINCE, new ChinaProvince());
//        stringEnumMatchHashMap.put(COUNTY_ADMINISTRATIVE_DISTRICT, new CountyAdministrativeDistrict());
//        stringEnumMatchHashMap.put(CURRENCY_CODE, new CurrencyCode());
//        stringEnumMatchHashMap.put(EDU_BACKGROUND, new EduBackground());
//        stringEnumMatchHashMap.put(EDUCATION_STATUS, new EducationStatus());
//        stringEnumMatchHashMap.put(EDU_MAJOR, new EduMajor());
//        stringEnumMatchHashMap.put(FITNESS, new Fitness());
//        stringEnumMatchHashMap.put(GENDER, new Gender());
//        stringEnumMatchHashMap.put(ICD10_DISEASE_CODE, new ICD10DiseaseCode());
//        stringEnumMatchHashMap.put(INTERNATIONAL_TELEPHONE, new InternationalTelephone());
//        stringEnumMatchHashMap.put(MARRIAGE_STATUS, new MarriageStatus());
//        stringEnumMatchHashMap.put(RELIGIOUS_BELIEF, new ReligiousBelief());
//        stringEnumMatchHashMap.put(TAXPAYER_CREDIT_RATING, new TaxpayerCredit());
//        stringEnumMatchHashMap.put(DEGREE_CODE, new UniversityDegree());
//        ArrayList<String> strings = new ArrayList<>();
//        strings.add(BANK_CARD);
//        strings.add(BRAND_DRUGS);
//        strings.add(CHINA_CITY);
//        strings.add(CHINA_NATION);
//        strings.add(CHINA_PROVINCE);
//        strings.add(COUNTY_ADMINISTRATIVE_DISTRICT);
//        strings.add(DEGREE_CODE);
//        strings.add(EDU_MAJOR);
//        strings.add(EDUCATION_STATUS);
//        strings.add(FITNESS);
//        strings.add(GENDER);
//        strings.add(MARRIAGE_STATUS);
//        strings.add(RELIGIOUS_BELIEF);
//        HashMap<String, String> hashMap = new HashMap<>();
//        Set<Map.Entry<String, HashSet<String>>> entries = EnumDict.dictMap.entrySet();
//        for (Map.Entry<String, HashSet<String>> en: entries) {
//            String key = en.getKey();
//            HashSet<String> value = en.getValue();
//            for (String ss: value) {
//                hashMap.put(ss, key);
//            }
//        }
//        System.out.println(hashMap.size());
//
//        String value = "昆山市";
//        long beginTime = System.currentTimeMillis();
//
//        for (int i = 0; i < 1000000; i++) {
//            boolean b = hashMap.containsKey(value);
//        }
//        System.out.println(hashMap.containsKey(value));

//        for (int i = 0; i < 1000000; i++) {
//            String res=strings.stream().map(s->TestChinaProvince.getMatch(s,stringEnumMatchHashMap))
//                    .filter(Objects::nonNull)
//                    .map(match -> match.match(value))
//                    .filter(Objects::nonNull)
//                    .findFirst()
//                    .orElse(null);
//        }

//        for (int i = 0; i < 1000000; i++) {
//            String result=null;
//            for (String e: strings) {
//                if (Optional.ofNullable(TestChinaProvince.getMatch(e,stringEnumMatchHashMap).match(value)).isPresent()) {
//                    break;
//                }
//            }
//        }

        long endTime = System.currentTimeMillis();
//        System.out.println("cost time " + (endTime - beginTime) + "ms");
//        System.out.println(res);
    }

}
