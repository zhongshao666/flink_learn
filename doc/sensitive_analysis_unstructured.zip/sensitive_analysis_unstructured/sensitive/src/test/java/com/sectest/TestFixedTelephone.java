package com.sectest;

import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

public class TestFixedTelephone {
    @Test
    public void MultiRegexp() throws InterruptedException {

        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        long beginTime = System.currentTimeMillis();

        for (int i = 0; i < 1000000; i++) {
            String match = multiRegexMatch.match("0571-88575373");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");

        String match = multiRegexMatch.match("0571-88575373");
        System.out.println(match);


    }
}
