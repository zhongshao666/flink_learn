package com.sectest;

import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;


public class TestHousingOwnershipCertificates {
    @Test
    public void MultiRegexp() throws InterruptedException {

        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        long beginTime = System.currentTimeMillis();

        for (int i = 0; i < 1000000; i++) {
            String match = multiRegexMatch.match("昆房权证西山居字第123456号");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");

        String match = multiRegexMatch.match("昆房权证西山居字第123456号");
        System.out.println(match);
    }
}
