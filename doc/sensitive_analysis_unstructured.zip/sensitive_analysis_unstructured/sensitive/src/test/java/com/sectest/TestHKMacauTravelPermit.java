package com.sectest;

import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

public class TestHKMacauTravelPermit {
    @Test
    public void MultiRegexp() throws InterruptedException {

        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        long beginTime = System.currentTimeMillis();

        for (int i = 0; i < 1000000; i++) {
            String match = multiRegexMatch.match("CW123456");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");

        String match = multiRegexMatch.match("CW1234567");
        System.out.println(match);


    }
}
