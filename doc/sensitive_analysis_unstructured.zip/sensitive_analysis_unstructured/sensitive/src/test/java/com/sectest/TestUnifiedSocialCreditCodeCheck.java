package com.sectest;

import com.secsmart.check.impl.UnifiedSocialCreditCodeCheck;
import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

import java.util.concurrent.CountDownLatch;

public class TestUnifiedSocialCreditCodeCheck {
    @Test
    public void MultiRegexp() throws InterruptedException {

        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        long beginTime = System.currentTimeMillis();

        for (int i = 0; i < 1000000; i++) {
            String match = multiRegexMatch.match("91330110328126571L");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");

        CountDownLatch countDownLatch = new CountDownLatch(10);
        long begin = System.currentTimeMillis();
        for (int i = 0; i < 10; i++) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    MultiRegexMatchImpl multi = new MultiRegexMatchImpl();
                    for (int j = 0; j < 100000; j++) {
                        String match = multi.match("91330110328126571L");
                    }
                    countDownLatch.countDown();
                }
            }).start();
        }
        countDownLatch.await();
        long end = System.currentTimeMillis();
        System.out.println("cost time " + (end - begin) + "ms");

        String match = multiRegexMatch.match("91330110328126571L");
        System.out.println(match);

        UnifiedSocialCreditCodeCheck check = new UnifiedSocialCreditCodeCheck();
        System.out.println(check.check("91330110328126571L"));

    }
}
