package com.sectest;

//import com.secsmart.enumerations.impl.ReligiousBelief;
import org.junit.Test;

public class TestReligiousBelief {
    @Test
    public void enumTest() throws InterruptedException {

//        ReligiousBelief enumCheck = new ReligiousBelief();
//        long beginTime = System.currentTimeMillis();
//
//        for (int i = 0; i < 1000000; i++) {
//            String match = enumCheck.match("基督教");
//        }
//        long endTime = System.currentTimeMillis();
//        System.out.println("cost time " + (endTime - beginTime) + "ms");
//
//        String match = enumCheck.match("基督教");
//        System.out.println(match);


    }
}
