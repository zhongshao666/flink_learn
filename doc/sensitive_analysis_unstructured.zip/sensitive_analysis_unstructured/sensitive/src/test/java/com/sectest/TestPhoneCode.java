package com.sectest;


import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Test;

import java.util.regex.Pattern;

public class TestPhoneCode {
    @Test
    public void match(){
        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        long beginTime = System.currentTimeMillis();

        for (int i = 0; i < 100000; i++) {
            multiRegexMatch.match("19338478469");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");


        String match = multiRegexMatch.match("13938478469");
        System.out.println(match);
        System.out.println("multiRegexMatch.match(\"18549918109\") = " + multiRegexMatch.match("18548694235"));
        Pattern cellPhonePatten =Pattern.compile( "^(?:\\+?86)?1([38]\\d{1}|4[579]|5[^4]|66|7[^49]|9[189])\\d{8}$");

        boolean matches = cellPhonePatten.matcher("18548694235").matches();
        System.out.println("matches = " + matches);
        boolean matches1 = cellPhonePatten.matcher("8613706532109").matches();
        System.out.println("matches1 = " + matches1);


    }
}

