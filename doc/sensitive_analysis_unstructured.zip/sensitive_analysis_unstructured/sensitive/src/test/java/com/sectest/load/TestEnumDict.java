package com.sectest.load;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.secsmart.discover.EnumDictInit;
import org.apache.commons.io.IOUtils;
import org.junit.Test;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static com.secsmart.discover.EnumDictMap.dictList;
import static com.secsmart.discover.EnumDictMap.dictMap;



public class TestEnumDict {

    @Test
    public  void testEnumDict() throws IOException {
        EnumDictInit enumDictInit = new EnumDictInit();
        enumDictInit.init();
        enumDictInit.dictListInit.forEach(System.out::println);
        enumDictInit.dictMapInit.forEach((k, v)->{
            System.out.println(k+":");
            System.out.println(v.size());
        });
        String jsonString = JSON.toJSONString(enumDictInit.dictMapInit);
        File file = new File("D:\\ideaPackage\\sensitive_analysis\\sensitive\\src\\main\\resources\\enum_dict.json");
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        fileOutputStream.write(jsonString.getBytes());
        fileOutputStream.flush();
        fileOutputStream.close();
    }

    @Test
    public void test() throws Exception {
        System.out.println(dictList);
        dictMap.forEach((k,v)-> {
            System.out.println(k + ":");
            System.out.println(v.size());
        });
        HashMap<String, String> hashMap = new HashMap<>();
//        ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream("C:\\Users\\admin\\IdeaProjects\\sensitive_analysis\\sensitive\\src\\main\\resources\\enum_map"));

    }

    @Test
    public void testEnum(){
        HashMap<String, String> enumDataMap = new HashMap<>(131072);
        ArrayList<String> dictList = new ArrayList<>();
        String[] names = {"area_code", "bank_account", "bank_card", "bank_code", "brand_drugs", "chemical_element", "china_city", "china_nation", "china_province", "color", "county_administrative_district", "currency_code", "degree_code", "education_status", "edu_major", "email_code", "fitness", "gender", "icd10_disease_code", "international_telephone", "marriage_status", "nationality", "religious_belief", "taxpayer_credit_rating"};
        dictList.addAll(Arrays.asList(names));

        try (InputStream in = getClass().getResourceAsStream("/enum_dict.json")) {
            Map<String, Object> obj = JSON.parseObject(IOUtils.toString(in, StandardCharsets.UTF_8));
            for (String s : dictList) {
                Arrays.asList(((JSONObject) obj).getJSONArray(s).toArray(new String[0]))
                        .forEach(value -> {
                            enumDataMap.put(value, s);
                        });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (enumDataMap.containsKey("")) {
            System.out.println("空字符串");
        }
        if (enumDataMap.containsKey(" ")) {
            System.out.println("空格");
        }
        if (enumDataMap.containsKey("-")) {
            System.out.println("-");
        }
        if (enumDataMap.containsKey("，")) {
            System.out.println("，");
        }
        if (enumDataMap.containsKey(",")) {
            System.out.println(",");
        }
    }
}
