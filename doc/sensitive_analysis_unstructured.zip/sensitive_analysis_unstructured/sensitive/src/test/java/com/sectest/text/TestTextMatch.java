package com.sectest.text;

import com.secsmart.discover.SensitiveRecord;
import com.secsmart.discover.TextMultiRegexMatchImpl;
import org.junit.Test;

import java.util.List;

public class TestTextMatch {
    @Test
    public void test(){
        TextMultiRegexMatchImpl textMultiRegexMatch = new TextMultiRegexMatchImpl();
        //623061541504967067 银行账户
        //浙CW689E,军V7891Q
        //put,昆房权证西山居字第123456号
        List<SensitiveRecord> list = textMultiRegexMatch.matchRegexp("460041234567891,360727199901180728,411422312192611,41142296011210700000,91330110328126571L,input,330184000352775,input,623061541504967067,input,356701119817008,B7f0Aac9C9C4F7a,input.LSVG449J472059134,input,UI345SD34,68DMK2S3-4,input,978055901330X,973958473X,input,ZL 201610032112.4,ZL95115608.X,ZL201610032112.4,input,C000318817,99C101325522,input,99C101325522,C000318817,0878715015,input,141234567,P1234567,input,h1234567891,M1239874561,input,CW1234567,input,1234:abce:1234:7161:9021:2a18:12ff:ffff,::192.168.44.58,fe80::3096:7161:9021:2a18%10000000,1234:abce:1234:7161:9021:2a18:12ff:ffff,[::6],::192.168.44.58,input,00-0c-29-01-3e-2b,00:0c:29:01:3e:2b,input,192.168.45.60,0.0.0.0,input,0571-88575373,input,18548694235,13180410719,input,1606193057@qq.com,input,政字第123456号,input,浙CW689E,军V7891Q,京Z20776港,input,鄂(2015)武汉市江汉不动产权第0000001号,input,昆房权证西山居字第123456号,input,%99623061571504965067∧CJJ∧221010712345678912345678912?,input,;6011896349392428=72049003919400421?,;6011896349392428=200994744730381?,input,;996011896349392428=156665916317802819620228400824969296503780341=75468=012985797834218?,;996011896349392428=1564787263590397233279972659787255733122372238269=5=062321370755596?,input,红色，绿色粉红色，卡其色");
        for (SensitiveRecord sensitiveRecord : list) {
            System.out.println(sensitiveRecord);
        }
        System.out.println("-------------------------------------------");
        List<SensitiveRecord> list1 = textMultiRegexMatch.matchRegexp("input,浙CW689E,军V7891Q");
        list1.forEach(System.out::println);
    }
}
