package com.sectest.test;

import com.secsmart.discover.MultiRegexMatchImpl;
import com.secsmart.discover.SensitiveRecord;
import com.secsmart.discover.TextMultiRegexMatchImpl;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

public class TestSortAndConflict {
    @Test
    public void test(){
        ArrayList<SensitiveRecord> sensitiveRecords = new ArrayList<>();
        sensitiveRecords.add(new SensitiveRecord("xxx","rule",0,2,true));
        sensitiveRecords.add(new SensitiveRecord("xxx","china_city",1,2,true));
        sensitiveRecords.add(new SensitiveRecord("xxx","rule",5,2,true));
        sensitiveRecords.add(new SensitiveRecord("xxx","rule",5,1,true));
        sensitiveRecords.add(new SensitiveRecord("xxx","office_number",1,2,true));
        sensitiveRecords.add(new SensitiveRecord("xxx","rule",2,3,true));
        sensitiveRecords.add(new SensitiveRecord("xxx","rule",2,2,true));
//        sensitiveRecords.sort(new Comparator<SensitiveRecord>() {
//            @Override
//            public int compare(SensitiveRecord o1, SensitiveRecord o2) {
//                if (o1.getStart()>o2.getStart())
//                    return 1;
//                else if (o1.getStart()==o2.getStart()){
//                    if (o1.getEnd() > o2.getEnd()) {
//                        return 1;
//                    } else if (o1.getEnd() == o2.getEnd())
//                        return 0;
//                }
//                return -1;
//            }
//        });
        HashMap<String, Integer> hashMap = new HashMap<>();

        hashMap.put("bank_card", 2);
        hashMap.put("brand_drugs", 3);
        hashMap.put("chemical_element", 4);
        hashMap.put("china_city", 5);
        hashMap.put("china_nation", 6);
        hashMap.put("china_province", 7);
        hashMap.put("county_administrative_district", 9);
        hashMap.put("currency_code", 10);
        hashMap.put("degree_code", 11);
        hashMap.put("education_status", 12);
        hashMap.put("edu_major", 13);
        hashMap.put("fitness", 14);
        hashMap.put("gender", 15);
        hashMap.put("icd10_disease_code", 16);
        hashMap.put("international_telephone", 17);
        hashMap.put("marriage_status", 18);
        hashMap.put("nationality", 19);
        hashMap.put("religious_belief", 20);
        hashMap.put("taxpayer_credit_rating", 21);
        hashMap.put("imsi_code", 22);
        hashMap.put("id_number", 23);
        hashMap.put("tax_id", 24);
        hashMap.put("unified_social_credit_code", 25);
        hashMap.put("business_license_number", 26);
        hashMap.put("bank_account", 27);
        hashMap.put("imei", 28);
        hashMap.put("meid_code", 29);
        hashMap.put("vin_number", 30);
        hashMap.put("org_code", 31);
        hashMap.put("standard_book_number", 32);
        hashMap.put("patent", 33);
        hashMap.put("sh_sucurity_number", 34);
        hashMap.put("sz_sucurity_number", 35);
        hashMap.put("pass_port_code", 36);
        hashMap.put("mtp_for_hkmacao", 37);
        hashMap.put("hk_macau_travel_permit", 38);
        hashMap.put("ipv6_code", 39);
        hashMap.put("mac", 40);
        hashMap.put("ip_code", 41);
        hashMap.put("fixed_telephone", 42);
        hashMap.put("cell_phone", 43);
        hashMap.put("email_code", 44);
        hashMap.put("office_number", 45);
        hashMap.put("bus_number", 46);
        hashMap.put("real_estate", 47);
        hashMap.put("housing_ownership_certificates", 48);
        hashMap.put("unionpay_card_frist_track", 49);
        hashMap.put("unionpay_card_second_track", 50);
        hashMap.put("unionpay_card_third_track", 51);
        hashMap.put("color", 52);
        hashMap.put("PER", 53);
        hashMap.put("LOC", 54);
        hashMap.put("ORG", 55);
        hashMap.put("PRO", 56);
        hashMap.put("BANK", 56);
        hashMap.put("TIME", 56);



        List<SensitiveRecord> collect = sensitiveRecords.stream().sorted(Comparator.comparing(SensitiveRecord::getStart).thenComparing(SensitiveRecord::getEnd).thenComparing(new Comparator<SensitiveRecord>() {
            @Override
            public int compare(SensitiveRecord o1, SensitiveRecord o2) {
                return hashMap.get(o1.getRule()).compareTo(hashMap.get(o2.getRule()));
            }
        })).collect(Collectors.toList());

        for (SensitiveRecord sensitiveRecord : collect) {
            System.out.println(sensitiveRecord);
        }
    }

    @Test
    public void testCh(){
        TextMultiRegexMatchImpl textMultiRegexMatch = new TextMultiRegexMatchImpl();
        String s1 = "aaaa";
        String s2 = "123";
        String s3 = "，";
        String s4 = "哈哈哈";
        String s5 = "芝";
        String s6 = "㐀";
        String s7 = "㐂";
        String s8 = "㐄";
        System.out.println(textMultiRegexMatch.checkChinese(s1));
        System.out.println(textMultiRegexMatch.checkChinese(s2));
        System.out.println(textMultiRegexMatch.checkChinese(s3));
        System.out.println(textMultiRegexMatch.checkChinese(s4));
        System.out.println(textMultiRegexMatch.checkChinese(s5));
        System.out.println(textMultiRegexMatch.checkChinese(s6));
        System.out.println(textMultiRegexMatch.checkChinese(s7));
        System.out.println(textMultiRegexMatch.checkChinese(s8));
        String ss = "华南理工";
        boolean b = ss.endsWith("理工");
        System.out.println(b);

    }

    @Test
    public void testConflict(){

    }
    @Test
    public void test1(){
        HashMap<String, Integer> sortMap = new HashMap<>();
        sortMap.put("bank_card", 2);
        sortMap.put("brand_drugs", 3);
        sortMap.put("chemical_element", 4);
        sortMap.put("china_city", 5);
        sortMap.put("china_nation", 6);
        sortMap.put("china_province", 7);
        sortMap.put("county_administrative_district", 9);
        sortMap.put("currency_code", 10);
        sortMap.put("degree_code", 11);
        sortMap.put("education_status", 12);
        sortMap.put("edu_major", 13);
        sortMap.put("fitness", 14);
        sortMap.put("gender", 15);
        sortMap.put("icd10_disease_code", 16);
        sortMap.put("international_telephone", 17);
        sortMap.put("marriage_status", 18);
        sortMap.put("nationality", 19);
        sortMap.put("religious_belief", 20);
        sortMap.put("taxpayer_credit_rating", 21);
        sortMap.put("imsi_code", 22);
        sortMap.put("id_number", 23);
        sortMap.put("tax_id", 24);
        sortMap.put("unified_social_credit_code", 25);
        sortMap.put("business_license_number", 26);
        sortMap.put("bank_account", 27);
        sortMap.put("imei", 28);
        sortMap.put("meid_code", 29);
        sortMap.put("vin_number", 30);
        sortMap.put("org_code", 31);
        sortMap.put("standard_book_number", 32);
        sortMap.put("patent", 33);
        sortMap.put("sh_sucurity_number", 34);
        sortMap.put("sz_sucurity_number", 35);
        sortMap.put("pass_port_code", 36);
        sortMap.put("mtp_for_hkmacao", 37);
        sortMap.put("hk_macau_travel_permit", 38);
        sortMap.put("ipv6_code", 39);
        sortMap.put("mac", 40);
        sortMap.put("ip_code", 41);
        sortMap.put("fixed_telephone", 42);
        sortMap.put("cell_phone", 43);
        sortMap.put("email_code", 44);
        sortMap.put("office_number", 45);
        sortMap.put("bus_number", 46);
        sortMap.put("real_estate", 47);
        sortMap.put("housing_ownership_certificates", 48);
        sortMap.put("unionpay_card_frist_track", 49);
        sortMap.put("unionpay_card_second_track", 50);
        sortMap.put("unionpay_card_third_track", 51);
        sortMap.put("color", 52);
        sortMap.put("PER", 53);
        sortMap.put("LOC", 54);
        sortMap.put("ORG", 55);
        sortMap.put("PRO", 56);
        sortMap.put("BANK", 57);
        sortMap.put("TIME", 58);
        sortMap.put("SCH", 58);
        new MultiRegexMatchImpl();

    }


}
