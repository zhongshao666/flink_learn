package com.sectest;


import com.secsmart.discover.MultiRegexMatchImpl;
import com.secsmart.discover.TextMultiRegexMatchImpl;
import org.junit.Test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Pattern;

/**
 * 正则待优化
 */
public class TestBusNumber {
    private static final Pattern a = Pattern.compile("^([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵青藏川宁琼][A-HJ-NP-Z][A-HJ-NP-Z\\d]{4,5}[A-HJ-NP-Z\\d领学警挂试超]|粤([A-HJ-NP-Y][A-HJ-NP-Z\\d]{4,5}[A-HJ-NP-Z\\d领学警挂试超]|Z[A-HJ-NP-Z\\d]{4,5}[港澳])|使(10[1-9]|1[1-9]\\d|2[0-5]\\d|30\\d|31[0-8])\\d{3}|[济J兰L沈S南N军V成C北B广G空K海H][A-HJ-NP-Z][A-HJ-NP-Z\\d]{5})$");
    @Test
    public void match(){
//        HashSet<String> busNumbersSuffix= new HashSet<>(Arrays.asList("使100456","使256456","使321456","使320476","使C20476"));
//        for (String numbersSuffix : busNumbersSuffix) {
//            System.out.println("EMPATTERN.matcher(numbersSuffix).matches() = " + a.matcher(numbersSuffix).matches()+"----->" +numbersSuffix);
//        }
//
//        String s = "使100456,"
//                + "使C20476,"
//                + "浙CW689E,"
//                + "军V7891Q,"
//                + "VV78919,"
//                + "豫AAW689,"
//                + "粤Z1112澳,"
//                + "京NH1N10,"
//                + "桂LD00600,"
//                + "吉J1111学,"
//                + "浙C0030警,"
//                + "浙Q9037挂,"
//                + "浙P1097试,"
//                + "使Z20476,"
//                + "粤Z20476,"
//                + "粤C20476港,"
//                + "京Z207里6,"
//                + "京Z20776港,"
//                + "浙P10979超,"
//               ;
//        List<String> lst = Arrays.asList(s.split(","));
//
//
//        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
//        long beginTime = System.currentTimeMillis();
//
//        for (int i = 0; i < 1000000; i++) {
//            lst.forEach(multiRegexMatch::match);
//        }
//        long endTime = System.currentTimeMillis();
//        System.out.println("cost time " + (endTime - beginTime) + "ms");
//
//        String match = multiRegexMatch.match("使256456");
//        System.out.println(match);
        TextMultiRegexMatchImpl textMultiRegexMatch = new TextMultiRegexMatchImpl();
        System.out.println(textMultiRegexMatch.matchRegexp("浙CW689E,军V7891Q,6217002430043730010"));


    }
}
