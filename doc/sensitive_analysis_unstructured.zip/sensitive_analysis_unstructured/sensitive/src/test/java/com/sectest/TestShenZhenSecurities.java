package com.sectest;

//import com.secsmart.check.impl.cjj.SecuritiesAccount;
import com.secsmart.discover.MultiRegexMatchImpl;
import org.junit.Assert;
import org.junit.Test;

/***
 * 正则待优化100秒左右
 */
public class TestShenZhenSecurities {
    @Test
    public void match(){
//        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
//        SecuritiesAccount securitiesAccount = new SecuritiesAccount();
//        long beginTime = System.currentTimeMillis();
//
//        for (int i = 0; i < 1000000; i++) {
//            String check = multiRegexMatch.match("A123456789");
//        }
//        long endTime = System.currentTimeMillis();
//        System.out.println("cost time " + (endTime - beginTime) + "ms");
//        String check = multiRegexMatch.match("A123456789");
//        //识别出是  通讯信息类-固定电话
//        System.out.println("multiRegexMatch.match(\"0121234567\") = " + multiRegexMatch.match("0121234567"));
//
//        System.out.println("check = " + check);
//
//        Assert.assertTrue(securitiesAccount.check("A123456789"));
//        Assert.assertTrue(securitiesAccount.check("B123456789"));
//        Assert.assertTrue(securitiesAccount.check("C123456789"));
//        Assert.assertTrue(securitiesAccount.check("D123456789"));
//        Assert.assertTrue(securitiesAccount.check("F123456789"));
//        Assert.assertTrue(securitiesAccount.check("C023456789"));
//        Assert.assertTrue(securitiesAccount.check("C123456789"));
//        Assert.assertTrue(securitiesAccount.check("C903456789"));
//        Assert.assertTrue(securitiesAccount.check("C993456789"));
//        Assert.assertTrue(securitiesAccount.check("99C023456789"));
//        //深圳
//        System.out.println("securitiesAccount = " + securitiesAccount.check("0121234567"));

    }
}
