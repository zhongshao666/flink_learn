package com.sectest;

//import com.secsmart.enumerations.impl.EduMajor;
import org.junit.Test;

public class TestEduMajor {
    @Test
    public void testEduMajor() {
//        EduMajor eduMajor = new EduMajor();
//        long beginTime = System.currentTimeMillis();
//
//        for (int i = 0; i < 1000000; i++) {
//            String match = eduMajor.match("ZL201610032112.4");
//        }
//        long endTime = System.currentTimeMillis();
//        System.out.println("cost time " + (endTime - beginTime) + "ms");
    }
}
