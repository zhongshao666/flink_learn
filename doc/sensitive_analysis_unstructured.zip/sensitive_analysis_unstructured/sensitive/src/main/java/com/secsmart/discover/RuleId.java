package com.secsmart.discover;

public class RuleId {
    /**
     * 省级行政区
     */
    public static final String CHINA_PROVINCE = "china_province";

    /**
     * 专利号
     */
    public static final String PATENT = "patent";

    /**
     * 民族
     */
    public static final String CHINA_NATION = "china_nation";

    /**
     * 健康状况
     */
    public static final String FITNESS = "fitness";

    /**
     * 军官证号
     */
    public static final String OFFICE_NUMBER = "office_number";

    /**
     * 港澳居民来往内地通行证
     */
    public static final String MTP_FOR_HKMACAO = "mtp_for_hkmacao";

    /**
     * 邮政编码
     */
    public static final String POSTCODE = "postcode";

    /**
     * 个人信息类-性别
     */
    public static final String GENDER = "gender";
    /**
     * 个人信息类-教育情况
     */
    public static final String EDUCATION_STATUS = "education_status";
    /**
     * 个人信息类-宗教信仰
     */
    public static final String RELIGIOUS_BELIEF = "religious_belief";
    /**
     * 个人证件类-身份证号
     */
    public static final String ID_NUMBER = "id_number";
    /**
     * 个人证件类-社保证号
     */
    public static final String SOCIAL_SECURITY_NUMBER = "social_security_number";
    /**
     * 个人证件类-港澳通行证
     */
    public static final String HK_MACAU_TRAVEL_PERMIT = "hk_macau_travel_permit";
    /**
     * 通讯信息类-固定电话
     */
    public static final String FIXED_TELEPHONE = "fixed_telephone";
    /**
     * 财产信息类-银行编码
     */
    public static final String BANK_CODE = "bank_code";
    /**
     * 财产信息类-房屋产权证
     */
    public static final String HOUSING_OWNERSHIP_CERTIFICATES = "housing_ownership_certificates";
    /**
     * 财产信息类-银联卡第二磁道
     */
    public static final String UNIONPAY_CARD_SECOND_TRACK = "unionpay_card_second_track";
    /**
     * 财产信息类-银联卡第三磁道
     */
    public static final String UNIONPAY_CARD_THIRD_TRACK = "unionpay_card_third_track";
    /**
     * 企业信息类-营业执照号码
     */
    public static final String BUSINESS_LICENSE_NUMBER = "business_license_number";
    /**
     * 其他信息类-县级行政区
     */
    public static final String COUNTY_ADMINISTRATIVE_DISTRICT = "county_administrative_district";
    /**
     * 其他信息类-统一社会信用代码
     */
    public static final String UNIFIED_SOCIAL_CREDIT_CODE = "unified_social_credit_code";
    /**
     * 其他信息类-地域区号
     */
    public static final String AREA_CODE = "area_code";
    /**
     * 其他信息类-IMEI国际移动电话设备识别码
     */
    public static final String IMEI_CODE = "imei";
    /**
     * 其他信息类-icd10疾病编码
     */
    public static final String ICD10_DISEASE_CODE = "icd10_disease_code";
    /**
     * 其他信息类-化学元素
     */
    public static final String CHEMICAL_ELEMENT = "chemical_element";
    /**
     * 其他信息类-VLAN虚拟局域网
     */
    public static final String VLAN_CODE = "vlan";
    /**
     * 不动产登记证明
     */
    public static final String REAL_ESTATE = "real_estate";
    /**
     * 组织机构代码
     */
    public static final String ORG_CODE = "org_code";
    /**
     * MEID 移动设备识别码
     */
    public static final String MEID_CODE = "meid_code";
    /**
     * 车辆识别代码(VIN)
     **/
    public static final String VIN_NUMBER = "vin_number";
    /**
     * 年龄数字
     */
    public static final String AGE_NUMBER_CODE = "age_number";
    /**
     * 银行卡号
     */
    public static final String BANK_ACCOUNT_CODE = "bank_account";
    /**
     * 个人信息类-婚姻状况
     */
    public static final String MARRIAGE_STATUS = "marriage_status";
    /**
     * 个人信息类-学位
     */
    public static final String DEGREE_CODE = "degree_code";
    /**
     * 个人证件类-护照
     */
    public static final String PASS_PORT_CODE = "pass_port_code";
    /**
     * 车牌号
     */
    public static final String BUS_NUMBER_CODE = "bus_number";
    /**
     * 个人证件类-驾驶证号
     */
    public static final String DRIVERS_LICENSE = "drivers_license";
    /**
     * 基站号
     */
    public static final String BASE_STATION_NUMBER = "base_station";
    /**
     * 上海证券账户号码
     */
    public static final String SH_SECURITY_NUMBER = "sh_sucurity_number";
    /**
     * 深圳证券账户号码
     */
    public static final String SZ_SECURITY_NUMBER = "sz_sucurity_number";
    /**
     * 手机号（只限于中国内地）
     */
    public static final String CELLPHONE_NUMBER = "cell_phone";
    /**
     * 邮箱
     */
    public static final String EMAIL_CODE = "email_code";
    /**
     * 财产信息类-银联卡第一磁道
     */
    public static final String UNIONPAY_CARD_FIRST_TRACK = "unionpay_card_frist_track";
    /**
     * 税务登记号
     */
    public static final String TAX_ID = "tax_id";
    /**
     * 地级行政区(城市)
     */
    public static final String CHINA_CITY = "china_city";
    /**
     * IP地址 (IPV4和IPV6)
     * IPV4
     */
    public static final String IP_CODE = "ip_code";
    /**
     * IPV6
     */
    public static final String IPV6_CODE = "ipv6_code";
    /**
     * 国际电话区号
     */
    public static final String INTERNATIONAL_TELEPHONE = "international_telephone";
    /**
     * 纳税人信用等级
     */
    public static final String TAXPAYER_CREDIT_RATING = "taxpayer_credit_rating";
    /**
     * 药品品牌
     */
    public static final String BRAND_DRUGS = "brand_drugs";
    /**
     * 教育专业
     */
    public static final String EDU_MAJOR = "edu_major";
    /**
     * 学历
     **/
    public static final String EDU_BACKGROUND = "edu_background";
    /**
     * 银行卡类型
     **/
    public static final String BANK_CARD = "bank_card";
    /**
     * 国家货币代码
     **/
    public static final String CURRENCY_CODE = "currency_code";
    /**
     * 颜色
     **/
    public static final String COLOR = "color";
    /**
     * 国际标准图书编号
     **/
    public static final String STANDARD_BOOK_NUMBER = "standard_book_number";
    /**
     * SIM卡的IMSI号（国际移动用户识别码）
     */
    public static final String IMSI_CODE = "imsi_code";
    /**
     * 小区id
     **/
    public static final String CELL_ID = "cell_id";
    /**
     * 国籍
     **/
    public static final String  NATIONALITY="nationality";
    /**
     * MAC
     **/
    public static final String  MAC="mac";

}
