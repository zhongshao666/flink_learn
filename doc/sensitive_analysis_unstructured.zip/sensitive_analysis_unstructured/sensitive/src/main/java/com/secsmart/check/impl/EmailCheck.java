package com.secsmart.check.impl;

import com.secsmart.check.Check;

import java.util.Arrays;
import java.util.HashSet;

import static com.secsmart.discover.EnumDictMap.dictMap;
import static com.secsmart.discover.RuleId.EMAIL_CODE;

/**
 * @author cjj
 * @Date 2021/12/09
 * @Description 邮箱
 */
public class EmailCheck implements Check {

    private static final HashSet<String> enumSet;
    private static final char[] specialSymbols ;

    static {
        enumSet= dictMap.get(EMAIL_CODE);
        specialSymbols = new char[]{'.','_','-'};
    }
    @Override
    public Boolean check(String data) {
        int oldSize = enumSet.size();
        char[] chars ;
        int j = 0;
        String string = null;
        for (int i = 0; i < data.length(); i++) {
            if (data.charAt(i) == '@') {
                char c = data.charAt(i - 1);
                for (char symbol : specialSymbols) {
                    if (c == symbol) {
                        return false;
                    }
                }
                for (int k = i+1; k < data.length(); k++) {
                    if (data.charAt(k) == '.'){
                        chars = new char[data.length() - k - 1];
                            for (int l = k+1 ; l < data.length(); l++) {
                                chars[j++] = data.charAt(l);
                            }
                            string= new String(chars);
                            break;
                    }
                }
                break;
            }
        }
        if (string != null && string.contains(".")) {
            String[] domains = string.split("\\.");
            enumSet.addAll(Arrays.asList(domains));
            int newSize = enumSet.size();
            return newSize == oldSize;
        }else {
            return enumSet.contains(string);
        }
    }
}
