package com.secsmart.discover;

import java.util.List;

public interface TextLacMatch {

    List<SensitiveRecord> match(String value);

}
