package com.secsmart.check.impl;

import com.secsmart.check.Check;

import java.util.ArrayList;

/**
 * @Author zzh
 * @Date 2021/12/13
 * @Description TODO 国际标准图书编号校验
 **/
public class StandardBookNumber implements Check {
    private static final int[] arr9 = {10, 9, 8, 7, 6, 5, 4, 3, 2};
    private static final int[] arr12 = {1, 3, 1, 3, 1, 3, 1, 3, 1, 3, 1, 3};

    @Override
    public Boolean check(String data) {
        int sum = 0;

        char[] chars = new char[13];
        int j = 0;
        for (int i = 0; i < data.length(); i++) {
            if (data.charAt(i) != '-') {
                chars[j++] = data.charAt(i);
            }
        }
        if (j == 10) {
            for (int i = 0; i < 9; i++) {
                sum += (chars[i] - 48) * arr9[i];
            }
            int r = 11 - sum % 11;
            if (r == 11) {
                return '0' == chars[9];
            }
            else if (r == 10) {
                return 'X' == chars[9];
            } else return r == (chars[9] - '0');
        } else {
            for (int i = 0; i < 12; i++) {
                sum += (chars[i] - 48) * arr12[i];
            }
            int r = 10 - sum % 10;
            if (r == 10) {
                return 'X' == chars[12];
            } else return r == (chars[12] - '0');
        }


//        data=data.replace("-", "");
//
//        String[] split = data.split("\\s*");
//        if (data.length() > 10) {
//            for (int i = 0; i < split.length-1; i++) {
//                sum += Integer.parseInt(split[i]) * arr12[i];
//            }
//            int s=10-sum%10;
//            if (s == 10) {
//                return "X".equals(split[12]);
//            }else return String.valueOf(s).equals(split[12]);
//        }else {
//            for (int i = 0; i < split.length-1; i++) {
//                sum += Integer.parseInt(split[i]) * arr9[i];
//            }
//            int r = sum % 11;
//            if (r == 0) {
//                return "0".equals(split[9]);
//            } else if (r == 1) {
//                return "X".equals(split[9]);
//            }
//            else return String.valueOf(11-r).equals(split[9]);
//        }
    }
}
