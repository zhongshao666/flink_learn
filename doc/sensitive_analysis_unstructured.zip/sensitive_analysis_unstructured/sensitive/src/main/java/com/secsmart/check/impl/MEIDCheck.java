package com.secsmart.check.impl;

import com.secsmart.check.Check;

/**
* @Author zzh
* @Date 2021/12/13
* @Description TODO MEID校验
**/
public class MEIDCheck implements Check {
    @Override
    public Boolean check(String data) {
        return String.valueOf(data.charAt(14)).equals(getMeid15(data));
//        return data.substring(14).equalsIgnoreCase(getMeid15(data.substring(0,14)));
    }

    /**
     * 根据MEID的前14位，得到第15位的校验位
     * MEID校验码算法：
     * (1).将偶数位数字分别乘以2，分别计算个位数和十位数之和，注意是16进制数
     * (2).将奇数位数字相加，再加上上一步算得的值
     * (3).如果得出的数个位是0则校验位为0，否则为10(这里的10是16进制)减去个位数
     * 如：AF 01 23 45 0A BC DE 偶数位乘以2得到F*2=1E 1*2=02 3*2=06 5*2=0A A*2=14 C*2=18 E*2=1C,
     * 	计算奇数位数字之和和偶数位个位十位之和，得到 A+(1+E)+0+2+2+6+4+A+0+(1+4)+B+(1+8)+D+(1+C)=64
     *  校验位 10-4 = C
     * @param meid
     * @return
     */
    private static String getMeid15(String meid) {
        if (meid.length() == 14) {
            String myStr[] = { "a", "b", "c", "d", "e", "f" };
            int sum = 0;
            for (int i = 0; i < meid.length(); i++) {
                String param = meid.substring(i, i + 1);
                for (int j = 0; j < myStr.length; j++) {
                    if (param.equalsIgnoreCase(myStr[j])) {
                        param = "1" + j;
                    }
                }
                if (i % 2 == 0) {
                    sum = sum + Integer.parseInt(param);
                } else {
                    sum = sum + 2 * Integer.parseInt(param) % 16;
                    sum = sum + 2 * Integer.parseInt(param) / 16;
                }
            }
            if (sum % 16 == 0) {
                return "0";
            } else {
                int result = 16 - sum % 16;
                if (result > 9) {
                    result += 65 - 10;
                    return String.valueOf((char)result);
                } else return result + "";

            }
        } else {
            return "";
        }
    }

}
