package com.secsmart;

import com.baidu.nlp.LAC;
import com.secsmart.discover.LacMatchImpl;

import java.util.concurrent.CountDownLatch;

public class LacTestMulti {
    public static void main(String[] args) throws InterruptedException {



        CountDownLatch countDownLatch = new CountDownLatch(10);
        long begin = System.currentTimeMillis();
        for (int i = 0; i < 10; i++) {
            new Thread(()->{
                LacMatchImpl lacMatch = new LacMatchImpl();
                for (int j = 0; j <Integer.parseInt(args[0]) ; j++) {
                    lacMatch.match("余杭区");
                }
                countDownLatch.countDown();
            }).start();
        }
        countDownLatch.await();
        long end = System.currentTimeMillis();
        System.out.println("cost time " + (end - begin) + "ms");
    }
}
