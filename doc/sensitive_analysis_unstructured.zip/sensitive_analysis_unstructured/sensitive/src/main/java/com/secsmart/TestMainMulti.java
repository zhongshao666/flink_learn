package com.secsmart;


import cn.hutool.core.collection.CollUtil;
import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.secsmart.discover.MultiRegexMatchImpl;


import java.io.File;
import java.util.*;

public class TestMainMulti {
    public static void main(String[] args) throws Exception {
        long beginTime = System.currentTimeMillis();
        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        long endTime = System.currentTimeMillis();
        System.out.println("load time " + (endTime - beginTime) + "ms");
        File file = new File(args[0]);
        ExcelReader reader = ExcelUtil.getReader(file);
        List<Map<String, Object>> readAll = reader.readAll();
        HashMap<String, String> map = new LinkedHashMap<>();
        readAll.forEach(x->{
            map.put(String.valueOf(x.get("data")),String.valueOf(x.get("type")));
        });
        List<List<String>> list = CollUtil.newArrayList();
        for (Map.Entry<String, String> entry : map.entrySet()) {
            String matchRes = multiRegexMatch.match(entry.getKey());
            List<String> dataRes = CollUtil.newArrayList(entry.getKey(), entry.getValue(), matchRes);
            list.add(dataRes);
        }
        endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");
        ExcelWriter writer = ExcelUtil.getWriter("result_"+args[0]);
        writer.write(list,true);
        writer.close();
    }
}
