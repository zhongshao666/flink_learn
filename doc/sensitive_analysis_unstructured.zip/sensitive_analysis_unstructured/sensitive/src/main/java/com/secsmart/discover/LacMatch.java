package com.secsmart.discover;

public interface LacMatch {
    String match(String value);
}

