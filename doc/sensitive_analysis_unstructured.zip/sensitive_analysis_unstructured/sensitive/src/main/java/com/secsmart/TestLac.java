package com.secsmart;

import com.secsmart.discover.MultiRegexMatchImpl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.ArrayList;

public class TestLac {
    public static void main(String[] args)throws Exception  {
        long beginTime = System.currentTimeMillis();
        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        long endTime = System.currentTimeMillis();
        System.out.println("load time " + (endTime - beginTime) + "ms");

        ArrayList<String> source = new ArrayList<>();
        ArrayList<String> result = new ArrayList<>();
        File file = new File(args[0]);
        BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
        while (bufferedReader.ready()) {
            source.add(bufferedReader.readLine());
        }
        bufferedReader.close();
        beginTime = System.currentTimeMillis();
        for (String s:
                source) {
            result.add(multiRegexMatch.matchLac(s));
        }

        endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");

        File fileRes = new File("result_" + args[0]);
        FileOutputStream fileOutputStream = new FileOutputStream(fileRes);
        for (String s:
                result) {
            fileOutputStream.write((s + "\n").getBytes());
        }
        fileOutputStream.flush();
        fileOutputStream.close();
        System.exit(0);
    }
}
