package com.secsmart.check.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.secsmart.check.Check;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

/**
 * @Author lcy
 * @Date 2021/12/8
 * @Description 个人证件类-身份证号 即为个人证件类-社保证号
 */
public class IDNumberCheck implements Check {
    //尾部校验码
    private final static char[] VERIFY_CODE = {'1', '0', 'X', '9', '8', '7',
            '6', '5', '4', '3', '2'};
    //校验码权重
    private final static int[] VERIFY_CODE_WEIGHT = {7, 9, 10, 5, 8, 4, 2, 1,
            6, 3, 7, 9, 10, 5, 8, 4, 2};

    private final static String BIRTH_DATE_FORMAT = "yyyyMMdd";
    private final static DateTimeFormatter formatter = DateTimeFormatter.ofPattern(BIRTH_DATE_FORMAT);

    //天数
    private final static String DAY_OF_MONTH = "{1:31, 3:31, 4:30, 5:31, 6:30, 7:31, 8:31, 9:30, 10:31, 11:30, 12:31}";
    private final static HashMap<Integer, Integer> dayMap = JSON.parseObject(DAY_OF_MONTH, new TypeReference<HashMap<Integer, Integer>>() {
    });

    private static int now = Integer.parseInt(LocalDate.now().format(formatter));
    private static int discardDate = 20060630;

    static {
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                now = Integer.parseInt(LocalDate.now().format(formatter));
            }
        }, 0, 24 * 60 * 1000);
    }


    @Override
    public Boolean check(String data) {
        String birthDay;
        if (data.length() == 15) {
            birthDay = data.substring(6, 12);
            return dateCheck("19" + birthDay, true) || dateCheck("20" + birthDay, true);
        } else {
            if (verifyCheck(data.toUpperCase())) {
                birthDay = data.substring(6, 14);
                return dateCheck(birthDay, false);
            }
            return false;
        }
    }

    public static boolean dateCheck(String birthday, Boolean history) {
        int year = Integer.parseInt(birthday.substring(0, 4));
        int month = Integer.parseInt(birthday.substring(4, 6));
        int day = Integer.parseInt(birthday.substring(6));
        int birthInt = Integer.parseInt(birthday);
        if ((!history && birthInt <= now) || (history && birthInt <= discardDate)) {
            if (month == 2) {
                boolean isLeapYear = (year % 400 == 0) || (year % 4 == 0 && year % 100 != 0);
                return day <= (isLeapYear ? 29 : 28);
            }
            return day <= dayMap.getOrDefault(month, -1);
        }
        return false;
    }

    /**
     * 校验码（第十八位数）：
     * <p>
     * 十七位数字本体码加权求和公式 S = Sum(Ai * Wi), i = 0...16 ，先对前17位数字的权求和；
     * Ai:表示第i位置上的身份证号码数字值 Wi:表示第i位置上的加权因子 Wi: 7 9 10 5 8 4 2 1 6 3 7 9 10 5 8 4
     * 2; 计算模 Y = mod(S, 11)< 通过模得到对应的校验码 Y: 0 1 2 3 4 5 6 7 8 9 10 校验码: 1 0 X 9
     * 8 7 6 5 4 3 2
     *
     * @param cardNumber
     * @return
     */
    private static boolean verifyCheck(CharSequence cardNumber) {
        int sum = 0;
        char ch;
        for (int i = 0; i < cardNumber.length() - 1; i++) {
            ch = cardNumber.charAt(i);
            sum += ((int) (ch - '0')) * VERIFY_CODE_WEIGHT[i];
        }
        return VERIFY_CODE[sum % 11] == cardNumber.charAt(cardNumber.length() - 1);
    }
}
