package com.secsmart.discover;

import com.hylanda.lightgrep.*;
import com.secsmart.check.Check;
import com.secsmart.check.impl.*;
import com.secsmart.utils.Util;
import org.ahocorasick.trie.Emit;
import org.ahocorasick.trie.Trie;
import org.ahocorasick.tuple.Tuple2;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.util.*;
import java.util.stream.Collectors;

import static com.secsmart.discover.RegexRead.regexList;
import static com.secsmart.discover.RuleId.*;

public class TextMultiRegexMatchImpl implements TextMultiRegexMatch {

    private final Trie trie;
    private final Matcher matcher;
    private TextLacMatch textLacMatch;
    private static final Map<String, Check> checkMap = new HashMap<>();
    private static final HashMap<String, Integer> sortMap = new HashMap<>();
    private boolean lac = false;
    /**
     * <枚举数据，枚举类型></枚举数据，枚举类型>
     **/
    private static final HashMap<String, String> enumDictDataMap = com.secsmart.discover.EnumDictMap.enumDataMap;
    private static final Map<Integer, String> ruleMap = com.secsmart.discover.RegexRead.ruleMap;
    private static final HashSet<String> ruleName ;

    static {
        checkMap.put(PATENT, new PatentCheck());
        checkMap.put(ORG_CODE, new OrgCodeCheck());
        checkMap.put(VIN_NUMBER, new VINCheck());
        checkMap.put(MEID_CODE, new MEIDCheck());
        checkMap.put(STANDARD_BOOK_NUMBER, new StandardBookNumber());
        checkMap.put(ID_NUMBER, new IDNumberCheck());
        checkMap.put(FIXED_TELEPHONE, new FixedTelephoneCheck());
        checkMap.put(BUSINESS_LICENSE_NUMBER, new BusinessLicenseNumberCheck());
        checkMap.put(UNIFIED_SOCIAL_CREDIT_CODE, new UnifiedSocialCreditCodeCheck());
        checkMap.put(IMEI_CODE, new IMEICheck());
        checkMap.put(EMAIL_CODE, new EmailCheck());
        checkMap.put(BANK_ACCOUNT_CODE, new BankAccountCheck());
        checkMap.put(DRIVERS_LICENSE, new DriversLicenseCheck());
        checkMap.put(TAX_ID, new TaxNumberCheck());
        checkMap.put(IPV6_CODE, new IPv6Check());

        sortMap.put("bank_card", 2);
        sortMap.put("brand_drugs", 3);
        sortMap.put("chemical_element", 4);
        sortMap.put("china_city", 5);
        sortMap.put("china_nation", 6);
        sortMap.put("china_province", 7);
        sortMap.put("county_administrative_district", 9);
        sortMap.put("currency_code", 10);
        sortMap.put("degree_code", 11);
        sortMap.put("education_status", 12);
        sortMap.put("edu_major", 13);
        sortMap.put("fitness", 14);
        sortMap.put("gender", 15);
        sortMap.put("icd10_disease_code", 16);
        sortMap.put("international_telephone", 17);
        sortMap.put("marriage_status", 18);
        sortMap.put("nationality", 19);
        sortMap.put("religious_belief", 20);
        sortMap.put("taxpayer_credit_rating", 21);
        sortMap.put("imsi_code", 22);
        sortMap.put("id_number", 23);
        sortMap.put("tax_id", 24);
        sortMap.put("unified_social_credit_code", 25);
        sortMap.put("business_license_number", 26);
        sortMap.put("bank_account", 27);
        sortMap.put("imei", 28);
        sortMap.put("meid_code", 29);
        sortMap.put("vin_number", 30);
        sortMap.put("org_code", 31);
        sortMap.put("standard_book_number", 32);
        sortMap.put("patent", 33);
        sortMap.put("sh_sucurity_number", 34);
        sortMap.put("sz_sucurity_number", 35);
        sortMap.put("pass_port_code", 36);
        sortMap.put("mtp_for_hkmacao", 37);
        sortMap.put("hk_macau_travel_permit", 38);
        sortMap.put("ipv6_code", 39);
        sortMap.put("mac", 40);
        sortMap.put("ip_code", 41);
        sortMap.put("fixed_telephone", 42);
        sortMap.put("cell_phone", 43);
        sortMap.put("email_code", 44);
        sortMap.put("office_number", 45);
        sortMap.put("bus_number", 46);
        sortMap.put("real_estate", 47);
        sortMap.put("housing_ownership_certificates", 48);
        sortMap.put("unionpay_card_frist_track", 49);
        sortMap.put("unionpay_card_second_track", 50);
        sortMap.put("unionpay_card_third_track", 51);
        sortMap.put("color", 52);
        sortMap.put("PER", 53);
        sortMap.put("LOC", 54);
        sortMap.put("ORG", 55);
        sortMap.put("PRO", 56);
        sortMap.put("BANK", 56);
        sortMap.put("TIME", 56);
        sortMap.put("SCH", 58);
        ruleName = new HashSet<>(Arrays.asList("pass_port_code","mtp_for_hkmacao","hk_macau_travel_permit","id_number","email_code","post_code","fixed_telephone","cell_phone",
                "unionpay_card_frist_track","unionpay_card_second_track","unionpay_card_third_track","bank_account","tax_id","org_code","business_license_number", "vin_number","ip_code",
                "ipv6_code","mac","imsi_code","unified_social_credit_code","imei","meid_code","sh_sucurity_number","sz_sucurity_number","standard_book_number", "patent","bus_number"));
    }


    public TextMultiRegexMatchImpl() {
        trie = new Trie(false);
        enumDictDataMap.forEach((k, v) -> {
            trie.addKeyword(new Tuple2<>(k, v));
        });

        MultiPattern patterns = new MultiPattern();
        for (String s : regexList) {
            patterns.addPattern(s, 0);
        }
        Automation automation = patterns.toAutomation();
        matcher = automation.createMatcher();

        initLac();
    }

    @Override
    public List<SensitiveRecord> match(String value) {
        if (value == null || StringUtils.isBlank(value)) {
            return null;
        }
        List<SensitiveRecord> listTrie = matchTrie(value);
        List<SensitiveRecord> listRegexp = matchRegexp(value);
        List<SensitiveRecord> listLac = matchLac(value);
        List<SensitiveRecord> filter = filter(listTrie, listRegexp, listLac, value);

        return filter;
    }


    @Override
    public List<SensitiveRecord> matchLac(String value) {
        if (lac)
            return textLacMatch.match(value);
        return new ArrayList<>();
    }

    @Override
    public List<SensitiveRecord> matchRegexp(String value) {
        //正则
        ArrayList<SensitiveRecord> sensitiveRecords = new ArrayList<>();
        matcher.match(new GrepString(value), item ->
                {
                    if (ruleName.contains(ruleMap.get(item.getId()))) {
                        if (ruleMap.get(item.getId()).equals("bus_number")) {
                            if (item.getEnd() != value.length()) {
                                char suffix = value.charAt(item.getEnd());
                                if (Util.isCnSymbolChar(suffix) || Util.isCnChar(suffix) || Util.isSpace(suffix))
                                    return;
                            }
                        }else
                        if (checkChar(value,item.getStart(),item.getEnd(),value.length()))
                            return;
                    }
                    if (Optional.ofNullable(getCheck(item.getId())).isPresent()) {
                        if (getCheck(item.getId()).check(value.subSequence(item.getStart(), item.getEnd()).toString())) {
                            sensitiveRecords.add(new SensitiveRecord(value.subSequence(item.getStart(), item.getEnd()).toString(), ruleMap.get(item.getId()), item.getStart(), item.getEnd(), true));
                        }
                    } else
                        sensitiveRecords.add(new SensitiveRecord(value.subSequence(item.getStart(), item.getEnd()).toString(), ruleMap.get(item.getId()), item.getStart(), item.getEnd(), true));

                }
        );

        return sensitiveRecords;
    }

    @Override
    public List<SensitiveRecord> matchTrie(String value) {
        Collection<Emit> emits = trie.parseText(value);
        ArrayList<SensitiveRecord> sensitiveRecords = new ArrayList<>();
        for (Emit emit : emits) {
            if (emit.getValue().equals("bank_code") || emit.getValue().equals("currency_code")) {
                if (checkChar(value,emit.getStart(),emit.getEnd()+1,value.length()))
                    break;
            }else if (emit.getValue().equals("fitness")) {
                if (fitCheck(value,emit.getStart()))
                    break;
            }
            sensitiveRecords.add(new SensitiveRecord(emit.getKeyword(), emit.getValue(), emit.getStart(), emit.getEnd(), true));
        }
        return sensitiveRecords;
    }


    private Check getCheck(int i) {
        return Optional.ofNullable(checkMap.get(ruleMap.get(i))).orElse(null);
    }

    public List<SensitiveRecord> filter(List<SensitiveRecord> listTrie, List<SensitiveRecord> listRegexp, List<SensitiveRecord> listLac, String value) {
        listTrie.addAll(listRegexp);
        listTrie.addAll(listLac);
        List<SensitiveRecord> listSensitive = listTrie.stream().sorted(Comparator.comparing(SensitiveRecord::getStart).thenComparing(SensitiveRecord::getEnd).thenComparing(new Comparator<SensitiveRecord>() {
            @Override
            public int compare(SensitiveRecord o1, SensitiveRecord o2) {
                return sortMap.get(o1.getRule()).compareTo(sortMap.get(o2.getRule()));
            }
        })).collect(Collectors.toList());

        for (int i = 0; i < listSensitive.size(); i++) {
            if (!listSensitive.get(i).isAttr())
                continue;
            for (int j = i + 1; j < listSensitive.size(); j++) {
                if (listSensitive.get(j).getStart() >= listSensitive.get(i).getEnd())
                    break;
                if (listSensitive.get(j).isAttr()) {
                    if (listSensitive.get(i).getStart() == listSensitive.get(j).getStart()) {
                        listSensitive.get(i).setAttr(false);
                        break;
                    } else if (listSensitive.get(i).getEnd() < listSensitive.get(j).getEnd()) {
                        String substring = value.substring(listSensitive.get(j).getStart(), listSensitive.get(i).getEnd());
                        if (checkChinese(substring))
                            listSensitive.get(j).setAttr(false);
                        else {
                            listSensitive.get(i).setAttr(false);
                            listSensitive.get(j).setAttr(false);
                            break;
                        }
                    } else if (listSensitive.get(i).getEnd() >= listSensitive.get(j).getEnd())
                        listSensitive.get(j).setAttr(false);
                }
            }
        }

        return listSensitive;
    }

    public boolean checkChinese(String s) {
        int n;
        for (int i = 0; i < s.length(); i++) {
            n = s.charAt(i);
            if (!(19968 <= n && n <= 40869)) {
                return false;
            }
        }
        return true;
    }

    /**
     *前后字符校验
     * @param value 字符串
     * @param start 起始下标
     * @param end 结束下标
     * @param length 字符串长度
     * @return
     */
    public boolean checkChar (String value ,int start,int end,int length ) {
        if (end != value.length() && start != 0) {
            char suffix = value.charAt(end);
            char prefix = value.charAt(start - 1);
            return Util.isEnOrNum(prefix) || Util.isEnOrNum(suffix);
        }else {
            if (start != 0) {
                char prefix = value.charAt(start - 1);
                return Util.isEnOrNum(prefix);
            }else {
                if (end != length) {
                    char suffix = value.charAt(end);
                    return Util.isEnOrNum(suffix);
                }
            }
        }
        return false;
    }

    /***
     * 健康状况校验
     * @param value
     * @param start
     * @return
     */
    public boolean fitCheck(String value, int start ) {
        if (value.length() > 16 && start > 10) {
            String sub = value.substring(start - 10, start);
            return !sub.contains("身体");
        }else {
            String sub = value.substring(0, start);
            return !sub.contains("身体");
        }
    }

    /**
     * 初始化lac
     */
    private void initLac() {
        String paddleRoot = System.getenv("PADDLE_ROOT");
        if (Objects.nonNull(paddleRoot)) {
            File file = new File(paddleRoot);
            if (file.exists()) {
                this.textLacMatch = new TextLacMatchImpl();
                lac = true;
            } else {
                System.out.println("LAC paddle root not exists, not load lac !");
            }
        } else {
            System.out.println("LAC env not ready, not load lac !");
        }
    }
}
