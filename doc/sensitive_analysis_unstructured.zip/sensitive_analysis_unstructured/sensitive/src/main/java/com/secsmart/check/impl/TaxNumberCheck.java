package com.secsmart.check.impl;


import com.secsmart.check.Check;
import com.secsmart.utils.IdCardUtil;
import com.secsmart.utils.OrgCodeUtil;
import org.apache.commons.lang3.StringUtils;

/**
 * @Author cjj
 * @Date 2021/12/13
 * @Description 税务登记号
 * 按组织机构代码注册/按身份证号注册
 * 共15位前6位行政区划分码   后九位组织机构代码
 * 共20位 18位身份证号 2位数字（注册次数） 15位身份证 后面是00000 （注册次数）依次累加
 */
public class TaxNumberCheck implements Check {
    @Override
    public Boolean check(String data) {
        return verify(data);
    }

    private static boolean verify(String data) {
        if (data.length() == 16 || data.length() == 15) {
            if (StringUtils.isNumeric(data.substring(0, 6))) {
                //后9位  是否包含'-'?
                return OrgCodeUtil.isOrganizationCertificate(data.substring(6));
            }
        }
        if (data.length() == 20){
            if (IdCardUtil.dateCheck(data.substring(6,14))) {
                return IdCardUtil.IDCardCheck(data.substring(0, 18));
            }else {
                if (StringUtils.isNumeric(data.substring(15))) {
                    return IdCardUtil.IDCardCheck(data.substring(0, 15));
                }
            }
        }
        return false;
    }
}



