package com.secsmart.discover;

public interface MultiRegexMatch {
    /**
     * 正则&枚举&lac算法
     * @param value
     * @return
     */
    String match(String value);

    /**
     * 正则&枚举&lac算法
     * @param value
     * @return
     */
    String matchLac(String value);

    /**
     * 正则&枚举
     * @param value
     * @return
     */
    String matchRegexp(String value);
}
