package com.secsmart.check.impl;

import com.secsmart.check.Check;
import com.secsmart.utils.IdCardUtil;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashSet;
import java.util.regex.Pattern;

/**
 * @Author cjj
 * @Date 2021/12/10
 * @Description 驾驶证号
 */
public class DriversLicenseCheck implements Check {

    private static final String DATE_TIME_FORMATTER = "yyyyMMdd";
    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMATTER);
    //权重
    private static final String[] weight ;
    //校验码
    private static final String[] checkCode;
    private static final HashSet<String> yearPrefix;
    private static int now ;

    static {
        now = Integer.parseInt(LocalDate.now().format(dateTimeFormatter));
        yearPrefix = new HashSet<>(Arrays.asList("00", "01", "02", "03", "04", "05", "06"));

        weight = new String[]{"7", "9", "10", "5", "8", "4", "2", "1", "6", "3", "7",
                "9", "10", "5", "8", "4", "2"};
        checkCode = new String[]{"1", "0", "X", "9", "8", "7", "6", "5", "4",
                "3", "2"};

    }
    @Override
    public Boolean check(String data) {
        if (data.length() == 15 || data.length() == 18 ) {
            return IDCardCheck(data);
            }
        return false;
    }
    public static boolean IDCardCheck(String data){
        String birthday = "";
            if (data.length() ==15) {
                if (yearPrefix.contains(data.substring(6,8))) {
                    birthday = "20" + data.substring(6, 12);
                }else {
                    birthday = "19" + data.substring(6, 12);
                }
                return dateCheck(birthday);
            }else {
                birthday = data.substring(6,14);
                if (dateCheck(birthday)) {
                    return tailCheck(data);
                }
                return tailCheck(data);
            }
    }

    /**
     * 日期合法性
     * @param birthday 出生日期
     * @return
     */
    public static boolean dateCheck(String birthday) {
        boolean isRn;
        boolean isLess;
        int year = Integer.parseInt(birthday.substring(0, 4));
        int month = Integer.parseInt(birthday.substring(4, 6));
        int day = Integer.parseInt(birthday.substring(6));
        isLess = Integer.parseInt(birthday) <= now;
        if (isLess) {
            isRn = (year % 400 == 0) || (year % 4 == 0 && year % 100 != 0);
            if (month == 1 || month == 3 ||month == 5 ||month == 7 ||month == 8 ||month == 10 || month == 12) {
                return day <= 31;
            } else if (month == 2) {
                if (isRn) {
                    return day <= 29;
                }else {
                    return day <= 28;
                }
            }else if (month == 4 || month == 6 ||month == 9 ||month == 11 ) {
                return day <= 30;
            }
        }
        return false;
    }

    /**
     * 校验码
     * @param data 身份证号
     * @return
     */
    private static boolean tailCheck(String data){

        String ai = data.substring(0, 17);
        int checkSum = 0;
        for (int i = 0; i < 17; i++) {
            checkSum = checkSum
                    + Integer.parseInt(String.valueOf(ai.charAt(i)))
                    * Integer.parseInt(weight[i]);
        }
        int modValue = checkSum % 11;
        String strVerifyCode = checkCode[modValue];
        return strVerifyCode.toUpperCase().equals(data.substring(17));

    }
}
