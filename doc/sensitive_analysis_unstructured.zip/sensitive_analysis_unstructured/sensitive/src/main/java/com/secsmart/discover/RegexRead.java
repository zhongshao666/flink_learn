package com.secsmart.discover;

import org.apache.commons.lang3.StringUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;

/**
 * @Auther zzh
 * TODO 获取正则列表
 */
public class RegexRead {
    /**
     * 正则列表
     */
    public static final List<String> regexList = new ArrayList<>();
    /**
     *  <正则id,正则名称></>
     */
    public static final Map<Integer, String> ruleMap = new HashMap<>();

    static {
        try (InputStream in = RegexRead.class.getResourceAsStream("/regex_dict");
             BufferedReader br=new BufferedReader(new InputStreamReader(in))
        ){
            int i = 0;
            while (br.ready()) {
                String s = br.readLine();
                //只分割成两项
                String[] split = StringUtils.split(s, "=", 2);
                regexList.add(split[1]);
                ruleMap.put(i++,split[0]);
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("读取正则列表失败");
        }
    }

}
