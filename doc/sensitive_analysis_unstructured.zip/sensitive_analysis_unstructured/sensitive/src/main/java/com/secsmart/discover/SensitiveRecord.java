package com.secsmart.discover;

/**
* @Author zzh
* @Date 2022/1/20
* @Description TODO 敏感字段记录
**/
public class SensitiveRecord {
    /**
     * 字段记录
     **/
    private String record;
    /**
    * 标签
    **/
    private String rule;
    /**
     * 开始偏移量
     **/
    private int start;
    /**
     * 结束偏移量
     **/
    private int end;
    /**
    * 是否保留
    **/
    private boolean attr;

    public SensitiveRecord() {
    }

    public SensitiveRecord(String record, String rule, int start, int end, boolean attr) {
        this.record = record;
        this.rule = rule;
        this.start = start;
        this.end = end;
        this.attr = attr;
    }

    public String getRecord() {
        return record;
    }

    public void setRecord(String record) {
        this.record = record;
    }

    public String getRule() {
        return rule;
    }

    public void setRule(String rule) {
        this.rule = rule;
    }

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public int getEnd() {
        return end;
    }

    public void setEnd(int end) {
        this.end = end;
    }

    public boolean isAttr() {
        return attr;
    }

    public void setAttr(boolean attr) {
        this.attr = attr;
    }

    @Override
    public String toString() {
        return "SensitiveRecord{" +
                "record='" + record + '\'' +
                ", rule='" + rule + '\'' +
                ", start=" + start +
                ", end=" + end +
                ", attr=" + attr +
                '}';
    }
}
