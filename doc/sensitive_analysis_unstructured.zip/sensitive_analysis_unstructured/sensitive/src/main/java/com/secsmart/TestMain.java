package com.secsmart;

import com.secsmart.discover.MultiRegexMatchImpl;

import java.io.*;
import java.util.ArrayList;

public class TestMain {
    public static void main(String[] args) throws Exception {
        long beginTime = System.currentTimeMillis();
        MultiRegexMatchImpl multiRegexMatch = new MultiRegexMatchImpl();
        long endTime = System.currentTimeMillis();
        System.out.println("load time " + (endTime - beginTime) + "ms");

        ArrayList<String> source = new ArrayList<>();
        ArrayList<String> result = new ArrayList<>();
        File file = new File(args[0]);
        BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
        while (bufferedReader.ready()) {
            source.add(bufferedReader.readLine());
        }
        bufferedReader.close();
        ArrayList<String> arr100 = new ArrayList<>();
        for (int i = 0; i < 1000; i++) {
            arr100.addAll(source);
        }
        beginTime = System.currentTimeMillis();
        for (String s:
                arr100) {
            result.add(multiRegexMatch.match(s));
        }

        endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");

        File fileRes = new File("result_" + args[0]);
        FileOutputStream fileOutputStream = new FileOutputStream(fileRes);
        for (String s:
             result) {
            fileOutputStream.write((s + "\n").getBytes());
        }
        fileOutputStream.flush();
        fileOutputStream.close();
    }
}
