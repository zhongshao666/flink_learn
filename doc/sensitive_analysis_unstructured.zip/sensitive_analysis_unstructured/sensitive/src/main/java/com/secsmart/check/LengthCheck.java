package com.secsmart.check;

import com.secsmart.check.Check;

public class LengthCheck {

    public String check(String rule, String data) {
        switch (rule) {
            case "pass_port_code" :{
                if (data.length() == 8 || data.length() == 9) {
                    return rule;
                } else return null;
            }
            case "mtp_for_hkmacao": {
                if (data.length() == 11)
                    return rule;
                else return null;
            }
            case "hk_macau_travel_permit" : {
                if (data.length() == 9) {
                    return rule;
                } else return null;
            }
            case "mac" : {
                if (data.length() == 17) {
                    return rule;
                } else return null;
            }
            case "ip_code" : {//待优化
                if (data.length() < 16) {
                    return rule;
                } else return null;
            }
//            case "fixed_telephone" :{//待优化
//                return rule;
//            }
            case "cell_phone" :{
                if (data.length() < 15) {
                    return rule;
                } else return null;
            }
            case "post_code":{
                if (data.length() == 6) {
                    return rule;
                } else return null;
            }
            case "office_number":{
                if (data.length() < 13) {
                    return rule;
                } else return null;
            }
            case "bus_number":{
                if (data.length() == 7 || data.length() == 8) {
                    return rule;
                } else return null;
            }
//            case "real_estate" :{
//                return rule;
//            }
//            case "housing_ownership_certificates" :{
//                return rule;
//            }
            case "unionpay_card_frist_track":{
                if (data.length() < 79) {
                    return rule;
                } else return null;
            }
            case "unionpay_card_second_track":{
                if (data.length() < 40) {
                    return rule;
                } else return null;
            }
            case "unionpay_card_third_track":{
                if (data.length() < 107) {
                    return rule;
                } else return null;
            }
        }
        return rule;
    }

}
