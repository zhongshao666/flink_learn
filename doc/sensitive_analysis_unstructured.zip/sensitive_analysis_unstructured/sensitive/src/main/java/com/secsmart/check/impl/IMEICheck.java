package com.secsmart.check.impl;

import com.secsmart.check.Check;

/**
 * @Author lcy
 * @Date 2021/12/9
 * @Description 其他信息类-IMEI国际移动电话设备识别码
 */
public class IMEICheck implements Check {

    @Override
    public Boolean check(String data) {
        //校验码验证
        int sum = 0;
        data = data.length() > 15 ? data.substring(0, 15) : data;
        for (int i = 0; i < data.length() - 1; i++) {
            int odd = data.charAt(i) - '0';
            i++;
            int even = (data.charAt(i) - '0') * 2;
            int even_digit = even < 10 ? even : even - 9;
            sum += odd + even_digit;
        }
        sum %= 10;
        sum = sum == 0 ? 0 : 10 - sum;
        int verify = data.charAt(data.length() - 1) - '0';
        return sum == verify;
    }
}
