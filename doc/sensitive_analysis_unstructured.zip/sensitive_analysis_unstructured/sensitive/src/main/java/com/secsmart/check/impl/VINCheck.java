package com.secsmart.check.impl;

import com.secsmart.check.Check;

import java.util.HashMap;
import java.util.Map;

/**
 * @Author zzh
 * @Date 2021/12/13
 * @Description TODO 车辆识别代码(VIN)校验
 **/
public class VINCheck implements Check {
    /**
     * 字符权重表
     */
    private static final Map<Character, Integer> CHAR_WEIGHTS = new HashMap<>();
    /**
     * 位置权重表
     */
    private static final int[] POS_WEIGHTS = {8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2};

    static {
        for (int i = 0; i < 10; i++) {
            CHAR_WEIGHTS.put(String.valueOf(i).charAt(0), i);
        }
        CHAR_WEIGHTS.put('A', 1);
        CHAR_WEIGHTS.put('B', 2);
        CHAR_WEIGHTS.put('C', 3);
        CHAR_WEIGHTS.put('D', 4);
        CHAR_WEIGHTS.put('E', 5);
        CHAR_WEIGHTS.put('F', 6);
        CHAR_WEIGHTS.put('G', 7);
        CHAR_WEIGHTS.put('H', 8);
        CHAR_WEIGHTS.put('J', 1);
        CHAR_WEIGHTS.put('K', 2);
        CHAR_WEIGHTS.put('L', 3);
        CHAR_WEIGHTS.put('M', 4);
        CHAR_WEIGHTS.put('N', 5);
        CHAR_WEIGHTS.put('P', 7);
        CHAR_WEIGHTS.put('R', 9);
        CHAR_WEIGHTS.put('S', 2);
        CHAR_WEIGHTS.put('T', 3);
        CHAR_WEIGHTS.put('U', 4);
        CHAR_WEIGHTS.put('V', 5);
        CHAR_WEIGHTS.put('W', 6);
        CHAR_WEIGHTS.put('X', 7);
        CHAR_WEIGHTS.put('Y', 8);
        CHAR_WEIGHTS.put('Z', 9);

        CHAR_WEIGHTS.put('a', 1);
        CHAR_WEIGHTS.put('b', 2);
        CHAR_WEIGHTS.put('c', 3);
        CHAR_WEIGHTS.put('d', 4);
        CHAR_WEIGHTS.put('e', 5);
        CHAR_WEIGHTS.put('f', 6);
        CHAR_WEIGHTS.put('g', 7);
        CHAR_WEIGHTS.put('h', 8);
        CHAR_WEIGHTS.put('j', 1);
        CHAR_WEIGHTS.put('k', 2);
        CHAR_WEIGHTS.put('l', 3);
        CHAR_WEIGHTS.put('m', 4);
        CHAR_WEIGHTS.put('n', 5);
        CHAR_WEIGHTS.put('p', 7);
        CHAR_WEIGHTS.put('r', 9);
        CHAR_WEIGHTS.put('s', 2);
        CHAR_WEIGHTS.put('t', 3);
        CHAR_WEIGHTS.put('u', 4);
        CHAR_WEIGHTS.put('v', 5);
        CHAR_WEIGHTS.put('w', 6);
        CHAR_WEIGHTS.put('x', 7);
        CHAR_WEIGHTS.put('y', 8);
        CHAR_WEIGHTS.put('z', 9);
    }

    @Override
    public Boolean check(String data) {

        data = data.toUpperCase();
        int sum = 0;
        int checkSum = 0;
        for (int i = 0; i < data.length(); i++) {
            char code = data.charAt(i);
            Integer cw = CHAR_WEIGHTS.get(code);
            if (cw == null) {
                return false;
            }
            int pw = POS_WEIGHTS[i];
            sum += cw * pw;
            if (i == 8) {
                // 获取校验位的值
                if (code == 'X') {
                    checkSum = 10;
                } else if (code >= '0' && code <= '9') {
                    checkSum = code-48;
                } else {
                    return false;
                }
            }
        }
        return checkSum == sum % 11;


    }

}
