package com.secsmart.discover;

import java.io.*;
import java.net.URL;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * @Auther zzh
 * TODO 获取枚举字典
 */
public class EnumDictInit {
    /**
     * 枚举名称列表
     */
    public  final ArrayList<String> dictListInit = new ArrayList<>();

    /**
     * <枚举名称,枚举集合></>
     */
    public  final HashMap<String, HashSet<String>> dictMapInit=new HashMap<>();


    public void init() {
        try {
            //读取fileList
            URL location = getClass().getProtectionDomain().getCodeSource().getLocation();
            //jar包环境下
            if (location.toString().endsWith(".jar")) {
                ZipInputStream zin = new ZipInputStream(location.openStream());
                ZipEntry ze;
                while ((ze = zin.getNextEntry()) != null) {
                    if (ze.getName().startsWith("enum_dict")) {
                        dictListInit.add(ze.getName());
                    }
                }
            } else {
                //本地测试环境下
                String path = location.getPath() + "enum_dict";
                File[] files = new File(path).listFiles();
                Arrays.asList(Objects.requireNonNull(files)).forEach(file -> dictListInit.add(file.getName()));
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("枚举文件列表读取错误");
        }

        //初始化字典
        dictListInit.forEach(fileName->{
            try (InputStream in = getClass().getResourceAsStream("/enum_dict/" + fileName);
                 BufferedReader br=new BufferedReader(new InputStreamReader(in))
            ) {
                HashSet<String> values = new HashSet<>();
                while (br.ready()) {
                    values.add(br.readLine());
                }
                dictMapInit.put(fileName, values);
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("字典读取失败");
            }
        });

    }



}
