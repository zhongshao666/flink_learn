package com.secsmart.check.impl;

import com.secsmart.check.Check;
import org.apache.commons.lang3.StringUtils;
import sun.net.util.IPAddressUtil;

/**
 * @Author lcy
 * @Date 2021/12/23
 * @Description 其他信息类-IPv6地址
 * 1.  IPV6格式,以16位为一组,每组以冒号隔开,可以分为8组,每组以4位16进制方式表示
 * 2.  每项数字前导的0可以省略,至少保留一个0
 * 3.  可以用双冒号::表示一组0或多组连续的0,但只能出现一次
 * 4.  ipv6地址后可能包含/nn  nn位子网掩码前缀(数字)最多三位 范围（0~128）
 * 5.  ipv6可能包在[]内
 * 6.  ipv4映射的ipv6地址ipv4占后两组 13::3096:7161:9021:192.168.14.5
 * 7.  ipv6地址中最后可能包含%后面会带Zone ID/Scope ID
 * 8.  windows系统中%后面为纯数字区分网卡 最长24位
 * 9. linux地址中最后可能包含%后面为网络接口名(网卡名)包含数字，字母，_  最长13位
 * 10. ipv6地址中最后可能包含%后面会带（Zone ID/Scope ID）/子网掩码
 */
public class IPv6Check implements Check {

    @Override
    public Boolean check(String data) {
        //[]判别
        if (data.charAt(0) == '[') {
            if (data.charAt(data.length() - 1) == ']') {
                data = data.substring(1, data.length() - 1);
            } else {
                return false;
            }
        }
        //地址前缀判别
        if (data.contains("/")) {
            int index = data.indexOf('/');
            if (data.length() - 1 != index) {
                int value = Integer.parseInt(data.substring(index + 1));
                if (value < 0 || value > 128) {
                    return false;
                }
            }
            data = data.substring(0, index);
        }
        //剔除ZoneID检查
        data = data.contains("%") ? data.substring(0, data.indexOf('%')) : data;
        //兼容IPv4映射IPv6
        data = (data = data.toLowerCase()).contains("ffff") ? StringUtils.replace(data, "ffff", "0000") : data;
        //长度检查
        String[] split = data.split(":+");
        for (int i = 0; i <= split.length - 1; i++) {
            if (!split[i].contains(".") && split[i].length() > 4) {
                return false;
            }
        }
        //IPv6检查
        if (Character.digit(data.charAt(0), 16) != -1
                || (data.charAt(0) == ':')) {
            return IPAddressUtil.textToNumericFormatV6(data) != null;
        }
        return false;
    }
}

