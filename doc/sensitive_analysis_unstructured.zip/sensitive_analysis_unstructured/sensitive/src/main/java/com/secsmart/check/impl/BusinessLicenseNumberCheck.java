package com.secsmart.check.impl;

import com.secsmart.check.Check;

/**
 * @Author lcy
 * @Date 2021/12/9
 * @Description 企业信息类-营业执照号码
 */
public class BusinessLicenseNumberCheck implements Check {

    @Override
    public Boolean check(String data) {
        //递归式求校验码
        int checkNum = 10;
        for (int i = 0; i < 15; i++) {
            char ch = data.charAt(i);
            int modValue = (checkNum % 11 + (int) (ch - '0')) % 10;
            modValue = (modValue == 0) ? 10 : modValue;
            checkNum = modValue * 2;
        }
        return checkNum / 2 == 1;
    }
}
