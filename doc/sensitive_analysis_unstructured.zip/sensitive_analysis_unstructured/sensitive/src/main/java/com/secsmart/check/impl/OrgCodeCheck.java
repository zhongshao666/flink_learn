package com.secsmart.check.impl;

import com.secsmart.check.Check;

/**
 * @Author zzh
 * @Date 2021/12/13
 * @Description TODO 组织机构代码校验
 **/
public class OrgCodeCheck implements Check {
    /**
     * 加权因子
     */
    private static final int[] power = {3, 7, 9, 10, 5, 8, 4, 2};

    @Override
    public Boolean check(String data) {
        char[] chars = new char[8];
        for (int i = 0; i < 8; i++) {
            chars[i] = data.charAt(i);
        }
        char check=data.charAt(8);
        if (data.length() == 10)
            check = data.charAt(9);
        return isCode(String.valueOf(check),sum(chars));
    }



    /**
     * 求和
     */
    private static int sum(char[] bit) {
        int sum = 0;
        for (int i = 0; i < bit.length; i++) {
            int intTemp = bit[i] > '9' ? (bit[i] - 'A' + 10) : bit[i]-'0';
            sum += intTemp * power[i];
        }
        return sum;
    }

    /**
     * 判断机构代码的校验码和计算出的校验码是否一致
     */
    private static boolean isCode(String a, int b) {
        String codeTEmp = (11 - b % 11) == 10 ? "X" : (11 - b % 11) == 11 ? 0 + "" : (11 - b % 11) + "";
        return a.equals(codeTEmp);
    }
}
