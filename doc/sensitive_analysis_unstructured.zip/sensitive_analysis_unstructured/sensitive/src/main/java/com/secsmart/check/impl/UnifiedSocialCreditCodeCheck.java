package com.secsmart.check.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.secsmart.check.Check;

import java.util.HashMap;

/**
 * @Author lcy
 * @Date 2021/12/9
 * @Description 其他信息类-统一社会信用代码
 */
public class UnifiedSocialCreditCodeCheck implements Check {
    //校验码
    private final static char[] VERIFY_CODE = {'1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'Q',
            'R', 'T', 'U', 'W', 'X', 'Y', '0'};
    //原码值
    private final static String ORIGINAL_CODE = "{'0':0,'1':1,'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9, 'A':10,'B':11,'C':12, 'D':13, 'E':14, 'F':15, 'G':16," +
            "'H':17, 'J':18, 'K':19, 'L':20, 'M':21, 'N':22, 'P':23, 'Q':24,'R':25, 'T':26, 'U':27, 'W':28, 'X':29, 'Y':30}";
    private final static HashMap<Character, Integer> originalMap = JSON.parseObject(ORIGINAL_CODE, new TypeReference<HashMap<Character, Integer>>() {
    });
    //对应位数权重
    private final static int[] VALUE_WEIGHT = {1, 3, 9, 27, 19, 26, 16, 17, 20, 29, 25, 13, 8, 24, 10, 30, 28};

    //组织机构
    private final static char[] ORG_VERIFY_CODE = {'1', '2', '3', '4', '5', '6', '7', '8', '9', 'X', '0'};
    private final static String ORG_CODE = "{'0':0,'1':1,'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9, 'A':10,'B':11,'C':12, 'D':13, 'E':14, 'F':15, 'G':16," +
            "'H':17, 'J':19, 'K':20, 'L':21, 'M':22, 'N':23, 'P':25, 'Q':26,'R':27, 'T':29, 'U':30, 'W':32, 'X':33, 'Y':34}";
    private final static HashMap<Character, Integer> orgMap = JSON.parseObject(ORG_CODE, new TypeReference<HashMap<Character, Integer>>() {
    });
    private static final int[] ORG_WEIGHT = {3, 7, 9, 10, 5, 8, 4, 2};

    @Override
    public Boolean check(String data) {
        int sum = 0;
        //组织机构代码校验
        if (verify(data)) {
            String org = data.substring(8, 17);
            for (int i = 0; i < org.length() - 1; i++) {
                sum += orgMap.get(org.charAt(i)) * ORG_WEIGHT[i];
            }
            return ORG_VERIFY_CODE[11 - sum % 11 - 1] == org.charAt(org.length() - 1);
        }
        return false;
    }

    //校验码验证
    private Boolean verify(String data) {
        int sum = 0;
        for (int i = 0; i < data.length() - 1; i++) {
            sum += originalMap.get(data.charAt(i)) * VALUE_WEIGHT[i];
        }
        return VERIFY_CODE[31 - sum % 31 - 1] == data.charAt(data.length() - 1);
    }
}
