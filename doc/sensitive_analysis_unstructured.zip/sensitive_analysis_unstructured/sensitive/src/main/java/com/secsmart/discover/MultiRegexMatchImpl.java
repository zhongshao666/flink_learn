package com.secsmart.discover;


import com.fulmicoton.multiregexp.MultiPatternMatcher;
import com.secsmart.check.Check;
import com.secsmart.check.LengthCheck;
import com.secsmart.check.impl.*;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.util.*;


import static com.secsmart.discover.RegexRead.regexList;
import static com.secsmart.discover.RuleId.*;


public class MultiRegexMatchImpl implements MultiRegexMatch {

    private LacMatch lacMatch;
    private static final Map<String, Check> checkMap = new HashMap<>();
    private static final LengthCheck lengthCheck = new LengthCheck();
    /**
     * <枚举数据，枚举类型></枚举数据，枚举类型>
     **/
    private static final HashMap<String, String> enumDictDataMap=com.secsmart.discover.EnumDictMap.enumDataMap;
    private static final Map<Integer, String> ruleMap = com.secsmart.discover.RegexRead.ruleMap;

    static {
        checkMap.put(PATENT, new PatentCheck());
        checkMap.put(ORG_CODE, new OrgCodeCheck());
        checkMap.put(VIN_NUMBER, new VINCheck());
        checkMap.put(MEID_CODE, new MEIDCheck());
        checkMap.put(STANDARD_BOOK_NUMBER, new StandardBookNumber());
        checkMap.put(ID_NUMBER, new IDNumberCheck());
        checkMap.put(FIXED_TELEPHONE, new FixedTelephoneCheck());
        checkMap.put(BUSINESS_LICENSE_NUMBER, new BusinessLicenseNumberCheck());
        checkMap.put(UNIFIED_SOCIAL_CREDIT_CODE, new UnifiedSocialCreditCodeCheck());
        checkMap.put(IMEI_CODE, new IMEICheck());
        checkMap.put(EMAIL_CODE, new EmailCheck());
        checkMap.put(BANK_ACCOUNT_CODE, new BankAccountCheck());
        checkMap.put(DRIVERS_LICENSE, new DriversLicenseCheck());
        checkMap.put(TAX_ID, new TaxNumberCheck());
        checkMap.put(IPV6_CODE, new IPv6Check());
    }

    //    private final Matcher matcher;
    private final MultiPatternMatcher multiPatternMatcher;

    public MultiRegexMatchImpl() {
        List<String> simplifiedPatterns = new ArrayList<>();
        //不能使用lambda,会乱序
        for (String pattern : regexList) {
            //简化正则
            if (Optional.ofNullable(pattern).isPresent() && !pattern.equals("")) {
                String simplifiedPattern = pattern.replaceAll("\\?:", "");
                simplifiedPatterns.add(simplifiedPattern);
            }
        }
        multiPatternMatcher = com.fulmicoton.multiregexp.MultiPattern.of(
                simplifiedPatterns
        ).matcher();
        initLac();
    }

    @Override
    public String match(String value) {
        String res;
        if (Optional.ofNullable(res=matchRegexp(value)).isPresent()) {
            return res;
        }
        return lacMatch.match(value);
    }


    @Override
    public String matchLac(String value) {
        return lacMatch.match(value);
    }

    @Override
    public String matchRegexp(String value) {
        if (value == null || StringUtils.isBlank(value)) {
            return null;
        }
        //枚举
        if (enumDictDataMap.containsKey(value)) {
            return enumDictDataMap.get(value);
        }

        //正则
        int[] match = multiPatternMatcher.match(value);
        for (int i : match) {
            if (Optional.ofNullable(getCheck(i)).isPresent()) {
                if (getCheck(i).check(value)) {
                    return ruleMap.get(i);
                }
            } else {
                return lengthCheck.check(ruleMap.get(i),value);
            }
        }
        return null;
    }

    private Check getCheck(int i) {
        return Optional.ofNullable(checkMap.get(ruleMap.get(i))).orElse(null);
    }

    /**
     * 初始化lac
     */
    private void initLac() {
        String paddleRoot = System.getenv("PADDLE_ROOT");
        if (Objects.nonNull(paddleRoot)) {
            File file = new File(paddleRoot);
            if(file.exists()) {
                this.lacMatch = new LacMatchImpl();
            }else{
                System.out.println("LAC paddle root not exists, not load lac!!!");
            }
        } else {
            System.out.println("LAC env not ready, not load lac!!!");
        }
    }

}
