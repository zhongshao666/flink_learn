package com.secsmart.utils;

public class Util {

    public static final int NUMBER_BEGIN_ASCII = 48;
    public static final int NUMBER_END_ASCII = 57;

    public static final int EN_LOW_BEGIN_ASCII = 65;
    public static final int EN_LOW_END_ASCII = 90;
    public static final int EN_UPPER_BEGIN_ASCII = 97;
    public static final int EN_UPPER_END_ASCII = 122;

    /**
     * 是否英文字符
     *
     * @param value
     * @return
     */
    public static boolean isEnChar(char value) {
        return (value >= EN_LOW_BEGIN_ASCII && value <= EN_LOW_END_ASCII) || (value >= EN_UPPER_BEGIN_ASCII && value <= EN_UPPER_END_ASCII);
    }

    /**
     * 是否是数字字符
     *
     * @param value
     * @return
     */
    public static boolean isNumberChar(char value) {
        return value >= NUMBER_BEGIN_ASCII && value <= NUMBER_END_ASCII;
    }

    /**
     * 是字母还是数字
     * @param value
     * @return
     */
    public static boolean isEnOrNum(char value) {
        return isEnChar(value) || isNumberChar(value);
    }

    /**
     * 是否中文字符
     *
     * @param value
     * @return
     */
    public static boolean isCnChar(char value) {
        Character.UnicodeScript us = Character.UnicodeScript.of(value);
        return us == Character.UnicodeScript.HAN;

    }

    /**
     * 是否是空格
     * @param value
     * @return
     */
    public static boolean isSpace(char value) {
        return Character.isWhitespace(value);
    }

    /**
     * 是否是中文符号
     * @param value
     * @return
     */
    public static boolean isCnSymbolChar(char value) {
        Character.UnicodeBlock ub = Character.UnicodeBlock.of(value);
        return ub == Character.UnicodeBlock.GENERAL_PUNCTUATION
                || ub == Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION
                || ub == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS
                || ub == Character.UnicodeBlock.CJK_COMPATIBILITY_FORMS
                || ub == Character.UnicodeBlock.VERTICAL_FORMS;
    }

    /**
     * 判断字符串是否全是中文
     *
     * @param value
     * @return
     */
    public static boolean isCnChar(String value) {
        for (int i = 0; i < value.length(); i++) {
            if (!isCnChar(value.charAt(i))) {
                return false;
            }
        }
        return true;
    }

}
