package com.secsmart.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashSet;
import java.util.regex.Pattern;

/**
 * @author cjj
 * @date 2021-12/13
 * 身份证号码
 **/
public class IdCardUtil {
    public static final Pattern PROVINCE_PATTERN = Pattern.compile("^(1[1-5])|(2[1-3])|(3[1-7])|(4[1-6])|(5[0-4])|(6[1-5])|(71)|(8[1-2])$");
    private static final String DATE_TIME_FORMATTER = "yyyyMMdd";
    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMATTER);
    //权重
    private static final String[] weight ;
    //校验码
    private static final String[] checkCode;
    private static final HashSet<String> yearPrefix ;
    private static LocalDate localDate = LocalDate.now();
    private static int now ;
    static {
        now = Integer.parseInt(localDate.format(dateTimeFormatter));

        weight = new String[]{"7", "9", "10", "5", "8", "4", "2", "1", "6", "3", "7",
                "9", "10", "5", "8", "4", "2"};
        checkCode = new String[]{"1", "0", "X", "9", "8", "7", "6", "5", "4",
                "3", "2"};
        yearPrefix = new HashSet<>(Arrays.asList("00", "01", "02", "03", "04", "05", "06"));

    }

    public static boolean IDCardCheck(String data){
        String birthday = "";
        String province = data.substring(0, 2);
        if (!PROVINCE_PATTERN.matcher(province).matches()) {
            return false;

        }else {
            if (data.length() ==15) {
                if (yearPrefix.contains(data.substring(6,8))) {
                    birthday = "20" + data.substring(6, 12);
                }else {
                    birthday = "19" + data.substring(6, 12);
                }
                 return dateCheck(birthday);
            }else {
                return tailCheck(data);
            }
        }
    }

    /**
     * 出生日期
     * @param birthday
     * @return
     */
    //日期合法性
    public static boolean dateCheck(String birthday) {
        boolean isRn;
        boolean isLess;
        int year = Integer.parseInt(birthday.substring(0, 4));
        int month = Integer.parseInt(birthday.substring(4, 6));
        int day = Integer.parseInt(birthday.substring(6));
        isLess = Integer.parseInt(birthday) <= now;
        if (isLess) {
            isRn = (year % 400 == 0) || (year % 4 == 0 && year % 100 != 0);
            if (month == 1 || month == 3 ||month == 5 ||month == 7 ||month == 8 ||month == 10 || month == 12) {
                return day <= 31;
            } else if (month == 2) {
                if (isRn) {
                    return day <= 29;
                }else {
                    return day <= 28;
                }
            }else if (month == 4 || month == 6 ||month == 9 ||month == 11 ) {
                return day <= 30;
            }
        }
        return false;
    }

    /**
     * 校验码
     * @param data 身份证号
     * @return
     */
    private static boolean tailCheck(String data){

        String ai = data.substring(0, 17);
        int checkSum = 0;
        for (int i = 0; i < 17; i++) {
            checkSum = checkSum
                    + Integer.parseInt(String.valueOf(ai.charAt(i)))
                    * Integer.parseInt(weight[i]);
        }
        int modValue = checkSum % 11;
        String strVerifyCode = checkCode[modValue];
        return strVerifyCode.toUpperCase().equals(data.substring(17));

    }
}
