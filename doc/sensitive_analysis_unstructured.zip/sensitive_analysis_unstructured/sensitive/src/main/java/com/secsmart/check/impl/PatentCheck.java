package com.secsmart.check.impl;

import com.secsmart.check.Check;

/**
 * @Author zzh
 * @Date 2021/12/13
 * @Description TODO 专利校验
 **/
public class PatentCheck implements Check {
    private static final int[] arr8 = {2, 3, 4, 5, 6, 7, 8, 9};
    private static final int[] arr12 = {2, 3, 4, 5, 6, 7, 8, 9, 2, 3, 4, 5};

    @Override
    public Boolean check(String data) {
        int sum = 0;
        int[] num;
        if (data.charAt(2) != ' ') {
            num = new int[data.length() - 4];
            //for
            for (int i = 0; i < num.length; i++) {
                num[i] = data.charAt(i + 2) - 48;
            }
        } else {
            num = new int[data.length() - 5];
            //for
            for (int i = 0; i < num.length; i++) {
                num[i] = data.charAt(i + 3) - 48;
            }
        }

        if (data.length() > 13) {
            return getBoolean(data, sum, num, arr12);
        } else {
            return getBoolean(data, sum, num, arr8);
        }
    }

    private Boolean getBoolean(String data, int sum, int[] num, int[] arr) {
        for (int i = 0; i < num.length; i++) {
            sum += num[i] * arr[i];
        }
        int s = sum % 11;
        if (s >= 10) {
            return "X".equals(String.valueOf(data.charAt(data.length() - 1)));
        } else
            return s == ((int) data.charAt(data.length() - 1) - '0');
    }

}
