package com.secsmart.check;

public interface Check {
    /**
     * 校验函数
     * @param data
     * @return
     */
    Boolean check(String data);
}
