package com.secsmart.discover;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.io.IOUtils;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class EnumDictMap {
    /**
     * <枚举数据，枚举类型></枚举数据，枚举类型>
     **/
    public static final HashMap<String, String> enumDataMap = new HashMap<>(131072);
    /**
     * 枚举名称列表
     */
    public static final ArrayList<String> dictList = new ArrayList<>();

    /**
     * 校验枚举名称列表
     */
    public static final ArrayList<String> checkDictList = new ArrayList<>();
    /**
     * <校验枚举名称,枚举集合></>
     */
    public static final HashMap<String, HashSet<String>> dictMap = new HashMap<>();


    static {
        String[] names = {"bank_card", "bank_code", "brand_drugs", "chemical_element", "china_city", "china_nation", "china_province", "color", "county_administrative_district", "currency_code", "degree_code", "education_status", "edu_major",  "fitness", "gender", "icd10_disease_code", "marriage_status", "nationality", "religious_belief"};
        String[] checkNames = {"email_code", "area_code", "bank_account"};
        dictList.addAll(Arrays.asList(names));
        checkDictList.addAll(Arrays.asList(checkNames));

        try (InputStream in = EnumDictMap.class.getResourceAsStream("/enum_dict.json")) {
            Map<String, Object> obj = JSON.parseObject(IOUtils.toString(in, StandardCharsets.UTF_8));
            for (String s : dictList) {
                Arrays.asList(((JSONObject) obj).getJSONArray(s).toArray(new String[0]))
                        .forEach(value -> {
                            enumDataMap.put(value, s);
                        });
            }
            for (String s :
                    checkDictList) {
                dictMap.put(s, new HashSet<>(Arrays.asList(((JSONObject) obj).getJSONArray(s).toArray(new String[0]))));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
