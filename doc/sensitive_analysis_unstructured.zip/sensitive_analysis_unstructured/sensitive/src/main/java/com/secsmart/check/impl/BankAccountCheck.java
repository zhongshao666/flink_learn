package com.secsmart.check.impl;

import com.secsmart.check.Check;
import org.apache.commons.lang3.StringUtils;

import java.util.HashSet;

import static com.secsmart.discover.EnumDictMap.dictMap;
import static com.secsmart.discover.RuleId.BANK_ACCOUNT_CODE;


/**
 * @Author cjj
 * @Date 2021/12/09
 * @Description 银行卡号
 */
public class BankAccountCheck implements Check {
    private static final HashSet<String> enumSet;

    static {
        enumSet= dictMap.get(BANK_ACCOUNT_CODE);
    }
    @Override
    public Boolean check(String data) {
        if (StringUtils.isBlank(data)) {
            return false;
        }
        return  (enumSet.contains(data.substring(0, 3)) || enumSet.contains(data.substring(0, 4))
                || enumSet.contains(data.substring(0, 5)) || enumSet.contains(data.substring(0, 6))) && isLuhn(data);

    }
    /**
     * 使用luhn算法进行校验
     **/
    private Boolean isLuhn(String data) {
        int[] num = new int[data.length()];
        for (int i = 0; i < data.length(); i++) {
            num[i] = data.charAt(i) - 48;
        }

        for (int i = num.length - 2; i >= 0; i -= 2) {
            num[i] <<= 1;
            num[i] = num[i] / 10 + num[i] % 10;
        }
        int sum = 0;
        for (int value : num) {
            sum += value;
        }
        return sum % 10 == 0;
    }

}

