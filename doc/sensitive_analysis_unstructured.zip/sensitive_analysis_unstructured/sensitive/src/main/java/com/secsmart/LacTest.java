package com.secsmart;

import com.baidu.nlp.LAC;
import com.secsmart.discover.LacMatchImpl;

import java.util.Scanner;

public class LacTest {
    public static void main(String[] args) {
        long beginTime = System.currentTimeMillis();
        LacMatchImpl lacMatch = new LacMatchImpl();
        long endTime = System.currentTimeMillis();
        System.out.println("load time " + (endTime - beginTime) + "ms");
        beginTime = System.currentTimeMillis();
//        for (int i = 0; i < Integer.parseInt(args[0]); i++) {
//            String res = lacMatch.match("余杭区");
//        }
        endTime = System.currentTimeMillis();
        System.out.println("cost time " + (endTime - beginTime) + "ms");

        Scanner scanner = new Scanner(System.in);
        while (true) {
            lacMatch.match(scanner.nextLine());
        }
//        System.out.println(res);
    }
}
