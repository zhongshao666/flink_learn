package com.secsmart.discover;

import com.baidu.nlp.LAC;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

public class TextLacMatchImpl implements TextLacMatch {

    static {
        System.loadLibrary("lacjni");
    }

    private final LAC lac;
    private final HashSet<String> hashSet=new HashSet<>();

    public TextLacMatchImpl() {
        String lacModelPath = System.getenv("LAC_MODEL_PATH");
        if (Objects.isNull(lacModelPath)) {
            lacModelPath = "./my_lac_model_01";
        }
        lac = new LAC(lacModelPath);
        hashSet.add("PER");
        hashSet.add("LOC");
        hashSet.add("ORG");
        hashSet.add("TIME");

    }

    @Override
    public List<SensitiveRecord> match(String value) {
        ArrayList<String> words = new ArrayList<>();
        ArrayList<String> tags = new ArrayList<>();
        ArrayList<SensitiveRecord> sensitiveRecords = new ArrayList<>();
        lac.run(value, words, tags);
        int index = 0;
        for (int i = 0; i < words.size(); i++) {
            if (hashSet.contains(tags.get(i))) {
                sensitiveRecords.add(new SensitiveRecord(words.get(i), tags.get(i), index, index += words.get(i).length(), true));
            } else index += words.get(i).length();
        }
        return sensitiveRecords;
    }


}
