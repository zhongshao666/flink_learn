package com.secsmart.check.impl;

import com.secsmart.check.Check;
import org.apache.commons.lang3.StringUtils;

import java.util.HashSet;

import static com.secsmart.discover.EnumDictMap.dictMap;
import static com.secsmart.discover.RuleId.AREA_CODE;

/**
 * @Author lcy
 * @Date 2021/12/14
 * @Description
 */
public class FixedTelephoneCheck implements Check {

    private static final HashSet<String> enumSet = dictMap.get(AREA_CODE);

    @Override
    public Boolean check(String data) {
        int dataLen = data.length();
        for (int i = 0; i < data.length(); ++i) {
            if (!Character.isDigit(data.charAt(i))) {
                dataLen--;
            }
        }
        if (data.startsWith("400")) {
            return dataLen == 10;
        }
        //仅考虑国内
        if (data.charAt(0) != '0') {
            data = "0".concat(data);
            dataLen++;
        }
        //区号检测
        return (enumSet.contains(data.substring(0, 3)) || enumSet.contains(data.substring(0, 4))) && dataLen >= 11;
    }
}