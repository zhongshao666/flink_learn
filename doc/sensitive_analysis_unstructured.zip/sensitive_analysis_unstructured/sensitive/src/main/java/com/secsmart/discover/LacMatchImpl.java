package com.secsmart.discover;

import com.baidu.nlp.LAC;

import java.util.ArrayList;
import java.util.Objects;


public class LacMatchImpl implements LacMatch{
    static {
        System.loadLibrary("lacjni");
    }

    private final LAC lac;

    public LacMatchImpl() {
        String lacModelPath = System.getenv("LAC_MODEL_PATH");
        if (Objects.isNull(lacModelPath)) {
            lacModelPath = "./lac_model";
        }
        lac = new LAC(lacModelPath);
    }

    @Override
    public String match(String value) {
        ArrayList<String> words = new ArrayList<>();
        ArrayList<String> tags = new ArrayList<>();
        lac.run(value, words, tags);
        return tags.stream().findFirst().orElse(null);
    }
}
