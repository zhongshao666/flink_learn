package com.secsmart.discover;

import java.util.List;

public interface TextMultiRegexMatch {
    /**
     * 正则&枚举&lac算法
     * @param value
     * @return
     */
    List<SensitiveRecord> match(String value);

    /**
     * 正则&枚举&lac算法
     * @param value
     * @return
     */
    List<SensitiveRecord> matchLac(String value);

    /**
     * 正则
     * @param value
     * @return
     */
    List<SensitiveRecord> matchRegexp(String value);

    /**
     * 枚举
     * @param value
     * @return
     */
    List<SensitiveRecord> matchTrie(String value);
}
