# sensitive

敏感数据识别作为独立的模块可以供各个项目调用,使用公共的接口输出相同,而且支持传统的正则表达式识别以及LAC识别  
输出参数为敏感类型编码
使用LAC识别时,需要配置依赖环境,

### 支持的结构化敏感数据识别类型
|敏感类型|常量名(com.secsmart.discover.RuleId)|类型编码|
|----|----|----|
|省级行政区|CHINA_PROVINCE|china_province|
|专利号|PATENT|patent|
|民族|CHINA_NATION|china_nation|
|健康状况|FITNESS|fitness|
|军官证号|OFFICE_NUMBER|office_number|
|港澳居民来往内地通行证|MTP_FOR_HKMACAO|mtp_for_hkmacao|
|邮政编码|POSTCODE|post_code|
|性别|GENDER|gender|
|教育情况|EDUCATION_STATUS|education_status|
|宗教信仰|RELIGIOUS_BELIEF|religious_belief|
|身份证号|ID_NUMBER|id_number|
|港澳通行证|HK_MACAU_TRAVEL_PERMIT|hk_macau_travel_permit|
|固定电话|FIXED_TELEPHONE|fixed_telephone|
|银行编码|BANK_CODE|bank_code|
|房屋产权证|HOUSING_OWNERSHIP_CERTIFICATES|housing_ownership_certificates|
|银联卡第二磁道|UNIONPAY_CARD_SECOND_TRACK|unionpay_card_second_track|
|银联卡第三磁道|UNIONPAY_CARD_THIRD_TRACK|unionpay_card_third_track|
|营业执照号码|BUSINESS_LICENSE_NUMBER|business_license_number|
|县级行政区|COUNTY_ADMINISTRATIVE_DISTRICT|county_administrative_district|
|统一社会信用代码|UNIFIED_SOCIAL_CREDIT_CODE|unified_social_credit_code|
|地域区号|AREA_CODE|area_code|
|IMEI国际移动电话设备识别码|IMEI_CODE|imei|
|icd10疾病编码|ICD10_DISEASE_CODE|icd10_disease_code|
|化学元素|CHEMICAL_ELEMENT|chemical_element|
|不动产登记证明|REAL_ESTATE|real_estate|
|组织机构代码|ORG_CODE|org_code|
|MEID 移动设备识别码|MEID_CODE|meid_code|
|车辆识别代码(VIN)|VIN_NUMBER|vin_number|
|银行卡号|BANK_ACCOUNT_CODE|bank_account|
|婚姻状况|MARRIAGE_STATUS|marriage_status|
|学位|DEGREE_CODE|degree_code|
|护照|PASS_PORT_CODE|pass_port_code|
|车牌号|BUS_NUMBER_CODE|bus_number|
|上海证券账户号码|SH_SECURITY_NUMBER|sh_sucurity_number|
|深圳证券账户号码|SZ_SECURITY_NUMBER|sz_sucurity_number|
|手机号(只限于中国内地)|CELLPHONE_NUMBER|cell_phone|
|邮箱|EMAIL_CODE|email_code|
|银联卡第一磁道|UNIONPAY_CARD_FIRST_TRACK|unionpay_card_frist_track|
|税务登记号|TAX_ID|tax_id|
|地级行政区(城市)|CHINA_CITY|china_city|
|IP地址 (IPV4和IPV6)|IP_CODE|ip_code|
|IPV6|IPV6_CODE|ipv6_code|
|国际电话区号|INTERNATIONAL_TELEPHONE|international_telephone|
|纳税人信用等级|TAXPAYER_CREDIT_RATING|taxpayer_credit_rating|
|药品品牌|BRAND_DRUGS|brand_drugs|
|教育专业|EDU_MAJOR|edu_major|
|银行卡类型|BANK_CARD|bank_card|
|国家货币代码|CURRENCY_CODE|currency_code|
|颜色|COLOR|color|
|国际标准图书编号|STANDARD_BOOK_NUMBER|standard_book_number|
|SIM卡的IMSI号(国际移动用户识别码)|IMSI_CODE|imsi_code|
|国籍|NATIONALITY|nationality|
|MAC地址|MAC|mac
|人名|PER
|地址|LOC
|组织机构|ORG
|职业|PRO
|银行|BANK
|时间|TIME
|学校|SCH
|其他|O|


### 接口及调用方式
#### 接口内容
固定识别:
```java
public interface MultiRegexMatch {
    /**
     * 正则&枚举&lac算法
     */
    String match(String value);

    /**
     * lac算法
     */
    String matchLac(String value);

    /**
     * 正则&枚举
     */
    String matchRegexp(String value);
}
```

使用LAC进行识别
```java
public interface LacMatch {
    /**
     * 采用LAC进行Match,目前可以识别的类型为人名\地址\组织机构\时间\学校\银行\职业\其他
     * @param value
     * @return
     */
    String match(String value);
}
```

#### POM引入
```
<!-- 敏感数据识别 -->
<dependency>
    <groupId>com.secsmart</groupId>
    <artifactId>sensitive_analysis</artifactId>
    <version>v1.0-SNAPSHOT</version>
</dependency>
```

#### 调用识别算法方式

```
MultiRegexMatchImpl multiRegexMatchImpl = new MultiRegexMatchImpl();
```

### LAC依赖环境配置方式
1. 解压paddle/root/fluid_inference.tgz,并将解压后的目录设置为环境变量PADDLE_ROOT  
```
export PADDLE_ROOT=/usr/local/paddle/fluid_inference
```
2. 将paddle/jniso/liblacjni.so加入环境变量LD_LIBRARY_PATH
```shell script
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/paddle/jniso
```
3. 解压paddle/lac_model/lac_model.tar.gz,并将解压后的目录设置为LAC_MODEL_PATH
```shell script
export LAC_MODEL_PATH=/usr/local/paddle/lac_model
```

也可以将paddle文件拷贝到系统中,直接执行install.sh,会将上面的环境变量加入全局
```shell script
./install.sh
```


