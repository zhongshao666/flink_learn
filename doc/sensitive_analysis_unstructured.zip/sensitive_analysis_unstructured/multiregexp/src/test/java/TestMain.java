import com.hylanda.lightgrep.*;

public class TestMain {
    public static void main(String[] args) {
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("敏感词", 0);
        patterns.addPattern("红牛", 0);
        patterns.addPattern("可乐雪碧", 0);
        patterns.addPattern("匹配", 0);
        patterns.addPattern("(978)?\\d{9}[1-9X]", 0);
        patterns.addPattern("ZL\\s?(\\d{2}|\\d{4})[12389](\\d{5}|\\d{7})\\.[0-9X]", 0);
        patterns.addPattern("([0-9a-fA-F]{0,4}::[0-9a-fA-F]{0,4}((((:[0-9a-fA-F]{0,4}){3})?)|(((:[0-9a-fA-F]{0,4}){3}%[1-9]\\d{0,23})?)))"
                + "|([0-9a-fA-F]{0,4}((:[0-9a-fA-F]{0,4}){7}))"
                + "|(([0-9a-fA-F]{0,4}:){6}(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])((\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])){3}))"
                + "|([0-9a-fA-F]{0,4}::(([0-9a-fA-F]{0,4}:)?)(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])((\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])){3}))", 0);

        Automation automation = patterns.toAutomation();
//        patterns.close();

        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("ZL 201610032112.4 敏感词");
        matcher.match(r,  new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });

        final GrepString r2 = new GrepString("fe80::c528:7912:beda:6e97%5");
        matcher.match(r2,  new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r2.subSequence(item.getStart(), item.getEnd()));
            }
        });


        r.close();
//        matcher.close();

//        automation.close();
    }
}
