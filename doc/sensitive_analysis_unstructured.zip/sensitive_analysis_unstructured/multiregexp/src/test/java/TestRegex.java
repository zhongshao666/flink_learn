import java.io.*;
import java.util.regex.Pattern;

public class TestRegex {
    public static void main(String[] args) throws IOException {
        test1();
    }

    public static void test1() throws IOException {
        Pattern pattern1= Pattern.compile("银行");
        Pattern pattern2= Pattern.compile("学校");
        Pattern pattern3= Pattern.compile("匹配");
        Pattern pattern4= Pattern.compile("公司");
        Pattern pattern5= Pattern.compile("大学");
        Pattern pattern6= Pattern.compile("高中");
        Pattern pattern7= Pattern.compile("医生");
        Pattern pattern8= Pattern.compile("农民");
        Pattern pattern9= Pattern.compile("员工");
        Pattern pattern10= Pattern.compile("老板");

        File file = new File("data/data.txt");
        FileInputStream fileInputStream = new FileInputStream(file);
        InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
        char[] buf = new char[8];
        int len;
        long beginTime = System.currentTimeMillis();

        while ((len = inputStreamReader.read(buf)) != -1) {
            boolean result1 = pattern1.matcher(new String(buf,0,len)).matches();
            boolean result2 = pattern2.matcher(new String(buf,0,len)).matches();
            boolean result3 = pattern3.matcher(new String(buf,0,len)).matches();
            boolean result4 = pattern4.matcher(new String(buf,0,len)).matches();
            boolean result5 = pattern5.matcher(new String(buf,0,len)).matches();
            boolean result6 = pattern6.matcher(new String(buf,0,len)).matches();
            boolean result7 = pattern7.matcher(new String(buf,0,len)).matches();
            boolean result8 = pattern8.matcher(new String(buf,0,len)).matches();
            boolean result9 = pattern9.matcher(new String(buf,0,len)).matches();
            boolean result10 = pattern10.matcher(new String(buf,0,len)).matches();
        }

        long endTime = System.currentTimeMillis();

        System.out.println("cost time " + (endTime - beginTime) + "ms");


    }
}
