import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.hylanda.lightgrep.*;
import org.apache.commons.io.IOUtils;
import org.junit.Test;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class TestEnum {
    @Test
    public void test() {
        HashMap<String, String> enumDataMap = new HashMap<>(131072);
        ArrayList<String> dictList = new ArrayList<>();
        String[] names = {"area_code", "bank_account", "bank_card", "bank_code", "brand_drugs", "chemical_element", "china_city", "china_nation", "china_province", "color", "county_administrative_district", "currency_code", "degree_code", "education_status", "edu_major", "email_code", "fitness", "gender", "icd10_disease_code", "international_telephone", "marriage_status", "nationality", "religious_belief", "taxpayer_credit_rating"};
        dictList.addAll(Arrays.asList(names));

        try (InputStream in = TestEnum.class.getResourceAsStream("/enum_dict.json")) {
            Map<String, Object> obj = JSON.parseObject(IOUtils.toString(in, StandardCharsets.UTF_8));
            for (String s : dictList) {
                Arrays.asList(((JSONObject) obj).getJSONArray(s).toArray(new String[0]))
                        .forEach(value -> {
                            enumDataMap.put(value, s);
                        });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        MultiPattern patterns = new MultiPattern();

        long begin = System.currentTimeMillis();

        int i = 0;
        Set<Map.Entry<String, String>> entries = enumDataMap.entrySet();
            for (Map.Entry<String, String> entry :
                    entries) {
                String k = entry.getKey();
                try {
                    if (!k.contains("(") && !k.contains(")") && !k.contains("\\")&& !k.contains("["))
                        patterns.addPattern(k, 0);
                    i++;
                }
                catch (Exception e) {
                    e.printStackTrace();
                    System.out.println(k);
                }
            }
//        String[] ss=new String[];
        System.out.println(i);
//        enumDataMap.forEach((k,v)->{
//            patterns.addPattern(k, 0);
//        });


        long end = System.currentTimeMillis();

        System.out.println("cost time " + (end - begin) + "ms");

        begin = System.currentTimeMillis();
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("汉族蒙古族回族藏族维吾尔族苗族彝族壮族布依族朝鲜族满族侗族瑶族白族土家族哈尼族哈萨克族傣族黎族傈僳族佤族畲族高山族拉祜族水族东乡族纳西族景颇族柯尔克孜族土族达斡尔族仫佬族羌族布朗族撒拉族毛南族仡佬族锡伯族阿昌族普米族塔吉克族怒族乌孜别克族俄罗斯族鄂温克族德昂族保安族裕固族京族塔塔尔族独龙族鄂伦春族赫哲族门巴族珞巴族基诺族余杭区汉族蒙古族回族藏族维吾尔族苗族彝族壮族布依族朝鲜族满族侗族瑶族白族土家族哈尼族哈萨克族傣族黎族傈僳族佤族畲族高山族拉祜族水族东乡族纳西族景颇族柯尔克孜族土族达斡尔族仫佬族羌族布朗族撒拉族毛南族仡佬族锡伯族阿昌族普米族塔吉克族怒族乌孜别克族俄罗斯族鄂温克族德昂族保安族裕固族京族塔塔尔族独龙族鄂伦春族赫哲族门巴族珞巴族基诺族");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
        end = System.currentTimeMillis();
        System.out.println("cost time " + (end - begin) + "ms");

    }
}
