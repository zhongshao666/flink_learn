import com.hylanda.lightgrep.*;

import java.io.*;
import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;

public class TestSpeed {
    public static void main(String[] args) throws IOException {
        MultiPattern patterns = new MultiPattern();
//        patterns.addPattern("银行", 0);
//        patterns.addPattern("学校", 0);
//        patterns.addPattern("匹配", 0);
//        patterns.addPattern("公司", 0);
//        patterns.addPattern("大学", 0);
//        patterns.addPattern("高中", 0);
//        patterns.addPattern("医生", 0);
//        patterns.addPattern("农民", 0);
//        patterns.addPattern("员工", 0);
        patterns.addPattern("ZL\\s?(\\d{2}|\\d{4})[12389](\\d{5}|\\d{7})\\.[0-9X]", 0);




        Automation automation = patterns.toAutomation();
//        patterns.close();

        Matcher matcher = automation.createMatcher();
        long begin = System.currentTimeMillis();
        for (int i = 0; i <1000000 ; i++) {
            GrepString grepString = new GrepString("ZL201610032112.4");

            matcher.match(grepString, new HitCallback() {
                @Override
                public void match(HitItem item) {

                }
            });
        }


        long end = System.currentTimeMillis();

        System.out.println("cost time " + (end - begin) + "ms");



    }
}