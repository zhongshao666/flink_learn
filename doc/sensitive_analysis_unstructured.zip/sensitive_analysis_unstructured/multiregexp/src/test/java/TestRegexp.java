import com.hylanda.lightgrep.*;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TestRegexp {
    @Test
    public void test(){
        final List<String> regexList = new ArrayList<>();
        final Map<Integer, String> ruleMap = new HashMap<>();
        try (InputStream in = new FileInputStream(new File("C:\\Users\\admin\\IdeaProjects\\sensitive_analysis\\sensitive\\src\\main\\resources\\regex_dict"));
             BufferedReader br=new BufferedReader(new InputStreamReader(in))
        ){
            int i = 0;
            while (br.ready()) {
                String s = br.readLine();
                //只分割成两项
                String[] split = StringUtils.split(s, "=", 2);
                regexList.add(split[1]);
                ruleMap.put(i++,split[0]);
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("读取正则列表失败");
        }
        String[] regexp=new String[regexList.size()];
        for (int i = 0; i < regexList.size(); i++) {
            regexp[i] = regexList.get(i);
        }

        MultiPattern patterns = new MultiPattern();
        long begin = System.currentTimeMillis();
        patterns.addPatterns(0, regexp);

        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        long end = System.currentTimeMillis();
        System.out.println("cost time " + (end - begin) + "ms");

//        String input = "LSVG449J472059134,aaaaaaaaaaaaaaaaaaaaaaaaaaaaab提1问,ZL 201610032112.4传讯,B7f0Aac9C9C4F7a,460101234567891,, LOGIN a% ,91330110328126571L,责难UI345SD34我还是10国家1973长叹一声啊,疲乏生肉你国家1972-01-22不好啊有没有未来好玩我要充一亿灰白质,15000016951226697X,123智力";
//        StringBuilder input111 = new StringBuilder();
//        for (int i = 0; i < 1000; i++) {
//            input111.append(input);
//        }
        String input = "460041234567891,360727199901180728,411422312192611,41142296011210700000,91330110328126571L,input,330184000352775,input,623061541504967067,input,356701119817008,B7f0Aac9C9C4F7a,input.LSVG449J472059134,input,UI345SD34,68DMK2S3-4,input,978055901330X,973958473X,input,ZL 201610032112.4,ZL95115608.X,ZL201610032112.4,input,C000318817,99C101325522,input,99C101325522,C000318817,0878715015,input,141234567,P1234567,input,h1234567891,M1239874561,input,CW1234567,input,1234:abce:1234:7161:9021:2a18:12ff:ffff,::192.168.44.58,fe80::3096:7161:9021:2a18%10000000,1234:abce:1234:7161:9021:2a18:12ff:ffff,[::6],::192.168.44.58,input,00-0c-29-01-3e-2b,00:0c:29:01:3e:2b,input,192.168.45.60,0.0.0.0,input,0571-88575373,input,18548694235,13180410719,input,1606193057@qq.com,input,政字第123456号,input,浙CW689E,军V7891Q,京Z20776港,input,鄂(2015)武汉市江汉不动产权第0000001号,input,昆房权证西山居字第123456号,input,%99623061571504965067∧CJJ∧221010712345678912345678912?,input,;6011896349392428=72049003919400421?,;6011896349392428=200994744730381?,input,;996011896349392428=156665916317802819620228400824969296503780341=75468=012985797834218?,;996011896349392428=1564787263590397233279972659787255733122372238269=5=062321370755596?,input,红色，绿色粉红色，卡其色";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 1000; i++) {
            sb.append(input);
        }
        System.out.println(sb.length());
        begin = System.currentTimeMillis();
        final GrepString r = new GrepString(sb.toString());
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
//                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
        end = System.currentTimeMillis();
        System.out.println("cost time " + (end - begin) + "ms");
    }

    @Test
    public void imsi_code(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("460(0\\d|1[0-3]|20)\\d{10}", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("460041234567891");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void id_number(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("(((1[1-5])|(2[1-3])|(3[1-7])|(4[1-6])|(5[0-4])|(6[1-5])|(71)|(8[1-2]))\\d{4}(19|20)\\d{2}((0[1-9])|10|11|12)(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx])|(((1[1-5])|(2[1-3])|(3[1-7])|(4[1-6])|(5[0-4])|(6[1-5])|(71)|(8[1-2]))\\d{6}((0[1-9])|10|11|12)(([0-2][1-9])|10|20|30|31)\\d{3})", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("360727199901180728");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void tax_id(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("(1[1-5]|2[1-3]|3[1-7]|4[1-6]|5[0-4]|6[1-5]|71|8[1-2])\\d{4}((19|20)\\d{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))\\d{3}[0-9Xx]\\d{2}|\\d{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))\\d{8}|[A-Z\\d]{8}[\\-]?[X\\d])", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("411422312192611,41142296011210700000");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void unified_social_credit_code(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("[\\dA-HJ-NPQRTUWXY]{2}(1[1-5]|2[1-3]|3[1-7]|4[1-6]|5[0-4]|6[1-5]|71|8[1-2])\\d{4}[\\dA-HJ-NPQRTUWXY]{10}", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("91330110328126571L,");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void business_license_number(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("(([1-6][1-9]|50|71|81|82)\\d{4}|100000)\\d{9}", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,330184000352775");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void bank_account(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("[1-9]\\d{11,18}", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,623061541504967067");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void imei(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("\\d{15,17}", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("356701119817008");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getStart());
                System.out.println(item.getEnd());
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void meid_code(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("[0-9A-Fa-f]{14,15}", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("B7f0Aac9C9C4F7a");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }


    @Test
    public void vin_number(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("[A-Za-z\\d]{11}\\d{6}", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input.LSVG449J472059134");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void org_code(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("[A-Z\\d]{8}[\\-]?[X\\d]", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,UI345SD34,68DMK2S3-4");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void standard_book_number(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("(978-?)?([\\dX]{10}|[\\dX-]{13})", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,978055901330X,973958473X");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void patent(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("ZL ?(\\d{2}|\\d{4})[12389](\\d{5}|\\d{7})\\.[0-9X]", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,ZL 201610032112.4,ZL95115608.X,ZL201610032112.4");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void sh_sucurity_number(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("(99)?([ABDF]\\d{9}|C([01]\\d|90|99)\\d{7})", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,C000318817,99C101325522");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void sz_sucurity_number(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("(98)?(01\\d{2}|08\\d{2}|001\\d|0878|20\\d{2}|27\\d{2}|287\\d|098\\d)\\d{6}", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,99C101325522,C000318817,0878715015");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void pass_port_code(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("[GgEe]\\d{8}|(14|15|[Ee][A-Ha-hJ-Nj-nP-Zp-z]|[Dd]|[Pp]|[Ss]|[DdPpSs][Ee])\\d{7}", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,141234567,P1234567");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void mtp_for_hkmacao(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("[HMhm]\\d{10}", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,h1234567891,M1239874561");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void hk_macau_travel_permit(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("[CcWw]{1}[0-9A-HJ-NP-Z]{1}\\d{7}", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,CW1234567");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }


    @Test
    public void ipv6_code(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("\\[?([A-Fa-f\\d]{0,4}:[A-Fa-f\\d:]{0,39}((1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|[1-9])(\\.(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)){3}|0\\.0\\.0\\.0)?(%([1-9]\\d{0,23}|[A-Za-z\\d_]{0,13}))?(/\\d{0,3})?)]?", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,1234:abce:1234:7161:9021:2a18:12ff:ffff,::192.168.44.58,fe80::3096:7161:9021:2a18%10000000,1234:abce:1234:7161:9021:2a18:12ff:ffff,[::6],::192.168.44.58");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void mac(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("(([A-Fa-f\\d]{2}-){5}[A-Fa-f\\d]{2})|(([A-Fa-f\\d]{2}:){5}[A-Fa-f\\d]{2})", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,00-0c-29-01-3e-2b,00:0c:29:01:3e:2b");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void ip_code(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("((1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|[1-9])(\\.(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)){3}|0\\.0\\.0\\.0)", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,192.168.45.60,0.0.0.0");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void fixed_telephone(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("(([0]?([1-9]\\d|[1-9]{2}\\d))([- ])?\\d{3,4}([- ])?\\d{3,4})|((400)([- ])?\\d{3}([- ])?\\d{4})", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,0571-88575373");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void cell_phone(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("(\\+?86)?1([38]\\d{1}|4[579]|5([0-3]|[5-9])|66|7([1-3]|[5-8])|9[189])\\d{8}", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,18548694235,13180410719");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }


    @Test
    public void email_code(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("[a-zA-Z0-9]+?(([._\\-])?)+[a-zA-Z0-9]@[a-zA-Z0-9]+(\\.[a-zA-Z]+)+", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,1606193057@qq.com,");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void office_number(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("[南北沈兰成济广军海空参政后装]字第\\d{6,8}号", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,政字第123456号");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void bus_number(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵青藏川宁琼][A-HJ-NP-Z][A-HJ-NP-Z\\d]{4,5}[A-HJ-NP-Z\\d领学警挂试超]|粤([A-HJ-NP-Y][A-HJ-NP-Z\\d]{4,5}[A-HJ-NP-Z\\d领学警挂试超]|Z[A-HJ-NP-Z\\d]{4,5}[港澳])|使(10[1-9]|1[1-9]\\d|2[0-5]\\d|30\\d|31[0-8])\\d{3}|[济J兰L沈S南N军V成C北B广G空K海H][A-HJ-NP-Z][A-HJ-NP-Z\\d]{5})", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,浙CW689E,军V7891Q,京Z20776港");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }


    @Test
    public void real_estate(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼][（(]\\d{4}[）)].{2,8}|国（\\d{4}）[林海])不动产(权|证明)第\\d{7}号", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,鄂(2015)武汉市江汉不动产权第0000001号");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void housing_ownership_certificates(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern(".{0,5}房权证.{1,8}字第[0-9A-Za-z\\-]{0,20}号", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,昆房权证西山居字第123456号");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void unionpay_card_frist_track(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("%(99|B)\\d{13,19}∧[a-zA-Z]{2,26}∧(\\d{2}(0[1-9]|1[0-2])|0000)[125679][024][0-7](\\d{20}|\\d{16})\\?", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,%99623061571504965067∧CJJ∧221010712345678912345678912?");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }


    @Test
    public void unionpay_card_second_track(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern(";\\d{13,19}=(\\d{2}(0[1-9]|1[0-2])|0000)[125679][024][0-7](\\d{8}|\\d{10})\\?", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,;6011896349392428=72049003919400421?,;6011896349392428=200994744730381?");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void unionpay_card_third_track(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern(";99\\d{13,19}=156\\d{12}\\d(00[1-9]|0[1-9]\\d|[12]\\d{2}|3[0-5]\\d|36[0-6])\\d{16}(\\d{2}(0[1-9]|1[0-2])|0000)\\d{2}(\\d{0,12}=\\d{0,12}=|==)[01]\\d{6}\\d{8}\\?", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,;996011896349392428=156665916317802819620228400824969296503780341=75468=012985797834218?,;996011896349392428=1564787263590397233279972659787255733122372238269=5=062321370755596?");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }

    @Test
    public void color(){
        MultiPattern patterns = new MultiPattern();
        patterns.addPattern("([棕橘橙灰白粉紫红绿蓝褐金银青黄黑]{1,2}色?)|卡其色?", 0);
        Automation automation = patterns.toAutomation();
        Matcher matcher = automation.createMatcher();
        final GrepString r = new GrepString("input,红色，绿色粉红色，卡其色");
        matcher.match(r, new HitCallback() {
            @Override
            public void match(HitItem item) {
                System.out.println(item.getId() + " " + r.subSequence(item.getStart(), item.getEnd()));
            }
        });
    }



}
