package com.hylanda.lightgrep;

public class RegExprException extends RuntimeException {
    private static final long serialVersionUID = 1L;

	public RegExprException(final String msg) {
        super(msg);
    }

}
