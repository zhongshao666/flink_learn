package com;

import com.fulmicoton.multiregexp.MultiPattern;
import com.fulmicoton.multiregexp.MultiPatternMatcher;
import com.fulmicoton.multiregexp.MultiPatternSearcher;

import java.util.Arrays;

public class Test {
    @org.junit.Test
    public void test(){
        String[] ss = new String[]{"幸福小区","幸福小区1幢1单元801室","红","红领巾幼儿园","(?:\\+?86)?1([38]\\d{1}|4[579]|5[^4]|66|7[^49]|9[189])\\d{8}"
        ,"浙江","江苏","苏乞儿"};
        MultiPatternSearcher searcher = MultiPattern.of(ss).searcher();
//        MultiPatternSearcher.Cursor res = searcher.search("我住幸福小区1幢1单元801室");
//        MultiPatternSearcher.Cursor res = searcher.search("我在红领巾幼儿园上学");
//        MultiPatternSearcher.Cursor res = searcher.search("1517002538163");
        MultiPatternSearcher.Cursor res = searcher.search("浙江苏乞儿");

        while (res.next()) {
            System.out.println(res.match()+"\t index: "+res.start()+"-"+ res.end());
        }
    }
}
