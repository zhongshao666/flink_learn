package org.text.algorithm.regexp;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.text.algorithm.regexp.vm.CharacterParser;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class TestEnum {
    static String input = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaab提1问,传讯, LOGIN a% 责难我还是10国家1973长叹一声啊,疲乏生肉你国家1972-01-22不好啊有没有未来好玩我要充一亿灰白质,123智力";

    @Test
    public void test(){
//        HashMap<String, String> enumDataMap = new HashMap<>(131072);
//        ArrayList<String> dictList = new ArrayList<>();
//        String[] names = {"area_code", "bank_account", "bank_card", "bank_code", "brand_drugs", "chemical_element", "china_city", "china_nation", "china_province", "color", "county_administrative_district", "currency_code", "degree_code", "education_status", "edu_major", "email_code", "fitness", "gender", "icd10_disease_code", "international_telephone", "marriage_status", "nationality", "religious_belief", "taxpayer_credit_rating"};
//        dictList.addAll(Arrays.asList(names));
//
//        try (InputStream in = TestEnum.class.getResourceAsStream("/enum_dict.json")) {
//            Map<String, Object> obj = JSON.parseObject(IOUtils.toString(in, StandardCharsets.UTF_8));
//            for (String s : dictList) {
//                Arrays.asList(((JSONObject) obj).getJSONArray(s).toArray(new String[0]))
//                        .forEach(value -> {
//                            enumDataMap.put(value, s);
//                        });
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//
//        ArrayList<String> arr = new ArrayList<>();
//        Set<Map.Entry<String, String>> entries = enumDataMap.entrySet();
//        for (Map.Entry<String, String> entry :
//                entries) {
//            String k = entry.getKey();
//            try {
//                if (!k.contains("(") && !k.contains(")") && !k.contains("\\")&& !k.contains("["))
//                    arr.add(k);
//            }
//            catch (Exception e) {
//                e.printStackTrace();
//                System.out.println(k);
//            }
//        }
//

        final List<String> regexList = new ArrayList<>();
        final Map<Integer, String> ruleMap = new HashMap<>();

        try (InputStream in = new FileInputStream(new File("C:\\Users\\admin\\IdeaProjects\\sensitive_analysis\\sensitive\\src\\main\\resources\\regex_dict"));
             BufferedReader br=new BufferedReader(new InputStreamReader(in))
        ){
            int i = 0;
            while (br.ready()) {
                String s = br.readLine();
                //只分割成两项
                String[] split = StringUtils.split(s, "=", 2);
                regexList.add(split[1]);
                ruleMap.put(i++,split[0]);
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("读取正则列表失败");
        }
        String[] regexp=new String[regexList.size()];
        for (int i = 0; i < regexList.size(); i++) {
            System.out.println(regexList.get(i));
            regexp[i] = regexList.get(i);
        }
//        String[] regexp=new String[]{"国家","责任"};
        CharacterParser.OPTIMIZE_RANGE = true;
        AutomatonBuilder builder = new AutomatonBuilder();

        long start = System.currentTimeMillis();
        Automaton automation = builder.build(200000, regexp);

        long end = System.currentTimeMillis();
        System.out.println("compile time =" + (end - start));

        System.out.println("automation count=" + automation.getDfaStateCount());
        if (automation.getDfaPendingStates() != null) {
            System.out.println("pending count=" + automation.getDfaPendingStates().length);

        } else {
            System.out.println("pending count=0");
        }


        //String input = "a提1问";
        MatcherCallback matcherCallback = new MatcherCallback() {
            @Override
            public boolean hit(int id) {
                return true;
            }

            @Override
            public void hitInfo(int id, int[] start, int[] end) {
//                System.out.print(id + ": " + input.substring(start[0], end[0]));
//                for (int i = 1; i < start.length; i++) {
//                    if (start[i] != -1) {
//                        System.out.print(" sub" + i + ":" + input.substring(start[i], end[i]));
//                    }
//                }
//                System.out.println();
            }
        };

        HookCallback hookCallback = new HookCallback() {
            @Override
            public int hook(int type, int dfaId, int[] args) {
                if (type == 0) {
                    return dfaHook(args);
                } else {
                    return nfaHook(dfaId, args);
                }
            }

            /**
             *
             * @param hookArgs
             * @return
             *  0 continue hook
             *  1 hook succ and stop hook
             *  2 hook succ and continue hook
             *  otherwise stop hook
             */
            private int dfaHook(int[] hookArgs) {
                if (hookArgs[3] == hookArgs[2]) {
                    return 1;
                } else {
                    return -1;
                }
            }

            /**
             *
             * @param dfaId
             * @param hookArgs
             * @return
             *  0 continue hook
             *  1 hook succ and stop hook
             *  2 hook succ and continue hook
             *  otherwise stop hook
             */
            private int nfaHook(int dfaId, int[] hookArgs) {
                if (hookArgs[3] == hookArgs[2]) {
                    return 1;
                } else {
                    return -1;
                }
            }
        };

        StringBuilder input111 = new StringBuilder();
        for (int i = 0; i < 10000; i++) {
            input111.append(input);
        }
        System.out.println("input length : "+input111.length());
        long beginTime = System.currentTimeMillis();

        AutomatonMatcher matcher = new AutomatonMatcher(automation, input111.toString(), matcherCallback, hookCallback);
        matcher.find();

        long endTime = System.currentTimeMillis();

        System.out.println("cost time " + (endTime - beginTime) + "ms");
    }
}
