package org.text.algorithm.regexp;

import org.junit.Test;
import org.text.algorithm.regexp.vm.CharacterParser;

public class TestConflict {
    @Test
    public void test(){
        String[] regexp = new String[]{
                "[A-Z\\d]{8}[-]?[X\\d]"
                ,"(1[1-5]|2[1-3]|3[1-7]|4[1-6]|5[0-4]|6[1-5]|71|8[1-2])\\d{4}((19|20)\\d{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))\\d{3}[0-9Xx]\\d{2}|\\d{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))\\d{8}|[A-Z\\d]{8}[-]?[X\\d])"
                ,"幸福小区"
                ,"幸福小区1幢1单元801室"
                , "红"
                ,"红领巾幼儿园"
                ,"(?:\\+?86)?1([38]\\d{1}|4[579]|5[^4]|66|7[^49]|9[189])\\d{8}"
                ,"浙江"
                ,"江苏"
                ,"苏乞儿"
                ,"((0[1-7]|1[036]|2[0-7]|3[0-6]|4[0-7]|5[1-7]|6[1-7]|7[1-5]|8[1345])\\d{4}|99907[789])"
                ,"([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵青藏川宁琼][A-HJ-NP-Z][A-HJ-NP-Z\\d]{4,5}[A-HJ-NP-Z\\d领学警挂试超]|粤([A-HJ-NP-Y][A-HJ-NP-Z\\d]{4,5}[A-HJ-NP-Z\\d领学警挂试超]|Z[A-HJ-NP-Z\\d]{4,5}[港澳])|使(10[1-9]|1[1-9]\\d|2[0-5]\\d|30\\d|31[0-8])\\d{3}|[济J兰L沈S南N军V成C北B广G空K海H][A-HJ-NP-Z][A-HJ-NP-Z\\d]{5})"
                ,"杭州市幸福小区"
                ,"幸福小区1幢1单元801室"
        };

        CharacterParser.OPTIMIZE_RANGE = true;
        AutomatonBuilder builder = new AutomatonBuilder();

        long start = System.currentTimeMillis();
        Automaton automation = builder.build(200000, regexp);

        long end = System.currentTimeMillis();
        System.out.println("compile time =" + (end - start));

        System.out.println("automation count=" + automation.getDfaStateCount());
        if (automation.getDfaPendingStates() != null) {
            System.out.println("pending count=" + automation.getDfaPendingStates().length);

        } else {
            System.out.println("pending count=0");
        }

        String input = "浙江苏乞儿";
//        String input = "我住幸福小区1幢1单元801室";
//        String input = "我在红领巾幼儿园上学";
//        String input = "1517002538163";
//        String input = "2217002538163";
//        String input = "我不知道浙A6YEH34H2319是什么意思";
//        String input = "我住杭州市幸福小区1幢1单元801室";
//        String input = "我看到了江苏C113U0";
//        String input = "2217002538163";
//        String input = "137645EH34H2319";
        MatcherCallback matcherCallback = new MatcherCallback() {
            @Override
            public boolean hit(int id) {
                return true;
            }

            @Override
            public void hitInfo(int id, int[] start, int[] end) {
                System.out.print(id + ": " + input.substring(start[0], end[0])+" start:"+start[0]+" end:"+end[0]+"  ");
                for (int i = 1; i < start.length; i++) {
                    if (start[i] != -1) {
                        System.out.print(" sub" + i + ":" + input.substring(start[i], end[i])+" start:"+start[i]+" end:"+end[i]+"  ");
                    }
                }
                System.out.println();
            }
        };

        HookCallback hookCallback = new HookCallback() {
            @Override
            public int hook(int type, int dfaId, int[] args) {
                if (type == 0) {
                    return dfaHook(args);
                } else {
                    return nfaHook(dfaId, args);
                }
            }

            private int dfaHook(int[] hookArgs) {
                if (hookArgs[3] == hookArgs[2]) {
                    return 1;
                } else {
                    return -1;
                }
            }

            private int nfaHook(int dfaId, int[] hookArgs) {
                if (hookArgs[3] == hookArgs[2]) {
                    return 1;
                } else {
                    return -1;
                }
            }
        };

        long beginTime = System.currentTimeMillis();

        AutomatonMatcher matcher = new AutomatonMatcher(automation, input.toString(), matcherCallback, hookCallback);
        boolean b = matcher.find();

        long endTime = System.currentTimeMillis();

        System.out.println("cost time " + (endTime - beginTime) + "ms");
    }
}
