package com.ssa;


import com.ssa.algorithmmodel.keys.ModelKeyed;
import com.ssa.algorithmmodel.map.FilterNonNull;
import com.ssa.algorithmmodel.transformation.ModelAndTimeAggregation;
import com.ssa.algorithmmodel.transformation.PstAnomalyDetectProcess;
import com.ssa.algorithmmodel.utils.MyTrigger;
import com.ssa.bean.AccountBean;
import com.ssa.keys.HttpKeySelector;
import com.ssa.sensitive.to.HttpLog;
import com.ssa.source.SecZookeeperSourceUpdate;
import com.ssa.transformation.*;
import com.ssa.utils.ArgsUtils;
import com.ssa.utils.CuratorOperator;
import com.ssa.utils.KafkaSinkProp;
import com.ssa.utils.KafkaSourceProp;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.api.GetDataBuilder;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.*;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.apache.flink.util.OutputTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.ivi.opensource.flinkclickhousesink.ClickHouseSink;
import ru.ivi.opensource.flinkclickhousesink.model.ClickHouseSinkConst;
import scala.collection.mutable.ListBuffer;

import java.io.ByteArrayInputStream;
import java.util.Map;
import java.util.Properties;


/**
 * @author : hld
 * @Date ： 2021/4/8
 * @Time : 15:56
 * @role ：
 */
public class ApisjMain {
    private static final Logger logger = LoggerFactory.getLogger(ApisjMain.class);

    public static OutputTag<HttpLog> apptags = new OutputTag<HttpLog>("apptags") {
    };
    public static OutputTag<HttpLog> interfacetags = new OutputTag<HttpLog>("interfacetags") {
    };
    public static OutputTag<AccountBean> usertags = new OutputTag<AccountBean>("usertags") {
    };
    public static OutputTag<String> sensitivedata = new OutputTag<String>("sensitivedata") {
    };
    public static OutputTag<String> sensitivelabels = new OutputTag<String>("sensitivelabels") {
    };


    public static void main(String[] args) throws Exception {


        StreamExecutionEnvironment streamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment();
        //   streamExecutionEnvironment.setRestartStrategy(RestartStrategies.fixedDelayRestart(5, Time.seconds(10)));


        ParameterTool map = ParameterTool.fromArgs(args);
        Properties properties = new Properties();
        CuratorOperator mcto = null;
        mcto = new CuratorOperator(map.get("zkAddr"));
        GetDataBuilder data = mcto.client.getData();
        properties.load(new ByteArrayInputStream(data.forPath(map.get("zkPath"))));
        ParameterTool parameterTool = ParameterTool.fromMap((Map) properties);

        streamExecutionEnvironment.getConfig()
                .setGlobalJobParameters(parameterTool);

        streamExecutionEnvironment.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);

        //创建datasource消费者 从kafka 消费数据
        FlinkKafkaConsumer011<String> stringFlinkKafkaConsumer011 = new FlinkKafkaConsumer011<>(parameterTool.get("kafka.config.apisj.topic"), new SimpleStringSchema(), getKafkaSourceProp(parameterTool).getProp());

        MapStateDescriptor<String, Tuple4<Integer, Integer, String, String>> zookeeperconfig = new MapStateDescriptor<>("zookeeperconfig", BasicTypeInfo.STRING_TYPE_INFO, Types.TUPLE(BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO));

        DataStreamSource<Tuple4<Integer, Integer, String, String>> tuple2DataStreamSource = streamExecutionEnvironment.addSource(new SecZookeeperSourceUpdate())
                .setParallelism(1);

        //zookeeper的配置广播流配置
        BroadcastStream<Tuple4<Integer, Integer, String, String>> broadcast = tuple2DataStreamSource.broadcast(zookeeperconfig);

        //从kafka获取数据
        DataStreamSource<String> stringDataStreamSource = streamExecutionEnvironment.addSource(stringFlinkKafkaConsumer011)
                .setParallelism(4);

        //join 数据广播流
        BroadcastConnectedStream<String, Tuple4<Integer, Integer, String, String>> broadcastConnectedStream = stringDataStreamSource.connect(broadcast);
        //应用发现
        SingleOutputStreamOperator<HttpLog> appDiscovery = broadcastConnectedStream.process(new AppTagProcess())
                .name("应用发现")
                .setParallelism(4);

        //http分组识别，发现新用户，用户打标，新接口标记
        SingleOutputStreamOperator<HttpLog> httpTagLater = appDiscovery.keyBy(new HttpKeySelector())
                .connect(broadcast)
                .process(new UserTagProcess())
                .name("http分组识别，发现新用户，用户打标，新接口标记");

        //敏感数据识别标记
        SingleOutputStreamOperator<HttpLog> sensitiveAnallyLater = httpTagLater.connect(broadcast)
                .process(new SensitiveAnalysisProcess())
                .name("敏感数据识别标记");

        //柳鹤的
        SingleOutputStreamOperator<ListBuffer<HttpLog>> modelAggregateStream = sensitiveAnallyLater.filter(new FilterNonNull(parameterTool)).keyBy(new ModelKeyed(parameterTool))
                .countWindow(parameterTool.getInt("model.apisj.pst.data.config.groupLength")).trigger(new MyTrigger(parameterTool.getLong("model.apisj.pst.data.config.expireTime"), parameterTool.getInt("model.apisj.pst.data.config.groupLength"))).aggregate(new ModelAndTimeAggregation());

        SingleOutputStreamOperator<HttpLog> modelProcessStream = modelAggregateStream.connect(broadcast).process(new PstAnomalyDetectProcess());

        //将数据写入click house中
        modelProcessStream.process(new SensitiveBean2StringProcess())
                .addSink(new ClickHouseSink(getHttpLogCkProp(parameterTool.get("clickhouse.dw.database"),parameterTool.get("clickhouse.apisj.table"),parameterTool)));

        //执行任务
        streamExecutionEnvironment.execute("apisj pst flink job");
    }


    /**
     * 获取 kafka consumer配置
     *
     * @return
     */
    public static KafkaSourceProp getKafkaSourceProp(ParameterTool parameterTool) {
        KafkaSourceProp kafkaSourceProp = new KafkaSourceProp(parameterTool);
        kafkaSourceProp.setBOOTSTRAP_SERVERS_CONFIG(parameterTool.get("kafka.url"));
        return kafkaSourceProp;
    }

    /**
     * @Author 赵臻柄
     * @Date 2021/4/13 19:22
     * @Method
     * @功能描述 获取kafka producer的配置
     * @Param
     * @Return
     */
    public static KafkaSinkProp getKafkaSinkProp(ParameterTool parameterTool) {
        KafkaSinkProp kafkaSinkProp = new KafkaSinkProp();
        kafkaSinkProp.setBOOTSTRAP_SERVERS_CONFIG(parameterTool.get("kafka.url"));

        return kafkaSinkProp;
    }

    /**
     * Asset_log ck config
     *
     * @return
     */
    private static Properties getHttpLogCkProp(String ckDb, String ckTb, ParameterTool parameterTool) {
        Properties properties = new Properties();
        properties.put(ClickHouseSinkConst.TARGET_TABLE_NAME, ckDb + "." + ckTb);
        properties.put(ClickHouseSinkConst.MAX_BUFFER_SIZE, parameterTool.get("clickhouse.sink.max-buffer-size"));
        return properties;
    }

}