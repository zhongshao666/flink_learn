create table dm_st_ssa.dm_nml_sensitive_table(
id int4 auto_increment primary key,
batchId varchar(100),
catalog varchar(100),
ip varchar(50),
`port` int4,
instance varchar(100),
pattern varchar(100),
sensitiveTable text,
sensitiveField text
);