package com.ssa.transformation;

import com.ssa.DbsjMain;
import com.ssa.bean.OfflineData;
import com.ssa.constants.CommonConstants;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.functions.co.CoProcessFunction;
import org.apache.flink.util.Collector;

/**
 * @author : hld
 * @Date ： 2021/5/18
 * @Time : 14:19
 * @role ：
 */
public class OfflineConnectMysqlProcess extends CoProcessFunction<OfflineData, OfflineData, OfflineData> {
    @Override
    public void processElement1(OfflineData value, Context ctx, Collector<OfflineData> out) throws Exception {
        String offlineTableType = value.getOfflineTableType();

        //模型黑名单和登录操作项的流
        if (CommonConstants.OfflineTableType.ANOTHER_LOGIN.getVal().equals(offlineTableType)) {
            out.collect(value);
        }
    }

    @Override
    public void processElement2(OfflineData value, Context ctx, Collector<OfflineData> out) throws Exception {
        String offlineTableType = value.getOfflineTableType();
        //模型黑名单和登录操作项的流
        if (CommonConstants.OfflineTableType.MODEL_BLACKLIST.getVal().equals(offlineTableType)) {
            out.collect(value);
        }
    }
}
