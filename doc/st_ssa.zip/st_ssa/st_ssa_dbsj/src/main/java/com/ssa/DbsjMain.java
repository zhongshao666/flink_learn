package com.ssa;


import com.alibaba.fastjson.JSON;
import com.ssa.bean.AssetLog;
import com.ssa.bean.OfflineData;
import com.ssa.bean.StatisticsBean;
import com.ssa.constants.CommonConstants;
import com.ssa.keyselectors.AccountKeySelector;
import com.ssa.keyselectors.IpKeySelector;
import com.ssa.mapfun.SensitiveKafkaMap;
import com.ssa.mapfun.FileterSourceMapFunction;
import com.ssa.mapfun.SourceMapFunction;
import com.ssa.outputtag.EventTypeProcess;
import com.ssa.outputtag.FilterDDLProcess;
import com.ssa.outputtag.FilterDMLProcess;
import com.ssa.outputtag.FilterDQLProcess;
import com.ssa.sink.MysqlSink;
import com.ssa.sink.SensitiveMysqlSink;
import com.ssa.source.ClickHouseZkSource;
import com.ssa.source.MysqlZkSource;
import com.ssa.source.SecZookeeperSource;
import com.ssa.statistics.StatisticsProcess;
import com.ssa.transformation.VisitEventProcess2;
import com.ssa.transformation.DropDBProcess;
import com.ssa.transformation.StatisToStringProcess;
import com.ssa.transformation.VisitEventProcess;
import com.ssa.transformation.*;
import com.ssa.utils.*;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.*;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.ConfigOption;
import org.apache.flink.configuration.ConfigOptions;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.api.GetDataBuilder;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.*;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer011;
import org.apache.flink.util.OutputTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.ivi.opensource.flinkclickhousesink.ClickHouseSink;
import ru.ivi.opensource.flinkclickhousesink.model.ClickHouseSinkConst;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;

/**
 * @author : hld
 * @Date ： 2021/4/8
 * @Time : 16:02
 * @role ：
 */
public class DbsjMain {

    private static final Logger logger = LoggerFactory.getLogger(DbsjMain.class);
    /**
     * 配置普通侧输出流
     */
    public static OutputTag<AssetLog> loginEventType = new OutputTag<AssetLog>("loginEventType") {
    };
    public static OutputTag<AssetLog> DQLOperation = new OutputTag<AssetLog>("DQLOperation") {
    };
    public static OutputTag<AssetLog> DDLOperation = new OutputTag<AssetLog>("DDLOperation") {
    };
    public static OutputTag<AssetLog> DMLOperation = new OutputTag<AssetLog>("DMLOperation") {
    };

    /**
     * 威胁情报ip侧输出
     */
    public static OutputTag<AssetLog> ThreatIpOutput = new OutputTag<AssetLog>("ThreatIpOutput") {
    };

    /**
     * 异地登录侧输出流
     */
    public static OutputTag<AssetLog> loginAddrAbnormal = new OutputTag<AssetLog>("LoginAddrAbnormal") {
    };

    /**
     * 配置侧输出流转广播流的outputTag
     */
    public static OutputTag<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> DQLOperationClientIpTag = new OutputTag<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>>("DQLOperationClientIpTag") {
    };
    public static OutputTag<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> DQLOperationAccountTag = new OutputTag<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>>("DQLOperationBroadTag") {
    };
    public static OutputTag<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> LoginOutput = new OutputTag<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>>("LoginOutput") {
    };
    public static OutputTag<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> machineOutputTag = new OutputTag<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>>("machineOutputTag"){};

    /**
     * 配置广播流的MapStateDescriptor
     */
    public static MapStateDescriptor<String, Tuple4<Integer, Integer, String, String>> zookeeperConfig = new MapStateDescriptor<>("zookeeperConfig", BasicTypeInfo.STRING_TYPE_INFO, Types.TUPLE(BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO));
    public static MapStateDescriptor<String, Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> DQLOperationBroad = new MapStateDescriptor<>("DQLOperationBroad", BasicTypeInfo.STRING_TYPE_INFO, TypeInformation.of(new TypeHint<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>>() {
    }));
    public static MapStateDescriptor<String, OfflineData> offlineConnectMysql = new MapStateDescriptor<>("offlineConnectMysql", BasicTypeInfo.STRING_TYPE_INFO, TypeInformation.of(new TypeHint<OfflineData>() {
    }));
    public static MapStateDescriptor<String, Tuple8<String, String, String, Integer, String, String, List<String>, List<String>>> sensitiveLabels = new MapStateDescriptor<>("sensitiveLabels", BasicTypeInfo.STRING_TYPE_INFO, TypeInformation.of(new TypeHint<Tuple8<String, String, String, Integer, String, String, List<String>, List<String>>>() {
    }));


    public static void main(String[] args) throws Exception {

        StreamExecutionEnvironment streamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment();
//        StreamExecutionEnvironment streamExecutionEnvironment = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(new Configuration());
//        streamExecutionEnvironment.setRestartStrategy(RestartStrategies.fixedDelayRestart(5, org.apache.flink.api.common.time.Time.seconds(10)));

        streamExecutionEnvironment.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);

        //--zkAddr 192.168.24.73:2181 --zkPath /dbsj_audit/dbsj/job/config/riskflinkjob
        ParameterTool map = ParameterTool.fromArgs(args);
        Properties properties = new Properties();
        CuratorOperator mcto = new CuratorOperator(map.get("zkAddr"));
//        mcto = new CuratorOperator("192.168.24.73:2181");
        GetDataBuilder data = mcto.client.getData();
//        properties.load(new ByteArrayInputStream(data.forPath("/dbsj_audit/dbsj/job/config/riskflinkjob")));
        properties.load(new ByteArrayInputStream(data.forPath(map.get("zkPath"))));
        ParameterTool parameterTool = ParameterTool.fromMap((Map) properties);

        streamExecutionEnvironment.getConfig().setGlobalJobParameters(parameterTool);

        streamExecutionEnvironment.setParallelism(map.get("p") == null ? 5 : Integer.parseInt(parameterTool.get("p")));


        //创建datasource消费者 从kafka 消费数据
        FlinkKafkaConsumer011<String> stringFlinkKafkaConsumer011 = new FlinkKafkaConsumer011<>(parameterTool.get("kafka.topic.collect.asset"), new SimpleStringSchema(), getKafkaSourceProp(parameterTool).getProp());

        //创建识别数据kafka  sink
        FlinkKafkaProducer011<String> strategymarking = new FlinkKafkaProducer011<String>(parameterTool.get("kafka.topic.send.strategymarking"), new SimpleStringSchema(), getKafkaSinkProp(parameterTool).getProp2());

        //创建dataSource生产者， 将数据生产到kafka中
        FlinkKafkaProducer011<String> stringFlinkKafkaProducer011 = new FlinkKafkaProducer011<String>(parameterTool.get("kafka.config.real.time.situation.topic.source"), new SimpleStringSchema(), getKafkaSinkProp(parameterTool).getProp2());
        //创建Kafka生产者对象,将数据生产到Kafka中
        FlinkKafkaProducer011<String> sinkKafkaProducer011 = new FlinkKafkaProducer011<>(parameterTool.get("kafka.config.real.time.situation.topic.source"), new SimpleStringSchema(), getKafkaSinkProp(parameterTool).getProp2());


        //获取ck数据源
        SingleOutputStreamOperator<OfflineData> offlineDataDataStreamSource = streamExecutionEnvironment.addSource(new ClickHouseZkSource()).name("click house source");

        //获取kafka数据
        SingleOutputStreamOperator<String> stringDataStreamSource = streamExecutionEnvironment.addSource(stringFlinkKafkaConsumer011).name("kafka source");
        SingleOutputStreamOperator<Tuple4<Integer, Integer, String, String>> tuple2DataStreamSource = streamExecutionEnvironment.addSource(new SecZookeeperSource())
                .setParallelism(1).name("zkConfig source");

        BroadcastStream<Tuple4<Integer, Integer, String, String>> broadcast = tuple2DataStreamSource.broadcast(zookeeperConfig);

        //将数据解析成bean
        SingleOutputStreamOperator<AssetLog> assetLogSingleDataStream = stringDataStreamSource.map(new SourceMapFunction()).filter(Objects::nonNull).name("解析bean");
        //将离线数据和zookeeper配置合并，用process做成多广播流，用户可在这里增加广播流分配
        SingleOutputStreamOperator<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> offlineConnectZkStream = offlineDataDataStreamSource
                .connect(tuple2DataStreamSource).process(new DistrriOutputProcess()).name("click house connect zkConfig");

        //获取kafka敏感数据
        DataStreamSource<String> kafkaSensitive = streamExecutionEnvironment.addSource(new FlinkKafkaConsumer011<>(parameterTool.get("kafka.topic.collect.sensitive"), new SimpleStringSchema(), getKafkaSourceProp(parameterTool).getProp())).setParallelism(1);
        SingleOutputStreamOperator<Tuple8<String, String, String, Integer, String, String, List<String>, List<String>>> sensitiveTuple = kafkaSensitive.process(new KafkaSensitiveProcess()).setParallelism(1);


        BroadcastStream<Tuple8<String, String, String, Integer, String, String, List<String>, List<String>>> sensitiveLabelBroadcast = sensitiveTuple.broadcast(sensitiveLabels);
        SingleOutputStreamOperator<AssetLog> markSensitiveDataStream = assetLogSingleDataStream.connect(sensitiveLabelBroadcast).process(new MarkSensitiveCodeProcess()).name("marking sensitive code");


        BroadcastStream<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> loginBlackBroadcast = offlineConnectZkStream.getSideOutput(LoginOutput).broadcast(DQLOperationBroad);
        //异地登录
        SingleOutputStreamOperator<AssetLog> loginAddrStream = markSensitiveDataStream.connect(loginBlackBroadcast).process(new LoginAddrAbnormalProcess()).name("策略过滤（白名单）和 异地登录");


        //威胁情报ip（黑名单）
        SingleOutputStreamOperator<AssetLog> threatIntelligenceStream = loginAddrStream.connect(broadcast).process(new ThreatIntelligenceIpProcess()).name("threat intelligence ip");


        DataStreamSource<OfflineData> mysqlSource = streamExecutionEnvironment.addSource(new MysqlZkSource());

        SingleOutputStreamOperator<OfflineData> offlineConnectMysqlStream = offlineDataDataStreamSource.connect(mysqlSource).process(new OfflineConnectMysqlProcess());
        BroadcastStream<OfflineData> blackBroadcast = offlineConnectMysqlStream.broadcast(offlineConnectMysql);

        //模型黑名单
        SingleOutputStreamOperator<AssetLog> modelBlackListStream = threatIntelligenceStream.connect(blackBroadcast).process(new BlackListModelProcess()).name("模型黑名单");

        //处理僵尸账号复活
        SingleOutputStreamOperator<AssetLog> activeZombieDataStream = modelBlackListStream.keyBy(AssetLog::getAccount)
                .connect(offlineDataDataStreamSource.filter(item -> item.getAccount() != null && CommonConstants.OfflineTableType.ZOMBIE_ACCOUNT.getVal().equals(item.getOfflineTableType()))
                        .keyBy(OfflineData::getAccount))
                .process(new ZombieAccountActiveProcess()).name("僵尸账号复活");

        //账号共享
        SingleOutputStreamOperator<AssetLog> accountSharingStream = activeZombieDataStream.keyBy(AssetLog::getAccount).connect(broadcast).process(new AccountSharingProcess()).name("账号共享");

        //分流非登录事件
        SingleOutputStreamOperator<AssetLog> nloginEventTypeStream = accountSharingStream.process(new EventTypeProcess()).name("分流登非录事件");
        //sql注入算子
        SingleOutputStreamOperator<AssetLog> sqlInjectionResult = nloginEventTypeStream.process(new SqlInjectionProcess()).name("SQL注入算子");

        //处理客户端ip为key的异常处理
        SingleOutputStreamOperator<AssetLog> visitEventProcessByIp = sqlInjectionResult.keyBy(new IpKeySelector()).connect(broadcast).process(new VisitEventProcess()).name("处理ip分组后数据库访问事件");
        //处理客户端account为key的异常处理
        SingleOutputStreamOperator<AssetLog> visitEventProcessByAccount = visitEventProcessByIp.keyBy(new AccountKeySelector()).connect(broadcast).process(new VisitEventProcess2()).name("处理用户分组后数据库访问事件");

        //获取登录事件
        DataStream<AssetLog> dealLoginStream = nloginEventTypeStream.getSideOutput(loginEventType);

        //非工作时间
        SingleOutputStreamOperator<AssetLog> nonWorkingTimeStream = dealLoginStream.connect(broadcast).process(new NonWorkingTimeProcess()).name("非工作时间");

        //4A认证绕行
        SingleOutputStreamOperator<AssetLog> certificationBypassStream = nonWorkingTimeStream.keyBy(AssetLog::getAccount).connect(broadcast).process(new CertificationBypassProcess()).name("4A认证绕行");

        //发起口令暴力破解(账号)
        SingleOutputStreamOperator<AssetLog> loginPasswordIncorrectByAccountStream = certificationBypassStream.keyBy(AssetLog::getAccount).connect(broadcast).process(new LoginPasswordIncorrectByAccountProcess()).name("发起口令暴力破解(账号)");

        //撞库（ip）
        SingleOutputStreamOperator<AssetLog> loginPasswordIncorrectByIpStream = loginPasswordIncorrectByAccountStream.keyBy(AssetLog::getClientIp).connect(broadcast).process(new LoginPasswordIncorrectByIpProcess()).name("撞库（ip）");

        //分流DQL(需要替代)
        SingleOutputStreamOperator<AssetLog> filterDqlOperationStream = visitEventProcessByAccount.process(new FilterDQLProcess()).name("分流DQL");

        //处理DQL类策略
        DataStream<AssetLog> dealDqlOperationStream = filterDqlOperationStream.getSideOutput(DQLOperation);
        //KeyBy客户端id处理
        BroadcastStream<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> dqlClientIpBroadcast = offlineConnectZkStream.getSideOutput(DQLOperationClientIpTag).broadcast(DqlClientIpCoProcess.dqlClientIpMap);
        SingleOutputStreamOperator<AssetLog> dqlKeyByClientIpDataStream = dealDqlOperationStream.keyBy(AssetLog::getClientIp)
                .connect(dqlClientIpBroadcast).process(new DqlClientIpCoProcess()).name("DQL-KeyBy-ClientIp");
        //KeyBy数据库账号处理
        BroadcastStream<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> dqlAccountBroadcast = offlineConnectZkStream.getSideOutput(DQLOperationAccountTag).broadcast(DqlAccountCoProcess.dqlAccountMap);
        SingleOutputStreamOperator<AssetLog> dqlKeyByAccountDataStream = dqlKeyByClientIpDataStream.keyBy(AssetLog::getAccount)
                .connect(dqlAccountBroadcast).process(new DqlAccountCoProcess()).name("DQL-KeyBy-Account");

        //异常下载敏感数据
        SingleOutputStreamOperator<AssetLog> abnormalDownloadSensitiveDataAccStream = dqlKeyByAccountDataStream.keyBy(AssetLog::getAccount).connect(broadcast).process(new AbnormalDownloadSensitiveDataProcess()).name("异常下载敏感数据(账号)");
        SingleOutputStreamOperator<AssetLog> abnormalDownloadSensitiveDataIpStream = abnormalDownloadSensitiveDataAccStream.keyBy(AssetLog::getClientIp).connect(broadcast).process(new AbnormalDownloadSensitiveDataProcess()).name("异常下载敏感数据(IP)");

        //connect zk处理伪开窗数据
        SingleOutputStreamOperator<AssetLog> dqlKeyByClientIpPseudoWindow = abnormalDownloadSensitiveDataIpStream.keyBy(AssetLog::getClientIp)
                .connect(broadcast).process(new DqlCliPseudoWindowProcess()).name("DQL-KeyBy-ClientIp-PseudoWindow");
        SingleOutputStreamOperator<AssetLog> dqlKeyByAccountPseudoWindow = dqlKeyByClientIpPseudoWindow.keyBy(AssetLog::getAccount)
                .connect(broadcast).process(new DqlAccPseudoWindowProcess()).name("DQL-KeyBy-Account-PseudoWindow");

        //分流DDL
        SingleOutputStreamOperator<AssetLog> filterDdlOperationStream = filterDqlOperationStream.process(new FilterDDLProcess()).name("filter DDL");

        //处理DDL类策略
        DataStream<AssetLog> dealDdlOperationStream = filterDdlOperationStream.getSideOutput(DDLOperation);

        SingleOutputStreamOperator<AssetLog> dropDBStream = dealDdlOperationStream.process(new DropDBProcess()).name("DDL类策略");

        //分流DML
        SingleOutputStreamOperator<AssetLog> filterDmlOperationStream = filterDdlOperationStream.process(new FilterDMLProcess()).name("filter DML");

        //处理DML
        DataStream<AssetLog> dealDmlOperationStream = filterDmlOperationStream.getSideOutput(DMLOperation);
        //后台变更敏感数据字段
        SingleOutputStreamOperator<AssetLog> abnormalOperationDmlStream = dealDmlOperationStream.connect(broadcast).process(new AbnormalOperationDmlProcess()).name("DML类策略");

        //将分流处理的数据进行流合并
        DataStream<AssetLog> unionStream = loginPasswordIncorrectByIpStream.union(dqlKeyByAccountPseudoWindow,dropDBStream,
                abnormalOperationDmlStream,threatIntelligenceStream.getSideOutput(ThreatIpOutput),loginAddrStream.getSideOutput(loginAddrAbnormal));


        //数据流join后统计数据转换成String
        SingleOutputStreamOperator<Tuple2<Integer, List<StatisticsBean>>> aggregateWindow = unionStream.timeWindowAll(Time.minutes(15)).aggregate(new StatisticsProcess());

        SingleOutputStreamOperator<List<StatisticsBean>> joinStaticsDataList = aggregateWindow.keyBy(item -> item.f0).process(new SsaProcess(Time.minutes(15))).setParallelism(1);

        joinStaticsDataList.addSink(new MysqlSink()).setParallelism(5).name("mysql sink");

        sensitiveTuple.addSink(new SensitiveMysqlSink()).name("sensitive mysql sink");

        unionStream.filter(item -> item.getFlowLabel().size() > 0).map(new SensitiveKafkaMap()).addSink(strategymarking).name("strategy kafka sink");

        SingleOutputStreamOperator<String> joinStaticsData = joinStaticsDataList.flatMap(new StatisToStringProcess());
        joinStaticsData.addSink(stringFlinkKafkaProducer011).name("ssa kafka sink");

        // 将数据写入click house中
        unionStream.process(new AssetLogToStringProcess())
                .addSink(new ClickHouseSink(getHttpLogCkProp(parameterTool))).setParallelism(5).name("click house sink");

        //将数据过滤告警标签的写入到Kafka中
        assetLogSingleDataStream.filter(item -> item.getAlarmLabel().size() != 0)
                .map(new FileterSourceMapFunction())
                .addSink(sinkKafkaProducer011);


        streamExecutionEnvironment.execute("dbsj strategy job");
    }

    /**
     * 获取 kafka consumer配置
     *
     * @return
     */
    public static KafkaSourceProp getKafkaSourceProp(ParameterTool parameterTool) {
        KafkaSourceProp kafkaSourceProp = new KafkaSourceProp();
        kafkaSourceProp.setBOOTSTRAP_SERVERS_CONFIG(parameterTool.get("kafka.url"));
        return kafkaSourceProp;
    }

    /**
     * @Author 赵臻柄
     * @Date 2021/4/13 19:22
     * @Method
     * @功能描述 获取kafka producer的配置
     * @Param
     * @Return
     */
    public static KafkaSinkProp getKafkaSinkProp(ParameterTool parameterTool) {
        KafkaSinkProp kafkaSinkProp = new KafkaSinkProp();
        kafkaSinkProp.setBOOTSTRAP_SERVERS_CONFIG(parameterTool.get("kafka.url"));

        return kafkaSinkProp;
    }

    /**
     * Asset_log ck config
     *
     * @return
     */
    public static Properties getHttpLogCkProp(ParameterTool parameterTool) {

        Properties properties = new Properties();
        properties.put(ClickHouseSinkConst.TARGET_TABLE_NAME, parameterTool.get("clickHouse.Database") + "." + parameterTool.get("clickHouse.Table"));
        properties.put(ClickHouseSinkConst.MAX_BUFFER_SIZE, parameterTool.get("clickhouse.sink.max-buffer-size"));
        return properties;
    }
}