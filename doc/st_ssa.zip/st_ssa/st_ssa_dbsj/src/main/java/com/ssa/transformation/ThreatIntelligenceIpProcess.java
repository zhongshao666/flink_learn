package com.ssa.transformation;

import com.ssa.bean.AssetLog;
import com.ssa.bean.ThreatIntelligenceIp;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import com.ssa.mapfun.ConditionTOMarking;
import com.ssa.mapfun.ParsingThreatIp;
import com.ssa.utils.IPUtils;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.BroadcastProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * 威胁情报IP(黑名单)
 */
public class ThreatIntelligenceIpProcess extends BroadcastProcessFunction<AssetLog, Tuple4<Integer, Integer, String, String>, AssetLog> {

    final private Logger logger = LoggerFactory.getLogger(ThreatIntelligenceIpProcess.class);

    List<Tuple2<Long, Long>> listThreatIp;
    List<String> listIp;
    boolean threatIpBool;

    @Override
    public void open(Configuration parameters) throws Exception {
        listThreatIp = new ArrayList<>();
        listIp = new ArrayList<>();
    }

    @Override
    public void processElement(AssetLog assetLog, ReadOnlyContext readOnlyContext, Collector<AssetLog> collector) throws Exception {
        threatIpBool = false;

        if (assetLog.getClientIp() != null && listIp.size() > 0) {
            for (String ip : listIp) {
                if (ip.equals(assetLog.getClientIp())) {
                    threatIpBool = true;
                    break;
                }
            }
        }

        if (assetLog.getClientIp() != null && listThreatIp.size() > 0) {
            long httpClientIp = IPUtils.ip2Long(assetLog.getClientIp());
            for (Tuple2<Long, Long> tuple2 : listThreatIp) {
                if (httpClientIp >= tuple2.f0 && httpClientIp <= tuple2.f1) {
                    threatIpBool = true;
                    break;
                }
            }
        }

        if (threatIpBool) {
            //威胁情报ip

            logger.info("asset log threat intelligence ip marking first id : {} , second id: {} , client ip :{}", assetLog.getFirstId(), assetLog.getSecondId(), assetLog.getClientIp());
            ConditionTOMarking.setStrategy(assetLog, AssetLogConstants.strategyLabelType.THREAT_IP.getVal(), CommonConstants.RiskLevel.HIGH_RISK.getVal());
//            readOnlyContext.output(DbsjMain.ThreatIpOutput, assetLog);
        } else {
        }
        collector.collect(assetLog);
    }

    @Override
    public void processBroadcastElement(Tuple4<Integer, Integer, String, String> tuple4, Context context, Collector<AssetLog> collector) throws Exception {
        if (tuple4.f0 == CommonConstants.ZkDataType.THREAT_IP.getVal()) {
            List<ThreatIntelligenceIp> threatIntelligenceIps = ParsingThreatIp.parsingThreatIp(tuple4.f3);
            if (Optional.ofNullable(threatIntelligenceIps).isPresent()  &&
                    (tuple4.f1 == CommonConstants.OperateType.ADD.getVal() || tuple4.f1 == CommonConstants.OperateType.UPDATE.getVal())) {
                listThreatIp.clear();
                listIp.clear();
                for (ThreatIntelligenceIp threatIntelligenceIp : threatIntelligenceIps) {
                    String[] split = threatIntelligenceIp.getClient_ip().split("-");
                    if (split.length == 1) {
                        this.listIp.add(threatIntelligenceIp.getClient_ip());
                    } else {
                        this.listThreatIp.add(new Tuple2<>(IPUtils.ip2Long(split[0]), IPUtils.ip2Long(split[1])));
                    }
                }
            }
        }
    }
}
