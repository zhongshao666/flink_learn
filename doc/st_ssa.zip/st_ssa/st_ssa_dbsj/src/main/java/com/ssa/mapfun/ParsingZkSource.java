package com.ssa.mapfun;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ssa.strategy.*;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ParsingZkSource implements Serializable {

    public StrategyMatch parsingZkJson(String str) {

        StrategyMatch strategyMatch = new StrategyMatch();

        JSONObject obj = JSON.parseObject(str);
        strategyMatch.setId(obj.getInteger("id"));
        strategyMatch.setName(obj.getString("name"));
        strategyMatch.setAppIds(JSONObject.parseArray(obj.getString("appIds"), Long.class));
        strategyMatch.setStrategy(obj.getString("strategy"));
        strategyMatch.setEnable(obj.getBoolean("enable"));
        strategyMatch.setRiskLevel(obj.getInteger("riskLevel"));
        strategyMatch.setRiskType(obj.getString("riskType"));
        JSONObject conditionTo = obj.getJSONObject("conditionTO");
        strategyMatch.setStrategyMatchCondition(conditionTo == null ? null : strategyMatchCondition(conditionTo));
        return strategyMatch;
    }


    public StrategyMatchCondition strategyMatchCondition(JSONObject obj) {

        StrategyMatchCondition strategyMatchCondition = new StrategyMatchCondition();
        strategyMatchCondition.setVariance(obj.getDouble("variance"));
        strategyMatchCondition.setGetOfflineDays(obj.getInteger("getOfflineDays"));
        strategyMatchCondition.setReqStatus(obj.getInteger("reqStatus"));
        strategyMatchCondition.setStatusCode(JSONObject.parseArray(obj.getString("statusCode"), Integer.class));
        strategyMatchCondition.setLabelCode(JSONObject.parseArray(obj.getString("labelCode"), String.class));
        strategyMatchCondition.setSensitiveLevel(JSONObject.parseArray(obj.getString("sensitiveLevel"), String.class));
        strategyMatchCondition.setLoginIntervalDay(obj.getInteger("loginIntervalDay"));
        strategyMatchCondition.setOperationValue(obj.getString("operationValue"));
        strategyMatchCondition.setMaximumAuthorityAccount(JSONObject.parseArray(obj.getString("maximumAuthorityAccount"), String.class));
        strategyMatchCondition.setSensitiveDataCount(obj.getInteger("sensitiveDataCount"));

        JSONObject interfaceIds = obj.getJSONObject("interfaceIds");
        strategyMatchCondition.setInterfaceIds(interfaceIds == null ? null : conditionToLongListTools(interfaceIds));

        JSONObject user = obj.getJSONObject("user");
        strategyMatchCondition.setUserAccount(user == null ? null : conditionToStringListTools(user));

        String dateTime = obj.getString("dateTime");
        strategyMatchCondition.setDateTime(JSON.parseObject(dateTime,DateTime.class));

        JSONObject month = obj.getJSONObject("month");
        strategyMatchCondition.setMonthTime(month == null ? null : conditionToIntegerListTools(month));

        JSONObject week = obj.getJSONObject("week");
        strategyMatchCondition.setWeekTime(week == null ? null : conditionToIntegerListTools(week));

        JSONObject date = obj.getJSONObject("date");
        strategyMatchCondition.setDateTimeDay(date == null ? null : conditionToIntegerListTools(date));

        JSONObject ip = obj.getJSONObject("ip");
        strategyMatchCondition.setClientAllIps(ip == null ? null : conditionToTuple2ListTools(ip));

        JSONObject tool = obj.getJSONObject("tool");
        strategyMatchCondition.setClientTools(tool == null ? null : conditionToStringListTools(tool));

        JSONObject reqMethod = obj.getJSONObject("reqMethod");
        strategyMatchCondition.setReqMethod(reqMethod == null ? null : conditionToStringListTools(reqMethod));

        JSONObject url = obj.getJSONObject("url");
        strategyMatchCondition.setUrlParsingTool(url == null ? null : urlParsingTool(url));

        JSONObject refererKeywords = obj.getJSONObject("refererKeywords");
        strategyMatchCondition.setRefererKeywords(refererKeywords == null ? null : conditionToStringListTools(refererKeywords));

        JSONObject cookieKeywords = obj.getJSONObject("cookieKeywords");
        strategyMatchCondition.setCookieKeywords(cookieKeywords == null ? null : conditionToStringListTools(cookieKeywords));

        JSONObject reqKeywords = obj.getJSONObject("reqKeywords");
        strategyMatchCondition.setReqKeywords(reqKeywords == null ? null : conditionToStringListTools(reqKeywords));

        JSONObject resBodyKeywords = obj.getJSONObject("resBodyKeywords");
        strategyMatchCondition.setResBodyKeywords(resBodyKeywords == null ? null : conditionToStringListTools(resBodyKeywords));

        String costTime = obj.getString("costTime");
        strategyMatchCondition.setCostTime(JSON.parseObject(costTime,CostTime.class));

        String triggerFrequency = obj.getString("triggerFrequency");
        strategyMatchCondition.setTriggerFrequency(JSON.parseObject(triggerFrequency, ConditionToFrequencyTools.class));

        String loginFrequency = obj.getString("loginFrequency");
        strategyMatchCondition.setLoginFrequency(JSON.parseObject(loginFrequency, ConditionToFrequencyTools.class));

        String sensitiveDataSize = obj.getString("sensitiveDataSize");
        strategyMatchCondition.setSensitiveDataSize(JSON.parseObject(sensitiveDataSize,ConditionToReqTools.class));

        String sensitiveFileSize = obj.getString("sensitiveFileSize");
        strategyMatchCondition.setSensitiveFileSize(JSON.parseObject(sensitiveFileSize,ConditionToReqTools.class));

        String workHour = obj.getString("workHour");
        strategyMatchCondition.setWrokingTimeToday(JSON.parseObject(workHour, WrokingTimeToday.class));

        return strategyMatchCondition;
    }


    public ConditionToIntegerListTools conditionToIntegerListTools(JSONObject obj) {
        ConditionToIntegerListTools conditionToIntegerListTools = new ConditionToIntegerListTools();
        conditionToIntegerListTools.setIntList(JSONObject.parseArray(obj.getString("list"), Integer.class));
        conditionToIntegerListTools.setInclude(obj.getInteger("include"));
        return conditionToIntegerListTools;
    }

    public ConditionToLongListTools conditionToLongListTools(JSONObject obj) {
        ConditionToLongListTools conditionToLongListTools = new ConditionToLongListTools();
        conditionToLongListTools.setLongList(JSONObject.parseArray(obj.getString("list"), Long.class));
        conditionToLongListTools.setInclude(obj.getInteger("include"));
        return conditionToLongListTools;
    }

    public ConditionToStringListTools conditionToStringListTools(JSONObject obj) {
        ConditionToStringListTools conditionToStringListTools = new ConditionToStringListTools();
        conditionToStringListTools.setToolList(JSONObject.parseArray(obj.getString("list"), String.class));
        conditionToStringListTools.setInclude(obj.getInteger("include"));
        return conditionToStringListTools;
    }

    public ConditionToTuple2ListTools conditionToTuple2ListTools(JSONObject obj) {
        ConditionToTuple2ListTools conditionToTuple2ListTools = new ConditionToTuple2ListTools();
        conditionToTuple2ListTools.setToolList(JSONObject.parseArray(obj.getString("list"), String.class));
        conditionToTuple2ListTools.setInclude(obj.getInteger("include"));
        return conditionToTuple2ListTools;
    }

    public UrlParsingTool urlParsingTool(JSONObject obj) {
        UrlParsingTool urlParsingTools = new UrlParsingTool();
        List<UrlContent> urlList = new ArrayList<>();
        List<String> strings = JSONObject.parseArray(obj.getString("list"), String.class);

        for (String string : strings) {
            JSONObject obj1 = JSON.parseObject(string);
            String content = obj1.getString("content");

            Integer reg = obj1.getInteger("reg");
            urlList.add(new UrlContent(content, reg));
        }

        urlParsingTools.setUrlList(urlList);
        return urlParsingTools;
    }
}
