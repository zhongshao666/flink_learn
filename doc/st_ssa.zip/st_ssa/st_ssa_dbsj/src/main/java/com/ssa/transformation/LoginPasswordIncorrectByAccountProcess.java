package com.ssa.transformation;

import com.ssa.bean.AssetLog;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import com.ssa.mapfun.ConditionTOMarking;
import com.ssa.mapfun.ParsingZkSource;
import com.ssa.matchrule.StrategyRuleToCalculate;
import com.ssa.strategy.StrategyMatch;
import org.apache.flink.api.common.state.StateTtlConfig;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.KeyedBroadcastProcessFunction;
import org.apache.flink.util.Collector;

import java.util.LinkedList;
import java.util.Optional;


//keyBy account

/**
 * 密码连续错误(账号)
 */
public class LoginPasswordIncorrectByAccountProcess extends KeyedBroadcastProcessFunction<String, AssetLog, Tuple4<Integer, Integer, String, String>,AssetLog> {
    private ValueState<LinkedList<Long>> userLoginTimeQueue;
    int times;
    StrategyMatch strategyMatch ;
    private ParsingZkSource parsingZkSource;
    private StrategyRuleToCalculate strategyRule;
    private ParameterTool parameterTool;

    @Override
    public void open(Configuration parameters) throws Exception {
        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        strategyMatch = new StrategyMatch();
        parsingZkSource=new ParsingZkSource();
        StateTtlConfig stateTtlConfig = StateTtlConfig.newBuilder(Time.minutes(30))
                .setUpdateType(StateTtlConfig.UpdateType.OnCreateAndWrite)
                .setStateVisibility(StateTtlConfig.StateVisibility.NeverReturnExpired)
                .disableCleanupInBackground()
                .cleanupFullSnapshot()
                .build();
        ValueStateDescriptor<LinkedList<Long>> userLoginTimeDesc = new ValueStateDescriptor<>("userLoginTimeQueue", TypeInformation.of(new TypeHint<LinkedList<Long>>() {
        }));
        userLoginTimeDesc.enableTimeToLive(stateTtlConfig);
        userLoginTimeQueue = getRuntimeContext().getState(userLoginTimeDesc);

        strategyRule = new StrategyRuleToCalculate();
    }

    @Override
    public void processElement(AssetLog assetLog, ReadOnlyContext readOnlyContext, Collector<AssetLog> collector) throws Exception {
        //返回码为密码错误
        if(strategyRule.strategySwitch(parameterTool.get("strategy.id.stg02080101")) && AssetLogConstants.requestStatus.SSFAIL.getValues().equals(assetLog.getRequestStatus())&& Optional.ofNullable(strategyMatch.getStrategyMatchCondition()).isPresent()) {
            times = strategyMatch.getStrategyMatchCondition().getLoginFrequency().getTimes();
            if (userLoginTimeQueue.value() == null) {
                LinkedList<Long> linkedList = new LinkedList<>();
                linkedList.addLast(assetLog.getRequestTime());
                userLoginTimeQueue.update(linkedList);
            } else {
                LinkedList<Long> value = userLoginTimeQueue.value();
                value.addLast(assetLog.getRequestTime());
                userLoginTimeQueue.update(value);
            }
            if (userLoginTimeQueue.value().size() > times) {
                ConditionTOMarking.reSetFrequencyAlarmModule(userLoginTimeQueue.value(), userLoginTimeQueue.value().size() - times);
            }

            if (userLoginTimeQueue.value().size() == times) {
                if ((assetLog.getRequestTime() - userLoginTimeQueue.value().getFirst()) <
                        ConditionTOMarking.transFormationTime(strategyMatch.getStrategyMatchCondition().getLoginFrequency().getTime(),
                                strategyMatch.getStrategyMatchCondition().getLoginFrequency().getUnit())) {
                    //打标
                    ConditionTOMarking.setStrategy(assetLog, strategyMatch, CommonConstants.RiskLevel.HIGH_RISK.getVal());
                }
            }
        }

        collector.collect(assetLog);
    }

    @Override
    public void processBroadcastElement(Tuple4<Integer, Integer, String, String> integerIntegerStringStringTuple4, Context context, Collector<AssetLog> collector) throws Exception {
        String filterStrategy = AssetLogConstants.strategyLabelType.PASSWORD_INCORRECT_ACCOUNT.getVal();
        if (integerIntegerStringStringTuple4.f0 == CommonConstants.ZkDataType.RISK_TYPE.getVal()) {
            StrategyMatch strategyMatchParsing = parsingZkSource.parsingZkJson(integerIntegerStringStringTuple4.f3);
            if (filterStrategy.equals(strategyMatchParsing.getStrategy())) {
                if (integerIntegerStringStringTuple4.f1 == CommonConstants.OperateType.ADD.getVal() || integerIntegerStringStringTuple4.f1 == CommonConstants.OperateType.UPDATE.getVal()) {
                    strategyMatch = strategyMatchParsing;
                }
            }
        }
    }

}
