package com.ssa.strategy;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Administrator
 */
@Data
public class StrategyMatchCondition {
    /**
     * 模型黑名单获取近几天的利希纳数据
     */
    private Integer getOfflineDays;

    /**
     * 请求状态 1信息提示 2成功 3重定向 4客户端错误 5服务器错误
     */
    private Integer reqStatus = 0;
    /**
     * 状态码
     */
    private List<Integer> statusCode = new ArrayList<>();
    /**
     * 敏感数据标签code
     */
    private List<String> labelCode = new ArrayList<>();
    /**
     * 距离上次登录的天数
     */
    private Integer loginIntervalDay;
    /**
     * 最高权限账号
     */
    private List<String> maximumAuthorityAccount = new ArrayList<>();
    /**
     * 敏感等级 S1 S2 S3
     */
    private List<String> sensitiveLevel = new ArrayList<>();
    /**
     * 单次请求感数据数量
     */
    private Integer sensitiveDataCount;
    /**
     * 接口
     */
    private ConditionToLongListTools interfaceIds;
    /**
     * 账号
     */
    private ConditionToStringListTools userAccount;
    /**
     * 请求时间
     */
    private DateTime dateTime;
    /**
     * 每月几号
     */
    private ConditionToIntegerListTools monthTime;
    /**
     * 0-6 0周日 1-6周一到周六
     */
    private ConditionToIntegerListTools weekTime;
    /**
     * 每天几点
     */
    private ConditionToIntegerListTools dateTimeDay;
    /**
     * 客户端ip
     */
    private ConditionToTuple2ListTools clientAllIps;
    /**
     * 客户端工具
     */
    private ConditionToStringListTools clientTools;
    /**
     * 请求方式
     */
    private ConditionToStringListTools reqMethod;
    /**
     * url
     */
    private UrlParsingTool urlParsingTool;
    /**
     * referer关键字
     */
    private ConditionToStringListTools refererKeywords;
    /**
     * cookie关键字
     */
    private ConditionToStringListTools cookieKeywords;
    /**
     * 请求关键字(包括请求头、请求体)
     */
    private ConditionToStringListTools reqKeywords;
    /**
     * 响应体关键字
     */
    private ConditionToStringListTools resBodyKeywords;
    /**
     * 响应时长
     */
    private CostTime costTime;
    /**
     * 响应体大小
     */
    private ConditionToReqTools resBodySize;
    /**
     * 触发频率
     */
    private ConditionToFrequencyTools triggerFrequency;
    /**
     * 登录失败频率
     */
    private ConditionToFrequencyTools loginFrequency;
    /**
     * 敏感数据大小
     */
    private ConditionToReqTools sensitiveDataSize;
    /**
     * 敏感文件大小
     */
    private ConditionToReqTools sensitiveFileSize;
    /**
     * 工作时间
     */
    private WrokingTimeToday wrokingTimeToday;
    /**
     * 比较对象，
     */
    private String operationValue;
    /**
     * 方差参数
     */
    private Double variance;
}