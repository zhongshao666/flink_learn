package com.ssa.source;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ssa.bean.OfflineData;
import com.ssa.constants.CommonConstants;
import com.ssa.utils.CuratorOperator;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.recipes.cache.PathChildrenCache;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.recipes.cache.PathChildrenCacheEvent;
import org.apache.flink.streaming.api.functions.source.RichSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.sql.*;


/**
 * @author Administrator
 * @sole ClickHouseZk离线数据源
 */
public class ClickHouseZkSource extends RichSourceFunction<OfflineData> {

    private static final Logger logger = LoggerFactory.getLogger(ClickHouseZkSource.class);
    CuratorOperator curatorOperator = null;
    SourceContext<OfflineData> sourceContext = null;
    private ParameterTool parameterTool;

    static {
        try {
            Class.forName("ru.yandex.clickhouse.ClickHouseDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig()
                .getGlobalJobParameters();
        curatorOperator = new CuratorOperator(parameterTool.get("zookeeper.url"));

    }

    @Override
    public void run(SourceContext<OfflineData> ctx) throws Exception {
        sourceContext = ctx;
        final PathChildrenCache pathChildrenCacheOffline = new PathChildrenCache(curatorOperator.client, parameterTool.get("zookeeper.strategy.config.offlinetask.path"), true);

        childrenListenOffline(pathChildrenCacheOffline);

        while (true) {
            Thread.sleep(10000);
        }
    }

    @Override
    public void cancel() {

    }

    public void childrenListenOffline(PathChildrenCache pathChildrenCache) throws Exception {
        pathChildrenCache.start(PathChildrenCache.StartMode.POST_INITIALIZED_EVENT);
        pathChildrenCache.getListenable().addListener((curatorFramework, event) -> {

            if (event.getType().equals(PathChildrenCacheEvent.Type.INITIALIZED)) {
                logger.info("初始化zookeeper监听完成.........");
            } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_ADDED)) {
                jdbcConnectChild(event, "add");
            } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_REMOVED)) {
            } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_UPDATED)) {
                jdbcConnectChild(event, "update");
            }
        });
    }

    public void jdbcConnectChild(PathChildrenCacheEvent event, String code) {
        String zkData = new String(event.getData().getData());
        JSONObject obj = JSON.parseObject(zkData);
        String table = obj.getString("tableName");
        int status = obj.getInteger("status");
        if (status == 1) {

            String address = "jdbc:clickhouse://" + parameterTool.get("clickhouse.access.hosts") + "/" + parameterTool.get("clickHouse.DatabaseDM");

            try (Connection connection = DriverManager.getConnection(address, parameterTool.get("clickhouse.access.user"), parameterTool.get("clickhouse.access.password"));
                 Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery("SELECT * FROM " + table)) {
                while (resultSet.next()) {
                    OfflineData offlineData = new OfflineData();
                    offlineData.setOfflineTableType(table);
                    logger.info("{}, offline data : {}", code, table);
                    if (CommonConstants.OfflineTableType.SENSITIVE_FIRST_DOWNLOAD.getVal().equals(table)) {
                        setSensitiveFirstDown(resultSet, offlineData);
                    } else if (CommonConstants.OfflineTableType.SENSITIVE_ABNORMAL_CLIENT_DOWNLOAD.getVal().equals(table)) {
                        setSensitiveAbnormalDown(resultSet, offlineData);
                    } else if (CommonConstants.OfflineTableType.SENSITIVE_TABLE_DOWNLOAD.getVal().equals(table)) {
                        setSensitiveTableDown(resultSet, offlineData);
                    } else if (CommonConstants.OfflineTableType.SENSITIVE_DATABASE_DOWNLOAD.getVal().equals(table)) {
                        setSensitiveDatabaseDown(resultSet, offlineData);
                    } else if (CommonConstants.OfflineTableType.SENSITIVE_SILENCE_USER_DOWNLOAD.getVal().equals(table)) {
                        setSensitiveSilenceUserDown(resultSet, offlineData);
                    } else if (CommonConstants.OfflineTableType.ZOMBIE_ACCOUNT.getVal().equals(table)) {
                        setZombieDown(resultSet, offlineData);
                    } else if (CommonConstants.OfflineTableType.ANOTHER_LOGIN.getVal().equals(table)) {
                        setAnotherLoginDown(resultSet, offlineData);
                    } else if (CommonConstants.OfflineTableType.MACHINE_OFFLINE_TABLE.getVal().equals(table)) {
                        setModelMachine(resultSet,offlineData);
                    }
                    sourceContext.collect(offlineData);
                }
            } catch (Exception e) {
                logger.error("query error", e);
            }
        }
    }

    public void setSensitiveFirstDown(ResultSet resultSet, OfflineData offlineData) throws SQLException {
        offlineData.setAccount(resultSet.getString("account"));
        offlineData.setUpdateDate(resultSet.getString("update_date"));
    }

    public void setSensitiveAbnormalDown(ResultSet resultSet, OfflineData offlineData) throws SQLException {
        offlineData.setClientIp(resultSet.getString("client_ip"));
        offlineData.setClientMac(resultSet.getString("client_mac"));
        offlineData.setAccount(resultSet.getString("account"));
        offlineData.setUpdateDate(resultSet.getString("update_date"));
    }

    public void setSensitiveTableDown(ResultSet resultSet, OfflineData offlineData) throws SQLException {
        offlineData.setClientIp(resultSet.getString("client_ip"));
        offlineData.setAccount(resultSet.getString("account"));
        offlineData.setCommonTable(resultSet.getString("sensitive_table"));
        offlineData.setUpdateDate(resultSet.getString("update_date"));
    }

    public void setSensitiveDatabaseDown(ResultSet resultSet, OfflineData offlineData) throws SQLException {
        offlineData.setClientIp(resultSet.getString("client_ip"));
        offlineData.setAccount(resultSet.getString("account"));
        offlineData.setInstanceName(resultSet.getString("database_name"));
        offlineData.setUpdateDate(resultSet.getString("update_date"));
    }

    public void setSensitiveSilenceUserDown(ResultSet resultSet, OfflineData offlineData) throws SQLException {
        offlineData.setAccount(resultSet.getString("account"));
        offlineData.setUpdateDate(resultSet.getString("update_date"));
    }

    public void setZombieDown(ResultSet resultSet, OfflineData offlineData) throws SQLException {
        offlineData.setAccount(resultSet.getString("account"));
        offlineData.setUpdateDate(resultSet.getString("update_date"));
    }

    public void setAnotherLoginDown(ResultSet resultSet, OfflineData offlineData) throws SQLException {
        offlineData.setClientIp(resultSet.getString("client_ip"));
        offlineData.setAccount(resultSet.getString("account"));
        offlineData.setUpdateDate(resultSet.getString("update_date"));
    }

    public void setModelMachine(ResultSet resultSet , OfflineData offlineData) throws SQLException {
        offlineData.setClientMac(resultSet.getString("client_mac"));
        offlineData.setRarity(resultSet.getDouble("rarity"));
    }

}
