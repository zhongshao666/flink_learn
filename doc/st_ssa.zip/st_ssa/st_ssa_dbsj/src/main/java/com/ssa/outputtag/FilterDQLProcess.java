package com.ssa.outputtag;

import com.ssa.DbsjMain;
import com.ssa.bean.AssetLog;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author : hld
 * @Date ： 2021/4/9
 * @Time : 13:43
 * @role ：
 */
public class FilterDQLProcess extends ProcessFunction<AssetLog, AssetLog> {

    private final Logger logger = LoggerFactory.getLogger(FilterDQLProcess.class);

    @Override
    public void processElement(AssetLog value, Context ctx, Collector<AssetLog> out) throws Exception {

        if (AssetLogConstants.operationTypeCatalog.CTDML.getValues() == value.getOperationType().intValue() &&
                "SELECT".equalsIgnoreCase(value.getOperationCommand())) {
            ctx.output(DbsjMain.DQLOperation, value);
        } else {
            out.collect(value);
        }
    }
}
