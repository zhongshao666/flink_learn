package com.ssa.transformation;

import com.ssa.bean.AssetLog;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import com.ssa.mapfun.ConditionTOMarking;
import com.ssa.mapfun.ParsingZkSource;
import com.ssa.matchrule.StrategyRuleToCalculate;
import com.ssa.strategy.StrategyMatch;
import org.apache.flink.api.common.state.StateTtlConfig;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.KeyedBroadcastProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;
// keyBy账号

/**
 * 账号共享
 */
public class AccountSharingProcess extends KeyedBroadcastProcessFunction<String, AssetLog, Tuple4<Integer, Integer, String, String>, AssetLog> {
    private static final Logger logger = LoggerFactory.getLogger(AccountSharingProcess.class);
    //<ip,出现次数>
    private ValueState<HashMap<String, Integer>> ipMap;
    //<请求时间,ip>
    private ValueState<LinkedList<Tuple2<String, Long>>> timeQueue;
    private StrategyMatch strategyMatch;
    private ParsingZkSource parsingZkSource;
    private StrategyRuleToCalculate strategyRule;
    private ParameterTool parameterTool;


    @Override
    public void open(Configuration parameters) throws Exception {
        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        strategyMatch = new StrategyMatch();
        parsingZkSource = new ParsingZkSource();
        StateTtlConfig stateTtlConfig = StateTtlConfig.newBuilder(Time.minutes(30))
                .setUpdateType(StateTtlConfig.UpdateType.OnCreateAndWrite)
                .setStateVisibility(StateTtlConfig.StateVisibility.NeverReturnExpired)
                .disableCleanupInBackground()
                .cleanupFullSnapshot()
                .build();
        ValueStateDescriptor<HashMap<String, Integer>> mapDesc = new ValueStateDescriptor<>("ipMap", TypeInformation.of(new TypeHint<HashMap<String, Integer>>() {
        }));
        ValueStateDescriptor<LinkedList<Tuple2<String, Long>>> listDesc = new ValueStateDescriptor<LinkedList<Tuple2<String, Long>>>("timeQueue", TypeInformation.of(new TypeHint<LinkedList<Tuple2<String, Long>>>() {
        }));

        mapDesc.enableTimeToLive(stateTtlConfig);
        listDesc.enableTimeToLive(stateTtlConfig);
        ipMap = getRuntimeContext().getState(mapDesc);
        timeQueue = getRuntimeContext().getState(listDesc);


        strategyRule = new StrategyRuleToCalculate();
    }

    @Override
    public void processElement(AssetLog assetLog, ReadOnlyContext readOnlyContext, Collector<AssetLog> collector) throws Exception {

        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg02060101"))) {

            //第一次进process 或 ttl超时变为null
            if (timeQueue.value() == null) {
                LinkedList<Tuple2<String, Long>> linkedList = new LinkedList<>();
                linkedList.addLast(new Tuple2<>(assetLog.getClientIp(), assetLog.getRequestTime()));
                timeQueue.update(linkedList);

                HashMap<String, Integer> hashMap = new HashMap<>();
                hashMap.put(assetLog.getClientIp(), 1);
                ipMap.update(hashMap);
            } else {
                LinkedList<Tuple2<String, Long>> list = timeQueue.value();
                list.addLast(new Tuple2<>(assetLog.getClientIp(), assetLog.getRequestTime()));
                timeQueue.update(list);

                HashMap<String, Integer> map = ipMap.value();
                if (map.containsKey(assetLog.getClientIp())) {
                    map.replace(assetLog.getClientIp(), map.get(assetLog.getClientIp()) + 1);
                } else {
                    map.put(assetLog.getClientIp(), 1);
                }
                ipMap.update(map);
            }


            if (Optional.ofNullable(strategyMatch.getStrategyMatchCondition()).isPresent()) {
                //维护map中过期key
                if (timeQueue.value().size() > 1) {
                    LinkedList<Tuple2<String, Long>> linkedList = timeQueue.value();
                    HashMap<String, Integer> hashMap = ipMap.value();

                    while (true){
                        Tuple2<String, Long> tuple2 = linkedList.getFirst();

                        if ((assetLog.getRequestTime() - tuple2.f1) > ConditionTOMarking.transFormationTime(strategyMatch.getStrategyMatchCondition().getLoginFrequency().getTime(),
                                strategyMatch.getStrategyMatchCondition().getLoginFrequency().getUnit())) {

                            if (hashMap.get(tuple2.f0) > 1) {
                                hashMap.replace(tuple2.f0, hashMap.get(tuple2.f0) - 1);
                            } else {
                                hashMap.remove(tuple2.f0);
                            }
                            linkedList.poll();
                        } else break;
                    }
                }

                if (timeQueue.value().size() > strategyMatch.getStrategyMatchCondition().getLoginFrequency().getTimes()) {
                    if ((assetLog.getRequestTime() - timeQueue.value().getFirst().f1) < ConditionTOMarking.transFormationTime(strategyMatch.getStrategyMatchCondition().getLoginFrequency().getTime(),
                            strategyMatch.getStrategyMatchCondition().getLoginFrequency().getUnit()) && ipMap.value().size() > 2) {
                        //打标
                        ConditionTOMarking.setStrategy(assetLog, strategyMatch, strategyMatch.getRiskLevel());
                    }
                }
            }
        }


        collector.collect(assetLog);

    }

    @Override
    public void processBroadcastElement(Tuple4<Integer, Integer, String, String> integerIntegerStringStringTuple4, Context context, Collector<AssetLog> collector) throws Exception {
        String filterStrategy = AssetLogConstants.strategyLabelType.ACCOUNT_SHARING.getVal();
        if (integerIntegerStringStringTuple4.f0 == CommonConstants.ZkDataType.RISK_TYPE.getVal()) {
            StrategyMatch strategyMatchParsing = parsingZkSource.parsingZkJson(integerIntegerStringStringTuple4.f3);
            if (filterStrategy.equals(strategyMatchParsing.getStrategy())) {
                if (integerIntegerStringStringTuple4.f1 == CommonConstants.OperateType.ADD.getVal() || integerIntegerStringStringTuple4.f1 == CommonConstants.OperateType.UPDATE.getVal()) {
                    strategyMatch = strategyMatchParsing;
                }
            }
        }
    }
}
