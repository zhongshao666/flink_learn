package com.ssa.keyselectors;

import com.ssa.bean.AssetLog;
import org.apache.flink.api.java.functions.KeySelector;

public class AccountKeySelector implements KeySelector<AssetLog,String> {

    @Override
    public String getKey(AssetLog assetLog) throws Exception {
        return assetLog.getOsUserName();
    }
}
