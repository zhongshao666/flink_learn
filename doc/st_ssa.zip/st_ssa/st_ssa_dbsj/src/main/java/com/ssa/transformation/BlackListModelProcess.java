package com.ssa.transformation;

import com.ssa.bean.AssetLog;
import com.ssa.bean.OfflineData;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import com.ssa.mapfun.ConditionTOMarking;
import com.ssa.matchrule.StrategyRuleToCalculate;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.BroadcastProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

/**
 * 模型黑名单
 */
public class BlackListModelProcess extends BroadcastProcessFunction<AssetLog, OfflineData, AssetLog> {
    private static final Logger logger = LoggerFactory.getLogger(BlackListModelProcess.class);

    private HashSet<String> blacklistIpSetFZWL;
    private HashSet<String> blacklistIpSetHXYD;
    private HashSet<String> blacklistIpSetSJXL;
    private HashSet<String> blacklistIpSetSJXLSEN;
    private HashSet<String> blacklistAccountSetFZWL;
    private HashSet<String> blacklistAccountSetHXYD;
    private HashSet<String> blacklistAccountSetSJXL;
    private HashSet<String> blacklistAccountSetSJXLSEN;
    private HashSet<String> blacklistAccountSetFALLACCOUNT;
    private HashSet<String> blacklistMacSetFZWL;
    private HashSet<String> blacklistMacSetHXYD;
    private HashSet<String> blacklistMacSetSJXL;
    private HashSet<String> blacklistMacSetSJXLSEN;
    private HashSet<String> blacklistHostSetFZWL;
    private HashSet<String> blacklistHostSetHXYD;
    private HashSet<String> blacklistHostSetSJXL;
    private HashSet<String> blacklistHostSetSJXLSEN;

    private StrategyRuleToCalculate strategyRule;
    
    private ParameterTool parameterTool;

    @Override
    public void open(Configuration parameters) throws Exception {
        
        parameterTool = (ParameterTool)getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        
        blacklistIpSetFZWL = new HashSet<>();
        blacklistIpSetHXYD = new HashSet<>();
        blacklistIpSetSJXL = new HashSet<>();
        blacklistIpSetSJXLSEN = new HashSet<>();
        blacklistAccountSetFZWL = new HashSet<>();
        blacklistAccountSetHXYD = new HashSet<>();
        blacklistAccountSetSJXL = new HashSet<>();
        blacklistAccountSetSJXLSEN = new HashSet<>();
        blacklistAccountSetFALLACCOUNT = new HashSet<>();
        blacklistMacSetFZWL = new HashSet<>();
        blacklistMacSetHXYD = new HashSet<>();
        blacklistMacSetSJXL = new HashSet<>();
        blacklistMacSetSJXLSEN = new HashSet<>();
        blacklistHostSetFZWL = new HashSet<>();
        blacklistHostSetHXYD = new HashSet<>();
        blacklistHostSetSJXL = new HashSet<>();
        blacklistHostSetSJXLSEN = new HashSet<>();

        strategyRule = new StrategyRuleToCalculate();
    }

    @Override
    public void processElement(AssetLog assetLog, ReadOnlyContext readOnlyContext, Collector<AssetLog> collector) throws Exception {

        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg06010102"))) {
            checkIp(blacklistIpSetFZWL, assetLog, AssetLogConstants.modelType.FZWL.getValues());
        }
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg06010106"))) {
            checkIp(blacklistIpSetHXYD, assetLog, AssetLogConstants.modelType.HXYD.getValues());
        }
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg0601010a"))) {
            checkIp(blacklistIpSetSJXL, assetLog, AssetLogConstants.modelType.SJXL.getValues());
        }
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg0601010e"))) {
            checkIp(blacklistIpSetSJXLSEN, assetLog, AssetLogConstants.modelType.SJXLSEN.getValues());
        }
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg06010103"))) {
            checkAccount(blacklistAccountSetFZWL, assetLog, AssetLogConstants.modelType.FZWL.getValues());
        }
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg06010107"))) {
            checkAccount(blacklistAccountSetHXYD, assetLog, AssetLogConstants.modelType.HXYD.getValues());
        }
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg0601010b"))) {
            checkAccount(blacklistAccountSetSJXL, assetLog, AssetLogConstants.modelType.SJXL.getValues());
        }
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg0601010f"))) {
            checkAccount(blacklistAccountSetSJXLSEN, assetLog, AssetLogConstants.modelType.SJXLSEN.getValues());
        }
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg06010113"))) {
            checkAccount(blacklistAccountSetFALLACCOUNT, assetLog, AssetLogConstants.modelType.FALLACCOUNT.getValues());
        }
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg06010104"))) {
            checkMac(blacklistMacSetFZWL, assetLog, AssetLogConstants.modelType.FZWL.getValues());
        }
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg06010108"))) {
            checkMac(blacklistMacSetHXYD, assetLog, AssetLogConstants.modelType.HXYD.getValues());
        }
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg0601010c"))) {
            checkMac(blacklistMacSetSJXL, assetLog, AssetLogConstants.modelType.SJXL.getValues());
        }
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg06010111"))) {
            checkMac(blacklistMacSetSJXLSEN, assetLog, AssetLogConstants.modelType.SJXLSEN.getValues());
        }
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg06010105"))) {
            checkHost(blacklistHostSetFZWL, assetLog, AssetLogConstants.modelType.FZWL.getValues());
        }
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg06010109"))) {
            checkHost(blacklistHostSetHXYD, assetLog, AssetLogConstants.modelType.HXYD.getValues());
        }
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg0601010d"))) {
            checkHost(blacklistHostSetSJXL, assetLog, AssetLogConstants.modelType.SJXL.getValues());
        }
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg06010112"))) {
            checkHost(blacklistHostSetSJXLSEN, assetLog, AssetLogConstants.modelType.SJXLSEN.getValues());
        }

        collector.collect(assetLog);

    }

    @Override
    public void processBroadcastElement(OfflineData offlineData, Context context, Collector<AssetLog> collector) throws Exception {

            String offlineTableType = offlineData.getOfflineTableType();
            if (CommonConstants.OfflineTableType.MODEL_BLACKLIST.getVal().equals(offlineTableType)) {
                if (offlineData.getDataType().equals(CommonConstants.DataType.DBSJ.getVal())) {
                    if (offlineData.getModelType().equals(AssetLogConstants.modelType.FZWL.getValues())) {
                        addSetFZWL(offlineData);
                    } else if (offlineData.getModelType().equals(AssetLogConstants.modelType.HXYD.getValues())) {
                        addSetHXYD(offlineData);
                    } else if (offlineData.getModelType().equals(AssetLogConstants.modelType.SJXL.getValues())) {
                        addSetSJXL(offlineData);
                    } else if (offlineData.getModelType().equals(AssetLogConstants.modelType.SJXLSEN.getValues())) {
                        addSetSJXLSEN(offlineData);
                    } else if (offlineData.getModelType().equals(AssetLogConstants.modelType.FALLACCOUNT.getValues())) {
                        addSetFALLACCOUNT(offlineData);
                    }

                }
            }
    }


    public void addSetFZWL(OfflineData offlineData) {
        if (AssetLogConstants.blackType.IP.getValues().equals(offlineData.getBlackType())) {
            blacklistIpSetFZWL.add(offlineData.getTypeValue());
        } else if (AssetLogConstants.blackType.ACCOUNT.getValues().equals(offlineData.getBlackType())) {
            blacklistAccountSetFZWL.add(offlineData.getTypeValue());
        } else if (AssetLogConstants.blackType.MAC.getValues().equals(offlineData.getBlackType())) {
            blacklistMacSetFZWL.add(offlineData.getTypeValue());
        } else if (AssetLogConstants.blackType.HOST.getValues().equals(offlineData.getBlackType())) {
            blacklistHostSetFZWL.add(offlineData.getTypeValue());
        }
    }

    public void addSetHXYD(OfflineData offlineData) {
        if (AssetLogConstants.blackType.IP.getValues().equals(offlineData.getBlackType())) {
            blacklistIpSetHXYD.add(offlineData.getTypeValue());
        } else if (AssetLogConstants.blackType.ACCOUNT.getValues().equals(offlineData.getBlackType())) {
            blacklistAccountSetHXYD.add(offlineData.getTypeValue());
        } else if (AssetLogConstants.blackType.MAC.getValues().equals(offlineData.getBlackType())) {
            blacklistMacSetHXYD.add(offlineData.getTypeValue());
        } else if (AssetLogConstants.blackType.HOST.getValues().equals(offlineData.getBlackType())) {
            blacklistHostSetHXYD.add(offlineData.getTypeValue());
        }
    }

    public void addSetSJXL(OfflineData offlineData) {
        if (AssetLogConstants.blackType.IP.getValues().equals(offlineData.getBlackType())) {
            blacklistIpSetSJXL.add(offlineData.getTypeValue());
        } else if (AssetLogConstants.blackType.ACCOUNT.getValues().equals(offlineData.getBlackType())) {
            blacklistAccountSetSJXL.add(offlineData.getTypeValue());
        } else if (AssetLogConstants.blackType.MAC.getValues().equals(offlineData.getBlackType())) {
            blacklistMacSetSJXL.add(offlineData.getTypeValue());
        } else if (AssetLogConstants.blackType.HOST.getValues().equals(offlineData.getBlackType())) {
            blacklistHostSetSJXL.add(offlineData.getTypeValue());
        }
    }

    public void addSetSJXLSEN(OfflineData offlineData) {
        if (AssetLogConstants.blackType.IP.getValues().equals(offlineData.getBlackType())) {
            blacklistIpSetSJXLSEN.add(offlineData.getTypeValue());
        } else if (AssetLogConstants.blackType.ACCOUNT.getValues().equals(offlineData.getBlackType())) {
            blacklistAccountSetSJXLSEN.add(offlineData.getTypeValue());
        } else if (AssetLogConstants.blackType.MAC.getValues().equals(offlineData.getBlackType())) {
            blacklistMacSetSJXLSEN.add(offlineData.getTypeValue());
        } else if (AssetLogConstants.blackType.HOST.getValues().equals(offlineData.getBlackType())) {
            blacklistHostSetSJXLSEN.add(offlineData.getTypeValue());
        }
    }

    public void addSetFALLACCOUNT(OfflineData offlineData) {
        if (AssetLogConstants.blackType.ACCOUNT.getValues().equals(offlineData.getBlackType())) {
            blacklistAccountSetFALLACCOUNT.add(offlineData.getTypeValue());
        }
    }

    public String getLabel(String type, String model) {

        //1  ip
        if (type.equals(AssetLogConstants.blackType.IP.getValues())) {
            if (model.equals(AssetLogConstants.modelType.FZWL.getValues())) {
                return AssetLogConstants.strategyLabelType.FZWL_IP.getVal();
            } else if (model.equals(AssetLogConstants.modelType.HXYD.getValues())) {
                return AssetLogConstants.strategyLabelType.HXYD_IP.getVal();
            } else if (model.equals(AssetLogConstants.modelType.SJXL.getValues())) {
                return AssetLogConstants.strategyLabelType.SJXL_IP.getVal();
            } else if (model.equals(AssetLogConstants.modelType.SJXLSEN.getValues())) {
                return AssetLogConstants.strategyLabelType.SJXL_SENSITIVE_IP.getVal();
            }

        }
        //2账号
        else if (type.equals(AssetLogConstants.blackType.ACCOUNT.getValues())) {
            if (model.equals(AssetLogConstants.modelType.FZWL.getValues())) {
                return AssetLogConstants.strategyLabelType.FZWL_ACCOUNT.getVal();
            } else if (model.equals(AssetLogConstants.modelType.HXYD.getValues())) {
                return AssetLogConstants.strategyLabelType.HXYD_ACCOUNT.getVal();
            } else if (model.equals(AssetLogConstants.modelType.SJXL.getValues())) {
                return AssetLogConstants.strategyLabelType.SJXL_ACCOUNT.getVal();
            } else if (model.equals(AssetLogConstants.modelType.SJXLSEN.getValues())) {
                return AssetLogConstants.strategyLabelType.SJXL_SENSITIVE_IP.getVal();
            } else if (model.equals(AssetLogConstants.modelType.FALLACCOUNT.getValues())) {
                return AssetLogConstants.strategyLabelType.FALL_ACCOUNT.getVal();
            }
        }
        //3 mac
        else if (type.equals(AssetLogConstants.blackType.MAC.getValues())) {
            if (model.equals(AssetLogConstants.modelType.FZWL.getValues())) {
                return AssetLogConstants.strategyLabelType.FZWL_MAC.getVal();
            } else if (model.equals(AssetLogConstants.modelType.HXYD.getValues())) {
                return AssetLogConstants.strategyLabelType.HXYD_MAC.getVal();
            } else if (model.equals(AssetLogConstants.modelType.SJXL.getValues())) {
                return AssetLogConstants.strategyLabelType.SJXL_MAC.getVal();
            } else if (model.equals(AssetLogConstants.modelType.SJXLSEN.getValues())) {
                return AssetLogConstants.strategyLabelType.SJXL_SENSITIVE_MAC.getVal();
            }
        }
        //4 host
        else if (type.equals(AssetLogConstants.blackType.HOST.getValues())) {
            if (model.equals(AssetLogConstants.modelType.FZWL.getValues())) {
                return AssetLogConstants.strategyLabelType.FZWL_HOST.getVal();
            } else if (model.equals(AssetLogConstants.modelType.HXYD.getValues())) {
                return AssetLogConstants.strategyLabelType.HXYD_HOST.getVal();
            } else if (model.equals(AssetLogConstants.modelType.SJXL.getValues())) {
                return AssetLogConstants.strategyLabelType.SJXL_HOST.getVal();
            } else if (model.equals(AssetLogConstants.modelType.SJXLSEN.getValues())) {
                return AssetLogConstants.strategyLabelType.SJXL_SENSITIVE_MAC.getVal();
            }
        }

        return "";
    }

    public void checkIp(Set<String> set, AssetLog assetLog, String model) {
        if (Optional.ofNullable(assetLog.getClientIp()).isPresent()) {
            for (String s : set) {
                if (s.equals(assetLog.getClientIp())) {
                    ConditionTOMarking.setStrategy(assetLog, getLabel(AssetLogConstants.blackType.IP.getValues(), model), CommonConstants.RiskLevel.HIGH_RISK.getVal());
                    break;
                }
            }
        }
    }

    public void checkAccount(Set<String> set, AssetLog assetLog, String model) {
        if (Optional.ofNullable(assetLog.getAccount()).isPresent()) {
            for (String s : set) {
                if (s.equals(assetLog.getAccount())) {
                    ConditionTOMarking.setStrategy(assetLog, getLabel(AssetLogConstants.blackType.ACCOUNT.getValues(), model), CommonConstants.RiskLevel.HIGH_RISK.getVal());
                }
            }
        }
    }

    public void checkMac(Set<String> set, AssetLog assetLog, String model) {
        if (Optional.ofNullable(assetLog.getClientMac()).isPresent()) {
            for (String s : set) {
                if (s.equals(assetLog.getClientMac())) {
                    ConditionTOMarking.setStrategy(assetLog, getLabel(AssetLogConstants.blackType.MAC.getValues(), model), CommonConstants.RiskLevel.HIGH_RISK.getVal());
                }
            }
        }
    }

    public void checkHost(Set<String> set, AssetLog assetLog, String model) {
        if (Optional.ofNullable(assetLog.getClientHost()).isPresent()) {
            for (String s : set) {
                if (s.equals(assetLog.getClientHost())) {
                    ConditionTOMarking.setStrategy(assetLog, getLabel(AssetLogConstants.blackType.HOST.getValues(), model), CommonConstants.RiskLevel.HIGH_RISK.getVal());
                }
            }
        }
    }
}
