package com.ssa.mapfun;

import com.alibaba.fastjson.JSON;
import com.ssa.bean.SensitiveData;

public class ParsingKafkaSensitive {
    public static SensitiveData parsingKafkaSensitive(String s) {
        return JSON.parseObject(s, SensitiveData.class);
    }
}
