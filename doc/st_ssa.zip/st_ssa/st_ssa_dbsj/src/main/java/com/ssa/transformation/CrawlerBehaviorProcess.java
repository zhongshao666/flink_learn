package com.ssa.transformation;

import com.ssa.bean.AssetLog;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import com.ssa.mapfun.ParsingZkSource;
import com.ssa.matchrule.StrategyRuleToCalculate;
import com.ssa.strategy.StrategyMatch;
import com.ssa.utils.NotLoginOperateUtils;
import com.ssa.utils.VariUtils;
import org.apache.flink.api.common.state.StateTtlConfig;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.KeyedBroadcastProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.stream.Collectors;


/**
 * 爬虫行为访问文件
 */
public class CrawlerBehaviorProcess extends KeyedBroadcastProcessFunction<String, AssetLog,Tuple4<Integer, Integer, String, String>,AssetLog> {
    private static final Logger logger = LoggerFactory.getLogger(CrawlerBehaviorProcess.class);
    //请求时间
    private ValueState<LinkedList<Long>>  timeState;

    private ParameterTool parameterTool;
    private StrategyRuleToCalculate strategyRule;
    private ParsingZkSource parsingZkSource;
    StrategyMatch strategyMatch;
    private NotLoginOperateUtils notLoginOperateUtils = new NotLoginOperateUtils();
    //访问次数
    private Integer count = 5;


    @Override
    public void open(Configuration parameters) throws Exception {

        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        strategyRule = new StrategyRuleToCalculate();
        parsingZkSource = new ParsingZkSource();
        strategyMatch = new StrategyMatch();
        ValueStateDescriptor<LinkedList< Long>> listDesc = new ValueStateDescriptor<LinkedList< Long>>("timeListedIp", TypeInformation.of(new TypeHint<LinkedList< Long>>() {
        }));

        StateTtlConfig stateTtlConfig = StateTtlConfig.newBuilder(Time.minutes(30))
                .setUpdateType(StateTtlConfig.UpdateType.OnCreateAndWrite)
                .setStateVisibility(StateTtlConfig.StateVisibility.NeverReturnExpired)
                .disableCleanupInBackground()
                .cleanupFullSnapshot()
                .build();
        listDesc.enableTimeToLive(stateTtlConfig);
        timeState = getRuntimeContext().getState(listDesc);


    }

    @Override
    public void processElement(AssetLog assetLog, ReadOnlyContext ctx, Collector<AssetLog> out) throws Exception {
        //如果请求状态码 = 不存在文件
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg02120101")) && notLoginOperateUtils.isNoFile(assetLog)) {

            //第一次进入process时，或者ttl超时为空
            if (timeState.value() == null) {
                LinkedList<Long> timeList = new LinkedList<>();
                timeList.add(assetLog.getRequestTime());
                timeState.update(timeList);
            } else {
                LinkedList<Long> timeList = timeState.value();
                timeList.add(assetLog.getRequestTime());
                timeState.update(timeList);

            }
            //访问次数>五次
            if (timeState.value().size() > 5) {
                LinkedList<Long> value = timeState.value();
                value.sort((v1,v2)->v1.compareTo(v2));

                ArrayList<Long> list = new ArrayList<>();
                //计算间隔差值
                for (int i = 0; i < value.size(); i++) {
                    if (i > 0) {
                        long l = value.get(i) - value.get(i - 1);
                        list.add(l);
                    }
                }



            }

            out.collect(assetLog);


        }
    }

    @Override
    public void processBroadcastElement(Tuple4<Integer, Integer, String, String> value, Context ctx, Collector<AssetLog> out) throws Exception {
        String filterStrategy = AssetLogConstants.strategyLabelType.CRAWLER_BEHAVIOR_IP.getVal();
        if (value.f0 == CommonConstants.ZkDataType.RISK_TYPE.getVal()) {
            StrategyMatch strategyMatchParsing = parsingZkSource.parsingZkJson(value.f3);
            if (filterStrategy.equals(strategyMatchParsing.getStrategy())) {
                if (value.f1 == CommonConstants.OperateType.ADD.getVal() || value.f1 == CommonConstants.OperateType.UPDATE.getVal()) {
                    strategyMatch = strategyMatchParsing;
                }
            }
        }
    }
}
