package com.ssa.transformation;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ssa.DbsjMain;
import com.ssa.bean.OfflineData;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.CoProcessFunction;
import org.apache.flink.util.Collector;

/**
 * @author : hld
 * @Date ： 2021/4/25
 * @Time : 14:18
 * @role ：
 */
public class DistrriOutputProcess extends CoProcessFunction<OfflineData, Tuple4<Integer, Integer, String, String>, Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> {

    private Tuple4<Integer, Integer, String, String> tuple4;


    @Override
    public void open(Configuration parameters) throws Exception {

        tuple4 = new Tuple4(1, 1, null, null);
    }

    @Override
    public void processElement1(OfflineData value, Context ctx, Collector<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> out) throws Exception {

        String offlineTableType = value.getOfflineTableType();
        //过滤出来DqlClientIpCoProcess所使用的离线表
        if (CommonConstants.OfflineTableType.SENSITIVE_ABNORMAL_CLIENT_DOWNLOAD.getVal().equals(offlineTableType) ||
                CommonConstants.OfflineTableType.SENSITIVE_TABLE_DOWNLOAD.getVal().equals(offlineTableType) ||
                CommonConstants.OfflineTableType.SENSITIVE_DATABASE_DOWNLOAD.getVal().equals(offlineTableType)) {

            ctx.output(DbsjMain.DQLOperationClientIpTag, new Tuple2<>(value, tuple4));
        }

        //过滤出来DqlAccountCoProcess所使用的离线表
        if (CommonConstants.OfflineTableType.SENSITIVE_ABNORMAL_CLIENT_DOWNLOAD.getVal().equals(offlineTableType) ||
                CommonConstants.OfflineTableType.SENSITIVE_TABLE_DOWNLOAD.getVal().equals(offlineTableType) ||
                CommonConstants.OfflineTableType.SENSITIVE_DATABASE_DOWNLOAD.getVal().equals(offlineTableType) ||
                CommonConstants.OfflineTableType.SENSITIVE_FIRST_DOWNLOAD.getVal().equals(offlineTableType) ||
                CommonConstants.OfflineTableType.SENSITIVE_SILENCE_USER_DOWNLOAD.getVal().equals(offlineTableType)) {

            ctx.output(DbsjMain.DQLOperationAccountTag, new Tuple2<>(value, tuple4));
        }
        //过滤机器请求所使用的离线表
        if (CommonConstants.OfflineTableType.MACHINE_OFFLINE_TABLE.getVal().equals(offlineTableType)) {
            //System.out.println("value+++++++++++++++ = " + value);
            ctx.output(DbsjMain.machineOutputTag, new Tuple2<>(value, tuple4));
        }

        //登录
        if (CommonConstants.OfflineTableType.ANOTHER_LOGIN.getVal().equals(offlineTableType)) {
            ctx.output(DbsjMain.LoginOutput, new Tuple2<>(value, tuple4));
        }
    }

    @Override
    public void processElement2(Tuple4<Integer, Integer, String, String> value, Context ctx, Collector<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> out) throws Exception {
        //过滤出来跨境ip的zk配置参数

        if (value.f0== CommonConstants.ZkDataType.THREAT_IP.getVal()) {
            ctx.output(DbsjMain.DQLOperationAccountTag, new Tuple2<>(null, value));
        }
        //过滤出来内网ip的zk配置参数
        if (value.f0 == CommonConstants.ZkDataType.COMMON_ACCOUNT.getVal() ||
                value.f0 == CommonConstants.ZkDataType.COMMON_IP.getVal()
        ) {
            ctx.output(DbsjMain.LoginOutput, new Tuple2<>(null, value));
        }

        //过滤出常用访问时间段，用于匹配非工作时间下载敏感数据操作
        if (value.f0 == CommonConstants.ZkDataType.COMMON_TIME.getVal()) {
            ctx.output(DbsjMain.DQLOperationClientIpTag, new Tuple2<>(null, value));
            ctx.output(DbsjMain.DQLOperationAccountTag, new Tuple2<>(null, value));
            ctx.output(DbsjMain.LoginOutput, new Tuple2<>(null, value));
        }

        //过滤出策略配置，获取开关风险等级等配置
        if (value.f0 == CommonConstants.ZkDataType.RISK_TYPE.getVal()) {
            String strategy = JSON.parseObject(value.f3).getString("strategy");
            if (AssetLogConstants.strategyLabelType.SENSITIVE_ABNORMAL_CLIENTMAC.getVal().equals(strategy) ||
                    AssetLogConstants.strategyLabelType.SENSITIVE_NONUSE_TABLE.getVal().equals(strategy) ||
                    AssetLogConstants.strategyLabelType.SENSITIVE_NONUSE_DATABASE.getVal().equals(strategy) ||
                    AssetLogConstants.strategyLabelType.SENSITIVE_DOWNLOAD_NONWORKTIME.getVal().equals(strategy) ||
                    AssetLogConstants.strategyLabelType.INTRANET_IP_DOWN.getVal().equals(strategy)) {

                ctx.output(DbsjMain.DQLOperationClientIpTag, new Tuple2<>(null, value));
                ctx.output(DbsjMain.DQLOperationAccountTag, new Tuple2<>(null, value));

            } else if (AssetLogConstants.strategyLabelType.SENSITIVE_FIRST_DOWNLOAD.getVal().equals(strategy) ||
                    AssetLogConstants.strategyLabelType.SENSITIVE_SILENCEACCOUNT_DOWNLOAD.getVal().equals(strategy) ||

                    AssetLogConstants.strategyLabelType.FOREIGN_IP_DOWN.getVal().equals(strategy)) {

                ctx.output(DbsjMain.DQLOperationAccountTag, new Tuple2<>(null, value));
            }

        }
        //过滤出机器请求行为需要的
        if (value.f0 == CommonConstants.ZkDataType.MACHINE_REQUEST.getVal()) {
            //System.out.println("value------------------------------ = " + value);
            ctx.output(DbsjMain.machineOutputTag,new Tuple2<>(null,value));
        }

    }
}
