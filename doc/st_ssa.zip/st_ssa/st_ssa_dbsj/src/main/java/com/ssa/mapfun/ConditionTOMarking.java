package com.ssa.mapfun;

import com.ssa.bean.AssetLog;
import com.ssa.strategy.StrategyMatch;

import java.util.LinkedList;
import java.util.List;

/**
 * @author Administrator
 * @sole strategy打标以及时间转换
 */
public class ConditionTOMarking {

    /**
     * n分钟出现m次告警
     * 当出现次数变小时，缩小linkedList长度
     */
    public static void reSetFrequencyAlarmModule(LinkedList<Long> linkedList, Integer size) {
        for (int i = 0; i < size; i++) {
            linkedList.poll();
        }
    }

    /**
     * 打标
     */
    public static void setStrategy(AssetLog assetLog, StrategyMatch strategyMatch, Integer riskTypeAi) {
        setStrategyMark(assetLog, strategyMatch.getStrategy(), riskTypeAi);
    }

    /**
     * 打标
     */
    public static void setStrategy(AssetLog assetLog, String matchRule, Integer riskTypeAi) {
        setStrategyMark(assetLog, matchRule, riskTypeAi);
    }

    /**
     * 敏感表、字段打标
     */
    public static void setStrategy(AssetLog assetLog, String type, String value, List<String> columns) {
        if ("table".equals(type)) {
            assetLog.getSensitiveTables().add(value);
        } else if ("column".equals(type)) {
            if ("*".equals(value)){
                assetLog.getSensitiveColumns().addAll(columns);
            }else {
                assetLog.getSensitiveColumns().add(value);
            }
        }
    }

    /**
     * 窗口多少分钟
     */
    public static Integer transFormationTime(Integer time, String unit) {
        int longTime = 0;
        if (("ms".equals(unit))) {
            longTime = time;
        } else if ("s".equals(unit)) {
            longTime = time * 1000;
        } else if ("min".equals(unit)) {
            longTime = time * 1000 * 60;
        }

        return longTime;
    }

    /**
     * 提取公共打标类
     *
     * @param assetLog
     * @param matchRule
     * @param riskTypeAi
     */
    private static void setStrategyMark(AssetLog assetLog, String matchRule, Integer riskTypeAi) {

        assetLog.getFlowLabel().add(matchRule);
        assetLog.getAlarmLabel().add(matchRule.substring(0, 6));

        if (assetLog.getRiskTypeAi() == null) {
            assetLog.setRiskTypeAi(riskTypeAi);
        } else {
            assetLog.setRiskTypeAi(Math.max(riskTypeAi, assetLog.getRiskTypeAi()));
        }
    }
}
