package com.ssa.transformation;

import com.ssa.bean.AssetLog;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import com.ssa.matchrule.BroadcastDataMatch;
import com.ssa.matchrule.StrategyRuleToCalculate;
import com.ssa.strategy.StrategyMatch;
import org.apache.flink.api.common.state.StateTtlConfig;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.KeyedBroadcastProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;


/**
 * @author : hld
 * @Date ： 2021/4/13
 * @Time : 17:41
 * @role ：
 */
public class DqlCliPseudoWindowProcess extends KeyedBroadcastProcessFunction<String, AssetLog, Tuple4<Integer, Integer, String, String>, AssetLog> {

    private Logger  logger = LoggerFactory.getLogger(DqlCliPseudoWindowProcess.class);

    private ValueState<LinkedList<Tuple2<Long, Integer>>> downMoreSensData;
    private ValueState<Integer> countRowsAffected;

    private BroadcastDataMatch broadcastDataMatch;

    private Map<String, StrategyMatch> strategyMatchMap;
    private StrategyRuleToCalculate strategyRule;
    private ParameterTool parameterTool;

    private String matchUserType;

    @Override
    public void open(Configuration parameters) throws Exception {
        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        StateTtlConfig stateTtlConfig = StateTtlConfig.newBuilder(Time.minutes(30))
                .setUpdateType(StateTtlConfig.UpdateType.OnCreateAndWrite)
                .setStateVisibility(StateTtlConfig.StateVisibility.NeverReturnExpired)
                .disableCleanupInBackground()
                .cleanupFullSnapshot()
                .build();
        ValueStateDescriptor<LinkedList<Tuple2<Long, Integer>>> downMoreSensDataDesc = new ValueStateDescriptor<LinkedList<Tuple2<Long, Integer>>>("downMoreSensDataDqlClient", TypeInformation.of(new TypeHint<LinkedList<Tuple2<Long, Integer>>>() {
        }));
        downMoreSensDataDesc.enableTimeToLive(stateTtlConfig);
        downMoreSensData = getRuntimeContext().getState(downMoreSensDataDesc);

        countRowsAffected = getRuntimeContext().getState(new ValueStateDescriptor<Integer>("countRowsAffectedDqlClient", Integer.class));

        broadcastDataMatch = new BroadcastDataMatch();
        strategyMatchMap = new HashMap<>();
        strategyRule = new StrategyRuleToCalculate();

        matchUserType="clientIp";
    }

    @Override
    public void processElement(AssetLog value, ReadOnlyContext ctx, Collector<AssetLog> out) throws Exception {

        //敏感数据下载量异常
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg01090101"))) {
            String downMoreIpVal = AssetLogConstants.strategyLabelType.SENSITIVE_DOWN_MORE_IP.getVal();
            strategyRule.downMoreSensData(value, downMoreSensData, countRowsAffected, strategyMatchMap.get(downMoreIpVal),
                    downMoreIpVal, CommonConstants.RiskLevel.SERIOUS.getVal(), logger, matchUserType, value.getClientIp());
        }
        out.collect(value);
    }

    @Override
    public void processBroadcastElement(Tuple4<Integer, Integer, String, String> value, Context ctx, Collector<AssetLog> out) throws Exception {
        broadcastDataMatch.matchStrategyRule(value,AssetLogConstants.strategyLabelType.SENSITIVE_DOWN_MORE_IP.getVal(), strategyMatchMap);
    }
}
