package com.ssa.matchrule;

import com.ssa.bean.AssetLog;
import com.ssa.constants.AssetLogConstants;
import com.ssa.mapfun.ConditionTOMarking;
import com.ssa.strategy.StrategyMatch;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.java.tuple.Tuple2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Serializable;
import java.util.LinkedList;

/**
 * @author : hld
 * @Date ： 2021/4/10
 * @Time : 15:09
 * @role ：匹配单条规则
 */
public class MatchStrategyRule implements Serializable {

    /**
     * 匹配数据标识符
     */
    public Boolean sensitiveType(AssetLog assetLog) {
        boolean flag = false;
        Integer isSensitiveType = assetLog.getIsSensitiveTable();
        if (isSensitiveType != null && isSensitiveType == AssetLogConstants.eSensitiveType.TABLELABEL.getValues().intValue()) {
            flag = true;
        }
        return flag;
    }

    /**
     * 执行下载命令(Outfile)
     */
    public Boolean downCommOutfile(AssetLog assetLog, String download) {
        boolean flag = false;
        if (assetLog.getOperationStatement().toUpperCase().contains(download)) {
            flag = true;
        }
        return flag;
    }

    /**
     * 执行下载命令（OperationCommand）
     */
    public Boolean downOperationCommand(AssetLog assetLog, String download) {
        boolean flag = false;
        if (assetLog.getOperationCommand().equalsIgnoreCase(download)) {
            flag = true;
        }
        return flag;
    }

    /**
     * 数据返回行数是否满足
     */
    public Boolean rowsAffected(AssetLog assetLog, Integer rowsAffected) {
        boolean flag = false;
        Integer rowsAffect = assetLog.getRowsAffected();
        if (rowsAffect != null && rowsAffect >= rowsAffected) {
            flag = true;
        }
        return flag;
    }

    /**
     * 敏感数据下载异常队列判定
     */
    public void queueMatchDownMore(AssetLog assetLog, ValueState<LinkedList<Tuple2<Long, Integer>>> downMoreSensData,
                                   ValueState<Integer> countRowsAffected, StrategyMatch strategyMatch, String code,
                                   Integer riskLabelAi, Logger logger, String matchUserType, String matchUserTypeValue) throws IOException {

        if (downMoreSensData.value() == null) {
            LinkedList<Tuple2<Long, Integer>> tuple2s = new LinkedList<>();
            tuple2s.addLast(new Tuple2<>(assetLog.getRequestTime(), assetLog.getRowsAffected()));
            downMoreSensData.update(tuple2s);
            countRowsAffected.update(assetLog.getRowsAffected());
        } else {
            LinkedList<Tuple2<Long, Integer>> value = downMoreSensData.value();
            value.addLast(new Tuple2<>(assetLog.getRequestTime(), assetLog.getRowsAffected()));
            downMoreSensData.update(value);
            countRowsAffected.update(countRowsAffected.value() + assetLog.getRowsAffected());
        }

        while (true) {
            if (assetLog.getRequestTime() - downMoreSensData.value().getFirst().f0 > ConditionTOMarking.transFormationTime(
                    strategyMatch.getStrategyMatchCondition().getTriggerFrequency().getTime(),
                    strategyMatch.getStrategyMatchCondition().getTriggerFrequency().getUnit())) {
                countRowsAffected.update(countRowsAffected.value() - downMoreSensData.value().getFirst().f1);
                downMoreSensData.value().poll();
            } else {
                break;
            }
        }

        if (countRowsAffected.value() >= Integer.parseInt( strategyMatch.getStrategyMatchCondition().getOperationValue())) {
            logger.info("asset log  download more sensitive data first id : {} , {} : {}, countRowsAffected: {}", assetLog.getFirstId(), matchUserType, matchUserTypeValue,countRowsAffected.value());
            ConditionTOMarking.setStrategy(assetLog, code, riskLabelAi);
        }
    }
}
