package com.ssa.transformation;

import com.alibaba.fastjson.JSON;
import com.ssa.bean.AssetLog;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import com.ssa.mapfun.ConditionTOMarking;
import com.ssa.mapfun.ParsingZkSource;
import com.ssa.matchrule.StrategyRuleToCalculate;
import com.ssa.strategy.StrategyMatch;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.BroadcastProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @author : hld
 * @Date ： 2021/4/12
 * @Time : 16:29
 * @role ：
 */
public class AbnormalOperationDmlProcess extends BroadcastProcessFunction<AssetLog,Tuple4<Integer, Integer, String, String>, AssetLog> {

    private static final Logger logger = LoggerFactory.getLogger(AbnormalOperationDmlProcess.class);
    private StrategyRuleToCalculate strategyRule;
    private ParsingZkSource parsingZkSource;
    private  StrategyMatch strategyMatch;
    private ParameterTool parameterTool;

    @Override
    public void open(Configuration parameters) throws Exception {
        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        strategyRule = new StrategyRuleToCalculate();
        parsingZkSource = new ParsingZkSource();
        strategyMatch = new StrategyMatch();
    }

    @Override
    public void processElement(AssetLog value, ReadOnlyContext ctx, Collector<AssetLog> out) throws Exception {
        boolean flag = false;
        Integer rowsAffected = value.getRowsAffected();
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg05010101")) && value.getIsSensitiveTable() != null && rowsAffected != null &&
                rowsAffected >= Integer.parseInt( strategyMatch.getStrategyMatchCondition().getOperationValue())) {
            flag = true;
        }
        if (flag && (value.getClientIp() != null || value.getAccount() != null)) {
            logger.info("后台变更敏感字段 first_id:{},second_id:{}", value.getFirstId(), value.getSecondId());
            ConditionTOMarking.setStrategy(value, AssetLogConstants.strategyLabelType.SENSITIVE_ABNORMAL_OPERATION.getVal(),
                    CommonConstants.RiskLevel.SERIOUS.getVal());
        }
        out.collect(value);
    }

    @Override
    public void processBroadcastElement(Tuple4<Integer, Integer, String, String> value, Context ctx, Collector<AssetLog> out) throws Exception {
        if (value.f0 == CommonConstants.ZkDataType.RISK_TYPE.getVal()){
            String strategy = JSON.parseObject(value.f3).getString("strategy");
            if (AssetLogConstants.strategyLabelType.SENSITIVE_ABNORMAL_OPERATION.getVal().equals(strategy)){
                 strategyMatch = parsingZkSource.parsingZkJson(value.f3);
            }
        }
    }
}
