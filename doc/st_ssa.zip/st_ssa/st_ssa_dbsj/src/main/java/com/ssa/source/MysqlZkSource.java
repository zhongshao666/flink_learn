package com.ssa.source;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ssa.bean.OfflineData;
import com.ssa.utils.CuratorOperator;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.CuratorFramework;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.recipes.cache.PathChildrenCache;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.recipes.cache.PathChildrenCacheEvent;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.recipes.cache.PathChildrenCacheListener;
import org.apache.flink.streaming.api.functions.source.RichSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.Optional;


public class MysqlZkSource extends RichSourceFunction<OfflineData> {
    private final Logger logger = LoggerFactory.getLogger(MysqlZkSource.class);

    CuratorOperator cto = null;
    SourceContext<OfflineData> sourceContext = null;
    private ParameterTool parameterTool;

    @Override
    public void open(Configuration parameters) throws Exception {

        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig()
                .getGlobalJobParameters();
        Class.forName(parameterTool.get("mysql.class"));
        cto = new CuratorOperator(parameterTool.get("zookeeper.url"));
    }

    @Override
    public void run(SourceContext<OfflineData> ctx) throws Exception {
        sourceContext = ctx;
        final PathChildrenCache pathChildrenCache = new PathChildrenCache(cto.client, parameterTool.get("zookeeper.strategy.mysql.model.path"), true);

        childrenListen(pathChildrenCache, parameterTool.get("zookeeper.strategy.mysql.model.path"));

        while (true) {
            Thread.sleep(10000);
        }
    }

    @Override
    public void cancel() {

    }


    public void childrenListen(PathChildrenCache pathChildrenCache, String nodepath) throws Exception {
        pathChildrenCache.start(PathChildrenCache.StartMode.POST_INITIALIZED_EVENT);
        pathChildrenCache.getListenable().addListener(new PathChildrenCacheListener() {
            @Override
            public void childEvent(CuratorFramework curatorFramework, PathChildrenCacheEvent event) throws Exception {

                if (event.getType().equals(PathChildrenCacheEvent.Type.INITIALIZED)) {
                    logger.info("初始化zookeeper监听完成.........");
                } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_ADDED)) {
                    jdbcConnectChilld(event);
                } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_REMOVED)) {
                } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_UPDATED)) {
                    jdbcConnectChilld(event);
                }
            }
        });
    }

    public void jdbcConnectChilld(PathChildrenCacheEvent event) {
        String zkData = new String(event.getData().getData());
        JSONObject obj = JSON.parseObject(zkData);
        String table = obj.getString("tableName");
        int status = obj.getInteger("status");
        if (status == 1) {


            try (Connection connection = DriverManager.getConnection(parameterTool.get("mysql.url"), parameterTool.get("mysql.user"), parameterTool.get("mysql.passwd"));
                 Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery("select * from " + parameterTool.get("mysql.table.blacklist"))) {
                while (resultSet.next()) {
                    OfflineData offlineData = new OfflineData();

                    offlineData.setOfflineTableType(table);
                    offlineData.setClientIp(resultSet.getString("client_ip"));
                    offlineData.setClientMac(resultSet.getString("client_mac"));
                    offlineData.setAccount(resultSet.getString("account"));
                    offlineData.setCommonTable(resultSet.getString("sensitive_table"));
                    offlineData.setInstanceName(resultSet.getString("database_name"));
                    offlineData.setDataType(resultSet.getString("dataType"));
                    offlineData.setModelType(resultSet.getString("modelType"));
                    offlineData.setBlackType(resultSet.getString("blackType"));
                    offlineData.setTypeValue(resultSet.getString("typeValue"));
                    offlineData.setUpdateDate(resultSet.getString("updateDate"));

                    sourceContext.collect(offlineData);
                }
            } catch (Exception e) {
                logger.error("query error", e);
            }
        }
    }

}
