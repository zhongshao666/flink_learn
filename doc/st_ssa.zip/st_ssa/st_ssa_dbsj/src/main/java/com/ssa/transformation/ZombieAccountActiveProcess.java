package com.ssa.transformation;

import com.ssa.bean.AssetLog;
import com.ssa.bean.OfflineData;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import com.ssa.mapfun.ConditionTOMarking;
import com.ssa.matchrule.StrategyRuleToCalculate;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.KeyedCoProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @author : hld
 * @Date ： 2021/4/14
 * @Time : 9:59
 * @role ：
 */
public class ZombieAccountActiveProcess extends KeyedCoProcessFunction<String, AssetLog, OfflineData, AssetLog> {

    private final Logger logger = LoggerFactory.getLogger(ZombieAccountActiveProcess.class);

    private ValueState<String> zombieAccount;
    private StrategyRuleToCalculate strategyRule;
    private ParameterTool parameterTool;

    @Override
    public void open(Configuration parameters) throws Exception {

        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        zombieAccount = getRuntimeContext().getState(new ValueStateDescriptor<String>("zombieAccountActiveByAccount", String.class));
        strategyRule = new StrategyRuleToCalculate();
    }

    @Override
    public void processElement1(AssetLog value, Context ctx, Collector<AssetLog> out) throws Exception {
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg020a0101")) && zombieAccount.value() == null && value.getIsSensitiveTable() != null) {

            logger.info("zombie_account active, firstId :{} , account : {}", value.getFirstId(), value.getAccount());
            ConditionTOMarking.setStrategy(value, AssetLogConstants.strategyLabelType.ZOMBIE_ACCOUNT_ACTIVE.getVal(),
                    CommonConstants.RiskLevel.HIGH_RISK.getVal());
            zombieAccount.update(value.getAccount());
        }
        out.collect(value);
    }

    @Override
    public void processElement2(OfflineData value, Context ctx, Collector<AssetLog> out) throws Exception {
        zombieAccount.update(ctx.getCurrentKey());
    }
}
