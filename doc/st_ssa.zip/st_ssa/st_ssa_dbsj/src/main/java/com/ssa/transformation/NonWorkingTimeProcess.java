package com.ssa.transformation;

import com.ssa.bean.AssetLog;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import com.ssa.mapfun.ConditionTOMarking;
import com.ssa.mapfun.ParsingCommonConfig;
import com.ssa.bean.CommonConfig;
import com.ssa.matchrule.StrategyRuleToCalculate;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.BroadcastProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.*;


/**
 * 非常用时间
 */
public class NonWorkingTimeProcess extends BroadcastProcessFunction<AssetLog, Tuple4<Integer, Integer, String, String>, AssetLog> {
    private static final Logger logger = LoggerFactory.getLogger(NonWorkingTimeProcess.class);

    //0-6周末到周六    <上班时间，下班时间>
    private Map<Integer, Tuple2<Date, Date>> commonConfigMap;
    private SimpleDateFormat simpleDateFormat;
    private Calendar calendar;
    private ParameterTool parameterTool;
    private StrategyRuleToCalculate strategyRule;

    @Override

    public void open(Configuration parameters) throws Exception {
        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        commonConfigMap = new HashMap<>();
        simpleDateFormat = new SimpleDateFormat("HH:mm");
        calendar = Calendar.getInstance();
        strategyRule = new StrategyRuleToCalculate();
    }

    @Override
    public void processElement(AssetLog assetLog, ReadOnlyContext readOnlyContext, Collector<AssetLog> collector) throws Exception {
        //assetLog的请求时间不为空
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg02040101")) && Optional.ofNullable(assetLog.getRequestTime()).isPresent()) {
            //日期格式转换
            Date date = new Date(assetLog.getRequestTime());
            //string of date
            String sd = simpleDateFormat.format(date);
            //获取  HH:mm格式时间
            //HH:mm
            Date dateN = simpleDateFormat.parse(sd);
            calendar.setTimeInMillis(assetLog.getRequestTime());
            //获取周几
            int week = calendar.get(Calendar.DAY_OF_WEEK);
            if (commonConfigMap.containsKey(week)) {
                //时间前后判断
                if (dateN.before(commonConfigMap.get(week).f0) || dateN.after(commonConfigMap.get(week).f1)) {
                    //打标
                    ConditionTOMarking.setStrategy(assetLog, AssetLogConstants.strategyLabelType.NONWORKING.getVal(), CommonConstants.RiskLevel.HIGH_RISK.getVal());
                }
            }
        }

        collector.collect(assetLog);

    }


                                        // tuple4<策略类型，增删改，zk路径，内容>
    @Override
    public void processBroadcastElement(Tuple4<Integer, Integer, String, String> tuple4, Context context, Collector<AssetLog> collector) throws Exception {

        try {
            if (tuple4.f0 == CommonConstants.ZkDataType.COMMON_TIME.getVal()) {
                List<CommonConfig> commonConfigs = ParsingCommonConfig.parsingCommonConfig(tuple4.f3);
                if (commonConfigs != null) {
                    if (tuple4.f1 == CommonConstants.OperateType.ADD.getVal() || tuple4.f1 == CommonConstants.OperateType.UPDATE.getVal()) {
                        commonConfigMap.clear();
                        for (CommonConfig commonConfig : commonConfigs) {
                            String[] split = commonConfig.getValue().split("-");
                            //时间转换中间变量
                            Date dateBefore = simpleDateFormat.parse(split[0]);
                            Date dateAfter = simpleDateFormat.parse(split[1]);
                            if (commonConfig.getKey().equals("7")) {
                                commonConfigMap.put(1, new Tuple2<>(dateBefore, dateAfter));
                            } else {
                                commonConfigMap.put(Integer.parseInt(commonConfig.getKey()) + 1, new Tuple2<>(dateBefore, dateAfter));
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
