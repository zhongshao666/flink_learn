package com.ssa.bean;

import lombok.Data;

@Data
public class OfflineData {
    /**
     * 离线库的表名
     */
    private String offlineTableType;
    /**
     * 客户端ip
     */
    private String clientIp;
    /**
     * 客户端Mac
     */
    private String clientMac;
    /**
     * 数据库账号
     */
    private String account;
    /**
     * 表名
     */
    private String commonTable;
    /**
     * 库名
     */
    private String instanceName;
    /**
     * 数据类别 01数审 02API
     */
    private String dataType;
    /**
     * 模型类别
     */
    private String modelType;
    /**
     * 黑名单类别
     */
    private String blackType;
    /**
     * 黑名单值
     */
    private String typeValue;
    /**
     * 更新时间
     */
    private String updateDate;

    /**
     * MAC的稀有度
     */
    private Double rarity;
}
