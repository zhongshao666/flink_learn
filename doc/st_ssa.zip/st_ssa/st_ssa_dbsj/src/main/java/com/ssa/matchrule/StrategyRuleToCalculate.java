package com.ssa.matchrule;

import com.ssa.bean.AssetLog;
import com.ssa.bean.CommonConfig;
import com.ssa.constants.CommonConstants;
import com.ssa.mapfun.ConditionTOMarking;
import com.ssa.mapfun.ParsingCommonConfig;
import com.ssa.strategy.StrategyMatch;
import com.ssa.utils.IPUtils;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.tuple.Tuple5;
import org.slf4j.Logger;

import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * @author : hld
 * @Date ： 2021/4/13
 * @Time : 9:49
 * @role ：
 */
public class StrategyRuleToCalculate implements Serializable {

    private final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm");
    private final MatchStrategyRule strategyRule = new MatchStrategyRule();
    private final Calendar calendar = Calendar.getInstance();

    /**
     * 初次下载敏感数据离线查询
     */
    public Boolean firstDownload(AssetLog assetLog, StrategyMatch strategyMatch,
                                 Tuple5<HashSet<String>, HashSet<String>, HashSet<String>, HashSet<String>, HashSet<String>> userName,
                                 String code, Integer riskLabelAi,
                                 Logger logger, String matchUserType, String matchUserTypeValue) {
        if (userName == null) {

            userName = new Tuple5<>(new HashSet<>(), new HashSet<>(), new HashSet<>(), new HashSet<>(), new HashSet<>());

            if (firstDownCode(assetLog, strategyMatch, userName, code, riskLabelAi, logger, matchUserType, matchUserTypeValue))
                return false;
        } else if (userName.f0.size() == 0) {
            if (firstDownCode(assetLog, strategyMatch, userName, code, riskLabelAi, logger, matchUserType, matchUserTypeValue))
                return false;
        }
        return true;
    }


    /**
     * 异常终端下载敏感数据
     */
    public void abnormalClientMac(AssetLog assetLog, StrategyMatch strategyMatch, HashSet<String> clientMac, String code, Integer riskLabelAi,
                                  Logger logger, String matchUserType, String matchUserTypeValue) {

        if (clientMac == null || (!clientMac.contains(assetLog.getClientMac()) && assetLog.getIsSensitiveTable() != null &&
                strategyRule.downOperationCommand(assetLog, "SELECT") &&
                strategyRule.rowsAffected(assetLog, Integer.parseInt(strategyMatch.getStrategyMatchCondition().getOperationValue())))) {
            logger.info("asset log abnormal clientMac download sensitive data first id : {} , {} : {}", assetLog.getFirstId(), matchUserType, matchUserTypeValue);
            ConditionTOMarking.setStrategy(assetLog, code, riskLabelAi);
        }
    }

    /**
     * 下载非常用敏感表
     */
    public void nonUseSensitiveTable(AssetLog assetLog, StrategyMatch strategyMatch, HashSet<String> tables, String code, Integer riskLabelAi,
                                     Logger logger, String matchUserType, String matchUserTypeValue) {
        if ( strategyRule.sensitiveType(assetLog) && tables == null) {
            logger.info("asset log download  not commonly used sensitive table first id : {} , {} : {}", assetLog.getFirstId(), matchUserType, matchUserTypeValue);
            ConditionTOMarking.setStrategy(assetLog, code, riskLabelAi);
        }else if ( strategyRule.sensitiveType(assetLog) && tables != null && strategyRule.downOperationCommand(assetLog, "SELECT") && assetLog.getIsSensitiveTable() != null &&
                strategyRule.rowsAffected(assetLog, Integer.parseInt(strategyMatch.getStrategyMatchCondition().getOperationValue()))) {
            Optional.ofNullable(assetLog.getSensitiveTables()).ifPresent(item -> {
                for (String table : item) {
                    if (tables.contains(table)) {
                        logger.info("asset log download  not commonly used sensitive table first id : {} , {} : {}", assetLog.getFirstId(), matchUserType, matchUserTypeValue);
                        ConditionTOMarking.setStrategy(assetLog, code, riskLabelAi);
                        break;
                    }
                }
            });
        }
    }

    /**
     * 下载非常用敏感库
     */
    public void nonUseSensitiveDatabase(AssetLog assetLog, StrategyMatch strategyMatch, HashSet<String> databases, String code, Integer riskLabelAi,
                                        Logger logger, String matchUserType, String matchUserTypeValue) {
        if ( strategyRule.sensitiveType(assetLog) && databases == null ){
            logger.info("asset log  download not commonly used sensitive database first id : {} , {} : {}", assetLog.getFirstId(), matchUserType, matchUserTypeValue);
            ConditionTOMarking.setStrategy(assetLog, code, riskLabelAi);
        }else if( strategyRule.sensitiveType(assetLog)&& databases != null && strategyRule.downOperationCommand(assetLog, "SELECT") && assetLog.getIsSensitiveTable() != null &&
                strategyRule.rowsAffected(assetLog, Integer.parseInt(strategyMatch.getStrategyMatchCondition().getOperationValue()))) {
            Optional.ofNullable(assetLog.getInstanceName()).ifPresent(item -> {
                if (!databases.contains(item)) {
                    logger.info("asset log  download not commonly used sensitive database first id : {} , {} : {}", assetLog.getFirstId(), matchUserType, matchUserTypeValue);
                    ConditionTOMarking.setStrategy(assetLog, code, riskLabelAi);
                }
            });
        }
    }

    /**
     * 沉默账号下载敏感数据
     */
    public void silenceAccountDownSensData(AssetLog assetLog, StrategyMatch strategyMatch, HashSet<String> account, String code, Integer riskLabelAi,
                                           Logger logger, String matchUserType, String matchUserTypeValue) {
        if (account.contains(assetLog.getAccount()) &&
                strategyRule.sensitiveType(assetLog) && strategyRule.downOperationCommand(assetLog, "SELECT") &&
                strategyRule.rowsAffected(assetLog, Integer.parseInt(strategyMatch.getStrategyMatchCondition().getOperationValue()))) {
            logger.info("asset log silence account download sensitive data first id : {} , {} : {}", assetLog.getFirstId(), matchUserType, matchUserTypeValue);
            ConditionTOMarking.setStrategy(assetLog, code, riskLabelAi);
        }
    }

    /**
     * 来自恶意源的敏感数据下载
     */
    public void maliciousDownSensData(AssetLog assetLog, StrategyMatch strategyMatch, String code, Integer riskLabelAi, Logger logger,
                                      String matchUserType, String matchUserTypeValue) {
        if (strategyRule.sensitiveType(assetLog) && strategyRule.downOperationCommand(assetLog, "SELECT") &&
                strategyRule.rowsAffected(assetLog, Integer.parseInt(strategyMatch.getStrategyMatchCondition().getOperationValue()))) {
            logger.info("asset log malicious download sensitive data first id : {} , {} : {}", assetLog.getFirstId(), matchUserType, matchUserTypeValue);
            ConditionTOMarking.setStrategy(assetLog, code, riskLabelAi);
        }
    }

    /**
     * 非工作时间下载敏感数据
     */
    public void nonWorkTimeDownSensData(AssetLog assetLog, StrategyMatch strategyMatch, String code, Integer riskLabelAi, Map<Integer, Tuple2<LocalTime,
            LocalTime>> commonConfigMap, Logger logger, String matchUserType, String matchUserTypeValue) throws ParseException {

        LocalDateTime localDateTime = LocalDateTime.ofEpochSecond(assetLog.getRequestTime() / 1000L, 0, ZoneOffset.ofHours(8));
        String format = localDateTime.format(dateTimeFormatter);
        LocalTime dateN = LocalTime.parse(format);
        calendar.setTimeInMillis(assetLog.getRequestTime());
        int week = calendar.get(Calendar.DAY_OF_WEEK);

        if (commonConfigMap.containsKey(week) && (dateN.isBefore(commonConfigMap.get(week).f0) || dateN.isAfter(commonConfigMap.get(week).f1)) &&
                strategyRule.sensitiveType(assetLog) && strategyRule.downOperationCommand(assetLog, "SELECT") &&
                strategyRule.rowsAffected(assetLog, Integer.parseInt(strategyMatch.getStrategyMatchCondition().getOperationValue()))) {
            logger.info("asset log non working time download sensitive data first id : {} , {} : {}", assetLog.getFirstId(), matchUserType, matchUserTypeValue);
            ConditionTOMarking.setStrategy(assetLog, code, riskLabelAi);
        }

    }

    /**
     * 敏感数据下载量异常
     */
    public void downMoreSensData(AssetLog assetLog, ValueState<LinkedList<Tuple2<Long, Integer>>> downMoreSensData,
                                 ValueState<Integer> countRowsAffected, StrategyMatch strategyMatch, String code,
                                 Integer riskLabelAi, Logger logger, String matchUserType, String matchUserTypeValue) throws IOException {
        if (strategyRule.sensitiveType(assetLog) && strategyRule.downOperationCommand(assetLog, "SELECT")) {
            strategyRule.queueMatchDownMore(assetLog, downMoreSensData, countRowsAffected, strategyMatch, code,
                    riskLabelAi, logger, matchUserType, matchUserTypeValue);
        }
    }

    /**
     * 境外ip检测（异常地理位置下载敏感数据）
     */
    public void matchForeignIp(AssetLog assetLog, StrategyMatch strategyMatch, String code, Integer riskLabelAi,
                               Logger logger, String matchUserType, String matchUserTypeValue,
                               List<Tuple2<Long, Long>> listThreatIp, List<String> listIp) {
        if (assetLog.getRowsAffected() > Integer.parseInt(strategyMatch.getStrategyMatchCondition().getOperationValue()) &&
                strategyRule.downOperationCommand(assetLog, "SELECT") &&
                strategyRule.sensitiveType(assetLog) && isForeignIp(assetLog, listThreatIp, listIp)) {
            logger.info("asset log foreign Ip download sensitive data first id : {} , {} : {}", assetLog.getFirstId(), matchUserType, matchUserTypeValue);
            ConditionTOMarking.setStrategy(assetLog, code, riskLabelAi);
        }
    }

    /**
     * 向系统外可疑的数据传输（账号）
     */
    public boolean matchIntranetIp(AssetLog assetLog, StrategyMatch strategyMatch, String code, Integer riskLabelAi,
                                   Logger logger, String matchUserType, String matchUserTypeValue) {

        boolean innerNet = !(isInnerNet(assetLog));

        if (strategyMatch != null && assetLog.getRowsAffected() > Integer.parseInt(strategyMatch.getStrategyMatchCondition().getOperationValue()) &&
                strategyRule.downOperationCommand(assetLog, "SELECT") && innerNet) {
            logger.info("asset log intranet Ip download sensitive data first id : {} , {} : {}", assetLog.getFirstId(), matchUserType, matchUserTypeValue);
            ConditionTOMarking.setStrategy(assetLog, code, riskLabelAi);
        }
        return innerNet;
    }


    /**
     * broadcast匹配非工作时间map
     */
    public void matchNonWorkingTime(Tuple4<Integer, Integer, String, String> value, String values,
                                    Map<Integer, Tuple2<LocalTime, LocalTime>> commonConfigMap) throws ParseException {

        List<CommonConfig> value1 = ParsingCommonConfig.parsingCommonConfig(values);

        if (value.f1 == CommonConstants.OperateType.ADD.getVal() || value.f1 == CommonConstants.OperateType.UPDATE.getVal()) {
            if (value1 != null) {
                commonConfigMap.clear();
                for (CommonConfig commonConfig : value1) {
                    String[] split = commonConfig.getValue().split("-");
                    LocalTime dateBefore = LocalTime.parse(split[0]);
                    LocalTime dateAfter = LocalTime.parse(split[1]);

                    if ("7".equals(commonConfig.getKey())) {
                        commonConfigMap.put(1, new Tuple2<>(dateBefore, dateAfter));
                    } else {
                        commonConfigMap.put(Integer.parseInt(commonConfig.getKey()) + 1, new Tuple2<>(dateBefore, dateAfter));
                    }
                }

            }
        }
    }

    /**
     * 解析常用ip类
     */
    public void matchCommonIp(String value, HashSet<String> commonIp) {
        commonIp.clear();
        List<CommonConfig> list = ParsingCommonConfig.parsingCommonConfig(value);
        if (list != null) {
            for (CommonConfig commonConfig : list) {
                commonIp.add(commonConfig.getValue());
            }
        }
    }

    /**
     * 获取策略开关
     */
    public Boolean strategySwitch(String switchMatch) {
        if ("true".equals(switchMatch)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 内网ip判断
     */
    public boolean isInnerNet(AssetLog assetLog) {
        String ip = assetLog.getClientIp();
        if (ip.startsWith("10.")) {
            return true;
        } else if (ip.startsWith("172")) {
            if (ip.startsWith("172.1") && ip.charAt(5) >= '6' && ip.charAt(6) == '.') {
                return true;
            } else if (ip.startsWith("172.2") && ip.charAt(6) == '.') {
                return true;
            } else if (ip.startsWith("172.3") && ip.charAt(5) <= '1') {
                return true;
            } else {
                return false;
            }
        } else if (ip.startsWith("192.168")) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 境外ip
     */

    public boolean isForeignIp(AssetLog assetLog, List<Tuple2<Long, Long>> listThreatIp, List<String> listIp) {
        boolean threatIpBool = false;
        if (assetLog.getClientIp() != null && listIp.size() > 0) {
            for (String ip : listIp) {
                if (ip.equals(assetLog.getClientIp())) {
                    threatIpBool = true;
                    break;
                }
            }
        }

        if (assetLog.getClientIp() != null && listThreatIp.size() > 0) {
            long httpClientIp = IPUtils.ip2Long(assetLog.getClientIp());
            for (Tuple2<Long, Long> tuple2 : listThreatIp) {
                if (httpClientIp >= tuple2.f0 && httpClientIp <= tuple2.f1) {
                    threatIpBool = true;
                    break;
                }
            }
        }
        return threatIpBool;
    }



    private boolean firstDownCode(AssetLog assetLog, StrategyMatch strategyMatch, Tuple5<HashSet<String>, HashSet<String>, HashSet<String>, HashSet<String>, HashSet<String>> userName, String code, Integer riskLabelAi, Logger logger, String matchUserType, String matchUserTypeValue) {
        if (strategyRule.downCommOutfile(assetLog, "OUTFILE") &&
                strategyRule.sensitiveType(assetLog) && strategyRule.rowsAffected(assetLog,1)) {

            logger.info("asset log first download sensitive data first id : {} , {} : {}", assetLog.getFirstId(), matchUserType, matchUserTypeValue);
            ConditionTOMarking.setStrategy(assetLog, code, riskLabelAi);
            userName.f0.add(assetLog.getAccount());
            return true;
        }
        return false;
    }
}
