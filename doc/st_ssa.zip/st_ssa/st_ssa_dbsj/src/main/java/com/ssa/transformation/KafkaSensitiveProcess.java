package com.ssa.transformation;


import com.ssa.bean.ControlData;
import com.ssa.bean.SensitiveData;
import com.ssa.mapfun.ParsingKafkaControlData;
import com.ssa.mapfun.ParsingKafkaSensitive;
import org.apache.flink.api.java.tuple.Tuple8;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.interfaces.RSAPrivateKey;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.ssa.utils.RSAUtils.getPrivateKey;
import static com.ssa.utils.RSAUtils.privateDecrypt;

/**
 * Kafka敏感数据接收（放入mysql进行维护）
 */
public class KafkaSensitiveProcess extends ProcessFunction<String, Tuple8<String, String, String, Integer, String, String, List<String>, List<String>>> {
    private static final Logger logger = LoggerFactory.getLogger(KafkaSensitiveProcess.class);
    private ParameterTool parameterTool;

    static {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void open(Configuration parameters) throws Exception {
        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig()
                .getGlobalJobParameters();

    }

    @Override
    public void processElement(String value, Context ctx, Collector<Tuple8<String, String, String, Integer, String, String, List<String>, List<String>>> out) throws Exception {

        try {

            //获取私钥
            RSAPrivateKey privateKey1 = getPrivateKey(parameterTool.get("kafka.sensitive.rsakey"));
            SensitiveData sensitiveData = ParsingKafkaSensitive.parsingKafkaSensitive(value);

            if (sensitiveData.getControlData() != null) {
                //解密
                String data = privateDecrypt(sensitiveData.getControlData(), privateKey1);
                //解析
                ControlData controlData = ParsingKafkaControlData.parsingKafkaControlData(data);

                String key = controlData.getKey();
                if (key != null) {

                    String[] split = key.split("&_");
                    if (split.length > 1) {
                        switch (split[1]) {

                            //01敏感表
                            case "01": {
                                List<String> tableList;
                                if (sensitiveData.getControlData() != null) {
                                    String tables = controlData.getValue();
                                    if (tables != null) {


                                        tableList = Arrays.asList(tables.split(","));
                                        List<String> listField = new ArrayList<>();
                                        Tuple8<String, String, String, Integer, String, String, List<String>, List<String>> tuple8 =
                                                new Tuple8<>(split[7], split[1], split[3], Integer.parseInt(split[4]), split[5], split[6], tableList, listField);
                                     out.collect(tuple8);
                                    }
                                }
                                break;
                            }
                            //02敏感字段
                            case "02": {
                                List<String> tableList = new ArrayList<>();
                                tableList.add(split[7]);
                                List<String> fieldList;
                                if (sensitiveData.getControlData() != null) {
                                    String fields = controlData.getValue();
                                    if (fields != null) {

                                        fieldList = Arrays.asList(fields.split(","));
                                        Tuple8<String, String, String, Integer, String, String, List<String>, List<String>> tuple8 =
                                                new Tuple8<>(split[8], split[1], split[3], Integer.parseInt(split[4]), split[5], split[6], tableList, fieldList);

                                        out.collect(tuple8);
                                    }
                                }
                                break;
                            }
                            //03只存批次号
                            case "03":
                                String values = controlData.getValue();
                                out.collect(new Tuple8<>(values, "01", "", 0, "", "", new ArrayList<>(), new ArrayList<>()));
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
