package com.ssa.matchrule;

import com.ssa.bean.OfflineData;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import com.ssa.mapfun.ParsingZkSource;
import com.ssa.strategy.StrategyMatch;
import org.apache.flink.api.common.state.BroadcastState;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.tuple.Tuple5;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Map;

/**
 * @author : hld
 * @Date ： 2021/4/14
 * @Time : 11:38
 * @role ：
 */
public class BroadcastDataMatch implements Serializable {

    private final ParsingZkSource parsingZkSource = new ParsingZkSource();

    /**
     * 匹配策略规则
     */
    public void matchStrategyRule(Tuple4<Integer, Integer, String, String> value, String strategyLabel, Map<String, StrategyMatch> strategyMatchMap) {
        if (value.f0 == CommonConstants.ZkDataType.RISK_TYPE.getVal()) {
            StrategyMatch strategyMatch = parsingZkSource.parsingZkJson(value.f3);
            if (strategyLabel.equals(strategyMatch.getStrategy())) {
                if (value.f1 == CommonConstants.OperateType.DELETE.getVal()) {
                    strategyMatchMap.remove(strategyMatch.getStrategy());
                } else if (value.f1 == CommonConstants.OperateType.ADD.getVal() || value.f1 == CommonConstants.OperateType.UPDATE.getVal()) {
                    strategyMatchMap.put(strategyMatch.getStrategy(), strategyMatch);
                }
            }
        }
    }

    /**
     * KeyBy clientIp的离线表数据匹配
     */
    public void matchClientIpTableData(OfflineData value, String keyed,
                                       BroadcastState<String, Tuple3<HashSet<String>, HashSet<String>, HashSet<String>>> broadcastState) throws Exception {

        String offlineTableType = value.getOfflineTableType();
        Tuple3<HashSet<String>, HashSet<String>, HashSet<String>> hashsetTuple3 = broadcastState.get(keyed);

        if (hashsetTuple3 == null) {
            hashsetTuple3 = new Tuple3<>(new HashSet<>(), new HashSet<>(), new HashSet<>());
        }
        if (CommonConstants.OfflineTableType.SENSITIVE_ABNORMAL_CLIENT_DOWNLOAD.getVal().equals(offlineTableType)) {

            hashsetTuple3.f0.add(value.getClientIp());
            broadcastState.put(keyed, hashsetTuple3);
        }
        if (CommonConstants.OfflineTableType.SENSITIVE_TABLE_DOWNLOAD.getVal().equals(offlineTableType)) {

            hashsetTuple3.f1.add(value.getCommonTable());
            broadcastState.put(keyed, hashsetTuple3);
        }
        if (CommonConstants.OfflineTableType.SENSITIVE_DATABASE_DOWNLOAD.getVal().equals(offlineTableType)) {

            hashsetTuple3.f2.add(value.getInstanceName());
            broadcastState.put(keyed, hashsetTuple3);
        }
    }

    /**
     * KeyBy Account的离线表数据匹配
     */
    public void matchAccountTableData(OfflineData value, String keyed,
                                      BroadcastState<String, Tuple5<HashSet<String>, HashSet<String>, HashSet<String>, HashSet<String>, HashSet<String>>> broadcastState) throws Exception {
        String offlineTableType = value.getOfflineTableType();
        Tuple5<HashSet<String>, HashSet<String>, HashSet<String>, HashSet<String>, HashSet<String>> hashSetTuple5 = broadcastState.get(keyed);

        if (hashSetTuple5 == null) {
            hashSetTuple5 = new Tuple5<>(new HashSet<>(), new HashSet<>(), new HashSet<>(), new HashSet<>(), new HashSet<>());
        }

        if (CommonConstants.OfflineTableType.SENSITIVE_FIRST_DOWNLOAD.getVal().equals(offlineTableType)) {

            hashSetTuple5.f0.add(value.getAccount());
            broadcastState.put(keyed, hashSetTuple5);

        }

        if (CommonConstants.OfflineTableType.SENSITIVE_ABNORMAL_CLIENT_DOWNLOAD.getVal().equals(offlineTableType)) {

            hashSetTuple5.f1.add(value.getClientMac());
            broadcastState.put(keyed, hashSetTuple5);

        }
        if (CommonConstants.OfflineTableType.SENSITIVE_TABLE_DOWNLOAD.getVal().equals(offlineTableType)) {

            hashSetTuple5.f2.add(value.getCommonTable());
            broadcastState.put(keyed, hashSetTuple5);

        }
        if (CommonConstants.OfflineTableType.SENSITIVE_DATABASE_DOWNLOAD.getVal().equals(offlineTableType)) {

            hashSetTuple5.f3.add(value.getInstanceName());
            broadcastState.put(keyed, hashSetTuple5);

        }

        if (CommonConstants.OfflineTableType.SENSITIVE_SILENCE_USER_DOWNLOAD.getVal().equals(offlineTableType)) {

            hashSetTuple5.f4.add(value.getAccount());
            broadcastState.put(keyed, hashSetTuple5);

        }
    }
}
