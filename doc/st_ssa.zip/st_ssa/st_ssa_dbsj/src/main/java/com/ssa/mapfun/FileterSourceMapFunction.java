package com.ssa.mapfun;

import com.alibaba.fastjson.JSON;
import com.ssa.bean.AssetLog;
import com.ssa.source.ClickHouseZkSource;
import org.apache.flink.api.common.functions.MapFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FileterSourceMapFunction implements MapFunction<AssetLog,String> {
    private static final Logger logger = LoggerFactory.getLogger(FileterSourceMapFunction.class);
    @Override
    public String map(AssetLog assetLog) throws Exception {
       logger.info("assetLog----------");
        return JSON.toJSONString(assetLog);
    }
}
