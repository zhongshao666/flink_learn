package com.ssa.transformation;

import com.ssa.bean.AssetLog;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import com.ssa.mapfun.ConditionTOMarking;
import com.ssa.mapfun.ParsingZkSource;
import com.ssa.matchrule.StrategyRuleToCalculate;
import com.ssa.strategy.StrategyMatch;
import org.apache.flink.api.common.state.StateTtlConfig;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.KeyedBroadcastProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 * 异常下载敏感数据
 * 010b0101
 */
public class AbnormalDownloadSensitiveDataProcess extends KeyedBroadcastProcessFunction<String, AssetLog, Tuple4<Integer, Integer, String, String>, AssetLog> {
    private static final Logger logger = LoggerFactory.getLogger(AbnormalDownloadSensitiveDataProcess.class);
    private ValueState<LinkedList<Long>> timeList;
    StrategyMatch strategyMatch;
    private ParsingZkSource parsingZkSource;
    private StrategyRuleToCalculate strategyRule;
    private ParameterTool parameterTool;


    @Override
    public void open(Configuration parameters) throws Exception {

        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        strategyMatch = new StrategyMatch();
        parsingZkSource = new ParsingZkSource();
        strategyRule = new StrategyRuleToCalculate();

        StateTtlConfig stateTtlConfig = StateTtlConfig.newBuilder(Time.minutes(30))
                .setUpdateType(StateTtlConfig.UpdateType.OnCreateAndWrite)
                .setStateVisibility(StateTtlConfig.StateVisibility.NeverReturnExpired)
                .disableCleanupInBackground()
                .cleanupFullSnapshot()
                .build();

        ValueStateDescriptor<LinkedList<Long>> listDesc = new ValueStateDescriptor<>("timeList", TypeInformation.of(new TypeHint<LinkedList<Long>>() {
        }));

        listDesc.enableTimeToLive(stateTtlConfig);
        timeList = getRuntimeContext().getState(listDesc);


    }

    @Override
    public void processElement(AssetLog assetLog, ReadOnlyContext ctx, Collector<AssetLog> out) throws Exception {

        //固定频率(标准差)
        //参数  窗口多少分钟  窗口内访问敏感数据数量达到多少次开始检测  标准差的阈值

        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg02060101"))) {
            if (assetLog.getIsSensitiveTable().equals(1) && assetLog.getOperationStatement().contains("outfile")) {
                //第一次进process 或 ttl超时变为null
                if (timeList.value() == null) {
                    LinkedList<Long> list = new LinkedList<>();
                    list.addLast(assetLog.getRequestTime());
                    timeList.update(list);
                } else {
                    LinkedList<Long> value = timeList.value();
                    value.addLast(assetLog.getRequestTime());
                    timeList.update(value);
                }
            }

            //可保留，可删除（保持条数不超过times）
/*            if (timeList.value() != null && timeList.value().size() > strategyMatch.getStrategyMatchCondition().getTriggerFrequency().getTimes()) {
                logger.error(String.valueOf(timeList.value().size()));
                ConditionTOMarking.reSetFrequencyAlarmModule(timeList.value(), timeList.value().size() - strategyMatch.getStrategyMatchCondition().getTriggerFrequency().getTimes());
            }*/


            if (timeList.value() != null && timeList.value().size() >= strategyMatch.getStrategyMatchCondition().getTriggerFrequency().getTimes()) {
                long l;
                ArrayList<Double> doubles = new ArrayList<>();
                for (int i = 0; i < timeList.value().size() - 1; i++) {
                    l = timeList.value().get(i + 1) - timeList.value().get(i);
                    doubles.add((double) (l / 1000));
                }
                double v = StandardDiviation(doubles);
                logger.info(String.valueOf(timeList.value()));
                logger.info(String.valueOf(doubles));
                logger.info(String.valueOf(v));
                if (v < strategyMatch.getStrategyMatchCondition().getVariance()) {
                    //固定频率  打标
                    ConditionTOMarking.setStrategy(assetLog, strategyMatch, strategyMatch.getRiskLevel());
                }
            }
        }

        out.collect(assetLog);

    }

    // tuple4<策略类型，增删改，zk路径，内容>
    @Override
    public void processBroadcastElement(Tuple4<Integer, Integer, String, String> tuple4, Context ctx, Collector<AssetLog> out) throws Exception {
        String filterStrategy = AssetLogConstants.strategyLabelType.ABNORMAL_DOWNLOAD_SENSITIVE.getVal();
        if (tuple4.f0 == CommonConstants.ZkDataType.RISK_TYPE.getVal()) {
            StrategyMatch strategyMatchParsing = parsingZkSource.parsingZkJson(tuple4.f3);
            if (filterStrategy.equals(strategyMatchParsing.getStrategy())) {
                if (tuple4.f1 == CommonConstants.OperateType.ADD.getVal() || tuple4.f1 == CommonConstants.OperateType.UPDATE.getVal()) {
                    strategyMatch = strategyMatchParsing;
                }
            }
        }
    }

    public double StandardDiviation(ArrayList<Double> x) {
        double sum = 0d;
        for (double i : x) {
            sum += i;
        }
        //平均值
        double avg = sum / x.size();
        //求方差
        double variance = 0d;
        for (double i : x) {
            variance += (i - avg) * (i - avg);
        }

        return Math.sqrt(variance / x.size());
    }
}
