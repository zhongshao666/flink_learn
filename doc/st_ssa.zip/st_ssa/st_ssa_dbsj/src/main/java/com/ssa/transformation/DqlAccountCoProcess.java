package com.ssa.transformation;

import com.ssa.bean.AssetLog;
import com.ssa.bean.OfflineData;
import com.ssa.bean.ThreatIntelligenceIp;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import com.ssa.mapfun.ParsingThreatIp;
import com.ssa.mapfun.ParsingZkSource;
import com.ssa.matchrule.BroadcastDataMatch;
import com.ssa.matchrule.StrategyRuleToCalculate;
import com.ssa.strategy.StrategyMatch;
import com.ssa.utils.IPUtils;
import org.apache.flink.api.common.state.*;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.tuple.Tuple5;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.KeyedBroadcastProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalTime;
import java.util.*;


/**
 * @author : hld
 * @Date ： 2021/4/13
 * @Time : 10:10
 * @role ：处理：初次下载敏感数据、异常终端下载敏感数据（账号)、下载非常用敏感表、下载非常用敏感库、
 * 沉默账号下载敏感数据、非工作时间下载敏感数据需求
 */
public class DqlAccountCoProcess extends KeyedBroadcastProcessFunction<String, AssetLog, Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>, AssetLog> {

    private Logger logger = LoggerFactory.getLogger(DqlAccountCoProcess.class);

    public static MapStateDescriptor<String, Tuple5<HashSet<String>, HashSet<String>, HashSet<String>, HashSet<String>, HashSet<String>>> dqlAccountMap = new MapStateDescriptor<String, Tuple5<HashSet<String>, HashSet<String>, HashSet<String>, HashSet<String>, HashSet<String>>>("dqlAccountMap", BasicTypeInfo.STRING_TYPE_INFO, TypeInformation.of(new TypeHint<Tuple5<HashSet<String>, HashSet<String>, HashSet<String>, HashSet<String>, HashSet<String>>>() {
    }));

    private ValueState<Boolean> firstDown;
    private ParameterTool parameterTool;

    private Map<Integer, Tuple2<LocalTime, LocalTime>> commonConfigMap;
    private StrategyRuleToCalculate strategyRule;
    private BroadcastDataMatch broadcastDataMatch;

    private List<Tuple2<Long, Long>> listThreatIp;
    private List<String> listIp;

    private ParsingZkSource parsingZkSource;
    private Map<String, StrategyMatch> strategyMatchMap;
    private String matchUserType;

    @Override
    public void open(Configuration parameters) throws Exception {
        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        commonConfigMap = new HashMap<>();
        broadcastDataMatch = new BroadcastDataMatch();
        listThreatIp = new ArrayList<>();
        listIp = new ArrayList<>();

        matchUserType = "Account";
        strategyMatchMap = new HashMap<>();
        parsingZkSource = new ParsingZkSource();

        firstDown = getRuntimeContext().getState(new ValueStateDescriptor<Boolean>("firstDownSensitiveData", TypeInformation.of(Boolean.class)));

        strategyRule = new StrategyRuleToCalculate();
    }

    @Override
    public void processElement(AssetLog value, ReadOnlyContext ctx, Collector<AssetLog> out) throws Exception {

        boolean intranetIp = false;

        Tuple5<HashSet<String>, HashSet<String>, HashSet<String>, HashSet<String>, HashSet<String>> hashSetTuple5 = ctx.getBroadcastState(dqlAccountMap).get(ctx.getCurrentKey());

        if (hashSetTuple5 == null || hashSetTuple5.f0.size() == 0) {
            if (firstDown.value() == null) {
                firstDown.update(true);
            }
            //初次下载敏感数据
            if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg01030101")) && firstDown.value()) {
                String firstDownloadVal = AssetLogConstants.strategyLabelType.SENSITIVE_FIRST_DOWNLOAD.getVal();

                Boolean aBoolean = strategyRule.firstDownload(value, strategyMatchMap.get(firstDownloadVal), hashSetTuple5,
                        AssetLogConstants.strategyLabelType.SENSITIVE_FIRST_DOWNLOAD.getVal(),
                        CommonConstants.RiskLevel.HIGH_RISK.getVal(), logger, matchUserType, value.getAccount());

                firstDown.update(aBoolean);
            }
        }


        //异常终端下载敏感数据（账号)
        String abnormalClientMacVal = AssetLogConstants.strategyLabelType.SENSITIVE_ABNORMAL_CLIENTMAC.getVal();
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg01040101")) &&
                (value.getFlowLabel() == null || !value.getFlowLabel().contains(abnormalClientMacVal))) {
            strategyRule.abnormalClientMac(value, strategyMatchMap.get(abnormalClientMacVal),
                    Optional.ofNullable(hashSetTuple5).map(item -> item.f1).orElse(null),
                    abnormalClientMacVal, CommonConstants.RiskLevel.SERIOUS.getVal(), logger, matchUserType, value.getAccount());
        }

        //下载非常用敏感表
        String nonUseTableVal = AssetLogConstants.strategyLabelType.SENSITIVE_NONUSE_TABLE.getVal();
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg01060101")) &&
                (value.getFlowLabel() == null || !value.getFlowLabel().contains(nonUseTableVal))) {
            strategyRule.nonUseSensitiveTable(value, strategyMatchMap.get(nonUseTableVal),
                    Optional.ofNullable(hashSetTuple5).map(item -> item.f2).orElse(null),
                    nonUseTableVal, CommonConstants.RiskLevel.SERIOUS.getVal(), logger, matchUserType, value.getAccount());
        }
        //下载非常用敏感库
        String nonUseDatabaseVal = AssetLogConstants.strategyLabelType.SENSITIVE_NONUSE_DATABASE.getVal();
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg01070101")) &&
                (value.getFlowLabel() == null || !value.getFlowLabel().contains(nonUseDatabaseVal))) {
            strategyRule.nonUseSensitiveDatabase(value, strategyMatchMap.get(nonUseDatabaseVal),
                    Optional.ofNullable(hashSetTuple5).map(item -> item.f2).orElse(null),
                    nonUseDatabaseVal, CommonConstants.RiskLevel.SERIOUS.getVal(), logger, matchUserType, value.getAccount());
        }

        //沉默账号下载敏感数据
        String downloadVal = AssetLogConstants.strategyLabelType.SENSITIVE_SILENCEACCOUNT_DOWNLOAD.getVal();
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg01080101")) &&
                Optional.ofNullable(hashSetTuple5).map(item -> item.f2 != null).orElse(false)) {
            strategyRule.silenceAccountDownSensData(value, strategyMatchMap.get(downloadVal), hashSetTuple5.f4,
                    AssetLogConstants.strategyLabelType.SENSITIVE_SILENCEACCOUNT_DOWNLOAD.getVal(), CommonConstants.RiskLevel.HIGH_RISK.getVal(), logger, matchUserType, value.getAccount());
        }


        //非工作时间下载敏感数据
        String downloadNonWorkTimeVal = AssetLogConstants.strategyLabelType.SENSITIVE_DOWNLOAD_NONWORKTIME.getVal();
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg01050101")) && value.getRiskType() != null &&
                value.getFlowLabel() != null && !value.getFlowLabel().contains(downloadNonWorkTimeVal)) {
            strategyRule.nonWorkTimeDownSensData(value, strategyMatchMap.get(downloadNonWorkTimeVal), downloadNonWorkTimeVal, CommonConstants.RiskLevel.SERIOUS.getVal(), commonConfigMap, logger, matchUserType, value.getAccount());
        }

        //向系统外可疑的数据传输（账号）
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg01020101"))) {
            String intranetIpDownVal = AssetLogConstants.strategyLabelType.INTRANET_IP_DOWN.getVal();
            intranetIp = strategyRule.matchIntranetIp(value, strategyMatchMap.get(intranetIpDownVal), AssetLogConstants.strategyLabelType.INTRANET_IP_DOWN.getVal(), CommonConstants.RiskLevel.HIGH_RISK.getVal(), logger, matchUserType, value.getAccount());
        }


        //境外ip检测（异常地理位置下载敏感数据）
        if (intranetIp && strategyRule.strategySwitch(parameterTool.get("strategy.id.stg010a0101"))) {
            String foreignIpDownVal = AssetLogConstants.strategyLabelType.FOREIGN_IP_DOWN.getVal();
            strategyRule.matchForeignIp(value, strategyMatchMap.get(foreignIpDownVal), AssetLogConstants.strategyLabelType.FOREIGN_IP_DOWN.getVal(), CommonConstants.RiskLevel.SERIOUS.getVal(), logger, matchUserType, value.getAccount(), listThreatIp, listIp);
        }


        out.collect(value);
    }

    @Override
    public void processBroadcastElement(Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>> value, Context ctx, Collector<AssetLog> out) throws Exception {

        BroadcastState<String, Tuple5<HashSet<String>, HashSet<String>, HashSet<String>, HashSet<String>, HashSet<String>>> broadcastState = ctx.getBroadcastState(dqlAccountMap);

        if (value.f0 != null) {

            broadcastDataMatch.matchAccountTableData(value.f0, value.f0.getAccount(), broadcastState);

        } else {

            if (value.f1.f0 == CommonConstants.ZkDataType.RISK_TYPE.getVal()) {
                StrategyMatch strategyMatch = parsingZkSource.parsingZkJson(value.f1.f3);
                strategyMatchMap.put(strategyMatch.getStrategy(), strategyMatch);
            }
            if (value.f1.f0 == CommonConstants.ZkDataType.COMMON_TIME.getVal()) {
                strategyRule.matchNonWorkingTime(value.f1, value.f1.f3, commonConfigMap);
            }

            if (value.f1.f0 == CommonConstants.ZkDataType.THREAT_IP.getVal()) {
                List<ThreatIntelligenceIp> threatIntelligenceIps = ParsingThreatIp.parsingThreatIp(value.f1.f3);
                if (Optional.ofNullable(threatIntelligenceIps).isPresent()  &&
                        (value.f1.f1 == CommonConstants.OperateType.ADD.getVal() || value.f1.f1 == CommonConstants.OperateType.UPDATE.getVal())) {
                    listThreatIp.clear();
                    listIp.clear();
                    for (ThreatIntelligenceIp threatIntelligenceIp : threatIntelligenceIps) {
                        String[] split = threatIntelligenceIp.getClient_ip().split("-");
                        if (split.length == 1) {
                            this.listIp.add(threatIntelligenceIp.getClient_ip());
                        } else {
                            this.listThreatIp.add(new Tuple2<>(IPUtils.ip2Long(split[0]), IPUtils.ip2Long(split[1])));
                        }
                    }
                }
            }
        }
    }
}
