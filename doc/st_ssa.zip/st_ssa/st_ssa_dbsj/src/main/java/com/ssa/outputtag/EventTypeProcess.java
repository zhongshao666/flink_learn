package com.ssa.outputtag;

import com.ssa.DbsjMain;
import com.ssa.bean.AssetLog;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;

/**
 * @author : hld
 * @Date ： 2021/4/9
 * @Time : 11:33
 * @role ：
 */
public class EventTypeProcess extends ProcessFunction<AssetLog, AssetLog> {
    @Override
    public void processElement(AssetLog value, Context ctx, Collector<AssetLog> out) throws Exception {
        if (AssetLogConstants.operationTypeCatalog.CTLOGIN.getValues() == value.getOperationType().intValue()) {
            value.setEventType(CommonConstants.EventType.LOGIN.getVal());
            ctx.output(DbsjMain.loginEventType, value);
        } else {
            value.setEventType(CommonConstants.EventType.ACCESS.getVal());
            out.collect(value);
        }
    }
}
