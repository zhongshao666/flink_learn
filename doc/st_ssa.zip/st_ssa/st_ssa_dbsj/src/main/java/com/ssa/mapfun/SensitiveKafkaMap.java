package com.ssa.mapfun;

import com.alibaba.fastjson.JSON;
import com.ssa.bean.AssetLog;
import org.apache.flink.api.common.functions.MapFunction;

import java.util.stream.Collectors;

/**
 * @author : hld
 * @Date ： 2021/5/27
 * @Time : 20:52
 * @role ：
 */
public class SensitiveKafkaMap implements MapFunction<AssetLog, String> {
    @Override
    public String map(AssetLog value) throws Exception {

        value.setAlarmLabel(value.getAlarmLabel().stream().distinct().collect(Collectors.toList()));
        value.setFlowLabel(value.getFlowLabel().stream().distinct().collect(Collectors.toList()));

        return JSON.toJSONString(value);
    }
}
