package com.ssa.transformation;

import com.ssa.bean.AssetLog;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import com.ssa.mapfun.ConditionTOMarking;
import com.ssa.mapfun.ParsingZkSource;
import com.ssa.matchrule.StrategyRuleToCalculate;
import com.ssa.strategy.StrategyMatch;
import com.ssa.utils.NotLoginOperateUtils;
import org.apache.flink.api.common.state.StateTtlConfig;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.KeyedBroadcastProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;


public class VisitEventProcess2 extends KeyedBroadcastProcessFunction<String, AssetLog, Tuple4<Integer, Integer, String, String>, AssetLog> {
    private static final Logger logger = LoggerFactory.getLogger(VisitEventProcess2.class);

    private ValueState<LinkedList<Long>> noFileQueueTime;

    private ValueStateDescriptor<LinkedList<Long>> noFileQueueTimea;

    private ValueState<LinkedList<Long>> noAuthQueueTime;

    private ValueStateDescriptor<LinkedList<Long>> noAuthQueueTimea;

    private ValueState<LinkedList<Long>> notSuccessQueueTime;

    private ValueStateDescriptor<LinkedList<Long>> notSuccessQueueTimea;


    private ParsingZkSource parsingZkSource = new ParsingZkSource();

    private Map<String, StrategyMatch> strategyMatchMap;

    private Map<String, Boolean> strategystatusMap;
    ParameterTool parameterTool = null;
    private NotLoginOperateUtils notLoginOperateUtils = new NotLoginOperateUtils();
    private StrategyRuleToCalculate strategyRule;


    @Override
    public void open(Configuration parameters) throws Exception {

        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        StateTtlConfig stateTtlConfig = StateTtlConfig.newBuilder(Time.minutes(30))
                .setUpdateType(StateTtlConfig.UpdateType.OnCreateAndWrite)
                .setStateVisibility(StateTtlConfig.StateVisibility.NeverReturnExpired)
                .disableCleanupInBackground()
                .cleanupFullSnapshot()
                .build();

        noFileQueueTimea = new ValueStateDescriptor<>("noFileQueueTimeAccount", TypeInformation.of(new TypeHint<LinkedList<Long>>() {
        }));

        noFileQueueTimea.enableTimeToLive(stateTtlConfig);

        noFileQueueTime = getRuntimeContext().getState(noFileQueueTimea);


        noAuthQueueTimea = new ValueStateDescriptor<>("noAuthQueueTimeAccount", TypeInformation.of(new TypeHint<LinkedList<Long>>() {
        }));

        noAuthQueueTimea.enableTimeToLive(stateTtlConfig);

        noAuthQueueTime = getRuntimeContext().getState(noAuthQueueTimea);


        notSuccessQueueTimea = new ValueStateDescriptor<>("notSuccessQueueTimeAccount", TypeInformation.of(new TypeHint<LinkedList<Long>>() {
        }));

        notSuccessQueueTimea.enableTimeToLive(stateTtlConfig);

        notSuccessQueueTime = getRuntimeContext().getState(notSuccessQueueTimea);
        strategyMatchMap = new HashMap<>();
        strategyRule = new StrategyRuleToCalculate();

    }

    @Override
    public void processElement(AssetLog assetLog, ReadOnlyContext readOnlyContext, Collector<AssetLog> collector) throws Exception {
        //访问不存在文件
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg02020102")) && notLoginOperateUtils.isNoFile(assetLog)) {
            setLabel(AssetLogConstants.strategyLabelType.MUTILE_NON_FILE_ACCOUNT.getVal(), assetLog, noFileQueueTime,CommonConstants.RiskLevel.MIDDLE_RISK.getVal());
        }
        //权限不足
        else if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg02030102")) && notLoginOperateUtils.isNoAuth(assetLog) ) {
            setLabel(AssetLogConstants.strategyLabelType.MUTILE_NON_AUTH_ACCOUNT.getVal(), assetLog, noAuthQueueTime,CommonConstants.RiskLevel.MIDDLE_RISK.getVal());
        }
        //返回码为失败
        else if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg02050102")) && notLoginOperateUtils.isNotSuccess(assetLog)) {
            setLabel(AssetLogConstants.strategyLabelType.OPERATE_SQL_ACCOUNT.getVal(), assetLog, notSuccessQueueTime,CommonConstants.RiskLevel.HIGH_RISK.getVal());
        }
        collector.collect(assetLog);

    }


    private void setLabel(String code, AssetLog assetLog, ValueState<LinkedList<Long>> queueAccessTime,Integer risklevel) throws IOException {
        int times = strategyMatchMap.get(code).getStrategyMatchCondition().getTriggerFrequency().getTimes();
        StrategyMatch strategyMatch = strategyMatchMap.get(code);


        if (queueAccessTime.value() == null) {
            LinkedList<Long> queue = new LinkedList<>();
            queue.addLast(assetLog.getRequestTime());
            queueAccessTime.update(queue);
        } else {
            LinkedList<Long> value = queueAccessTime.value();
            value.addLast(assetLog.getRequestTime());
            queueAccessTime.update(value);
        }
        if (queueAccessTime.value().size() > times) {

            ConditionTOMarking.reSetFrequencyAlarmModule(queueAccessTime.value(), queueAccessTime.value().size() - times);
        }

        if (queueAccessTime.value().size() == times) {

            if (assetLog.getRequestTime() - queueAccessTime.value().getFirst() <
                    ConditionTOMarking.transFormationTime(strategyMatch.getStrategyMatchCondition().getTriggerFrequency().getTime(),
                            strategyMatch.getStrategyMatchCondition().getTriggerFrequency().getUnit())) {
                logger.info("asset log marking {} logid:{}, userName:{}", code, assetLog.getFirstId(), assetLog.getSecondId());
                ConditionTOMarking.setStrategy(assetLog, strategyMatch,risklevel);
            }
        }
    }

    @Override
    public void processBroadcastElement(Tuple4<Integer, Integer, String, String> value, Context context, Collector<AssetLog> collector) throws Exception {

        if (value.f0.equals(CommonConstants.ZkDataType.RISK_TYPE.getVal())) {
            StrategyMatch strategyMatch = parsingZkSource.parsingZkJson(value.f3);
            if (value.f1.equals(CommonConstants.OperateType.ADD.getVal()) || value.f1.equals(CommonConstants.OperateType.UPDATE.getVal())) {
                strategyMatchMap.put(strategyMatch.getStrategy(), strategyMatch);
            } else {
                strategyMatchMap.remove(strategyMatch.getStrategy());
            }

        }
//        else if (value.f0.equals(CommonConstants.ZkDataType.RISK_STATU.getVal())) {
//            if (value.f1.equals(CommonConstants.OperateType.ADD.getVal()) || value.f1.equals(CommonConstants.OperateType.UPDATE.getVal())) {
//                strategystatusMap = JSONObject.parseObject(value.f3, Map.class);
//            }
//        }

    }
}
