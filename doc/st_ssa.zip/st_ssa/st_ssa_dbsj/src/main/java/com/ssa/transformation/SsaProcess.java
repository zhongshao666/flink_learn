package com.ssa.transformation;

import com.ssa.bean.StatisticsBean;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.util.Collector;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class SsaProcess extends KeyedProcessFunction<Integer, Tuple2<Integer, List<StatisticsBean>>, List<StatisticsBean>> {
    private SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private Long interval;
    private ValueState<Boolean> bool;
    private List<StatisticsBean> tempBean;

    public SsaProcess(Time size) {
        this.interval = size.toMilliseconds();
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        bool = getRuntimeContext().getState(new ValueStateDescriptor<Boolean>("isOnTimerCollect", Boolean.class));

        tempBean = new ArrayList<>();
    }

    @Override
    public void processElement(Tuple2<Integer, List<StatisticsBean>> value, Context ctx, Collector<List<StatisticsBean>> out) throws Exception {

        bool.update(false);

        long time = format.parse(value.f1.get(0).getTs()).getTime();
        ctx.timerService().deleteProcessingTimeTimer(time + 10000);
        ctx.timerService().registerProcessingTimeTimer(time + interval + 10000);
        out.collect(value.f1);
    }

    @Override
    public void onTimer(long timestamp, OnTimerContext ctx, Collector<List<StatisticsBean>> out) throws Exception {

        System.out.println(bool.value());
        if (bool.value()) {
            ctx.timerService().registerProcessingTimeTimer(timestamp + interval);
            sendSsa(timestamp - 10000, out);
        } else {

            ctx.timerService().registerProcessingTimeTimer(timestamp + interval);
            bool.update(true);
            sendSsa(timestamp - 10000, out);
        }
    }

    private void sendSsa(long timestamp, Collector<List<StatisticsBean>> out) {
        String time = format.format(timestamp);
        tempBean.clear();
        tempBean.add(new StatisticsBean("01", "02", "01", time, 900, 0.0));
        tempBean.add(new StatisticsBean("01", "02", "02", time, 900, 0.0));
        tempBean.add(new StatisticsBean("01", "02", "03", time, 900, 0.0));
        out.collect(tempBean);
    }
}
