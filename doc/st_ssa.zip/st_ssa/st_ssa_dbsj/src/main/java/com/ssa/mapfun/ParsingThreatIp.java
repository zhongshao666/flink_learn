package com.ssa.mapfun;

import com.alibaba.fastjson.JSON;
import com.ssa.bean.ThreatIntelligenceIp;

import java.util.List;

public class ParsingThreatIp {
    public static List<ThreatIntelligenceIp> parsingThreatIp(String data) {
        return JSON.parseArray(data, ThreatIntelligenceIp.class);
    }
}
