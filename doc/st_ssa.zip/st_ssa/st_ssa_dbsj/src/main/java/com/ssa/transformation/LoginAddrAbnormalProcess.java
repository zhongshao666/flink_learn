package com.ssa.transformation;

import com.ssa.DbsjMain;
import com.ssa.bean.AssetLog;
import com.ssa.bean.CommonConfig;
import com.ssa.bean.OfflineData;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import com.ssa.mapfun.ConditionTOMarking;
import com.ssa.mapfun.ParsingCommonConfig;
import com.ssa.matchrule.MatchStrategyRule;
import com.ssa.matchrule.StrategyRuleToCalculate;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.BroadcastProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;


/**
 * 异地登录
 */
public class LoginAddrAbnormalProcess extends BroadcastProcessFunction<AssetLog, Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>, AssetLog> {
    private static final Logger logger = LoggerFactory.getLogger(LoginAddrAbnormalProcess.class);
    private HashMap<String, HashSet<String>> loginAddrMap;
    private HashSet<String> commonIp;
    private HashSet<Tuple3<String, Integer, String>> commonAccount;
    private ParameterTool parameterTool;
    private Map<Integer, Tuple2<LocalTime, LocalTime>> commonConfigMap;
    private StrategyRuleToCalculate strategyRule;

    private DateTimeFormatter dateTimeFormatter;
    private Calendar calendar;

    @Override
    public void open(Configuration parameters) throws Exception {
//        loginAddrSet = getRuntimeContext().getState(new ValueStateDescriptor<>("loginAddrSet", TypeInformation.of(new TypeHint<HashMap<String,String>>() {})));
//        loginAddrSet.update(new HashMap<>());
        loginAddrMap = new HashMap<>();
        commonIp = new HashSet<>();
        commonAccount = new HashSet<>();
        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        dateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm");

        calendar = Calendar.getInstance();

        commonConfigMap = new HashMap<>();

        strategyRule = new StrategyRuleToCalculate();
    }

    @Override
    public void processElement(AssetLog assetLog, ReadOnlyContext readOnlyContext, Collector<AssetLog> collector) throws Exception {
        boolean b = false;
        boolean c = false;

        LocalDateTime localDateTime = LocalDateTime.ofEpochSecond(assetLog.getRequestTime() / 1000L, 0, ZoneOffset.ofHours(8));
        String format = localDateTime.format(dateTimeFormatter);
        LocalTime dateN = LocalTime.parse(format);
        calendar.setTimeInMillis(assetLog.getRequestTime());
        int week = calendar.get(Calendar.DAY_OF_WEEK);


        if (Optional.ofNullable(assetLog.getClientIp()).isPresent() && commonIp.contains(assetLog.getClientIp())) {
            b = true;
        }


        for (Tuple3<String, Integer, String> tuple3 : commonAccount) {
            if (tuple3.f0.equals(assetLog.getServerIp()) && tuple3.f1.equals(assetLog.getServerPort()) && tuple3.f2.equals(assetLog.getAccount())) {
                b = true;
                break;
            }
        }


        if (commonConfigMap.containsKey(week) && dateN.isBefore(commonConfigMap.get(week).f1) && dateN.isAfter(commonConfigMap.get(week).f0)) {
            b = true;
        }

        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg02010101"))) {
            if (!b && Optional.ofNullable(assetLog.getAccount()).isPresent() && loginAddrMap.containsKey(assetLog.getAccount())) {
                if (!loginAddrMap.get(assetLog.getAccount()).contains(assetLog.getClientIp())) {
                    c = true;
                }
            }
        }

        if (b) {

            readOnlyContext.output(DbsjMain.loginAddrAbnormal, assetLog);
        } else {

            if (c) {
                //打标
                ConditionTOMarking.setStrategy(assetLog,
                        AssetLogConstants.strategyLabelType.DIFFERENT_ADDRESS_LOGIN.getVal(),
                        CommonConstants.RiskLevel.HIGH_RISK.getVal());
            }
            collector.collect(assetLog);
        }
    }

    @Override
    public void processBroadcastElement(Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>> value, Context context, Collector<AssetLog> collector) throws Exception {
        try {
            if (Optional.ofNullable(value.f0).isPresent()) {
                HashSet<String> strings = loginAddrMap.get(value.f0.getAccount());
                if (strings == null){
                    HashSet<String> hashSet = new HashSet<>();
                    hashSet.add(value.f0.getClientIp());
                    loginAddrMap.put(value.f0.getAccount(),hashSet );
                }else {
                    loginAddrMap.get(value.f0.getAccount()).add(value.f0.getClientIp());
                }
            } else if (Optional.ofNullable(value.f1).isPresent()) {
                List<CommonConfig> commonConfigs = ParsingCommonConfig.parsingCommonConfig(value.f1.f3);
                if (commonConfigs != null) {
                    if (value.f1.f0 == CommonConstants.ZkDataType.COMMON_IP.getVal()) {
                        if (value.f1.f1 == CommonConstants.OperateType.ADD.getVal() || value.f1.f1 == CommonConstants.OperateType.UPDATE.getVal()) {
                            commonIp.clear();
                            for (CommonConfig commonConfig : commonConfigs) {
                                commonIp.add(commonConfig.getValue());
                            }
                        }
                    } else if (value.f1.f0 == CommonConstants.ZkDataType.COMMON_ACCOUNT.getVal()) {
                        if (value.f1.f1 == CommonConstants.OperateType.ADD.getVal() || value.f1.f1 == CommonConstants.OperateType.UPDATE.getVal()) {
                            commonAccount.clear();
                            for (CommonConfig commonConfig : commonConfigs) {
                                String[] split = commonConfig.getKey().split(":");
                                if (split.length == 2)
                                    commonAccount.add(new Tuple3<>(split[0], Integer.parseInt(split[1]), commonConfig.getValue()));
                            }
                        }
                    } else if (value.f1.f0 == CommonConstants.ZkDataType.COMMON_TIME.getVal()) {
                        strategyRule.matchNonWorkingTime(value.f1, value.f1.f3, commonConfigMap);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
