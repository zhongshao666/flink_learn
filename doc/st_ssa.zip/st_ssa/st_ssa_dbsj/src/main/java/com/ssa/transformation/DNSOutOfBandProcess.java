package com.ssa.transformation;

import com.ssa.bean.AssetLog;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import com.ssa.mapfun.ConditionTOMarking;
import com.ssa.matchrule.StrategyRuleToCalculate;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashSet;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;

/**
 * 利用UTL_INADDR_GET_HOST_NAME进行DNS带外查询
 */
public class DNSOutOfBandProcess extends ProcessFunction<AssetLog, AssetLog> {
    private Logger logger = LoggerFactory.getLogger(DNSOutOfBandProcess.class);

    private HashSet<String> sqlInjection;
    private HashSet<String> sqlInjectionRegular;
    private StrategyRuleToCalculate strategyRule;
    private ParameterTool parameterTool;

    @Override
    public void open(Configuration parameters) throws Exception {
        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        sqlInjection = new HashSet<>();
        sqlInjectionRegular = new HashSet<>();

        setSqlInjectionSet(sqlInjection);
        setSqlInjectionRegularSet(sqlInjectionRegular);
        strategyRule = new StrategyRuleToCalculate();
    }

    @Override
    public void processElement(AssetLog value, Context ctx, Collector<AssetLog> out) throws Exception {
        AtomicBoolean flag = new AtomicBoolean(true);

        //Match DNS
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg03010101"))) {
            Optional.ofNullable(value.getOperationStatement()).ifPresent(item -> {
                for (String temp : sqlInjectionRegular) {
                    if (Pattern.compile(temp).matcher(item).find()) {
                        flag.set(false);
                        break;
                    }

                }
            });
        }
        //Match SQL Function
        Optional.ofNullable(value.getOperationStatement()).ifPresent(item -> {
            if (!flag.get()) {
                for (String temp : sqlInjection) {
                    if (item.toUpperCase().contains(temp)) {
                        marking(value);
                        break;
                    }
                }
            }
        });

        out.collect(value);
    }

    public void setSqlInjectionSet(HashSet<String> sqlInjection) {
        //Oracle
        sqlInjection.add("UTL_INADDR.GET_HOST_NAME");
        sqlInjection.add("UTL_INADDR.GET_HOST_ADDRESS");
        sqlInjection.add("UTL_HTTP.REQUEST");
        sqlInjection.add("HTTPURITYPE");
        sqlInjection.add("DBMS_LDAP.INIT");
        //MySql
        sqlInjection.add("LOAD_FILE");
    }

    public void setSqlInjectionRegularSet(HashSet<String> sqlInjectionRegular) {
        sqlInjectionRegular.add("'.+?\\.+[\\w/\\\\]{2,}'");
    }

    public void marking(AssetLog value) {
        logger.info("asset log marking sql intjection first id : {} , second id : {} ,client ip : {}, account : {}", value.getFirstId(), value.getSecondId(), value.getClientIp(), value.getAccount());
        ConditionTOMarking.setStrategy(value, AssetLogConstants.strategyLabelType.SQL_INJECTION.getVal(), CommonConstants.RiskLevel.HIGH_RISK.getVal());
    }

}
