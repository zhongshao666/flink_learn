package com.ssa.strategy;

import com.ssa.bean.AssetLog;
import org.apache.flink.api.common.functions.MapFunction;

public class SQLInjection implements MapFunction<AssetLog, AssetLog> {

    @Override
    public AssetLog map(AssetLog assetLog) throws Exception {



        return assetLog;
    }
}
