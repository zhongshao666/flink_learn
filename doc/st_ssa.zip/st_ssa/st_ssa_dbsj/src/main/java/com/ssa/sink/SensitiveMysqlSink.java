package com.ssa.sink;

import org.apache.flink.api.java.tuple.Tuple8;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;

import java.sql.*;
import java.util.List;

public class SensitiveMysqlSink extends RichSinkFunction<Tuple8<String, String, String, Integer, String, String, List<String>, List<String>>> {


    Connection connection = null;
    private ParameterTool parameterTool;

    PreparedStatement insertInto = null;
    PreparedStatement truncateTable = null;

    @Override
    public void open(Configuration parameters) throws Exception {
        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        Class.forName(parameterTool.get("mysql.class"));
        connection = DriverManager.getConnection(parameterTool.get("mysql.url"), parameterTool.get("mysql.user"), parameterTool.get("mysql.passwd"));
        insertInto = connection.prepareStatement("insert into dm_nml_sensitive_table(batchId,catalog,ip,`port`,instance,pattern,sensitiveTable,sensitiveField) values(?,?,?,?,?,?,?,?)");
        truncateTable = connection.prepareStatement("truncate dm_nml_sensitive_table");

    }

    @Override
    public void invoke(Tuple8<String, String, String, Integer, String, String, List<String>, List<String>> value, Context context) throws Exception {
        try {

            if (value.f1.equals("01")) {
                try (Connection connection = DriverManager.getConnection(parameterTool.get("mysql.url"), parameterTool.get("mysql.user"), parameterTool.get("mysql.passwd"));
                     Statement statement = connection.createStatement();
                     ResultSet resultSet = statement.executeQuery("select batchId from dm_nml_sensitive_table limit 1")) {
                    if (resultSet.next() ) {
                        if ( !resultSet.getString("batchId").equals(value.f0)) {
                            truncateTable.execute();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                insertInto.setString(1, value.f0);
                insertInto.setString(2, value.f1);
                insertInto.setString(3, value.f2);
                insertInto.setInt(4, value.f3);
                insertInto.setString(5, value.f4);
                insertInto.setString(6, value.f5);
                insertInto.setString(7, String.join(",", value.f6));
                insertInto.setString(8, String.join(",", value.f7));

                insertInto.execute();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void close() throws Exception {
        try {
            if (insertInto != null) {
                insertInto.close();
            }
            if (truncateTable != null) {
                truncateTable.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            super.close();
        }
    }
}
