package com.ssa.mapfun;

import com.alibaba.fastjson.JSON;
import com.ssa.bean.CommonConfig;

import java.util.List;

public class ParsingCommonConfig {
    public static List<CommonConfig> parsingCommonConfig(String data) {
        return JSON.parseArray(data, CommonConfig.class);
    }
}
