package com.ssa.transformation;

import com.alibaba.fastjson.JSONObject;
import com.ssa.bean.StatisticsBean;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.util.Collector;

import java.util.List;

public class StatisToStringProcess implements FlatMapFunction<List<StatisticsBean>,String> {
    @Override
    public void flatMap(List<StatisticsBean> statisticsBeans, Collector<String> collector) throws Exception {
        for(StatisticsBean statisticsBean:statisticsBeans){
            collector.collect( JSONObject.toJSONString(statisticsBean));
        }
    }
}
