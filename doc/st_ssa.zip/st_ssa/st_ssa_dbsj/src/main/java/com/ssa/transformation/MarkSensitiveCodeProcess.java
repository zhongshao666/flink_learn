package com.ssa.transformation;

import com.ssa.bean.AssetLog;

import com.ssa.mapfun.ConditionTOMarking;
import org.apache.flink.api.java.tuple.Tuple8;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.BroadcastProcessFunction;
import org.apache.flink.streaming.api.functions.co.CoProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


/**
 * 敏感字段打标
 */
public class MarkSensitiveCodeProcess extends BroadcastProcessFunction<AssetLog, Tuple8<String, String, String, Integer, String, String, List<String>, List<String>>, AssetLog> {
    private static final Logger logger = LoggerFactory.getLogger(MarkSensitiveCodeProcess.class);

    //tuple8  批次号    kafka类型(01,02,03)   ip       port     实例     模式     tableList     fieldList
    private List<Tuple8<String, String, String, Integer, String, String, List<String>, List<String>>> tableList;
    private List<Tuple8<String, String, String, Integer, String, String, List<String>, List<String>>> fieldList;

    private List<String> tables;
    private ParameterTool parameterTool;

    static {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void open(Configuration parameters) throws Exception {
        System.setProperty("zookeeper.sasl.client", "false");
        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig()
                .getGlobalJobParameters();

        tables = new ArrayList<>();
        tableList = new ArrayList<>();
        fieldList = new ArrayList<>();

        init();
    }

    @Override
    public void processElement(AssetLog assetLog, ReadOnlyContext context, Collector<AssetLog> collector) throws Exception {

        for (Tuple8<String, String, String, Integer, String, String, List<String>, List<String>> tableTuple8 : tableList) {
            if (tableTuple8.f2.equals(assetLog.getServerIp()) && tableTuple8.f3.equals(assetLog.getServerPort()) && tableTuple8.f4.equalsIgnoreCase(assetLog.getInstanceName())) {
                List<String> operandName = assetLog.getOperandName();
                for (String tableName : operandName) {
                    //表模式
                    if (tableName.contains(".")) {
                        for (String tb : tableTuple8.f6) {
                            String s = tableTuple8.f5 + "." + tb;
                            if (tableName.equalsIgnoreCase(s)) {
                                //敏感表
                                ConditionTOMarking.setStrategy(assetLog, "table", tableName,null);
                                assetLog.setIsSensitiveTable(1);
                            }
                        }
                    } else {
                        for (String tb : tableTuple8.f6) {
                            if (tableName.equalsIgnoreCase(tb)) {
                                //敏感表
                                ConditionTOMarking.setStrategy(assetLog, "table", tableName,null);
                                assetLog.setIsSensitiveTable(1);
                            }
                        }
                    }
                }
            }
        }

        for (Tuple8<String, String, String, Integer, String, String, List<String>, List<String>> fieldTuple8 : fieldList) {
            if (fieldTuple8.f2.equals(assetLog.getServerIp()) && fieldTuple8.f3.equals(assetLog.getServerPort()) && fieldTuple8.f4.equalsIgnoreCase(assetLog.getInstanceName())) {
                //先判断是否有这个表
                List<String> secondOperandName = assetLog.getSecondOperandName();
                tableAddInstance(assetLog);
                if (fieldTuple8.f5.equals("") && tables.contains((fieldTuple8.f4 + "." + fieldTuple8.f6.get(0)).toUpperCase())) {
                    getSensitiveCode(assetLog, fieldTuple8, secondOperandName);
                } else if (!fieldTuple8.f5.equals("") && tables.contains((fieldTuple8.f5 + "." + fieldTuple8.f6.get(0)).toUpperCase())) {
                    getSensitiveCode(assetLog, fieldTuple8, secondOperandName);
                }
            }
        }

        assetLog.setSensitiveTables(assetLog.getSensitiveTables().stream().distinct().collect(Collectors.toList()));
        assetLog.setSensitiveColumns(assetLog.getSensitiveColumns().stream().distinct().collect(Collectors.toList()));

        collector.collect(assetLog);

    }

    public void getSensitiveCode(AssetLog assetLog, Tuple8<String, String, String, Integer, String, String, List<String>, List<String>> fieldTuple8, List<String> secondOperandName) {
        for (String fieldName : secondOperandName) {
            if (fieldTuple8.f7.contains(fieldName) || "*".equals(fieldName)) {
                String tableName = fieldTuple8.f6.get(0);
                //敏感表  敏感字段
                if (!fieldTuple8.f5.equals("")) {
                    tableName = fieldTuple8.f4 + "." + fieldTuple8.f6.get(0);
                }
                ConditionTOMarking.setStrategy(assetLog, "table", tableName,null);
                ConditionTOMarking.setStrategy(assetLog, "column", fieldName,fieldTuple8.f7);
                assetLog.setIsSensitiveTable(1);
            }
        }
    }

    @Override
    public void processBroadcastElement(Tuple8<String, String, String, Integer, String, String, List<String>, List<String>> value, Context ctx, Collector<AssetLog> out) throws Exception {
        switch (value.f1) {
            case "01":
                tableList.add(value);
                break;
            case "02":
                fieldList.add(value);
                break;
            case "03":
                tableList.clear();
                fieldList.clear();
                break;
        }
    }

    public void init() {
        try (
                Connection connection = DriverManager.getConnection(parameterTool.get("mysql.url"), parameterTool.get("mysql.user"), parameterTool.get("mysql.passwd"));
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery("select * from " + parameterTool.get("mysql.table.sensitive"))) {
            while (resultSet.next()) {
                Tuple8<String, String, String, Integer, String, String, List<String>, List<String>> tuple8 = new Tuple8<>();
                tuple8.f0 = resultSet.getString("batchId");
                tuple8.f1 = resultSet.getString("catalog");
                tuple8.f2 = resultSet.getString("ip");
                tuple8.f3 = resultSet.getInt("port");
                tuple8.f4 = resultSet.getString("instance");
                tuple8.f5 = resultSet.getString("pattern");
                tuple8.f6 = Arrays.asList(resultSet.getString("sensitiveTable").split(","));
                tuple8.f7 = Arrays.asList(resultSet.getString("sensitiveField").split(","));
                if (tuple8.f1.equals("01")) {
                    tableList.add(tuple8);
                }
                if (tuple8.f1.equals("02")) {
                    fieldList.add(tuple8);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void tableAddInstance(AssetLog assetLog) {
        tables.clear();
        for (String table : assetLog.getOperandName()) {
            if (!table.contains(".")) {
                tables.add(assetLog.getInstanceName().toUpperCase() + "." + table);
            } else {
                tables.add(table);
            }
        }
    }

}
