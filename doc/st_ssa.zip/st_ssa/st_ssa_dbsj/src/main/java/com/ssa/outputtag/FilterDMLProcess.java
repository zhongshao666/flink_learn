package com.ssa.outputtag;

import com.ssa.DbsjMain;
import com.ssa.bean.AssetLog;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;

/**
 * @author : hld
 * @Date ： 2021/4/9
 * @Time : 14:53
 * @role ：
 */
public class FilterDMLProcess extends ProcessFunction<AssetLog, AssetLog> {
    @Override
    public void processElement(AssetLog value, Context ctx, Collector<AssetLog> out) throws Exception {
        if (AssetLogConstants.operationTypeCatalog.CTDML.getValues() == value.getOperationType().intValue()) {
            ctx.output(DbsjMain.DMLOperation, value);
        } else {
            out.collect(value);
        }
    }
}
