package com.ssa.transformation;

import com.ssa.bean.AssetLog;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import com.ssa.mapfun.ConditionTOMarking;
import com.ssa.matchrule.StrategyRuleToCalculate;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;



/**
 * @author : hld
 * @Date ： 2021/4/15
 * @Time : 20:24
 * @role ：
 */
public class SqlInjectionProcess extends ProcessFunction<AssetLog, AssetLog> {

    private Logger logger  = LoggerFactory.getLogger(SqlInjectionProcess.class);

    private HashSet<String> sqlInjection;
    private HashSet<String> sqlInjectionRegular;
    private StrategyRuleToCalculate strategyRule;
    private ParameterTool parameterTool;



    @Override
    public void open(Configuration parameters) throws Exception {
        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        sqlInjection = new HashSet<>();
        sqlInjectionRegular = new HashSet<>();

        setSqlInjectionSet(sqlInjection);
        setSqlInjectionRegularSet(sqlInjectionRegular);
        strategyRule = new StrategyRuleToCalculate();
    }

    @Override
    public void processElement(AssetLog value, Context ctx, Collector<AssetLog> out) throws Exception {

        AtomicBoolean flag = new AtomicBoolean(true);


        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg03010101"))) {
            Optional.ofNullable(value.getOperationStatement()).ifPresent(item -> {
                for (String temp : sqlInjectionRegular) {
                    if (Pattern.compile(temp).matcher(item).find()) {
                        marking(value);
                        flag.set(false);
                        break;
                    }

                }
            });
        }


        Optional.ofNullable(value.getOperationStatement()).ifPresent(item -> {
            if (flag.get()) {
                for (String temp : sqlInjection) {
                    if (item.toUpperCase().contains(temp)) {
                        if (temp.equalsIgnoreCase("ORD") && Pattern.compile("ORDER\\s+BY").matcher(temp).find() ){
                            marking(value);
                            break;
                        }
                        marking(value);
                        break;
                    }
                }
            }
        });

        out.collect(value);
    }

    public void setSqlInjectionSet(HashSet<String> sqlInjection) {

        sqlInjection.add("SUBSTRING_INDEX");
        sqlInjection.add("SUBSTR");
        sqlInjection.add("SUBSTRING");
        sqlInjection.add("LEFT");
        sqlInjection.add("RIGHT");
        sqlInjection.add("MID");
        sqlInjection.add("CHAR");
        sqlInjection.add("CONCAT_WS");
        sqlInjection.add("CONCAT");
        sqlInjection.add("MAKE_SET");
        sqlInjection.add("ELT");
        sqlInjection.add("RPAD");
        sqlInjection.add("LPAD");
        sqlInjection.add("RTRIM");
        sqlInjection.add("LTRIM");
        sqlInjection.add("TRIM");
        sqlInjection.add("STRCMP");
        sqlInjection.add("LENGTH");
        sqlInjection.add("ORD");
        sqlInjection.add("ORDSYS.ORD_DICOM.GETMAPPINGXPATH");
        sqlInjection.add("DBMS_XDB_VERSION.MAKEVERSIONED");
        sqlInjection.add("UTL_INADDR.GET_HOST_NAME");
        sqlInjection.add("UTL_INADDR.GET_HOST_ADDRESS");
        sqlInjection.add("DBMS_XDB_VERSION.UNCHECKOUT");
        sqlInjection.add("DBMS_XDB_VERSION.CHECKIN");
        sqlInjection.add("DBMS_UTILITY.SQLID_TO_SQLHASH");
        sqlInjection.add("CTXSYS.DRITHSX.SN");
        sqlInjection.add("MULTIPOLYGON");
        sqlInjection.add("LINESTRING");
        sqlInjection.add("MULTILINESTRING");
        sqlInjection.add("MULTIPOINT");
        sqlInjection.add("POLYGON");
        sqlInjection.add("GEOMETRYCOLLECTION");
        sqlInjection.add("EXP");
        sqlInjection.add("RAND");
        sqlInjection.add("FLOOR");
        sqlInjection.add("XMLTYPE");
        sqlInjection.add("CAST");
        sqlInjection.add("CONVERT");
        sqlInjection.add("UPDATEXML");
        sqlInjection.add("EXTRACTVALUE");
        sqlInjection.add("DBMS_PIPE.RECEIVE_MESSAGE");
        sqlInjection.add("SLEEP");
        sqlInjection.add("PG_SLEEP");
        sqlInjection.add("PG_SLEEP_FOR");
        sqlInjection.add("WAITFORDELAY");
        sqlInjection.add("PG_SLEEP_UNTIL");
        sqlInjection.add("WAITFORTIME");
        sqlInjection.add("GENERATE_SERIES");
        sqlInjection.add("BENCHMARK");
        sqlInjection.add("CTXSYS.DRILOAD");
        sqlInjection.add("SYS.KUPW$WORKER");
    }

    public void setSqlInjectionRegularSet(HashSet<String> sqlInjectionRegular) {
        sqlInjectionRegular.add("[\\(, \\), \\,, \\., \\', \\\", \\?, \\&, \\@, \\%, \\|, \\*, \\-]{5}");
        sqlInjectionRegular.add("\\d+\\s*\\=\\s*\\d+");
        sqlInjectionRegular.add("UNION.*\\s+.*SELECT");
    }

    public void marking(AssetLog value){
        logger.info("asset log marking sql intjection first id : {} , second id : {} ,client ip : {}, account : {}",value.getFirstId(),value.getSecondId(),value.getClientIp(),value.getAccount());
        ConditionTOMarking.setStrategy(value, AssetLogConstants.strategyLabelType.SQL_INJECTION.getVal(), CommonConstants.RiskLevel.HIGH_RISK.getVal());
    }
}
