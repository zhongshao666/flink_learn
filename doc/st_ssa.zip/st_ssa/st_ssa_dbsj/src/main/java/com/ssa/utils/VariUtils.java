package com.ssa.utils;

import java.util.ArrayList;

/**
 *  @author : cjj
 *  @Date ： 2021/4/27
 *  @Time :
 *  @role ：
 */
public class VariUtils {
    /**
     * 平均值
     * @param list 时间差
     * @param max 最大值
     * @return 平均值
     */
    public static double average(ArrayList<Long> list,double max){
        //归一化后的值
        double sum = 0;
        for (Long aLong : list) {
            double value = aLong/(max+0.0001);
            sum+=value;
        }
        return sum/list.size();
    }

    /**
     * 计算归一化后的方差
     * @param list 时间差
     * @param average 平均值
     * @param max 最大值
     * @return  方差
     */
    public static double variance(ArrayList<Long> list, double average, double max){
        double variance = 0;
        for (Long aLong : list) {
            double value = aLong/(max+0.0001);
            variance = variance+(value-average)*(value-average);
        }
        return  variance / list.size();
    }
}
