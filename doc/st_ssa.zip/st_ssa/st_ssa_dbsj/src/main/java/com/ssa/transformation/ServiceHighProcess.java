package com.ssa.transformation;

import com.ssa.bean.AssetLog;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.KeyedBroadcastProcessFunction;
import org.apache.flink.util.Collector;

/**
 *业务高频访问
 */
public class ServiceHighProcess extends KeyedBroadcastProcessFunction<String, AssetLog, Tuple4<Integer, Integer, String, String>, AssetLog> {

    //离线获取用户
    private String acc = "acc";

    @Override
    public void open(Configuration parameters) throws Exception {

    }

    @Override
    public void processElement(AssetLog assetLog, ReadOnlyContext ctx, Collector<AssetLog> out) throws Exception {

        //离线

        if (assetLog.getAccount().equals(acc)) {

        }
    }

    @Override
    public void processBroadcastElement(Tuple4<Integer, Integer, String, String> value, Context ctx, Collector<AssetLog> out) throws Exception {

    }
}
