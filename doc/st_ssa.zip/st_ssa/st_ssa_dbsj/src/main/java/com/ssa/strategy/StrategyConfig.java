package com.ssa.strategy;

import lombok.Data;

/**
 * @author Administrator
 */
@Data
public class StrategyConfig {
    private Long appId;

    private Integer ipLimitType;

    private Boolean dataFilteringEnable;

    private Boolean whitelistEnable;

    private Boolean blacklistEnable;

    private Boolean userDefinedEnable;

    private Boolean riskPolicyEnable;

    private String strategyId;

    private Boolean strategyEnable;
}
