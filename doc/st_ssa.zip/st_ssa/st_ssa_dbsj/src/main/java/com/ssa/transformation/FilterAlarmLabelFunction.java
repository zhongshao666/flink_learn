package com.ssa.transformation;

import com.ssa.bean.AssetLog;
import org.apache.flink.api.common.functions.FilterFunction;

import java.util.ArrayList;

public class FilterAlarmLabelFunction implements FilterFunction<AssetLog> {

    @Override
    public boolean filter(AssetLog assetLog) throws Exception {

//        ArrayList arrayList = new ArrayList();
//                arrayList.add("01010201");
//               assetLog.setAlarmLabel(arrayList);
        return assetLog.getAlarmLabel().size()!=0;
    }
}
