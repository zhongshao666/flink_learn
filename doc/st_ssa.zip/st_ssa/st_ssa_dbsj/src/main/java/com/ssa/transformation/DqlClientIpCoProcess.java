package com.ssa.transformation;

import com.ssa.bean.AssetLog;
import com.ssa.bean.CommonConfig;
import com.ssa.bean.OfflineData;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import com.ssa.mapfun.ParsingCommonConfig;
import com.ssa.mapfun.ParsingZkSource;
import com.ssa.matchrule.BroadcastDataMatch;
import com.ssa.matchrule.StrategyRuleToCalculate;
import com.ssa.strategy.StrategyMatch;
import org.apache.flink.api.common.state.BroadcastState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.KeyedBroadcastProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalTime;
import java.util.*;


/**
 * @author : hld
 * @Date ： 2021/4/12
 * @Time : 19:34
 * @role ：
 */
public class DqlClientIpCoProcess extends KeyedBroadcastProcessFunction<String, AssetLog, Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>, AssetLog> {

    private static final Logger logger = LoggerFactory.getLogger(DqlClientIpCoProcess.class);
    private ParameterTool parameterTool;

    public static MapStateDescriptor<String, Tuple3<HashSet<String>, HashSet<String>, HashSet<String>>> dqlClientIpMap = new MapStateDescriptor<String, Tuple3<HashSet<String>, HashSet<String>, HashSet<String>>>("dqlClientIpMap", BasicTypeInfo.STRING_TYPE_INFO, Types.TUPLE(TypeInformation.of(OfflineData.class), Types.TUPLE(BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO)));

    private StrategyRuleToCalculate strategyRule;
    private Map<Integer, Tuple2<LocalTime, LocalTime>> commonConfigMap;
    private BroadcastDataMatch broadcastDataMatch;
    private String matchUserType;
    private ParsingZkSource parsingZkSource;
    private Map<String, StrategyMatch> strategyMatchMap;

    @Override
    public void open(Configuration parameters) throws Exception {
        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        commonConfigMap = new HashMap<>();
        broadcastDataMatch = new BroadcastDataMatch();
        strategyRule = new StrategyRuleToCalculate();
        matchUserType = "ClientIp";
        strategyMatchMap = new HashMap<>();
        parsingZkSource = new ParsingZkSource();
    }


    @Override
    public void processElement(AssetLog value, ReadOnlyContext ctx, Collector<AssetLog> out) throws Exception {

        Tuple3<HashSet<String>, HashSet<String>, HashSet<String>> hashSetTuple3 = ctx.getBroadcastState(dqlClientIpMap).get(ctx.getCurrentKey());

        //异常终端下载敏感数据
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg01040101"))) {
            String abnormalClientMacVal = AssetLogConstants.strategyLabelType.SENSITIVE_ABNORMAL_CLIENTMAC.getVal();
            strategyRule.abnormalClientMac(value, strategyMatchMap.get(abnormalClientMacVal), Optional.ofNullable(hashSetTuple3).map(item -> item.f0).orElse(null),
                    AssetLogConstants.strategyLabelType.SENSITIVE_ABNORMAL_CLIENTMAC.getVal(),
                    CommonConstants.RiskLevel.SERIOUS.getVal(), logger, matchUserType, value.getClientIp());
        }


        //下载非常用敏感表
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg01060101"))) {
            String nonUseTableVal = AssetLogConstants.strategyLabelType.SENSITIVE_NONUSE_TABLE.getVal();
            strategyRule.nonUseSensitiveTable(value, strategyMatchMap.get(nonUseTableVal), Optional.ofNullable(hashSetTuple3).map(item -> item.f1).orElse(null),
                    AssetLogConstants.strategyLabelType.SENSITIVE_NONUSE_TABLE.getVal(), CommonConstants.RiskLevel.SERIOUS.getVal(), logger, matchUserType, value.getClientIp());
        }
        //下载非常用敏感库
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg01070101"))) {
            String nonUseDatabaseVal = AssetLogConstants.strategyLabelType.SENSITIVE_NONUSE_DATABASE.getVal();
            strategyRule.nonUseSensitiveDatabase(value, strategyMatchMap.get(nonUseDatabaseVal),Optional.ofNullable(hashSetTuple3).map(item -> item.f2).orElse(null),
                    AssetLogConstants.strategyLabelType.SENSITIVE_NONUSE_DATABASE.getVal(), CommonConstants.RiskLevel.SERIOUS.getVal(), logger, matchUserType, value.getClientIp());
        }

//        //来自恶意源的敏感数据下载
//        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg01010101)) {
//            strategyRule.maliciousDownSensData(value, AssetLogConstants.strategyLabelType.SENSITIVE_MALICIOUS_DOWNLOAD.getVal(), CommonConstants.RiskLevel.SERIOUS.getVal(), logger, matchUserType, value.getClientIp());
//        }

        //非工作时间下载敏感数据
        if (strategyRule.strategySwitch(parameterTool.get("strategy.id.stg01050101"))) {
            String downloadNonWorkTimeVal = AssetLogConstants.strategyLabelType.SENSITIVE_DOWNLOAD_NONWORKTIME.getVal();
            strategyRule.nonWorkTimeDownSensData(value, strategyMatchMap.get(downloadNonWorkTimeVal), AssetLogConstants.strategyLabelType.SENSITIVE_DOWNLOAD_NONWORKTIME.getVal(), CommonConstants.RiskLevel.SERIOUS.getVal(), commonConfigMap, logger, matchUserType, value.getClientIp());
        }

        out.collect(value);
    }

    @Override
    public void processBroadcastElement(Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>> value, Context ctx, Collector<AssetLog> out) throws Exception {
        BroadcastState<String, Tuple3<HashSet<String>, HashSet<String>, HashSet<String>>> broadcastState = ctx.getBroadcastState(dqlClientIpMap);

        if (value.f0 != null) {
            broadcastDataMatch.matchClientIpTableData(value.f0, value.f0.getClientIp(), broadcastState);
        } else {
            if (value.f1.f0 == CommonConstants.ZkDataType.COMMON_TIME.getVal()) {
                strategyRule.matchNonWorkingTime(value.f1, value.f1.f3, commonConfigMap);
            }
            if (value.f1.f0 == CommonConstants.ZkDataType.RISK_TYPE.getVal()) {
                StrategyMatch strategyMatch = parsingZkSource.parsingZkJson(value.f1.f3);
                strategyMatchMap.put(strategyMatch.getStrategy(), strategyMatch);
            }
        }
    }
}
