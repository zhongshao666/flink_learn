package com.ssa.mapfun;

import com.alibaba.fastjson.JSON;
import com.ssa.bean.ControlData;
import com.ssa.bean.SensitiveData;

public class ParsingKafkaControlData {
    public static ControlData parsingKafkaControlData(String s) {
        return JSON.parseObject(s, ControlData.class);
    }
}
