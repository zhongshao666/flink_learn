package com.ssa.transformation;

import com.ssa.bean.AssetLog;
import com.ssa.constants.AssetLogConstants;
import com.ssa.constants.CommonConstants;
import com.ssa.mapfun.ConditionTOMarking;
import com.ssa.matchrule.StrategyRuleToCalculate;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;


//======================================================================
//*@类名 DropDBProcess
//*@包名 com.ssa.strategy
//*@功能描述：
//*     1. 判断
//*     2.
//*     3.
//*@Version：
//*@创建时间：2021/4/15 20:08
//*@修改时间：2021/4/15 20:08
//*@修改版本号记录：
//*       1. VersionID:
//*          修改内容:
//*          修改原因:
//*       2. VersionID:
//*          修改内容:
//*          修改原因:
//*       3. VersionID:
//*          修改内容:
//*          修改原因:
//*@所属公司： 闪捷科技有限公司
//*@Author:   赵臻柄
//======================================================================
public class DropDBProcess extends ProcessFunction<AssetLog,AssetLog> {
    private ParameterTool parameterTool;
    private StrategyRuleToCalculate strategyRule;

    @Override
    public void open(Configuration parameters) throws Exception {
        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        strategyRule = new StrategyRuleToCalculate();
    }

    @Override
    public void processElement(AssetLog value, Context ctx, Collector<AssetLog> out) throws Exception {

        if(strategyRule.strategySwitch(parameterTool.get("strategy.id.stg04010101")) && "DROP".equalsIgnoreCase(value.getOperationCommand())){
            ConditionTOMarking.setStrategy(value, AssetLogConstants.strategyLabelType.DB_DROP.getVal(), CommonConstants.RiskLevel.HIGH_RISK.getVal());
        }
        out.collect(value);
    }
}
