package com.ssa;

import org.apache.flink.api.java.utils.ParameterTool;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {

        ParameterTool parameterTool = ParameterTool.fromPropertiesFile(DbsjMain.class.getResourceAsStream("/application.properties"));
        System.out.println(parameterTool.get("kafka.url"));

    }
}
