package com.ssa.statistics;

import com.ssa.bean.AssetLog;
import com.ssa.bean.StatisticsBean;
import org.apache.flink.api.common.functions.AggregateFunction;
import org.apache.flink.api.java.tuple.Tuple;
import org.apache.flink.api.java.tuple.Tuple2;

import java.text.SimpleDateFormat;
import java.util.*;

public class StatisticsProcess implements AggregateFunction<AssetLog, Map<String, Double>, Tuple2<Integer, List<StatisticsBean>>> {

    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");


    private List<StatisticsBean> list = new ArrayList<StatisticsBean>();
    private Tuple2<Integer, List<StatisticsBean>> tuple2 = new Tuple2<Integer, List<StatisticsBean>>(1, list);

    @Override
    public Map<String, Double> createAccumulator() {
        HashMap<String, Double> tempmap = new HashMap<>();
        tempmap.put("03", 0.0);
        tempmap.put("08", 0.0);
        tempmap.put("09", 0.0);
        return tempmap;
    }

    @Override
    public Map<String, Double> add(AssetLog assetLog, Map<String, Double> stringIntegerMap) {
        if (assetLog.getFlowLabel().contains("04010101")) {
            stringIntegerMap.put("03", stringIntegerMap.get("03") + 1);
        } else if (assetLog.getIsSensitiveTable() != null) {
            stringIntegerMap.put("08", stringIntegerMap.get("08") + assetLog.getRowsAffected());
        } else if ("SELECT".equals(assetLog.getOperationCommand())) {
            stringIntegerMap.put("09", stringIntegerMap.get("09") + assetLog.getRowsAffected());
        }
        return stringIntegerMap;
    }

    @Override
    public Tuple2<Integer, List<StatisticsBean>> getResult(Map<String, Double> stringIntegerMap) {
        list.clear();

        String time = sdf.format(Calendar.getInstance().getTime());
        list.add(new StatisticsBean("01", "02", "01", time, 900, stringIntegerMap.get("03")));
        list.add(new StatisticsBean("01", "02", "02", time, 900, stringIntegerMap.get("08")));
        list.add(new StatisticsBean("01", "02", "03", time, 900, stringIntegerMap.get("09")));

        return tuple2;
    }

    @Override
    public Map<String, Double> merge(Map<String, Double> stringIntegerMap, Map<String, Double> acc1) {
        Map<String, Double> map = new HashMap<String, Double>();
        map.put("03", acc1.get("03") + stringIntegerMap.get("03"));
        map.put("08", acc1.get("08") + stringIntegerMap.get("08"));
        map.put("09", acc1.get("09") + stringIntegerMap.get("09"));
        return map;
    }
}
