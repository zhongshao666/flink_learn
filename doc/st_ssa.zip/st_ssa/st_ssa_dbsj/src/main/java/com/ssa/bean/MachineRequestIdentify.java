package com.ssa.bean;

import lombok.Data;

/**
 * @author : hld
 * @Date ： 2021/4/28
 * @Time : 11:11
 * @role ：
 */
@Data
public class MachineRequestIdentify {
    /**
     *    稀有度权重
     */
    private Double rarityWeight;
    /**
     * 方差权重，
     */
    private Double varWeight;
    /**
     * 请求总量权重，
     */
    private Double eveNumWeight;
    /**
     * 请求不同Ip数量权重，
     */
    private Double ipNumWeight;
    /**
     * 请求不同port权重，
     */
    private Double portNumWeight;
    /**
     * 请求不同服务端Port权重
     */
    private Double serPortNumWeight;
    /**
     * 异常阈值
     */
    private Double abnormalThreshold;
    /**
     * 请求总量归一化常量
     */
    private Double eveNumThr;
    /**
     * 请求不同Ip数量归一化常量
     */
    private Double ipNumThr;
    /**
     * 请求不同port数量归一化常量
     */
    private Double portNumThr;
    /**
     * 请求不同服务器port数量归一化常量
     */
    private Double serPortNumThr;
    /**
     * 稀有度
     */
    private Double rarityThr;

    {
        rarityWeight = 0.1;
        varWeight = 0.2;
        eveNumWeight = 0.1;
        ipNumWeight = 0.2;
        portNumWeight = 0.2;
        serPortNumWeight = 0.2;
        //异常阈值
        abnormalThreshold = 0.8;
        //归一化常量
        eveNumThr = 100.0;
        ipNumThr = 10.0;
        portNumThr = 10.0;
        serPortNumThr = 10.0;
        rarityThr = 0.1;
    }

    public MachineRequestIdentify() {
    }

    public MachineRequestIdentify(Double rarityWeight, Double varWeight, Double eveNumWeight, Double ipNumWeight, Double portNumWeight, Double serPortNumWeight, Double abnormalThreshold, Double eveNumThr, Double ipNumThr, Double portNumThr, Double serPortNumThr, Double rarityThr) {
        this.rarityWeight = rarityWeight;
        this.varWeight = varWeight;
        this.eveNumWeight = eveNumWeight;
        this.ipNumWeight = ipNumWeight;
        this.portNumWeight = portNumWeight;
        this.serPortNumWeight = serPortNumWeight;
        this.abnormalThreshold = abnormalThreshold;
        this.eveNumThr = eveNumThr;
        this.ipNumThr = ipNumThr;
        this.portNumThr = portNumThr;
        this.serPortNumThr = serPortNumThr;
        this.rarityThr = rarityThr;
    }

    @Override
    public String toString() {
        return "MachineRequestIdentify{" +
                "rarityWeight=" + rarityWeight +
                ", varWeight=" + varWeight +
                ", eveNumWeight=" + eveNumWeight +
                ", ipNumWeight=" + ipNumWeight +
                ", portNumWeight=" + portNumWeight +
                ", serPortNumWeight=" + serPortNumWeight +
                ", abnormalThreshold=" + abnormalThreshold +
                ", eveNumThr=" + eveNumThr +
                ", ipNumThr=" + ipNumThr +
                ", portNumThr=" + portNumThr +
                ", serPortNumThr=" + serPortNumThr +
                ", rarityThr=" + rarityThr +
                '}';
    }
}
