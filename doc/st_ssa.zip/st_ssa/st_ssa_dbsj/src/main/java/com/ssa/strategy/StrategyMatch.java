package com.ssa.strategy;


import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class StrategyMatch {

    /**
     * 策略id
     */
    private Integer id;
    /**
     * 名称
     */
    private String name;
    /**
     * 应用id
     */
    private List<Long> appIds = new ArrayList<>();
    /**
     * 策略类型
     */
    private String strategy;

    /**
     * 规则是否启用
     */
    private Boolean enable;

    /**
     * 风险类型
     */
    private String riskType;

    /**
     * 风险等级
     */
    private Integer riskLevel;
    /**
     * 规则内容
     */
    private StrategyMatchCondition strategyMatchCondition;

}