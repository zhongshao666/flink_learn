package com.ssa.sink;

import com.ssa.bean.StatisticsBean;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.List;

public class MysqlSink extends RichSinkFunction<List<StatisticsBean>> {
    Logger logger = LoggerFactory.getLogger(MysqlSink.class);
    Connection connection = null;
    private ParameterTool parameterTool;

    PreparedStatement preparedStatement = null;

    @Override
    public void open(Configuration parameters) throws Exception {
        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        Class.forName(parameterTool.get("mysql.class"));
        connection = DriverManager.getConnection(parameterTool.get("mysql.url"), parameterTool.get("mysql.user"), parameterTool.get("mysql.passwd"));
        preparedStatement = connection.prepareStatement("insert into " + parameterTool.get("mysql.table.situation") + " (dataType,superType,subType,ts,samplePeriod,typeValue) values (?,?,?,?,?,?)");

    }

    @Override
    public void invoke(List<StatisticsBean> values, Context context) throws Exception {

        try {
            for (StatisticsBean statisticsBean : values) {
                preparedStatement.setString(1, statisticsBean.getDataType());
                preparedStatement.setString(2, statisticsBean.getSuperType());
                preparedStatement.setString(3, statisticsBean.getSubType());
                preparedStatement.setString(4, statisticsBean.getTs());
                preparedStatement.setInt(5, statisticsBean.getSamplePeriod());
                preparedStatement.setDouble(6, statisticsBean.getTypeValue());
                preparedStatement.addBatch();
            }
            preparedStatement.executeBatch();
            logger.info("insert into dm_nml_sjxl_tjjg ssa strategy");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void close() throws Exception {
        try {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            super.close();
        }
    }
}