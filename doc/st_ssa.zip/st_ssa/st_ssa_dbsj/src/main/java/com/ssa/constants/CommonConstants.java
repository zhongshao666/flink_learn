package com.ssa.constants;

/**
 * @author qsj
 * @since 2021/1/24
 */
public class CommonConstants {

    /**
     * dataType
     */
    public enum DataType{
        DBSJ("01"),
        APISJ("02");

        private String val;

        DataType(String val) {
            this.val = val;
        }

        public String getVal() {
            return this.val;
        }
    }


    /**
     * 状态
     */
    public enum Status {
        /**
         * 启用
         */
        ENABLE("1"),
        /**
         * 不启用
         */
        DISALE("0");

        private String val;

        Status(String val) {
            this.val = val;
        }

        public String getVal() {
            return this.val;
        }
    }

    /**
     * 请求时间格式化-yyyy-MM-dd HH:mm:ss.SSS
     */
    public static final String REQUEST_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";


    /**
     * zk数据类型:接口\应用\自动发现
     */
    public enum ZkDataType {
        /**
         * 接口类型
         */
        INTERFACE_TYPE(1),

        /**
         * 应用类型
         */
        APP_TYPE(2),

        /**
         * 自动发现类型
         */
        DISCOVERY_TYPE(3),

        /**
         * 敏感标签类型
         */
        SENSITIVE_LABEL(4),
        /**
         * 全局策略开关类型
         */
        STRATEGY_CONFIG(5),
        /**
         * 黑白名单列表类型
         */
        BW_LIST_TYPE(6),
        /**
         * 用户自定义标签类型
         */
        USER_DEFINE_TYPE(7),
        /**
         * 风险策略类型
         */
        RISK_TYPE(8),

        /**
         *@Author 赵臻柄
         *@Date 2021/4/10 11:24
         *@Method
         *@功能描述 策略开启状态
         *@Param
         *@Return
        */
        RISK_STATU(9),

        /**
         *@Author 赵臻柄
         *@Date 2021/4/10 11:27
         *@Method
         *@功能描述
         *@Param
         *@Return
        */
        OFFLINE_TASK(10),
        /**
         * 常用ip或ip段
         * @Author zhongzhihao
         */
        COMMON_IP(11),
        /**
         * 常用访问时间段
         * @Author zhongzhihao
         */
        COMMON_TIME(12),
        /**
         * 常用用户配置
         * @Author zhongzhihao
         */
        COMMON_ACCOUNT(13),
        /**
         * 威胁情报ip
         */
        THREAT_IP(14),

        /**
         *@Author 赵臻柄
         *@Date 2021/4/22 15:32
         *@Method
         *@功能描述 4A绕行ip配置
         *@Param
         *@Return
        */
        AUTH4A_IP(15),
        /**
         *@Author 赵臻柄
         *@Date 2021/4/22 15:32
         *@Method
         *@功能描述 跨境ip配置
         *@Param
         *@Return
        */
        FOREIGN_IP(16),
        /**
         *@Author 赵臻柄
         *@Date 2021/4/22 15:32
         *@Method
         *@功能描述 内网ip配置
         *@功能描述 内网ip配置
         *@功能描述 内网ip配置
         *@Param
         *@Return
        */
        INTRANET_IP(17),
        /**
         * 机器请求行为识别
         */
        MACHINE_REQUEST(18);
        private int val;

        ZkDataType(int val) {
            this.val = val;
        }

        public int getVal() {
            return this.val;
        }
    }

    /**
     * @Author 赵臻柄
     * @Date 2021/2/3 15:12
     * @Method
     * @功能描述 从zookeeper获取的数据操作类型
     * @Param
     * @Return
     */
    public enum OperateType {
        /**
         * 添加
         */
        ADD(1),
        /**
         * 删除
         */
        DELETE(-1),
        /**
         * 更新
         */
        UPDATE(2),
        /**
         * 其他类型
         */
        OTHER(0);

        private int val;

        OperateType(int val) {
            this.val = val;
        }

        public int getVal() {
            return this.val;
        }

        public static OperateType valueFor(int v) {
            for (OperateType value : OperateType.values()) {
                if (value.getVal() == v) {
                    return value;
                }
            }
            return OTHER;
        }
    }

    /**
     * @Author 赵臻柄
     * @Date 2021/2/3 15:18
     * @Method
     * @功能描述 事件访问类型，分为登入事件和访问事件
     * @Param
     * @Return
     */
    public enum EventType {
        /**
         * 登入事件
         */
        LOGIN(1),
        /**
         * 访问事件
         */
        ACCESS(2);

        private int val;

        EventType(int val) {
            this.val = val;
        }

        public int getVal() {
            return this.val;
        }
    }

    /**
     * 离线表
     */
    public enum OfflineTableType {
        /**
         * 敏感数据高危操作
         */
        SENSITIVE_FIRST_DOWNLOAD("dm_nml_rsba_no_sensitive_num_infor"),
        /**
         * 异常终端下载敏感数据
         */
        SENSITIVE_ABNORMAL_CLIENT_DOWNLOAD("dm_nml_rsba_mac_infor"),
        /**
         * 下载常用敏感表
         */
        SENSITIVE_TABLE_DOWNLOAD("dm_nml_rsba_often_sensitive_table_infor"),
        /**
         * 下载常用敏感库
         */
        SENSITIVE_DATABASE_DOWNLOAD("dm_nml_rsba_often_sensitive_database_infor"),
        /**
         * 沉默账号下载敏感数据
         */
        SENSITIVE_SILENCE_USER_DOWNLOAD("dm_nml_rsba_sensitive_silent_num_infor"),
        /**
         *僵尸账号复活
         */
        ZOMBIE_ACCOUNT("dm_nml_rsba_zombie_num_infor"),
        /**
         * 异地登录
         */
        ANOTHER_LOGIN("dm_nml_rsba_ip_range_infor"),
        /**
         *  和ip相关的通用提交
         */
        COMMON_OPERATION("dm_operation"),
        /**
         * 机器请求行为表
         */
        MACHINE_OFFLINE_TABLE("dm_nml_ueba_dbsj_rarity"),
        /**
         * 模型黑名单
         */
        MODEL_BLACKLIST("dm_dml_ueba_blacklist")
        ;
        private String val;
        OfflineTableType(String val){
            this.val = val;
        }
        public String getVal(){
            return this.val;
        }
    }

    /**
     *@Author 赵臻柄
     *@Date 2021/4/15 14:27
     *@Method
     *@功能描述 风险等级
     *@Param
     *@Return
    */
    public enum RiskLevel {
        /**
         *@Author 赵臻柄
         *@Date 2021/4/15 14:37
         *@Method
         *@功能描述 严重
         *@Param
         *@Return
        */
        SERIOUS(5),
        /**
         *@Author 赵臻柄
         *@Date 2021/4/15 14:37
         *@Method
         *@功能描述 高危
         *@Param
         *@Return
        */
        HIGH_RISK(4),
        /**
         *@Author 赵臻柄
         *@Date 2021/4/15 14:37
         *@Method
         *@功能描述 中危
         *@Param
         *@Return
        */
        MIDDLE_RISK(3),
        /**
         *@Author 赵臻柄
         *@Date 2021/4/15 14:38
         *@Method
         *@功能描述 低危
         *@Param
         *@Return
        */
        LOW_RISK(2),
        /**
         *@Author 赵臻柄
         *@Date 2021/4/15 14:38
         *@Method
         *@功能描述 可信
         *@Param
         *@Return
        */
        TRUSTED(1);
        private Integer val;
        RiskLevel(Integer val){
            this.val = val;
        }
        public Integer getVal(){
            return this.val;
        }
    }

}