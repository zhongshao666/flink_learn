package com.ssa.zzh;

import com.ssa.DbsjMain;
import com.ssa.bean.AssetLog;
import com.ssa.bean.OfflineData;
import com.ssa.mapfun.SourceMapFunction;
import com.ssa.source.ClickHouseZkSource;
import com.ssa.source.SecZookeeperSource;
import com.ssa.transformation.*;
import com.ssa.utils.CuratorOperator;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.api.GetDataBuilder;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.BroadcastStream;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer011;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.util.Map;
import java.util.Properties;

import static com.ssa.DbsjMain.zookeeperConfig;


public class TestLogin {


    StreamExecutionEnvironment streamExecutionEnvironment;
    BroadcastStream<Tuple4<Integer, Integer, String, String>> broadcast;
    SingleOutputStreamOperator<AssetLog> markSensitiveDataStream;
    SingleOutputStreamOperator<AssetLog> assetLogSingleDataStream;
    BroadcastStream<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> loginBlackBroadcast;


    @Test
    @Ignore
    @Before
    public void before() throws Exception {

        String[] args = {"--zkAddr","192.168.24.73:2181","--zkPath", "/dbsj_audit/dbsj/job/config/riskflinkjob"};
        streamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment();

        ParameterTool map = ParameterTool.fromArgs(args);
        Properties properties = new Properties();
        CuratorOperator mcto = null;
        mcto = new CuratorOperator(map.get("zkAddr"));
        GetDataBuilder data = mcto.client.getData();
        properties.load(new ByteArrayInputStream(data.forPath(map.get("zkPath"))));
        ParameterTool parameterTool = ParameterTool.fromMap((Map) properties);

        streamExecutionEnvironment.getConfig()
                .setGlobalJobParameters(parameterTool);


//        KafkaSinkProp kafkaSinkProp = new KafkaSinkProp();
//        kafkaSinkProp.setBOOTSTRAP_SERVERS_CONFIG(kafkaUrl);



        ;
        streamExecutionEnvironment.setParallelism(6);

//        ParameterTool clickHouseSinkGlobalParam = DbsjMain.getClickHouseSinkGlobalParam(clickHouseUrl, clickHouseUser, clickHousePassword);
//        streamExecutionEnvironment.getConfig().setGlobalJobParameters(clickHouseSinkGlobalParam);

        //创建datasource消费者 从kafka 消费数据
        FlinkKafkaConsumer011<String> stringFlinkKafkaConsumer011 = new FlinkKafkaConsumer011<>(parameterTool.get("kafka.topic.collect.asset"), new SimpleStringSchema(), DbsjMain.getKafkaSourceProp(parameterTool).getProp());


        //创建dataSource生产者， 将数据生产到kafka中
//        FlinkKafkaProducer011<String> stringFlinkKafkaProducer011 = new FlinkKafkaProducer011<String>(parameterTool.get("kafka.topic.send.statistics"), new SimpleStringSchema(), DbsjMain.getKafkaSinkProp(parameterTool).getProp2());


        //获取ck数据源
        DataStreamSource<OfflineData> offlineDataDataStreamSource = streamExecutionEnvironment.addSource(new ClickHouseZkSource());

        //获取kafka数据
        DataStreamSource<String> stringDataStreamSource = streamExecutionEnvironment.addSource(stringFlinkKafkaConsumer011);


        DataStreamSource<Tuple4<Integer, Integer, String, String>> tuple2DataStreamSource = streamExecutionEnvironment.addSource(new SecZookeeperSource())
                .setParallelism(1);

        broadcast = tuple2DataStreamSource.broadcast(zookeeperConfig);

        //将数据解析成bean
        assetLogSingleDataStream = stringDataStreamSource.map(new SourceMapFunction()).name("解析bean");

        //将离线数据和zookeeper配置合并，用process做成多广播流，用户可在这里增加广播流分配
        SingleOutputStreamOperator<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> singleOutputStreamOperator = offlineDataDataStreamSource
                .connect(tuple2DataStreamSource).process(new DistrriOutputProcess());

        //获取kafka敏感数据
        DataStreamSource<String> kafkaSensitive = streamExecutionEnvironment.addSource(new FlinkKafkaConsumer011<>("kaf_sensitive", new SimpleStringSchema(), DbsjMain.getKafkaSourceProp(parameterTool).getProp()));
        streamExecutionEnvironment.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
//        SingleOutputStreamOperator<Tuple8<String, String, String, Integer, String, String, List<String>, List<String>>> sensitiveTuple = kafkaSensitive.timeWindowAll(Time.minutes(1)).process(new KafkaSensitiveProcess());
//        markSensitiveDataStream = assetLogSingleDataStream.connect(sensitiveTuple).process(new MarkSensitiveCodeProcess());

        loginBlackBroadcast = singleOutputStreamOperator.getSideOutput(DbsjMain.LoginOutput).broadcast(DbsjMain.DQLOperationBroad);



    }

    @Test
    @Ignore
    public void testAbnormalDownloadSensitive() throws Exception {
        SingleOutputStreamOperator<AssetLog> loginAddrAbnormal = assetLogSingleDataStream.keyBy(AssetLog::getAccount).connect(broadcast).process(new AbnormalDownloadSensitiveDataProcess()).name("异地登录");
        loginAddrAbnormal.print("testAbnormalDownloadSensitive");
        streamExecutionEnvironment.execute();
    }

    @Test
    @Ignore
    public void testNonworking() throws Exception {
        markSensitiveDataStream.print("mark");
        SingleOutputStreamOperator<AssetLog> nonworking = markSensitiveDataStream.connect(broadcast).process(new NonWorkingTimeProcess()).name("非工作时间");
        nonworking.print("nonworking");
        streamExecutionEnvironment.execute();
    }

    @Test
    @Ignore
    public void testLoginAddr() throws Exception {
        SingleOutputStreamOperator<AssetLog> loginAddrAbnormal = markSensitiveDataStream.connect(loginBlackBroadcast).process(new LoginAddrAbnormalProcess()).name("异地登录");
        loginAddrAbnormal.print("LoginAddrAbnormalProcess");
        streamExecutionEnvironment.execute();
    }

    @Test
    @Ignore
    public void testSharing() throws Exception {
        SingleOutputStreamOperator<AssetLog> sharing = markSensitiveDataStream.keyBy(AssetLog::getAccount).connect(broadcast).process(new AccountSharingProcess()).name("账号共享");
        sharing.print("sharing");
        streamExecutionEnvironment.execute();
    }

    @Test
    @Ignore
    public void testLoginAccount() throws Exception {
        SingleOutputStreamOperator<AssetLog> loginAcc = markSensitiveDataStream.keyBy(AssetLog::getAccount).connect(broadcast).process(new LoginPasswordIncorrectByAccountProcess()).name("发起口令暴力破解(账号)");
        loginAcc.print("loginAcc");
        streamExecutionEnvironment.execute();
    }

    @Test
    @Ignore
    public void testLoginIp() throws Exception {
        SingleOutputStreamOperator<AssetLog> loginIp = markSensitiveDataStream.keyBy(AssetLog::getClientIp).connect(broadcast).process(new LoginPasswordIncorrectByIpProcess()).name("撞库（ip）");

        loginIp.print("loginIp");
        streamExecutionEnvironment.execute();
    }


}
