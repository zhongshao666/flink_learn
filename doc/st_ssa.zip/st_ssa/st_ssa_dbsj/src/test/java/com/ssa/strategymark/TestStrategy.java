package com.ssa.strategymark;

import com.ssa.DbsjMain;
import com.ssa.bean.AssetLog;
import com.ssa.bean.OfflineData;
import com.ssa.bean.StatisticsBean;
import com.ssa.constants.CommonConstants;
import com.ssa.keyselectors.AccountKeySelector;
import com.ssa.keyselectors.IpKeySelector;
import com.ssa.mapfun.SourceMapFunction;
import com.ssa.source.ClickHouseZkSource;
import com.ssa.source.SecZookeeperSource;
import com.ssa.statistics.StatisticsProcess;
import com.ssa.transformation.*;
import com.ssa.utils.CuratorOperator;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.api.GetDataBuilder;
import org.apache.flink.streaming.api.datastream.BroadcastStream;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer011;
import org.apache.flink.util.OutputTag;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import static com.ssa.DbsjMain.zookeeperConfig;

/**
 * @author : hld
 * @Date ： 2021/5/13
 * @Time : 16:52
 * @role ：
 */
public class TestStrategy {
    public static OutputTag<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> DQLOperationClientIpTag = new OutputTag<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>>("DQLOperationClientIpTag") {
    };

    public static OutputTag<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> DQLOperationAccountTag = new OutputTag<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>>("DQLOperationBroadTag") {
    };

    StreamExecutionEnvironment env;
    BroadcastStream<Tuple4<Integer, Integer, String, String>> broadcast;

    SingleOutputStreamOperator<AssetLog> test;
    DataStreamSource<OfflineData> offlineDataDataStreamSource;
    SingleOutputStreamOperator<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> offlineConnectZkStream;

    @Test
    @Ignore
    @Before
    public void before() throws Exception {

        String[] args = {"--zkAddr", "192.168.24.251:2181", "--zkPath", "/dbsj_audit/dbsj/job/config/riskflinkjob"};
        env = StreamExecutionEnvironment.getExecutionEnvironment();

        ParameterTool map = ParameterTool.fromArgs(args);
        Properties properties = new Properties();
        CuratorOperator mcto = new CuratorOperator(map.get("zkAddr"));
        GetDataBuilder data = mcto.client.getData();
        properties.load(new ByteArrayInputStream(data.forPath(map.get("zkPath"))));
        ParameterTool parameterTool = ParameterTool.fromMap((Map) properties);

        env.getConfig().setGlobalJobParameters(parameterTool);
        env.setParallelism(1);
        //创建datasource消费者 从kafka 消费数据
        FlinkKafkaConsumer011<String> stringFlinkKafkaConsumer011 = new FlinkKafkaConsumer011<>("test872", new SimpleStringSchema(), DbsjMain.getKafkaSourceProp(parameterTool).getProp());


        //创建dataSource生产者， 将数据生产到kafka中
        FlinkKafkaProducer011<String> stringFlinkKafkaProducer011 = new FlinkKafkaProducer011<String>(parameterTool.get("kafka.topic.send.statistics"), new SimpleStringSchema(), DbsjMain.getKafkaSinkProp(parameterTool).getProp2());


        //获取ck数据源
         offlineDataDataStreamSource = env.addSource(new ClickHouseZkSource());

        //获取kafka数据
        DataStreamSource<String> stringDataStreamSource = env.addSource(stringFlinkKafkaConsumer011);


        DataStreamSource<Tuple4<Integer, Integer, String, String>> tuple2DataStreamSource = env.addSource(new SecZookeeperSource())
                .setParallelism(1);

        broadcast = tuple2DataStreamSource.broadcast(zookeeperConfig);

        //将数据解析成bean
       test= stringDataStreamSource.map(new SourceMapFunction()).name("解析bean");

        //将离线数据和zookeeper配置合并，用process做成多广播流，用户可在这里增加广播流分配
        offlineConnectZkStream = offlineDataDataStreamSource
                .connect(tuple2DataStreamSource).process(new DistrriOutputProcess());
    }

    @Test
    @Ignore
    public void zombieAccountActive() throws Exception {
        //处理僵尸账号复活
      test.keyBy(AssetLog::getAccount)
                .connect(offlineDataDataStreamSource.filter(item -> item.getAccount() != null && CommonConstants.OfflineTableType.ZOMBIE_ACCOUNT.getVal().equals(item.getOfflineTableType()))
                        .keyBy(OfflineData::getAccount))
                .process(new ZombieAccountActiveProcess()).name("僵尸账号复活");
      env.execute();
    }


    @Test
    @Ignore
    public void  testDqlSome() throws Exception {
        BroadcastStream<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> dqlClientIpBroadcast = offlineConnectZkStream.getSideOutput(DQLOperationClientIpTag).broadcast(DqlClientIpCoProcess.dqlClientIpMap);
        SingleOutputStreamOperator<AssetLog> dqlKeyByClientIpDataStream = test.keyBy(AssetLog::getClientIp)
                .connect(dqlClientIpBroadcast).process(new DqlClientIpCoProcess()).name("DQL-KeyBy-ClientIp");
        env.execute();
    }

    @Test
    @Ignore
    public void  testDqlAccSome() throws Exception {
        //KeyBy数据库账号处理
        DataStream<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> sideOutput = offlineConnectZkStream.getSideOutput(DQLOperationAccountTag);
        BroadcastStream<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> dqlAccountBroadcast = sideOutput.broadcast(DqlAccountCoProcess.dqlAccountMap);
        SingleOutputStreamOperator<AssetLog> dqlKeyByAccountDataStream = test.keyBy(AssetLog::getAccount)
                .connect(dqlAccountBroadcast).process(new DqlAccountCoProcess()).name("DQL-KeyBy-Account");
        env.execute();
    }

    @Test
    @Ignore
    public void dqlKeyByClientIpPseudoWindow() throws Exception {
        SingleOutputStreamOperator<AssetLog> dqlKeyByClientIpPseudoWindow = test.keyBy(AssetLog::getClientIp)
                .connect(broadcast).process(new DqlCliPseudoWindowProcess()).name("DQL-KeyBy-ClientIp-PseudoWindow");
        env.execute();
    }

    @Test
    @Ignore
    public void dqlKeyByAccountPseudoWindow() throws Exception {
        SingleOutputStreamOperator<AssetLog> dqlKeyByAccountPseudoWindow = test.keyBy(AssetLog::getAccount)
                .connect(broadcast).process(new DqlAccPseudoWindowProcess()).name("DQL-KeyBy-Account-PseudoWindow");
        env.execute();
    }
    @Test
    @Ignore
    public void dropDBStream() throws Exception {
        SingleOutputStreamOperator<AssetLog> dropDBStream = test.process(new DropDBProcess()).name("DDL类策略");
        env.execute();
    }

    @Test
    @Ignore
    public void abnormalOperationDmlStream() throws Exception {
        //后台变更敏感数据字段
        SingleOutputStreamOperator<AssetLog> abnormalOperationDmlStream = test.connect(broadcast).process(new AbnormalOperationDmlProcess()).name("DML类策略");

        env.execute();
    }

    @Test
    @Ignore
    public void sqlInjectionResult() throws Exception {
        //sql注入算子
        SingleOutputStreamOperator<AssetLog> sqlInjectionResult = test.process(new SqlInjectionProcess()).name("SQL注入算子");

        env.execute();
    }


    @Test
    @Ignore
    public void visitEventProcessByIp() throws Exception {
        //处理客户端ip为key的异常处理
        SingleOutputStreamOperator<AssetLog> visitEventProcessByIp = test.keyBy(new IpKeySelector()).connect(broadcast).process(new VisitEventProcess()).name("处理ip分组后数据库访问事件");

        env.execute();
    }

    @Test
    @Ignore
    public void visitEventProcessByAccount() throws Exception {
        //处理客户端account为key的异常处理
        SingleOutputStreamOperator<AssetLog> visitEventProcessByAccount = test.keyBy(new AccountKeySelector()).connect(broadcast).process(new VisitEventProcess2()).name("处理用户分组后数据库访问事件");

        env.execute();
    }

}
