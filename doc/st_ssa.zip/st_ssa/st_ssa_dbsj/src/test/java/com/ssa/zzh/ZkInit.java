package com.ssa.zzh;

import com.alibaba.fastjson.JSON;
import com.ssa.zksource.OfflineTables;
import com.ssa.strategy.ConditionToFrequencyTools;
import com.ssa.strategy.StrategyMatch;
import com.ssa.strategy.StrategyMatchCondition;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.ZooDefs;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.data.ACL;
import org.junit.Ignore;
import org.junit.Test;

import java.util.ArrayList;

public class ZkInit {
    @Test
    @Ignore
    public void init() throws KeeperException, InterruptedException {
        StrategyMatch share = new StrategyMatch();
        share.setId(301);
        share.setName("登录使用终端异常");
        share.setStrategy("02060101");
        share.setEnable(true);
        share.setRiskLevel(4);
        share.setRiskType("020601");
        StrategyMatchCondition shareC = new StrategyMatchCondition();
        ConditionToFrequencyTools shareCt = new ConditionToFrequencyTools();
        shareCt.setTime(1);
        shareCt.setUnit("min");
        shareCt.setTimes(2);
        shareC.setLoginFrequency(shareCt);
        share.setStrategyMatchCondition(shareC);
        share.setAppIds(null);
        shareC.setLabelCode(null);
        shareC.setSensitiveLevel(null);
        shareC.setMaximumAuthorityAccount(null);
        shareC.setStatusCode(null);
        shareC.setReqStatus(null);


        StrategyMatch ipHit = new StrategyMatch();
        ipHit.setId(302);
        ipHit.setName("IP登录密码连续错误");
        ipHit.setStrategy("02070101");
        ipHit.setEnable(true);
        ipHit.setRiskLevel(4);
        ipHit.setRiskType("020701");
        StrategyMatchCondition ipHitI = new StrategyMatchCondition();
        ConditionToFrequencyTools ipHitIt = new ConditionToFrequencyTools();
        ipHitIt.setTime(1);
        ipHitIt.setUnit("min");
        ipHitIt.setTimes(5);
        ipHitI.setLoginFrequency(ipHitIt);
        ipHit.setStrategyMatchCondition(ipHitI);
        ipHit.setAppIds(null);
        ipHitI.setLabelCode(null);
        ipHitI.setSensitiveLevel(null);
        ipHitI.setMaximumAuthorityAccount(null);
        ipHitI.setStatusCode(null);
        ipHitI.setReqStatus(null);

        StrategyMatch accHit = new StrategyMatch();
        accHit.setId(303);
        accHit.setName("账号登录密码连续错误");
        accHit.setStrategy("02080101");
        accHit.setEnable(true);
        accHit.setRiskLevel(4);
        accHit.setRiskType("020801");
        StrategyMatchCondition accHitI = new StrategyMatchCondition();
        ConditionToFrequencyTools accHitAt = new ConditionToFrequencyTools();
        accHitAt.setTime(1);
        accHitAt.setUnit("min");
        accHitAt.setTimes(5);
        accHitI.setLoginFrequency(accHitAt);
        accHit.setStrategyMatchCondition(accHitI);
        accHit.setAppIds(null);
        accHitI.setLabelCode(null);
        accHitI.setSensitiveLevel(null);
        accHitI.setMaximumAuthorityAccount(null);
        accHitI.setStatusCode(null);
        accHitI.setReqStatus(null);

//        System.out.println(JSON.toJSONString(share));
//        System.out.println(JSON.toJSONString(ipHit));
//        System.out.println(JSON.toJSONString(accHit));

//        create(JSON.toJSONString(share),"/dbsj_audit/dbsj/strategy/risk_data/02060101");
//        create(JSON.toJSONString(ipHit),"/dbsj_audit/dbsj/strategy/risk_data/02070101");
//        create(JSON.toJSONString(accHit),"/dbsj_audit/dbsj/strategy/risk_data/02080101");

        get("/dbsj_audit/dbsj/strategy/risk_data/02060101");

//        while (true) {



            set("{\"id\": 210, \"name\": \"IP敏感数据下载量异常\", \"strategy\": \"01090101\", \"enable\": true, \"riskLevel\": 5, \"riskType\": \"010901\", \"conditionTO\": {\"operationValue\": \"100\", \"triggerFrequency\": {\"time\": 5, \"unit\": \"min\"}}}","/dbsj_audit/dbsj/strategy/risk_data/01090101");
            set(JSON.toJSONString(share), "/dbsj_audit/dbsj/strategy/risk_data/02060101");
            set(JSON.toJSONString(ipHit), "/dbsj_audit/dbsj/strategy/risk_data/02070101");
            set(JSON.toJSONString(accHit), "/dbsj_audit/dbsj/strategy/risk_data/02080101");
            Thread.sleep(1000);
//        }

    }


    @Test
    @Ignore
    public void init2() throws KeeperException, InterruptedException {
        OfflineTables dm_nml_rsba_ip_range_infor = new OfflineTables("dm_nml_rsba_ip_range_infor", System.currentTimeMillis(), 1, 1);
        set(JSON.toJSONString(dm_nml_rsba_ip_range_infor), "/dbsj_audit/dbsj/strategy/offline_task/02010101");

        OfflineTables dm_nml_rsba_mac_infor = new OfflineTables("dm_nml_rsba_mac_infor", System.currentTimeMillis(), 1, 1);
        set(JSON.toJSONString(dm_nml_rsba_mac_infor), "/dbsj_audit/dbsj/strategy/offline_task/01040101");

        OfflineTables dm_nml_rsba_no_sensitive_num_infor = new OfflineTables("dm_nml_rsba_no_sensitive_num_infor", System.currentTimeMillis(), 1, 1);
        set(JSON.toJSONString(dm_nml_rsba_no_sensitive_num_infor), "/dbsj_audit/dbsj/strategy/offline_task/01030101");

        OfflineTables dm_nml_rsba_often_sensitive_database_infor = new OfflineTables("dm_nml_rsba_often_sensitive_database_infor", System.currentTimeMillis(), 1, 1);
        set(JSON.toJSONString(dm_nml_rsba_often_sensitive_database_infor), "/dbsj_audit/dbsj/strategy/offline_task/01070101");

        OfflineTables dm_nml_rsba_often_sensitive_table_infor = new OfflineTables("dm_nml_rsba_often_sensitive_table_infor", System.currentTimeMillis(), 1, 1);
        set(JSON.toJSONString(dm_nml_rsba_often_sensitive_table_infor), "/dbsj_audit/dbsj/strategy/offline_task/01060101");

        OfflineTables dm_nml_rsba_sensitive_silent_num_infor = new OfflineTables("dm_nml_rsba_sensitive_silent_num_infor", System.currentTimeMillis(), 1, 1);
        set(JSON.toJSONString(dm_nml_rsba_sensitive_silent_num_infor), "/dbsj_audit/dbsj/strategy/offline_task/01080101");

        OfflineTables dm_nml_rsba_zombie_num_infor = new OfflineTables("dm_nml_rsba_zombie_num_infor", System.currentTimeMillis(), 1, 1);
        set(JSON.toJSONString(dm_nml_rsba_zombie_num_infor), "/dbsj_audit/dbsj/strategy/offline_task/020a0101");

    }

    private static void set(String message, String path) throws KeeperException, InterruptedException {
        ZooKeeper zk = D2Z.getZk();
        assert zk != null;
        zk.setData(path, message.getBytes(), -1);
        zk.close();
    }


    private static void get(String path) throws KeeperException, InterruptedException {
        ZooKeeper zk = D2Z.getZk();
        assert zk != null;
        byte[] data = zk.getData(path, false, null);
        System.out.println(new String(data));
    }

    private static void create(String message, String path) throws KeeperException, InterruptedException {
        ZooKeeper zk = D2Z.getZk();
        //文件value值
        byte[] buf = message.getBytes();
        //文件权限
        ArrayList<ACL> list = ZooDefs.Ids.OPEN_ACL_UNSAFE;
        //文件持久化保存
        CreateMode p = CreateMode.PERSISTENT;
        //返回路径
        assert zk != null;
        String s = zk.create(path, buf, list, p);
        System.out.println(s);
        zk.close();
    }
}
