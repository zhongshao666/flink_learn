package com.ssa;

import com.alibaba.fastjson.JSON;
import com.ssa.bean.AssetLog;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.junit.Ignore;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Random;

/**
 * @author : hld
 * @Date ： 2021/4/22
 * @Time : 16:27
 * @role ：
 */
public class KafkaProducerTest {
    private static Properties kafkaProps;

    private static void initKafka() {
        kafkaProps = new Properties();
        // broker url
        //在默认kafka的单节点配置时，不能使用IP，而是使用localhost进行连接，否则会连接异常。
        //用于初始化时建立链接到kafka集群，以host:port形式，多个以逗号分隔host1:port1,host2:port2；
        kafkaProps.put("bootstrap.servers", "192.168.24.72:9092,192.168.24.73:9092,192.168.24.74:9092,192.168.24.75:9092,192.168.24.76:9092"); //,192.168.216.139:9092,192.168.216.140:9092
//        kafkaProps.put("bootstrap.servers", "192.168.24.251:9092"); //,192.168.216.139:9092,192.168.216.140:9092
        // 请求需要验证
        //生产者需要server端在接收到消息后，进行反馈确认的尺度，主要用于消息的可靠性传输；acks=0表示生产者不需要来自server的确认；acks=1表示server端将消息保存后即可发送ack，而不必等到其他follower角色的都收到了该消息；acks=all(or acks=-1)意味着server端将等待所有的副本都被接收后才发送确认。
        kafkaProps.put("acks", "all");
        // 请求失败的尝试次数
        //:生产者发送失败后，重试的次数 batch.size:当多条消息发送到同一个partition时
        kafkaProps.put("retries", 0);
        // 缓存大小
        kafkaProps.put("batch.size", 65536);
        //:默认情况下缓冲区的消息会被立即发送到服务端，即使缓冲区的空间并没有被用完。可以将该值设置为大于0的值，这样发送者将等待一段时间后，再向服务端发送请求，以实现每次请求可以尽可能多的发送批量消息。
        kafkaProps.put("linger.ms", 1);
        //生产者缓冲区的大小，保存的是还未来得及发送到server端的消息，如果生产者的发送速度大于消息被提交到server端的速度，该缓冲区将被耗尽。
        kafkaProps.put("buffer.memory", 134217728);//33554432
        //定义的key和value序列化器
        //说明了使用何种序列化方式将用户提供的key和vaule值序列化成
        kafkaProps.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        kafkaProps.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
    }

    @Test
    @Ignore
    public void testProducer() throws InterruptedException {
        initKafka();
        Producer<String, String> producer = new KafkaProducer<>(kafkaProps);
        Random random = new Random();

        long firstId = 1;
        long secondId = 1L;


        while (true) {
            AssetLog assetLog = new AssetLog();



            int i = random.nextInt(3600000 * 24);
            long l = System.currentTimeMillis() / 1000;
            long l1 = l - 3600000 * 64 + i;


            assetLog.setFirstId((long) (firstId += ri(2)));
            assetLog.setSecondId(secondId += 1);
            assetLog.setEventType(ri(2) + 1);
            assetLog.setClientMac(rs());
            assetLog.setSessionId("1373261" + random.nextInt(10));
            assetLog.setClientIp(rip());
            assetLog.setClientPort(ri(10) + 8000);
            assetLog.setServerMac(rs());
            assetLog.setServerIp(rrip());
            assetLog.setServerPort(ri(10) + 4000);
            assetLog.setOperationType(ri(5));

            assetLog.setRequestTime(l);
            assetLog.setRequestTimeUsec((int)(l - ri(10) * 1000) / 1000);
            assetLog.setExecuteTime(ri(1000) + 1000L);
            //请求状态码
            assetLog.setRequestStatus(rst());
            assetLog.setAccount("root1");
            assetLog.setOsUserName(ro());
            assetLog.setInstanceName(rdb());
            assetLog.setClientApp(rca());
            assetLog.setClientHost(rip());


            if (assetLog.getEventType() == 1) {
                assetLog.setOperationType(random.nextInt(2) + 1);
                if (ri(11)/10 == 1){
                    assetLog.setOperationCommand("LOGIN");
                }else {
                    assetLog.setOperationCommand("LOGOUT");
                }

            } else {
                assetLog.setIsSensitiveTable(ri(2) );

                if (assetLog.getIsSensitiveTable() == 1) {
                    assetLog.setSensitiveTables(rt());
                    assetLog.setSensitiveColumns(rc(assetLog));
                }

                assetLog.setOperandName(rt());
                assetLog.setSecondOperandName(rc(assetLog));

                assetLog.setOperationCommand(rsqlc(assetLog));
                assetLog.setOperationStatement(rsql(assetLog));
                assetLog.setRowsAffected(ri(150) + 1);

            }

            producer.send(new ProducerRecord<String, String>("rt_dbsj_log_bd", JSON.toJSONString(assetLog)));
            System.out.println(JSON.toJSONString(assetLog));
            Thread.sleep(1000);
        }
    }


    /**
     * 业务语句
     */
    public String rsql(AssetLog assetLog) {

        Random r = new Random();
        ArrayList<String> dl = new ArrayList<>();
        dl.add("SELECT ");
        dl.add("DROP ");
        dl.add("INSERT INTO ");
        dl.add("UPDATE ");
        dl.add("DELETE ");
        int i = r.nextInt(12);
        ArrayList<String> mac = new ArrayList<>();
        Random random = new Random();
        mac.add("sensitiveTableA");
        mac.add("sensitiveTableB");
        mac.add("sensitiveTableC");

        ArrayList<String> macC = new ArrayList<>();
        macC.add("rowsAffected");
        macC.add("operationType");
        macC.add("operationCommand");
        macC.add("operandType");
        macC.add("operandName");
        macC.add("secondOperandName");
        macC.add("webUserName");
        macC.add("webUrl");
        macC.add("webIp");
        macC.add("webSessionId");
        macC.add("reviewed");
        macC.add("comment");
        macC.add("sent");
        macC.add("sensitiveTables");
        macC.add("sensitiveColumns");
        macC.add("riskTypeAi");
        macC.add("clientMac");
        macC.add("clientIp");
        macC.add("clientPort");
        macC.add("serverMac");
        macC.add("serverIp");

        if (assetLog.getOperationCommand().equals("SELECT")) {
            //随机操作
            return dl.get(0) + String.join(",", assetLog.getSecondOperandName()) + "," + String.join(",", assetLog.getSensitiveColumns()) +
                    " from " + String.join(",", assetLog.getOperandType()) + "," + String.join(",", assetLog.getSensitiveTables()) + " where " + "1=1";
        } else if (assetLog.getOperationCommand().equals("DROP")) {

            return dl.get(1) + "if exists" + mac.get(random.nextInt(mac.size()));
        } else if (assetLog.getOperationCommand().equals("INSERT")) {
            return dl.get(2) + mac.get(random.nextInt(mac.size())) + " values(" + " 'aa' ,'bb' )";
        } else if (assetLog.getOperationCommand().equals("UPDATE")) {
            String s = macC.get(random.nextInt(mac.size()));
            return dl.get(3) + mac.get(random.nextInt(mac.size())) + " SET " + s + " = 'aas' where " + s + " = 'ass'";
        } else if (assetLog.getOperationCommand().equals("DELETE")) {
            String s = macC.get(random.nextInt(mac.size()));
            return dl.get(4) + "from " + mac.get(random.nextInt(mac.size())) + " where " + s + " = 'ass'";
        }
        return null;
    }


    /**
     * 随机多大的数
     */
    public int ri(Integer a) {
        Random random = new Random();
        return random.nextInt(a);
    }


    /**
     * 数据库账号
     */
    public String ra() {
        Random random = new Random();
        ArrayList<String> mac = new ArrayList<>();
        mac.add("root");
        mac.add("admin");
        mac.add("test");

        return mac.get(random.nextInt(mac.size()));
    }

    /**
     * 客户端账号
     */
    public String ro() {
        Random random = new Random();
        ArrayList<String> mac = new ArrayList<>();
        mac.add("root");
        mac.add("admin");
        mac.add("test");
        mac.add("secsmart");
        mac.add("zhaozhenbing");
        mac.add("yeliuhe");
        mac.add("lixianguo");
        mac.add("qianweijie");
        mac.add("tangqiangshi");
        return mac.get(random.nextInt(mac.size()));
    }


    /**
     * 客户端mac
     */
    public String rs() {
        Random random = new Random();
        ArrayList<String> mac = new ArrayList<>();
        mac.add("00");
        mac.add("0A");
        mac.add("E6");
        mac.add("D2");
        mac.add("22");
        mac.add("C3");
        mac.add("C5");

        return mac.get(random.nextInt(2)) + ":" + mac.get(random.nextInt(mac.size() - 2) + 2) + ":" +
                mac.get(random.nextInt(mac.size() - 2) + 2) + ":" +
                mac.get(random.nextInt(mac.size() - 2) + 2) + ":" +
                mac.get(random.nextInt(mac.size() - 2) + 2) + ":" +
                mac.get(random.nextInt(mac.size() - 2) + 2);
    }

    /**
     * 敏感表
     */
    public List<String> rt() {
        Random random = new Random();
        ArrayList<String> mac = new ArrayList<>();
        ArrayList<String> macT = new ArrayList<>();
        mac.add("sensitiveTableB");
        mac.add("sensitiveTableC");
        for (int i = 0; i < random.nextInt(mac.size()); i++) {
            macT.add(mac.get(random.nextInt(mac.size())));
        }
        return macT;
    }

    /**
     * 非敏感表
     */

    public List<String> urt() {

        ArrayList<String> mac = new ArrayList<>();
        mac.add("unSensitiveTableA");

        return mac;
    }

    /**
     * 敏感columns
     */
    public List<String> rc(AssetLog assetLog) {
        Random random = new Random();
        ArrayList<String> mac = new ArrayList<>();
        ArrayList<String> macC = new ArrayList<>();

        mac.add("cell_phone");
        mac.add("bank_account");
        mac.add("business_name");
        mac.add("bus_number");
        mac.add("china_name");
        mac.add("chinese_address");
        mac.add("email");
        mac.add("id_card");
        mac.add("mtp_for_hkmacao");
        mac.add("mtp_for_taiwai");
        mac.add("officer_number");
        mac.add("passport_code");
        mac.add("phone_number");

        int integer = 0;
        String tb = "sensitiveTableB";
        for (String sensitiveTable : assetLog.getSensitiveTables()) {


            if ("sensitiveTableC".equals(sensitiveTable)) {
                tb = "sensitiveTableC";
                integer = 6;
            }
            for (int i = 0; i < ri(mac.size()); i++) {
                macC.add(tb + "." + mac.get(random.nextInt(6) + integer));
            }
        }

        return macC;
    }

    /**
     * 请求状态码
     */
    public Integer rst() {
        Random random = new Random();
        ArrayList<Integer> ent = new ArrayList<>();

        ent.add(1801);
        ent.add(1802);
        ent.add(1803);
        ent.add(1804);
        ent.add(1805);
        ent.add(1806);
        ent.add(1807);

        return ent.get(random.nextInt(ent.size()));
    }

    /**
     * 请求库
     */
    public String rdb() {
        Random random = new Random();
        ArrayList<String> mac = new ArrayList<>();
        mac.add("DataBaseA");
        mac.add("DataBaseB");
        return mac.get(random.nextInt(mac.size()));
    }

    /**
     * 请求库
     */
    public String rca() {
        Random random = new Random();
        ArrayList<String> mac = new ArrayList<>();
        mac.add("jdbc");
        mac.add("App");
        return mac.get(random.nextInt(mac.size()));
    }

    /**
     * 请求地址
     */
    public String rip() {
        Random random = new Random();
        ArrayList<String> mac = new ArrayList<>();
        mac.add("10");
        mac.add("11");
        mac.add("22");
        mac.add("13");
        mac.add("24");
        mac.add("15");
        mac.add("16");
        mac.add("27");
        mac.add("18");
        mac.add("19");
        mac.add("21");
        return "192.168." + mac.get(random.nextInt(2)) + "." + mac.get(random.nextInt(mac.size()));
    }

    /**
     * 响应地址
     */
    public String rrip() {
        Random random = new Random();
        ArrayList<String> mac = new ArrayList<>();
        mac.add("10");
        mac.add("11");
        mac.add("12");
        mac.add("13");
        mac.add("14");
        mac.add("15");
        return "192.168." + mac.get(random.nextInt(2)) + "." + mac.get(random.nextInt(mac.size()));
    }


    /**
     * 操作类型
     */
    public String rsqlc(AssetLog assetLog) {

        Random r = new Random();
        ArrayList<String> dl = new ArrayList<>();
        dl.add("SELECT ");
        dl.add("DROP ");
        dl.add("INSERT INTO ");
        dl.add("UPDATE ");
        dl.add("DELETE ");

        String sqlc = "";
        int i = r.nextInt(13);
        if (i < 10) {
            sqlc = "SELECT";
            assetLog.setOperationType(4);
            assetLog.setOperationCommand(sqlc);
        } else if (i % 10 + 1 == 1) {
            assetLog.setOperationType(3);

            sqlc = "DROP";
            assetLog.setOperationCommand(sqlc);

        } else if (i % 10 + 1 == 2) {
            assetLog.setOperationType(4);

            sqlc = "INSERT";
            assetLog.setOperationCommand(sqlc);

        } else if (i % 10 + 1 == 3) {
            assetLog.setOperationType(4);

            sqlc = "UPDATE";
            assetLog.setOperationCommand(sqlc);

        } else if (i % 10 + 1 == 4) {
            assetLog.setOperationType(4);

            sqlc = "DELETE";
            assetLog.setOperationCommand(sqlc);
        }
        return sqlc;
    }
}
