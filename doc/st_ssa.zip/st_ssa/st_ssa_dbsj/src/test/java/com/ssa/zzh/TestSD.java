package com.ssa.zzh;

import java.util.ArrayList;

public class TestSD {


    public static void main(String[] args) {

        ArrayList<Double> doubles = new ArrayList<>();
        doubles.add(10d);
        doubles.add(10d);
        doubles.add(9d);
        doubles.add(9d);
        doubles.add(12d);
        doubles.add(11d);
        doubles.add(12d);
        doubles.add(9d);

        TestSD testSD = new TestSD();
        double v = testSD.StandardDiviation(doubles);
        System.out.println(v);
    }

    public double StandardDiviation(ArrayList<Double> x) {
        double sum = 0d;
        for (double i : x) {
            sum += i;
        }
        //平均值
        double avg = sum / x.size();
        //求方差
        double variance = 0d;
        for (double i : x) {
            variance += (i - avg) * (i - avg);
        }

        return Math.sqrt(variance / x.size());
    }
}
