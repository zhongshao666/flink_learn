package com.ssa.zzh;

import com.alibaba.fastjson.JSON;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class TestHashMap {
    @Ignore
    public static void main(String[] args) {
//        System.out.println(1 << 4);
//        System.out.println(1 << 30);
        System.out.println(new HashMap<>());

        ArrayList<ArrayList<String>> arrayLists = new ArrayList<>();
        ArrayList<String> s1 = new ArrayList<>();
        s1.add("aaa");
        s1.add("bbb");
        ArrayList<String> s2 = new ArrayList<>();
        s2.add("ccc");
        s2.add("ddd");
        arrayLists.add(s1);
        arrayLists.add(s2);
//        System.out.println(JSON.toJSONString(arrayLists));
        A a1 = new A();
        a1.arrayList = arrayLists;
        String s = JSON.toJSONString(a1);
        System.out.println(a1.arrayList);
        A a = JSON.parseObject(s, A.class);
        System.out.println(JSON.toJSONString(a));
    }
}

class A{
    ArrayList<ArrayList<String>> arrayList;
}