package com.ssa.zzh;

public class TestT {
    public static void main(String[] args) throws InterruptedException {
        long l1 = System.currentTimeMillis();
        Thread.sleep(10000L);
        long l2 = System.currentTimeMillis();
        System.out.println(l2-l1);
    }
}
