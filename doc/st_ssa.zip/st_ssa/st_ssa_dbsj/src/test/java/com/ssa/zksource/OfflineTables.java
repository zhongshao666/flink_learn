package com.ssa.zksource;

/**
 * @author : hld
 * @Date ： 2021/5/13
 * @Time : 16:15
 * @role ：
 */
public class OfflineTables {
    private String tableName;
    private Long timestamp;
    private Integer status;
    private Integer dbtype;


    public OfflineTables(String tableName, Long timestamp, Integer status, Integer dbtype) {
        this.tableName = tableName;
        this.timestamp = timestamp;
        this.status = status;
        this.dbtype = dbtype;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getDbtype() {
        return dbtype;
    }

    public void setDbtype(Integer dbtype) {
        this.dbtype = dbtype;
    }
}
