object Testsource {
  def main(args: Array[String]): Unit = {


    val ints = new Array[Int](3)
    ints(0)=1
    ints(1)=1
    ints(2)=1
    val indices: Range = ints.indices
    for (elem <- indices) {

      println(elem)
    }


  }

}
