package zzh;/*
package com.ssa.zzh;

import com.alibaba.fastjson.JSON;
import com.ssa.bean.CommonConfig;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.ZooDefs;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.data.ACL;
import org.junit.Ignore;
import org.junit.Test;

import java.util.ArrayList;

import static com.ssa.utils.SystemConfig.*;

public class TestZk {


    @Test
    @Ignore
    public void testSet() throws KeeperException, InterruptedException {
        CommonConfig commonConfig = new CommonConfig();
        commonConfig.setKey("3");
        commonConfig.setValue("9:00-17:00");
        CommonConfig commonConfig1 = new CommonConfig();
        commonConfig1.setKey("4");
        commonConfig1.setValue("9:00-14:00");
        ArrayList<CommonConfig> list = new ArrayList<>();
        list.add(commonConfig);
        list.add(commonConfig1);
        String s = JSON.toJSONString(list);
        System.out.println(s);
//        List<CommonConfig> commonConfigs = JSON.parseArray(s, CommonConfig.class);
//        System.out.println(commonConfigs);
        set(s,zookeeperStrategyCommonTime);
    }


    @Test
    @Ignore
    public void testGet() throws KeeperException, InterruptedException {
        get(zookeeperStrategyCommonIP);
    }


    private static void create(String ss,String path) throws KeeperException, InterruptedException {
        ZooKeeper zk = D2Z.getZk();
//        path = "/app_audit/app/strategy/config/22957"; //4214
        //文件value值
        byte[] buf = ss.getBytes();
        //文件权限
        ArrayList<ACL> list = ZooDefs.Ids.OPEN_ACL_UNSAFE;
        //文件持久化保存
        CreateMode p = CreateMode.PERSISTENT;
        //返回路径
        assert zk != null;
        String s = zk.create(path, buf, list, p);
        System.out.println(s);
        zk.close();
    }

    private static void set(String ss,String path) throws KeeperException, InterruptedException {
        ZooKeeper zk = D2Z.getZk();
        assert zk != null;
        zk.setData(path, ss.getBytes(), -1);
        zk.close();
    }


    private static void get(String path) throws KeeperException, InterruptedException {
        ZooKeeper zk = D2Z.getZk();
        assert zk != null;
        byte[] data = zk.getData(path, false, null);
        System.out.println(new String(data));
    }

    @Test
    @Ignore
    public void testTime() throws KeeperException, InterruptedException {
        CommonConfig commonConfig = new CommonConfig();
        commonConfig.setKey("3");
        commonConfig.setValue("9:00-15:00");
        CommonConfig commonConfig1 = new CommonConfig();
        commonConfig1.setKey("4");
        commonConfig1.setValue("9:00-14:00");
        ArrayList<CommonConfig> list = new ArrayList<>();
        list.add(commonConfig);
        list.add(commonConfig1);
        String s = JSON.toJSONString(list);
        System.out.println(s);
//        List<CommonConfig> commonConfigs = JSON.parseArray(s, CommonConfig.class);
//        System.out.println(commonConfigs);
        create(s,zookeeperStrategyCommonTime);

    }

    @Test
    @Ignore
    public void testIp() throws KeeperException, InterruptedException {
        CommonConfig commonConfig = new CommonConfig();
        commonConfig.setValue("192.168.18.241");
        CommonConfig commonConfig1 = new CommonConfig();
        commonConfig1.setValue("192.168.18.245-192.168.18.251");
        ArrayList<CommonConfig> list = new ArrayList<>();
        list.add(commonConfig);
        list.add(commonConfig1);
        String s = JSON.toJSONString(list);
        System.out.println(s);
//        List<CommonConfig> commonConfigs = JSON.parseArray(s, CommonConfig.class);
//        System.out.println(commonConfigs);
        create(s,zookeeperStrategyCommonIP);

    }

    @Test
    @Ignore
    public void testAccount() throws KeeperException, InterruptedException {
        CommonConfig commonConfig = new CommonConfig();
        commonConfig.setKey("192.168.18.2:8080");
        commonConfig.setValue("root1");
        CommonConfig commonConfig1 = new CommonConfig();
        commonConfig1.setKey("192.168.18.2:9999");
        commonConfig1.setValue("root2");
        ArrayList<CommonConfig> list = new ArrayList<>();
        list.add(commonConfig);
        list.add(commonConfig1);
        String s = JSON.toJSONString(list);
        System.out.println(s);
//        List<CommonConfig> commonConfigs = JSON.parseArray(s, CommonConfig.class);
//        System.out.println(commonConfigs);
        create(s,zookeeperStrategyCommonAccount);

    }
}
*/
