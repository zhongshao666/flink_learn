package zzh;

import org.junit.Ignore;
import org.junit.Test;

import java.util.ResourceBundle;

public class TestProperties {
    @Test
    @Ignore
    public void test1() {
        System.out.println(Pro.mysqlClass);
    }
}

class Pro {
    public static String mysqlClass;
    public static String mysqlUrl;
    public static String mysqlUser;
    public static String mysqlPasswd;

    static {
        ResourceBundle resource = ResourceBundle.getBundle("application");

        mysqlClass = resource.getString("mysql.class");
        mysqlUrl = resource.getString("mysql.url");
        mysqlUser = resource.getString("mysql.user");
        mysqlPasswd = resource.getString("mysql.passwd");
    }
}