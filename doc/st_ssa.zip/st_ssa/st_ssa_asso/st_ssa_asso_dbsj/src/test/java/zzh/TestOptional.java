package zzh;

import com.ssa.bean.ControlData;
import com.ssa.bean.SensitiveData;
import jdk.nashorn.internal.ir.annotations.Ignore;
import org.apache.flink.api.java.tuple.Tuple7;
import org.junit.Test;

import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.util.*;

import static com.ssa.utils.RSAUtils.getPrivateKey;
import static com.ssa.utils.RSAUtils.privateDecrypt;

public class TestOptional {

    @Test
    @Ignore
    public void testOption() {
        String s = "d00a&_03&_ff&_batchnum";
        SensitiveData sensitiveData = new SensitiveData();
        ControlData controlData = new ControlData();

        Optional.ofNullable(sensitiveData.getControlData()).ifPresent(item -> {
/*            String[] split = item.split("&_");
            for (String s11:
                 split) {
                System.out.println(s11);
            }*/
            System.out.println("111111111");
        });
    }

    @Test
    @Ignore
    public void test1() {
        Tuple7<String, String, Integer, String, String, List<String>, List<String>> tuple7 = new Tuple7<>();
        tuple7.f0 = "batchId";
        System.out.println(tuple7.f0);

        String s = "";
        List<String> list = Arrays.asList(s.split(","));
        System.out.println(list.size());
    }

//
//    @Test
//    @Ignore
//    public void test2() throws InvalidKeySpecException, NoSuchAlgorithmException {
//        String s = "{\"controlData\":\"KBXS41P_SoKJKKQkfuFYec8hc3BqBjLmLpcRrPkQkJJ3_BfeE0EgI6NksLroIZ2_z2qn_Z-wUEvLe5pH-FJd0hVU1Ef8uqxJs78oDEbdVYYZBn5RhlOnZgOdbijQbAeB-PZCNfxOpR_bZgysJlfg3GvLULvN8NrkUpeNOxpiVQCPNg9OB0nbC0VTxZRkH1W44fuETPJsENVDKIHzTL9j7hFTSxp3KeEEdTG0TUPUbPDt1C-aG9xxRlO_ukqRWAlTm_yE5L5Mdjq5taNKUFTUuBdyunuDGlWCIkOrISiRcQA6_Y-KT16Rwp6xsc8xXGoxysnqTpbdpl4G9Yyur5EX5Q\",\"createTime\":\"1618388965812\",\"serviceCode\":\"FF7000FF\"}";
//
//        String priKey = "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAJvTCijZuAReMQ2sMuujWz7y8tVJ6z-qc4XBJvLVwfBlANFflKfKIBu5RVE76XyaRm6pTfQfzWvRfzeb6LQS3Hzlx8edQ0-fNSGgbopi_W9ql5N4De62HT14dgUlvBpXVf2nECdVMCRrTnp5HypTtob3QTzLe8E_9TyP4yJ0YbVBAgMBAAECgYBTuW_zBRBfoHCA5S4y-AHV79nUCjSRb7dEfcS8o2fiD5MB7HZGNU9NNh3tiOBqZ8ZCPUu6SMAqF1Vgfq_o2V2IE4gbgshf-xmSXf9DJy6PlRm3mD1NCKm7q2FlQvsp3cRT9fJzG2qmgUbkwwF5mjljzvCRS3jFBdojJX2aeF5gwQJBAMzArtXKGQDAjdZcudj_lbFMycZQgsYRAAuotVDmpUWAN2ABzv1NLuL-c73tmGrJN-1oLtDilV6rUfihDt8YPfkCQQDC01OWXXy0u-oyaXQxFMC5fleKWCXgZai3KNZGBnkZB-654EgeF2uZNmnlNJq7Cd1_9ElWqI0cwaskACyBS6OJAkB9Wn3vf2JdVoW_tldFpfxEZwmlM0dM8b2AZdJT7FFEwqGkUpch9u38pOHBZsQIpJZr73uyAPaH1gVCXYBYT2QpAkBAJWheF8XZlA2WL5ZsGpMh__E-wasm6RHVzIJQaA0zKqN1W90i2z84IOxY5SsU7jiZyorjF3fuwe1hWxVMNOVRAkAsc-iVU_0ius8BgFD2ejYfuddPliSBTm9Cn3cIwTvu27_If8P6ihxRCoe0YnmTEhlQNQh2PPx1LehZX9TNsByO";
//        RSAPrivateKey privateKey1 = getPrivateKey(priKey);
//        SensitiveData sensitiveData = ParsingKafkaSensitive.parsingKafkaSensitive(s);
//
//        //解密
//        String data = privateDecrypt(sensitiveData.getControlData(), privateKey1);
//        //解析
//        ControlData controlData = ParsingKafkaControlData.parsingKafkaControlData(data);
//
//        String key = controlData.getKey();
//        System.out.println(key);
//        String[] split = key.split("&_");
//        System.out.println(split.length);
//        System.out.println(Arrays.toString(split));
//
//    }

    @Test
    @Ignore
    public void test3() {
        Atest atest = new Atest();
        atest.setA("aaaa");
        Atest atest_1 = new Atest();
        atest_1.setA("11111");
//        new Btest().init(atest,atest_1);
        atest = atest_1;
        System.out.println(atest.getA());
    }

    @Test
    @Ignore
    public void test4() {
        new Atest().test();

    }

    @Test
    @Ignore
    public void test6() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        calendar.setTimeInMillis(System.currentTimeMillis());
//        calendar.setTimeInMillis(1618710874000L);

        int i = calendar.get(Calendar.DAY_OF_WEEK);
        System.out.println(i);
        System.out.println(new Date(1618710874000L));

        String s = "aaaa";
        String[] split = s.split("-");
        System.out.println(split[0]);
        HashSet<String> set = new HashSet<>();
        set.add("666");
        set.add("666");
        set.add("666");
        System.out.println(set);
    }

}

class Atest {
    String a;

    public String getA() {
        return a;
    }

    public void setA(String a) {
        this.a = a;
    }

    public void test() {
//        a = "asd";
        if (Optional.ofNullable(a).isPresent()) {
            System.out.println(666);
        }
        System.out.println(a);
    }
}

class Btest{
    public void init(Atest atest,Atest atest_1) {
        atest = atest_1;
    }
}