package zzh;

import org.junit.Ignore;

import java.util.HashMap;

public class TestHashMap {
    @Ignore
    public static void main(String[] args) {
//        System.out.println(1 << 4);
//        System.out.println(1 << 30);
        System.out.println(new HashMap<>());
    }
}
