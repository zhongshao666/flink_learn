package com.ssa.bean;

import lombok.Data;

@Data
public class OfflineData {
    /**
     * 离线库的表名
     */
    private String offlineTableType;
    /**
     * 客户端ip
     */
    private String clientIp;
    /**
     * 客户端Mac
     */
    private String clientMac;
    /**
     * 数据库账号
     */
    private String account;
    /**
     * 表名
     */
    private String commonTable;
    /**
     * 库名
     */
    private String instanceName;
    /**
     * 数据类别 01数审 02API
     */
    private String dataType;
    /**
     * 模型类别
     */
    private String modelType;
    /**
     * 黑名单类别
     */
    private String blackType;
    /**
     * 黑名单值
     */
    private String typeValue;
    /**
     * 更新时间
     */
    private String updateDate;

    private Double userCountPercent;
    private Integer assetId;
    private Integer operationType;
    private String requestTime;
    private Integer assetIdPos;
    private Integer clientIpPos;
    private Integer operationTypePos;
    private Integer requestTimePos;

    public String getOfflineTableType() {
        return offlineTableType;
    }

    public void setOfflineTableType(String offlineTableType) {
        this.offlineTableType = offlineTableType;
    }

    public String getClientIp() {
        return clientIp;
    }

    public void setClientIp(String clientIp) {
        this.clientIp = clientIp;
    }

    public String getClientMac() {
        return clientMac;
    }

    public void setClientMac(String clientMac) {
        this.clientMac = clientMac;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getCommonTable() {
        return commonTable;
    }

    public void setCommonTable(String commonTable) {
        this.commonTable = commonTable;
    }

    public String getInstanceName() {
        return instanceName;
    }

    public void setInstanceName(String instanceName) {
        this.instanceName = instanceName;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getModelType() {
        return modelType;
    }

    public void setModelType(String modelType) {
        this.modelType = modelType;
    }

    public String getBlackType() {
        return blackType;
    }

    public void setBlackType(String blackType) {
        this.blackType = blackType;
    }

    public String getTypeValue() {
        return typeValue;
    }

    public void setTypeValue(String typeValue) {
        this.typeValue = typeValue;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public Double getUserCountPercent() {
        return userCountPercent;
    }

    public void setUserCountPercent(Double userCountPercent) {
        this.userCountPercent = userCountPercent;
    }

    public Integer getAssetId() {
        return assetId;
    }

    public void setAssetId(Integer assetId) {
        this.assetId = assetId;
    }

    public Integer getOperationType() {
        return operationType;
    }

    public void setOperationType(Integer operationType) {
        this.operationType = operationType;
    }

    public String getRequestTime() {
        return requestTime;
    }

    public void setRequestTime(String requestTime) {
        this.requestTime = requestTime;
    }

    public Integer getAssetIdPos() {
        return assetIdPos;
    }

    public void setAssetIdPos(Integer assetIdPos) {
        this.assetIdPos = assetIdPos;
    }

    public Integer getClientIpPos() {
        return clientIpPos;
    }

    public void setClientIpPos(Integer clientIpPos) {
        this.clientIpPos = clientIpPos;
    }

    public Integer getOperationTypePos() {
        return operationTypePos;
    }

    public void setOperationTypePos(Integer operationTypePos) {
        this.operationTypePos = operationTypePos;
    }

    public Integer getRequestTimePos() {
        return requestTimePos;
    }

    public void setRequestTimePos(Integer requestTimePos) {
        this.requestTimePos = requestTimePos;
    }
}
