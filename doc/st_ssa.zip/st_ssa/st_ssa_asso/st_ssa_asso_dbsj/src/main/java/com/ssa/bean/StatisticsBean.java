package com.ssa.bean;

import lombok.Data;

@Data
public class StatisticsBean {

    private String dataType;

    private String superType;

    private String subType;

    private String ts;

    private Integer samplePeriod;

    private Integer typeValue;

    public StatisticsBean() {

    }

    public StatisticsBean(String dataType, String superType, String subType, String ts, Integer samplePeriod, Integer typeValue) {
        this.dataType = dataType;
        this.superType = superType;
        this.subType = subType;
        this.ts = ts;
        this.samplePeriod = samplePeriod;
        this.typeValue = typeValue;
    }
}
