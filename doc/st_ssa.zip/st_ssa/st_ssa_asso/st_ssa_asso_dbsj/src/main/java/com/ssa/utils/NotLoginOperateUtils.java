package com.ssa.utils;

import com.ssa.bean.AssetLog;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;

public class NotLoginOperateUtils  implements Serializable {
    private static final List<String> noauthlist = new ArrayList<>();
    private static final List<String> nofilelist = new ArrayList<>();

    public NotLoginOperateUtils() {
        noauthlist.add("ORA-09911");
        noauthlist.add("ORA-06132");
        noauthlist.add("1326");

        nofilelist.add("ORA-00268");
        nofilelist.add("ORA-00335");
        nofilelist.add("ORA-00337");
        nofilelist.add("ORA-00359");
        nofilelist.add("ORA-01179");
        nofilelist.add("ORA-01522");
        nofilelist.add("ORA-01516");
        nofilelist.add("ORA-03283");
        nofilelist.add("ORA-07290");
        nofilelist.add("8202");
        nofilelist.add("42501");
    }
    public boolean isNotSuccess(AssetLog assetLog) {
        return assetLog.getRequestStatus().equals(1803);
    }

    public boolean isNoAuth(AssetLog assetLog) {
        AtomicBoolean flag = new AtomicBoolean(false);

        String errorReply = assetLog.getErrorReply();
        for(String code: noauthlist){
            Optional.ofNullable(errorReply).ifPresent(item -> {
                if (item.contains(code)){
                    flag.set(true);
                }
            });
        }
        return flag.get();
    }

    public boolean isNoFile(AssetLog assetLog) {
        AtomicBoolean flag = new AtomicBoolean(false);
        String errorReply = assetLog.getErrorReply();
        for(String code: nofilelist){
            Optional.ofNullable(errorReply).ifPresent(item -> {
                if (item.contains(code)){
                    flag.set(true);
                }
            });
        }
        return flag.get();
    }
}
