package com.ssa;

import com.ssa.algorithmmodel.AssociationRuleProcess;
import com.ssa.bean.AssetLog;
import com.ssa.bean.OfflineData;
import com.ssa.mapfun.SourceMapFunction;
import com.ssa.source.ClickHouseZkSource;
import com.ssa.source.SecZookeeperSource;
import com.ssa.transformation.*;
import com.ssa.utils.CuratorOperator;
import com.ssa.utils.KafkaSinkProp;
import com.ssa.utils.KafkaSourceProp;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.api.GetDataBuilder;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.BroadcastStream;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.ivi.opensource.flinkclickhousesink.ClickHouseSink;
import ru.ivi.opensource.flinkclickhousesink.model.ClickHouseSinkConst;

import java.io.ByteArrayInputStream;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;


/**
 * @author : hld
 * @Date ： 2021/4/8
 * @Time : 16:02
 * @role ：
 */
public class DbsjMain {

    private static final Logger logger = LoggerFactory.getLogger(DbsjMain.class);

    /**
     * 配置广播流的MapStateDescriptor
     */
    public static MapStateDescriptor<String, Tuple4<Integer, Integer, String, String>> zookeeperConfig = new MapStateDescriptor<>("zookeeperConfig", BasicTypeInfo.STRING_TYPE_INFO, Types.TUPLE(BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO));


    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment streamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment();
        //   streamExecutionEnvironment.setRestartStrategy(RestartStrategies.fixedDelayRestart(5, Time.seconds(10)));


        ParameterTool map = ParameterTool.fromArgs(args);
        Properties properties = new Properties();
        CuratorOperator mcto = null;
        mcto = new CuratorOperator(map.get("zkAddr"));
        GetDataBuilder data = mcto.client.getData();
        properties.load(new ByteArrayInputStream(data.forPath(map.get("zkPath"))));
        ParameterTool parameterTool = ParameterTool.fromMap((Map) properties);

        streamExecutionEnvironment.getConfig().setGlobalJobParameters(parameterTool);

        streamExecutionEnvironment.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);

        //创建datasource消费者 从kafka 消费数据
        FlinkKafkaConsumer011<String> stringFlinkKafkaConsumer011 = new FlinkKafkaConsumer011<>(parameterTool.get("kafka.config.dbsj.topic"), new SimpleStringSchema(), getKafkaSourceProp(parameterTool).getProp());

        //获取kafka数据
        SingleOutputStreamOperator<String> stringDataStreamSource = streamExecutionEnvironment.addSource(stringFlinkKafkaConsumer011).filter(Objects::nonNull);
        //获取ck数据源
        DataStreamSource<OfflineData> offlineDataDataStreamSource = streamExecutionEnvironment.addSource(new ClickHouseZkSource());


        DataStreamSource<Tuple4<Integer, Integer, String, String>> tuple2DataStreamSource = streamExecutionEnvironment.addSource(new SecZookeeperSource())
                .setParallelism(1);

        BroadcastStream<Tuple4<Integer, Integer, String, String>> broadcast = tuple2DataStreamSource.broadcast(zookeeperConfig);

        //将数据解析成bean
        SingleOutputStreamOperator<AssetLog> assetLogSingleDataStream = stringDataStreamSource.map(new SourceMapFunction()).name("解析bean");

        //关联规则算法
        BroadcastStream<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> tuple2DataStream = offlineDataDataStreamSource.connect(broadcast)
                .process(new AssociationBroadcast()).broadcast(new AssociationRuleProcess().associationRule());

        SingleOutputStreamOperator<AssetLog> endStream = assetLogSingleDataStream.filter(item -> item.getAccount() != null).keyBy(AssetLog::getAccount).connect(tuple2DataStream).process(new AssociationRuleProcess());


//        将数据写入click house中
        endStream.process(new AssetLogToStringProcess())
                .addSink(new ClickHouseSink(getHttpLogCkProp(parameterTool)));


        streamExecutionEnvironment.execute("dbsj model asso job");
    }


    /**
     * 获取 kafka consumer配置
     *
     * @return
     */
    public static KafkaSourceProp getKafkaSourceProp(ParameterTool parameterTool) {
        KafkaSourceProp kafkaSourceProp = new KafkaSourceProp();
        kafkaSourceProp.setBOOTSTRAP_SERVERS_CONFIG(parameterTool.get("kafka.url"));
        return kafkaSourceProp;
    }

    /**
     * @Author 赵臻柄
     * @Date 2021/4/13 19:22
     * @Method
     * @功能描述 获取kafka producer的配置
     * @Param
     * @Return
     */
    public static KafkaSinkProp getKafkaSinkProp(ParameterTool parameterTool) {
        KafkaSinkProp kafkaSinkProp = new KafkaSinkProp();
        kafkaSinkProp.setBOOTSTRAP_SERVERS_CONFIG(parameterTool.get("kafka.url"));

        return kafkaSinkProp;
    }

    /**
     * Asset_log ck config
     *
     * @return
     */
    public static Properties getHttpLogCkProp( ParameterTool parameterTool) {

        Properties properties = new Properties();
        properties.put(ClickHouseSinkConst.TARGET_TABLE_NAME, parameterTool.get("clickHouse.Database") + "." + parameterTool.get("clickHouse.Table"));
        properties.put(ClickHouseSinkConst.MAX_BUFFER_SIZE, parameterTool.get("clickhouse.sink.max-buffer-size"));
        return properties;
    }
}
