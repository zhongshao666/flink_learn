package com.ssa.bean;

import lombok.Data;

@Data
public class SensitiveData {
    private String controlData;
    private Long createTime;
    private String serviceCode;
}
