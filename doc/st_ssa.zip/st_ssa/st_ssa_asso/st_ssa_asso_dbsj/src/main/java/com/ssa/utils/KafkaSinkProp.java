package com.ssa.utils;

import org.apache.kafka.clients.producer.ProducerConfig;

import java.util.Properties;

public class KafkaSinkProp {
    private String BOOTSTRAP_SERVERS_CONFIG = "192.168.24.251:9092";
    private String KEY_SERIALIZER_CLASS_CONFIG= "org.apache.kafka.common.serialization.StringSerializer";
    private String VALUE_SERIALIZER_CLASS_CONFIG= "org.apache.kafka.common.serialization.StringSerializer";
//    private String SEND_BUFFER_CONFIG = "10240";
//    private String BATCH_SIZE_CONFIG = "10";
    private Properties prop;


    public Properties getProp() {
        prop = new Properties();
        prop.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,BOOTSTRAP_SERVERS_CONFIG);
        prop.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,KEY_SERIALIZER_CLASS_CONFIG);
        prop.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,VALUE_SERIALIZER_CLASS_CONFIG);
        return prop;
    }
    public Properties getProp2() {
        prop = new Properties();
        prop.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,BOOTSTRAP_SERVERS_CONFIG);
        return prop;
    }

    public String getBOOTSTRAP_SERVERS_CONFIG() {
        return BOOTSTRAP_SERVERS_CONFIG;
    }

    public void setBOOTSTRAP_SERVERS_CONFIG(String BOOTSTRAP_SERVERS_CONFIG) {
        this.BOOTSTRAP_SERVERS_CONFIG = BOOTSTRAP_SERVERS_CONFIG;
    }

    public String getKEY_SERIALIZER_CLASS_CONFIG() {
        return KEY_SERIALIZER_CLASS_CONFIG;
    }

    public void setKEY_SERIALIZER_CLASS_CONFIG(String KEY_SERIALIZER_CLASS_CONFIG) {
        this.KEY_SERIALIZER_CLASS_CONFIG = KEY_SERIALIZER_CLASS_CONFIG;
    }

    public String getVALUE_SERIALIZER_CLASS_CONFIG() {
        return VALUE_SERIALIZER_CLASS_CONFIG;
    }

    public void setVALUE_SERIALIZER_CLASS_CONFIG(String VALUE_SERIALIZER_CLASS_CONFIG) {
        this.VALUE_SERIALIZER_CLASS_CONFIG = VALUE_SERIALIZER_CLASS_CONFIG;
    }
}
