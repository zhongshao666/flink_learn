package com.ssa.bean;

import lombok.Data;

@Data
public class ThreatIntelligenceIp {
    private String client_ip;
    private Long dateTime;
    private Integer type;
    private Float score;
    private String describe;
}
