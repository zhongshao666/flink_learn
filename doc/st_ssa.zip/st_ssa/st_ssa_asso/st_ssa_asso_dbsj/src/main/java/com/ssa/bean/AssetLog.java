package com.ssa.bean;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : hld
 * @Date ： 2021/4/8
 * @Time : 17:00
 * @role ：
 */

@Data
public class AssetLog {
    /**
     * first_id和second_id 和起来成为主键
     */
    private Long firstId;
    private Long secondId;
    /**
     * 标识服务的分组关系。
     */
    private Integer assetId;

    private Integer instanceId;

    private String tableSchema;

    private Integer tableId;

    private Integer databaseType;

    private Integer sourceTableCode;

    private String categoryLabelSourceSetJson;

    private Integer levelLabelId;

    private Integer isSensitiveTable;

    /**
     * 日志格式版本
     */
    private Integer logVersion;
    /**
     * 会话id
     */
    private String sessionId;
    /**
     * 事件类型 1 -登录 2 - 访问
     */
    private Integer eventType;
    /**
     * 客户端mac
     */
    private String clientMac;
    /**
     * 客户端ip
     */
    private String clientIp;
    /**
     * 客户端端口
     */
    private Integer clientPort;
    /**
     * 服务端mac
     */
    private String serverMac;
    /**
     * 服务端ip
     */
    private String serverIp;
    /**
     * 服务端端口
     */
    private Integer serverPort;
    /**
     * 请求时间
     */
    private Long requestTime;
    /**
     * 用户请求时间
     */
    private Integer requestTimeUsec;
    /**
     * 请求时间（分钟）
     */
    private Integer minuteTime;
    /**
     * 请求时间（微秒）
     */
    private Long requestMicrosecond;
    /**
     * 执行时长
     */
    private Long executeTime;
    /**
     * 请求状态码
     */
    private Integer requestStatus;
    /**
     * 数据库账号
     */
    private String account;
    /**
     * 客户端账号
     */
    private String osUserName;
    /**
     * 风险类型
     */
    private String riskType;
    /**
     * 匹配规则
     */
    private List<String> matchedRules = new ArrayList<>();
    /**
     * 风险等级
     */
    private Integer riskLevel;
    /**
     * 保护手段
     */
    private Integer protectOperate;
    /**
     * 请求库名
     */
    private String instanceName;
    /**
     * 客户端工具
     */
    private String clientApp;
    /**
     * 客户端地址
     */
    private String clientHost;
    /**
     * 业务语句
     */
    private String operationStatement;
    /**
     * 绑定变量
     */
    private List<List<String>> bindingVariables = new ArrayList<>();
    /**
     * sql模板
     */
    private String statementPattern;
    /**
     * 响应结果
     */
    private List<List<String>> reply = new ArrayList<>();
    /**
     * 错误sql
     */
    private String errorReply;
    /**
     * 响应行数
     */
    private Integer rowsAffected;
    /**
     * 操作类型
     */
    private Integer operationType;
    /**
     * 操作命令
     */
    private String operationCommand;
    /**
     * 操作对象
     */
    private String operandType;
    /**
     * 操作对象类
     */
    private List<String> operandName = new ArrayList<>();
    /**
     * 二级操作对象
     */
    private List<String> secondOperandName = new ArrayList<>();
    /**
     * web请求用户名
     */
    private String webUserName;
    /**
     * web请求地址
     */
    private String webUrl;
    /**
     * 三层关联时web客户端的IP地址（三层关联
     * 是将数据库信息，数据库客户端信息，web客户端信息关联起来，数据库客户端为web系统场景时使用。
     * 每个sql语句会关联触发sql请求的url请求、web系统账号、客户端IP）
     */
    private String webIp;


    private String webSessionId;

    private Integer reviewed;

    private String comment;

    private Integer sent;
    /**
     * 敏感表名称,逗号分隔
     */
    private List<String> sensitiveTables= new ArrayList<>();
    /**
     * 敏感字段名称,逗号分隔
     */
    private List<String> sensitiveColumns= new ArrayList<>();
    /**
     * 风险类型实时打标，（风险等级）
     */
    private Integer riskTypeAi;
    /**
     *@功能描述 流计算打标
    */
    private List<String> flowLabel= new ArrayList<>();
    /**
     * 告警编号标签
     */
    private List<String> alarmLabel= new ArrayList<>();

    private Integer isModelLabel;

    private String dateInfo;

    public Long getFirstId() {
        return firstId;
    }

    public void setFirstId(Long firstId) {
        this.firstId = firstId;
    }

    public Long getSecondId() {
        return secondId;
    }

    public void setSecondId(Long secondId) {
        this.secondId = secondId;
    }

    public Integer getAssetId() {
        return assetId;
    }

    public void setAssetId(Integer assetId) {
        this.assetId = assetId;
    }

    public Integer getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(Integer instanceId) {
        this.instanceId = instanceId;
    }

    public String getTableSchema() {
        return tableSchema;
    }

    public void setTableSchema(String tableSchema) {
        this.tableSchema = tableSchema;
    }

    public Integer getTableId() {
        return tableId;
    }

    public void setTableId(Integer tableId) {
        this.tableId = tableId;
    }

    public Integer getDatabaseType() {
        return databaseType;
    }

    public void setDatabaseType(Integer databaseType) {
        this.databaseType = databaseType;
    }

    public Integer getSourceTableCode() {
        return sourceTableCode;
    }

    public void setSourceTableCode(Integer sourceTableCode) {
        this.sourceTableCode = sourceTableCode;
    }

    public String getCategoryLabelSourceSetJson() {
        return categoryLabelSourceSetJson;
    }

    public void setCategoryLabelSourceSetJson(String categoryLabelSourceSetJson) {
        this.categoryLabelSourceSetJson = categoryLabelSourceSetJson;
    }

    public Integer getLevelLabelId() {
        return levelLabelId;
    }

    public void setLevelLabelId(Integer levelLabelId) {
        this.levelLabelId = levelLabelId;
    }

    public Integer getIsSensitiveTable() {
        return isSensitiveTable;
    }

    public void setIsSensitiveTable(Integer isSensitiveTable) {
        this.isSensitiveTable = isSensitiveTable;
    }

    public Integer getLogVersion() {
        return logVersion;
    }

    public void setLogVersion(Integer logVersion) {
        this.logVersion = logVersion;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public Integer getEventType() {
        return eventType;
    }

    public void setEventType(Integer eventType) {
        this.eventType = eventType;
    }

    public String getClientMac() {
        return clientMac;
    }

    public void setClientMac(String clientMac) {
        this.clientMac = clientMac;
    }

    public String getClientIp() {
        return clientIp;
    }

    public void setClientIp(String clientIp) {
        this.clientIp = clientIp;
    }

    public Integer getClientPort() {
        return clientPort;
    }

    public void setClientPort(Integer clientPort) {
        this.clientPort = clientPort;
    }

    public String getServerMac() {
        return serverMac;
    }

    public void setServerMac(String serverMac) {
        this.serverMac = serverMac;
    }

    public String getServerIp() {
        return serverIp;
    }

    public void setServerIp(String serverIp) {
        this.serverIp = serverIp;
    }

    public Integer getServerPort() {
        return serverPort;
    }

    public void setServerPort(Integer serverPort) {
        this.serverPort = serverPort;
    }

    public Long getRequestTime() {
        return requestTime;
    }

    public void setRequestTime(Long requestTime) {
        this.requestTime = requestTime;
    }

    public Integer getRequestTimeUsec() {
        return requestTimeUsec;
    }

    public void setRequestTimeUsec(Integer requestTimeUsec) {
        this.requestTimeUsec = requestTimeUsec;
    }

    public Integer getMinuteTime() {
        return minuteTime;
    }

    public void setMinuteTime(Integer minuteTime) {
        this.minuteTime = minuteTime;
    }

    public Long getRequestMicrosecond() {
        return requestMicrosecond;
    }

    public void setRequestMicrosecond(Long requestMicrosecond) {
        this.requestMicrosecond = requestMicrosecond;
    }

    public Long getExecuteTime() {
        return executeTime;
    }

    public void setExecuteTime(Long executeTime) {
        this.executeTime = executeTime;
    }

    public Integer getRequestStatus() {
        return requestStatus;
    }

    public void setRequestStatus(Integer requestStatus) {
        this.requestStatus = requestStatus;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getOsUserName() {
        return osUserName;
    }

    public void setOsUserName(String osUserName) {
        this.osUserName = osUserName;
    }

    public String getRiskType() {
        return riskType;
    }

    public void setRiskType(String riskType) {
        this.riskType = riskType;
    }

    public List<String> getMatchedRules() {
        return matchedRules;
    }

    public void setMatchedRules(List<String> matchedRules) {
        this.matchedRules = matchedRules;
    }

    public Integer getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(Integer riskLevel) {
        this.riskLevel = riskLevel;
    }

    public Integer getProtectOperate() {
        return protectOperate;
    }

    public void setProtectOperate(Integer protectOperate) {
        this.protectOperate = protectOperate;
    }

    public String getInstanceName() {
        return instanceName;
    }

    public void setInstanceName(String instanceName) {
        this.instanceName = instanceName;
    }

    public String getClientApp() {
        return clientApp;
    }

    public void setClientApp(String clientApp) {
        this.clientApp = clientApp;
    }

    public String getClientHost() {
        return clientHost;
    }

    public void setClientHost(String clientHost) {
        this.clientHost = clientHost;
    }

    public String getOperationStatement() {
        return operationStatement;
    }

    public void setOperationStatement(String operationStatement) {
        this.operationStatement = operationStatement;
    }

    public List<List<String>> getBindingVariables() {
        return bindingVariables;
    }

    public void setBindingVariables(List<List<String>> bindingVariables) {
        this.bindingVariables = bindingVariables;
    }

    public String getStatementPattern() {
        return statementPattern;
    }

    public void setStatementPattern(String statementPattern) {
        this.statementPattern = statementPattern;
    }

    public List<List<String>> getReply() {
        return reply;
    }

    public void setReply(List<List<String>> reply) {
        this.reply = reply;
    }

    public String getErrorReply() {
        return errorReply;
    }

    public void setErrorReply(String errorReply) {
        this.errorReply = errorReply;
    }

    public Integer getRowsAffected() {
        return rowsAffected;
    }

    public void setRowsAffected(Integer rowsAffected) {
        this.rowsAffected = rowsAffected;
    }

    public Integer getOperationType() {
        return operationType;
    }

    public void setOperationType(Integer operationType) {
        this.operationType = operationType;
    }

    public String getOperationCommand() {
        return operationCommand;
    }

    public void setOperationCommand(String operationCommand) {
        this.operationCommand = operationCommand;
    }

    public String getOperandType() {
        return operandType;
    }

    public void setOperandType(String operandType) {
        this.operandType = operandType;
    }

    public List<String> getOperandName() {
        return operandName;
    }

    public void setOperandName(List<String> operandName) {
        this.operandName = operandName;
    }

    public List<String> getSecondOperandName() {
        return secondOperandName;
    }

    public void setSecondOperandName(List<String> secondOperandName) {
        this.secondOperandName = secondOperandName;
    }

    public String getWebUserName() {
        return webUserName;
    }

    public void setWebUserName(String webUserName) {
        this.webUserName = webUserName;
    }

    public String getWebUrl() {
        return webUrl;
    }

    public void setWebUrl(String webUrl) {
        this.webUrl = webUrl;
    }

    public String getWebIp() {
        return webIp;
    }

    public void setWebIp(String webIp) {
        this.webIp = webIp;
    }

    public String getWebSessionId() {
        return webSessionId;
    }

    public void setWebSessionId(String webSessionId) {
        this.webSessionId = webSessionId;
    }

    public Integer getReviewed() {
        return reviewed;
    }

    public void setReviewed(Integer reviewed) {
        this.reviewed = reviewed;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Integer getSent() {
        return sent;
    }

    public void setSent(Integer sent) {
        this.sent = sent;
    }

    public List<String> getSensitiveTables() {
        return sensitiveTables;
    }

    public void setSensitiveTables(List<String> sensitiveTables) {
        this.sensitiveTables = sensitiveTables;
    }

    public List<String> getSensitiveColumns() {
        return sensitiveColumns;
    }

    public void setSensitiveColumns(List<String> sensitiveColumns) {
        this.sensitiveColumns = sensitiveColumns;
    }

    public Integer getRiskTypeAi() {
        return riskTypeAi;
    }

    public void setRiskTypeAi(Integer riskTypeAi) {
        this.riskTypeAi = riskTypeAi;
    }

    public List<String> getFlowLabel() {
        return flowLabel;
    }

    public void setFlowLabel(List<String> flowLabel) {
        this.flowLabel = flowLabel;
    }

    public List<String> getAlarmLabel() {
        return alarmLabel;
    }

    public void setAlarmLabel(List<String> alarmLabel) {
        this.alarmLabel = alarmLabel;
    }

    public Integer getIsModelLabel() {
        return isModelLabel;
    }

    public void setIsModelLabel(Integer isModelLabel) {
        this.isModelLabel = isModelLabel;
    }

    public String getDateInfo() {
        return dateInfo;
    }

    public void setDateInfo(String dateInfo) {
        this.dateInfo = dateInfo;
    }
}