package com.ssa.bean;

import lombok.Data;

@Data
public class ControlData {
    private String key;
    private String value;
}
