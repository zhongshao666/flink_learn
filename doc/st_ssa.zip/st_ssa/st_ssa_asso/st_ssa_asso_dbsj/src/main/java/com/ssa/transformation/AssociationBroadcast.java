package com.ssa.transformation;

import com.ssa.bean.OfflineData;
import com.ssa.constants.CommonConstants;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.BroadcastProcessFunction;
import org.apache.flink.util.Collector;

/**
 * @author : hld
 * @Date ： 2021/4/28
 * @Time : 15:38
 * @role ：
 */
public class AssociationBroadcast extends BroadcastProcessFunction<OfflineData, Tuple4<Integer, Integer, String, String>, Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> {

    private Tuple4<Integer, Integer, String, String> tuple4;

    @Override
    public void open(Configuration parameters) throws Exception {

        tuple4= new Tuple4<>(0,0,null,null);
    }

    @Override
    public void processElement(OfflineData value, ReadOnlyContext ctx, Collector<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> out) throws Exception {
        out.collect(new Tuple2<>(value, tuple4));
    }

    @Override
    public void processBroadcastElement(Tuple4<Integer, Integer, String, String> value, Context ctx, Collector<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> out) throws Exception {
        if (value.f0 == CommonConstants.ZkDataType.ASSO_RULE.getVal()){
            out.collect(new Tuple2<>(null, value));
        }
    }
}
