package com.ssa.bean;

import lombok.Data;

/**
 * @author : hld
 * @Date ： 2021/4/25
 * @Time : 14:06
 * @role ：
 */
@Data
public class CommonConfig {
    /**
     * 用于区分value 的值，暂时不填     周  1-7中的一个
     */
    private String key;
    /**
     * 数据本身   09:00-18:00    192.168.0.1 或 192.168.0.1-192.168.99.99  root
     */
    private String value;
    /**
     * 时间戳
     */
    private Long dateTime;
    /**
     * type ,1,ip ;0 ip段，用-隔开
     */
    private Integer type;
    /**
     * 描述，暂时无用
     */
    private String describe;
}
