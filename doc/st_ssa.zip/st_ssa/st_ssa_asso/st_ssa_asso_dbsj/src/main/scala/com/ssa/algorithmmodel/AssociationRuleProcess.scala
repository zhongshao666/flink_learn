package com.ssa.algorithmmodel

import java.text.SimpleDateFormat
import java.util.Date
import com.alibaba.fastjson.JSON
import com.ssa.bean.{AssetLog, AssociationRuleBean, OfflineData}
import com.ssa.constants.CommonConstants
import org.apache.flink.api.common.state.MapStateDescriptor
import org.apache.flink.api.java.tuple.Tuple2
import org.apache.flink.api.java.tuple.Tuple4
import org.apache.flink.configuration.Configuration
import org.apache.flink.streaming.api.functions.co.KeyedBroadcastProcessFunction
import org.apache.flink.util.Collector

import java.time.{LocalDateTime, LocalTime, ZoneOffset}
import java.time.format.DateTimeFormatter
import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
 * @author : hld,汤庆仕
 * @Date ： 2021/4/28
 * @Time : 15:49
 * @role ： 
 */
class AssociationRuleProcess extends KeyedBroadcastProcessFunction[String, AssetLog, Tuple2[OfflineData, Tuple4[Integer, Integer, String, String]], AssetLog] {
  //像这些从离线处获取的值而且你在更新表时候这些数值会发生变化的值（我假设他每次拉取离线数据时的pos会变嘛），一般保存在state里，防止重启时数据丢失

  /**
   * 1:assoRule,
   * 2:assoRuleUserCountbf,
   * 3:assoRuleAppIdPos,
   * 4:assoRuleClientIpPos,
   * 5:assoRuleOperationTypePos
   * 6:assoRuleRequestTimePos
   */
  val associationRule = new MapStateDescriptor[String, (mutable.ListBuffer[mutable.ListBuffer[Int]], Double, mutable.HashMap[Int, Int], mutable.HashMap[String, Int], mutable.HashMap[Int, Int], mutable.HashMap[String, Int])]("associationRule", classOf[String], classOf[(mutable.ListBuffer[mutable.ListBuffer[Int]], Double, mutable.HashMap[Int, Int], mutable.HashMap[String, Int], mutable.HashMap[Int, Int], mutable.HashMap[String, Int])])

  var dateTimeFormatter: DateTimeFormatter = _
  var associationRuleBean: AssociationRuleBean = _

  //编码范围0--9，大于9的编码仍赋值9，所以记录最大的编码值
  var maxAssetIdPos = 0
  var maxClientIpPos = 0
  var maxOperationTypePos = 0
  var maxRequestTImePos = 0

  override def open(parameters: Configuration): Unit = {
    //数据的初始化
    associationRuleBean = new AssociationRuleBean()
    dateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")

  }


  override def processElement(value: AssetLog, ctx: KeyedBroadcastProcessFunction[String, AssetLog, Tuple2[OfflineData, Tuple4[Integer, Integer, String, String]], AssetLog]#ReadOnlyContext, out: Collector[AssetLog]): Unit = {
    //将long类型的时间类转换为am、pm、after（实时单条数据的时间）
    //    val times: String = matchTime(in1.requestTime)requestTime

    //匹配编码
    //    matchEnCode(in1, times)

    val association = ctx.getBroadcastState(associationRule).get(ctx.getCurrentKey)

    //检查每条数据的异常情况
    if (association != null && calculateRule(value, association)) {
      //数据异常则打标
      value.setIsModelLabel(1)

      val ai: Integer = value.getRiskTypeAi
      if (ai == null){
        value.setRiskTypeAi(4)
      }else {
        value.setRiskTypeAi(math.max(value.getRiskTypeAi,4))
      }
      value.getFlowLabel.add("05030102")
      value.getAlarmLabel.add("050301")

      out.collect(value)
    }
  }

  override def processBroadcastElement(value: Tuple2[OfflineData, Tuple4[Integer, Integer, String, String]], ctx: KeyedBroadcastProcessFunction[String, AssetLog, Tuple2[OfflineData, Tuple4[Integer, Integer, String, String]], AssetLog]#Context, out: Collector[AssetLog]): Unit = {

    if (value.f0 != null) {

      var association = ctx.getBroadcastState(associationRule).get(value.f0.getAccount)

      if (association == null) {
        association = new Tuple6[mutable.ListBuffer[mutable.ListBuffer[Int]], Double, mutable.HashMap[Int, Int], mutable.HashMap[String, Int], mutable.HashMap[Int, Int], mutable.HashMap[String, Int]](new ListBuffer[ListBuffer[Int]](), 0.0, new mutable.HashMap[Int, Int](), new mutable.HashMap[String, Int](), new mutable.HashMap[Int, Int](), new mutable.HashMap[String, Int]())
      }

      //将离线表的各个pos放入state中储存起来
      if (value.f0.getOfflineTableType.equals(CommonConstants.OfflineTableType.ASSO_RULE.getVal)) {
        //保存userCount的百分比
        //上面如果直接获取表中的比例值，这里是不是就不用update了
        ctx.getBroadcastState(associationRule).put(value.f0.getAccount, (association._1, value.f0.getUserCountPercent, association._3, association._4, association._5, association._6))
      }

      if (value.f0.getOfflineTableType.equals(CommonConstants.OfflineTableType.ASSO_RULE_ENCODE.getVal)) {

        //将pos的最大值做保存
        maxAssetIdPos = Math.max(maxAssetIdPos, value.f0.getAssetIdPos)
        maxClientIpPos = Math.max(maxClientIpPos, value.f0.getClientIpPos)
        maxOperationTypePos = Math.max(maxOperationTypePos, value.f0.getOperationTypePos)
        maxRequestTImePos = Math.max(maxRequestTImePos, value.f0.getRequestTimePos)


        //将appid相应的pos以kv的形式保存（字典？）

        ctx.getBroadcastState(associationRule).get(value.f0.getAccount)

        association._3.put(value.f0.getAssetId, value.f0.getAssetIdPos)
        //clientip
        association._4.put(value.f0.getClientIp, value.f0.getClientIpPos)
        //eventtype
        association._5.put(value.f0.getOperationType, value.f0.getOperationTypePos)
        //requesttime
        association._6.put(value.f0.getRequestTime, value.f0.getRequestTimePos)
        //将每条frequent数据保存起来
        //这里直接存好了表中的所有频繁项吗，这里不是使用assoRuleAppIdPos这四项吗
        val ints = new ListBuffer[Int]()
        val buffer: ListBuffer[Int] = ints += value.f0.getAssetIdPos += value.f0.getClientIpPos += value.f0.getOperationTypePos += value.f0.getRequestTimePos
        association._1.append(buffer)

        ctx.getBroadcastState(associationRule).put(value.f0.getAccount, association)
      }

    } else {

      associationRuleBean = JSON.parseObject(value.f1.f3, classOf[AssociationRuleBean])
    }

  }


  def matchTime(requestTime: Long): String = {
    //时间格式转换
    val localDateTime: LocalDateTime = LocalDateTime.ofEpochSecond(requestTime / 1000, 0, ZoneOffset.ofHours(8))
    val format: String = localDateTime.format(dateTimeFormatter)
    val date: LocalTime = LocalTime.parse(format)

    new Date(format.format(requestTime))
    //判断时间区间，返回am、pm和after
    if (date.isAfter(LocalTime.parse("00")) && date.isBefore(LocalTime.parse("12"))) {
      "am"
    } else if (date.isBefore(LocalTime.parse("18"))) {
      "pm"
    } else {
      "after"
    }
  }

  def calculateRule(value: AssetLog, association: (mutable.ListBuffer[mutable.ListBuffer[Int]], Double, mutable.HashMap[Int, Int], mutable.HashMap[String, Int], mutable.HashMap[Int, Int], mutable.HashMap[String, Int])): Boolean = {

    if (association._3 != null && association._4 != null && association._5 != null && association._6 != null) {
      val buffer = new ListBuffer[Int]()

      buffer += association._3.getOrElse(value.getAssetId, addDefaultValue(maxAssetIdPos, association._2))
      buffer += association._4.getOrElse(value.getClientIp, addDefaultValue(maxClientIpPos, association._2))
      buffer += association._5.getOrElse(value.getEventType, addDefaultValue(maxOperationTypePos, association._2))
      buffer += association._6.getOrElse(matchTime(value.getRequestTime), addDefaultValue(maxRequestTImePos, association._2))


      for (elem <- association._1) {
        var sum: Double = 0
        for (i <- elem.indices) {
          sum += Math.log10(calculateRuleTuple(buffer(i), elem(i), elem.size + 1, i + 1)) * (1 / ((elem.size + 1) - (i + 1)))
        }
        if (sum / (elem.size + 1) < associationRuleBean.getAbnormalThreshold) {
          return false
        }
      }

    }
    true
  }

  def calculateRuleTuple(httpTuple: Int, ruleTuple: Int, lengths: Int, code: Int): Int = {
    if (Math.abs(httpTuple - ruleTuple) == 0) {
      1
    } else {
      (Math.abs(httpTuple - ruleTuple) * Math.pow(10, lengths - code - 1)).toInt //常值保存成val
    }
  }

  //特殊情况下，单条实时数据的编码规则(字段取值未出现过时)
  def addDefaultValue(maxPos: Int, assoRuleUserCountbf: Double): Int = {
    if (assoRuleUserCountbf > associationRuleBean.getRecordThreshold) {
      9
    } else {
      if (maxPos == 9) {
        9
      } else {
        maxPos + 1
      }
    }
  }

}