package com.ssa.algorithmmodel

import java.text.SimpleDateFormat
import java.util.Date

import com.alibaba.fastjson.JSON
import com.ssa.bean.{AssociationRuleBean, OfflineData}
import com.ssa.sensitive.constants.CommonConstants
import com.ssa.sensitive.to.HttpLog
import org.apache.flink.api.common.state.{MapStateDescriptor, ValueState, ValueStateDescriptor}
import org.apache.flink.configuration.Configuration
import org.apache.flink.streaming.api.functions.co.{KeyedBroadcastProcessFunction, KeyedCoProcessFunction}
import org.apache.flink.util.Collector
import org.apache.flink.api.java.tuple.Tuple2
import org.apache.hadoop.fs.StorageStatistics.CommonStatisticNames

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
 * @author : hld,汤庆仕
 * @Date ： 2021/4/28
 * @Time : 15:49
 * @role ：
 */
class AssociationRuleProcess extends KeyedBroadcastProcessFunction[String, HttpLog, Tuple2[OfflineData, String], HttpLog] { //列表里的这四个量什么说法
  //像这些从离线处获取的值而且你在更新表时候这些数值会发生变化的值（我假设他每次拉取离线数据时的pos会变嘛），一般保存在state里，防止重启时数据丢失
  //今天做的离线统计和昨天的统计可能不相同，所以位置排序也会变化

  /**
   * 1:assoRule,
   * 2:assoRuleUserCountbf,
   * 3:assoRuleAppIdPos,
   * 4:assoRuleClientIpPos,
   * 5:assoRuleEventTypePos
   * 6:assoRuleRequestTimePos
   */
  var associationRule: MapStateDescriptor[String, (mutable.ListBuffer[mutable.ListBuffer[Int]], Double, mutable.HashMap[Long, Int], mutable.HashMap[String, Int], mutable.HashMap[Int, Int], mutable.HashMap[String, Int])] = _

  //这些不变得值可以定义成常量，不需要存在state中
  //全是常量？

  var maxAppIdPos = 0
  var maxClientIpPos = 0
  var maxEventTypePos = 0
  var maxRequestTImePos = 0

  var associationRuleBean: AssociationRuleBean = _

  override def open(parameters: Configuration): Unit = {

    associationRule = new MapStateDescriptor[String, (mutable.ListBuffer[mutable.ListBuffer[Int]], Double, mutable.HashMap[Long, Int], mutable.HashMap[String, Int], mutable.HashMap[Int, Int], mutable.HashMap[String, Int])]("associationRule", classOf[String], classOf[(mutable.ListBuffer[mutable.ListBuffer[Int]], Double, mutable.HashMap[Long, Int], mutable.HashMap[String, Int], mutable.HashMap[Int, Int], mutable.HashMap[String, Int])])

    associationRuleBean = new AssociationRuleBean()
  }


  override def processElement(value: HttpLog, ctx: KeyedBroadcastProcessFunction[String, HttpLog, Tuple2[OfflineData, String], HttpLog]#ReadOnlyContext, out: Collector[HttpLog]): Unit = {
    //将long类型的时间类转换为am、pm、after（实时单条数据的时间）
    //    val times: String = matchTime(in1.requestTime)requestTime

    //匹配编码
    //    matchEnCode(in1, times)

    val association = ctx.getBroadcastState(associationRule).get(ctx.getCurrentKey)

    //检查每条数据的异常情况
    if (calculateRule(value, association)) {
      //数据异常则打标

      if (value.getRiskType == null) value.setRiskType("01030101")
      else value.setRiskType(value.getRiskType + "," + "01030101")

      if (value.getRiskLevel == null) value.setRiskLevel(4)
      else value.setRiskLevel(Math.max(value.getRiskLevel, 4))

      if (value.getStrategyName == null) value.setStrategyName("关联规则")
      else value.setStrategyName(value.getStrategyName + "," + "关联规则")

//      if (value.getStrategyId == null) value.setStrategyId(strategyMatch.getId.toString)
//      else value.setStrategyId(value.getStrategyId + "," + strategyMatch.getId)

//      if (value.getStrategyType == null) value.setStrategyType(strategyMatch.getStrategyType)
//      else value.setStrategyType(value.getStrategyType + "," + strategyMatch.getStrategyType)
      value.setIsModelLabel(1)
    }
    out.collect(value)

  }

  override def processBroadcastElement(value: Tuple2[OfflineData, String], ctx: KeyedBroadcastProcessFunction[String, HttpLog, Tuple2[OfflineData, String], HttpLog]#Context, out: Collector[HttpLog]): Unit = {
    if (value.f0 != null) {

      val association = ctx.getBroadcastState(associationRule).get(value.f0.getUserName)

      //将离线表的各个pos放入state中储存起来
      if (value.f0.getOfflineTableType.equals(CommonConstants.OfflineTableType.ASSO_RULE.getVal)) {
        //保存userCount的百分比
        //上面如果直接获取表中的比例值，这里是不是就不用update了
        ctx.getBroadcastState(associationRule).put(value.f0.getUserName, (association._1, value.f0.getUserCountPercent, association._3, association._4, association._5, association._6))
      }

      if (value.f0.getOfflineTableType.equals(CommonConstants.OfflineTableType.ASSO_RULE_ENCODE.getVal)) {

        //将pos的最大值做保存
        maxAppIdPos = Math.max(maxAppIdPos, value.f0.getAppIdPos)
        maxClientIpPos = Math.max(maxClientIpPos, value.f0.getClientIpPos)
        maxEventTypePos = Math.max(maxEventTypePos, value.f0.getEventTypePos)
        maxRequestTImePos = Math.max(maxRequestTImePos, value.f0.getRequestTimePos)




        //将appid相应的pos以kv的形式保存（字典？）
        association._3.put(value.f0.getAppId, value.f0.getAppIdPos)
        //clientip
        association._4.put(value.f0.getClientIp, value.f0.getClientIpPos)
        //eventtype
        association._5.put(value.f0.getEventType, value.f0.getEventTypePos)
        //requesttime
        association._6.put(value.f0.getRequestTime, value.f0.getRequestTimePos)
        //将每条frequent数据保存起来
        //这里直接存好了表中的所有频繁项吗，这里不是使用assoRuleAppIdPos这四项吗
        val ints = new ListBuffer[Int]()
        val buffer: ListBuffer[Int] = ints += value.f0.getAppIdPos += value.f0.getClientIpPos += value.f0.getEventTypePos += value.f0.getRequestTimePos
        association._1.append(buffer)

        ctx.getBroadcastState(associationRule).put(value.f0.getUserName, association)
      }

    } else {

      associationRuleBean = JSON.parseObject(value.f1, classOf[AssociationRuleBean])
    }
  }


  def matchTime(requestTime: Long): String = {
    //时间格式转换
    val format = new SimpleDateFormat("HH")
    val date = new Date(format.format(requestTime))

    new Date(format.format(requestTime))
    //判断时间区间，返回am、pm和after
    if (date.after(format.parse("00")) && date.before(format.parse("12"))) {
      "am"
    } else if (date.before(format.parse("18"))) {
      "pm"
    } else {
      "after"
    }
  }

  def calculateRule(value: HttpLog, association: (mutable.ListBuffer[mutable.ListBuffer[Int]], Double, mutable.HashMap[Long, Int], mutable.HashMap[String, Int], mutable.HashMap[Int, Int], mutable.HashMap[String, Int])): Boolean = {
    val buffer = new ListBuffer[Int]()

    buffer += association._3.getOrElse(value.getAppId, addDefaultValue(maxAppIdPos, association._2))
    buffer += association._4.getOrElse(value.getClientIp, addDefaultValue(maxClientIpPos, association._2))
    buffer += association._5.getOrElse(value.getEventType, addDefaultValue(maxEventTypePos, association._2))
    buffer += association._6.getOrElse(matchTime(value.getRequestTime), addDefaultValue(maxRequestTImePos, association._2))


    for (elem <- association._1) {
      var sum: Double = 0
      for (i <- elem.indices) {
        sum += Math.log10(calculateRuleTuple(buffer(i), elem(i), elem.size + 1, i + 1)) * (1 / ((elem.size + 1) - (i + 1)))
      }
      if (sum / (elem.size + 1) < associationRuleBean.getAbnormalThreshold) {
        return false
      }
    }
    true
  }

  def calculateRuleTuple(httpTuple: Int, ruleTuple: Int, lengths: Int, code: Int): Int = {
    if (Math.abs(httpTuple - ruleTuple) == 0) {
      1
    } else {
      (Math.abs(httpTuple - ruleTuple) * Math.pow(10, (lengths - code - 1))).toInt //常值保存成val
    }
  }

  //特殊情况下，单条实时数据的编码规则(字段取值未出现过时)
  def addDefaultValue(maxPos: Int, assoRuleUserCountbf: Double): Int = {
    if (assoRuleUserCountbf > associationRuleBean.getRecordThreshold) {
      9
    } else {
      if (maxPos == 9) {
        9
      } else {
        maxPos + 1
      }
    }
  }
}
