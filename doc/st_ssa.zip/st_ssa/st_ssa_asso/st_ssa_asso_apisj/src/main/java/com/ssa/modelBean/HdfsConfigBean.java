package com.ssa.modelBean;

/**
 * @author : hld
 * @Date ： 2021/4/27
 * @Time : 10:15
 * @role ：
 */
public class HdfsConfigBean {
    /**
     * hdfs_url_python : http://192.168.18.70:9870/
     * hdfs_file_path : /home/secsmart/documents/pst_result.json
     * hdfs_hostname : nn1
     * hdfs_url_scala : hdfs://192.168.18.70:8020/
     */

    private String hdfs_url_python;
    private String hdfs_file_path;
    private String hdfs_hostname;
    private String hdfs_url_scala;

    public String getHdfs_url_python() {
        return hdfs_url_python;
    }

    public void setHdfs_url_python(String hdfs_url_python) {
        this.hdfs_url_python = hdfs_url_python;
    }

    public String getHdfs_file_path() {
        return hdfs_file_path;
    }

    public void setHdfs_file_path(String hdfs_file_path) {
        this.hdfs_file_path = hdfs_file_path;
    }

    public String getHdfs_hostname() {
        return hdfs_hostname;
    }

    public void setHdfs_hostname(String hdfs_hostname) {
        this.hdfs_hostname = hdfs_hostname;
    }

    public String getHdfs_url_scala() {
        return hdfs_url_scala;
    }

    public void setHdfs_url_scala(String hdfs_url_scala) {
        this.hdfs_url_scala = hdfs_url_scala;
    }
}
