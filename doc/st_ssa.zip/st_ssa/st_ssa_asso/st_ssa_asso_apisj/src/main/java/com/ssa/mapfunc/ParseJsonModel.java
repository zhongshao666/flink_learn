package com.ssa.mapfunc;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ssa.modelBean.ModelBean;

import java.util.HashMap;
import java.util.Map;

/**
 * @author : hld
 * @Date ： 2021/4/27
 * @Time : 10:38
 * @role ：
 */
public class ParseJsonModel {
    /**
     * 解析概率后缀树hdfs数据
     */
    public void matchHdfsPstConfig(String config, ModelBean modelBean) {
        JSONObject object = JSON.parseObject(config);

        HashMap<String, HashMap<String, Double>> pstHashMap = new HashMap<>();

        Map pst_map = object.getJSONObject("pst_map");

        for (Object o : pst_map.keySet()) {
            HashMap<String, Double> inHashMap = new HashMap<>();
            Map jsonObject = JSON.parseObject(pst_map.get(o).toString());
            for (Object o1 : jsonObject.keySet()) {
                inHashMap.put(o1.toString(), Double.parseDouble(jsonObject.get(o1).toString()));
            }
            pstHashMap.put(o.toString(), inHashMap);
        }
        modelBean.setPstMap(pstHashMap);

        HashMap<String, Double> baselineHashMap = new HashMap<>();
        Map baseline_map = object.getJSONObject("baseline_map");
        for (Object o : baseline_map.keySet()) {
            baseline_map.put(o.toString(), Double.parseDouble(baseline_map.get(o).toString()));
        }
        modelBean.setBaselineMap(baselineHashMap);

        HashMap<String, String> eventSymbolHashMap = new HashMap<>();
        Map event_symbol_map = object.getJSONObject("event_symbol_map");
        for (Object o : event_symbol_map.keySet()) {
            eventSymbolHashMap.put(o.toString(), event_symbol_map.get(o).toString());
        }
        modelBean.setEventSymbolMap(eventSymbolHashMap);
    }

    /**
     * 计算zkconfig配置
     *
     * @param config
     * @param modelBean
     */
    public void matchZkPstConfig(String config, ModelBean modelBean) {
        // 配置json
        JSONObject config_json = JSON.parseObject(config);
        // 事件字段
        modelBean.setEventKey(config_json.getJSONObject("field_config").getString("event_field"));
        // 对象字段
        modelBean.setObjectKey(config_json.getJSONObject("field_config").getString("object_field"));
        // 时间字段
        modelBean.setTimeKey(config_json.getJSONObject("field_config").getString("time_field"));
        modelBean.setPstDepth(Integer.parseInt(config_json.getJSONObject("pst_config").getString("l")));
        modelBean.setPstThd(Double.parseDouble(config_json.getJSONObject("data_config").getString("anomaly_thd")));
    }

}
