package com.ssa.source;


import com.ssa.ApisjMain;
import com.ssa.sensitive.constants.CommonConstants;
import com.ssa.utils.CuratorOperator;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.CuratorFramework;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.recipes.cache.*;
import org.apache.flink.streaming.api.functions.source.RichSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.ssa.sensitive.util.SystemConfig.*;

public class SecZookeeperSourceUpdate extends RichSourceFunction<Tuple4<Integer, Integer, String, String>> {

    private static final Logger logger = LoggerFactory.getLogger(SecZookeeperSourceUpdate.class);

    CuratorOperator cto = null;
    SourceContext<Tuple4<Integer, Integer, String, String>> sourceContextGlobal = null;

    // hdfs文件路径
    String hdfs_file_path = null;
    // hdfs地址
    String hdfs_url = null;


    @Override
    public void open(Configuration parameters) throws Exception {
        System.setProperty("zookeeper.sasl.client", "false");
        ParameterTool parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig()
                .getGlobalJobParameters();
        ApisjMain.setConfig(parameterTool);
        cto = new CuratorOperator(zookeeperUrl);

    }

    private void nodeListen(NodeCache nodeCache, Integer label) throws Exception {
        nodeCache.start(true);
        if (nodeCache.getCurrentData() != null) {
            sourceContextGlobal.collect(new Tuple4<>(label, CommonConstants.OperateType.ADD.getVal(), zookeeperAppDiscoveryPath, new String(nodeCache.getCurrentData().getData())));
        }

        nodeCache.getListenable().addListener(new NodeCacheListener() {
            @Override
            public void nodeChanged() throws Exception {
                if (nodeCache.getCurrentData() != null) {
                    sourceContextGlobal.collect(new Tuple4<>(label, CommonConstants.OperateType.ADD.getVal(), zookeeperAppDiscoveryPath, new String(nodeCache.getCurrentData().getData())));
                }
            }
        });
    }

    private void childrenListen(PathChildrenCache pathChildrenCache, int type, String nodepath) throws Exception {
        pathChildrenCache.start(PathChildrenCache.StartMode.POST_INITIALIZED_EVENT);
        pathChildrenCache.getListenable().addListener(new PathChildrenCacheListener() {
            @Override
            public void childEvent(CuratorFramework curatorFramework, PathChildrenCacheEvent event) throws Exception {
                if (event.getType().equals(PathChildrenCacheEvent.Type.INITIALIZED)) {
                    logger.info("初始化zookeeper监听完成.........");
                } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_ADDED)) {
                    String path = event.getData().getPath();
                    if (path.startsWith(nodepath)) {
                        sourceContextGlobal.collect(new Tuple4<>(type, CommonConstants.OperateType.ADD.getVal(), path, new String(event.getData().getData())));
                        logger.info("create " + path + "----" + new String(event.getData().getData()));
                    }
                } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_REMOVED)) {
                    sourceContextGlobal.collect(new Tuple4<>(type, CommonConstants.OperateType.DELETE.getVal(), event.getData().getPath(), new String(event.getData().getData())));
                    logger.info("remove " + event.getData().getPath() + "----" + new String(event.getData().getData()));
                } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_UPDATED)) {
                    sourceContextGlobal.collect(new Tuple4<>(type, CommonConstants.OperateType.UPDATE.getVal(), event.getData().getPath(), new String(event.getData().getData())));
                    logger.info("update " + event.getData().getPath());
                }
            }
        });

    }

    @Override
    public void run(SourceContext<Tuple4<Integer, Integer, String, String>> sourceContext) throws Exception {
        sourceContextGlobal = sourceContext;

        final PathChildrenCache childrenCacheInterface = new PathChildrenCache(cto.client, zookeeperInterfaceDataPath, true);
        final PathChildrenCache childrenCacheApp = new PathChildrenCache(cto.client, zookeeperAppDataPath, true);
        final PathChildrenCache childrenSensitiveLabel = new PathChildrenCache(cto.client, zookeeperSensitiveLabelDataPath, true);

        final PathChildrenCache childrenBWList = new PathChildrenCache(cto.client, zookeeperBWListDataPath, true);

        final PathChildrenCache childrenUserDefine = new PathChildrenCache(cto.client, zookeeperUserDefineDataPath, true);

        final PathChildrenCache childrenRisk = new PathChildrenCache(cto.client, zookeeperRiskDataPath, true);

        final PathChildrenCache childrenStrategyConfig = new PathChildrenCache(cto.client, zookeeperStrategyConfigDataPath, true);

        //模型节点监听获取数据
        final NodeCache modelZkCfg = new NodeCache(cto.client, modelZkConfig);

        nodeListen(modelZkCfg, CommonConstants.ZkDataType.ASSO_RULE.getVal());



        //对zookeeper的接口的路径监听

        childrenListen(childrenCacheInterface, CommonConstants.ZkDataType.INTERFACE_TYPE.getVal(), zookeeperInterfaceDataPath);

        childrenListen(childrenCacheApp, CommonConstants.ZkDataType.APP_TYPE.getVal(), zookeeperAppDataPath);

        childrenListen(childrenSensitiveLabel, CommonConstants.ZkDataType.SENSITIVE_LABEL.getVal(), zookeeperSensitiveLabelDataPath);

        childrenListen(childrenBWList, CommonConstants.ZkDataType.BW_LIST_TYPE.getVal(), zookeeperBWListDataPath);

        childrenListen(childrenUserDefine, CommonConstants.ZkDataType.USER_DEFINE_TYPE.getVal(), zookeeperUserDefineDataPath);

        childrenListen(childrenRisk, CommonConstants.ZkDataType.RISK_TYPE.getVal(), zookeeperRiskDataPath);

        childrenListen(childrenStrategyConfig, CommonConstants.ZkDataType.STRATEGY_CONFIG.getVal(), zookeeperStrategyConfigDataPath);

        while (true) {
            Thread.sleep(50000);
        }
    }

    @Override
    public void cancel() {

    }
}
