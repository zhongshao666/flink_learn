package com.ssa.transformation;

import com.ssa.bean.OfflineData;
import com.ssa.sensitive.constants.CommonConstants;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.streaming.api.functions.co.BroadcastProcessFunction;
import org.apache.flink.util.Collector;

/**
 * @author : hld
 * @Date ： 2021/4/27
 * @Time : 15:11
 * @role ：
 */
public class AlgorithOutputTag extends BroadcastProcessFunction<OfflineData, Tuple4<Integer, Integer, String, String>, Tuple2<OfflineData, String>> {
    @Override
    public void processElement(OfflineData value, ReadOnlyContext ctx, Collector<Tuple2<OfflineData, String>> out) throws Exception {
        out.collect(new Tuple2<>(value, null));
    }

    @Override
    public void processBroadcastElement(Tuple4<Integer, Integer, String, String> value, Context ctx, Collector<Tuple2<OfflineData, String>> out) throws Exception {
        if (value.f0 == CommonConstants.ZkDataType.ASSO_RULE.getVal()){
            out.collect(new Tuple2<>(null, value.f3));
        }
    }
}
