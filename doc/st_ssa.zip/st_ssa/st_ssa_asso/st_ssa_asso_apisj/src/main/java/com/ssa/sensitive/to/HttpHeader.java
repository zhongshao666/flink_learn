package com.ssa.sensitive.to;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;


/**
 * @author qsj
 * @since 2021/1/20
 */
public class HttpHeader {
    private String accept;

    private String acceptEncoding;

    private String acceptLanguage;

    private String cacheControl;

    private String connection;

    private String contentType;

    private String contentLength;

    private String transferEncoding;

    private String contentEncoding;

    private String cookie;

    private String origin;

    private String host;

    private String pragma;

    private String referer;

    private String secFetchDest;

    private String secFetchMode;

    private String secFetchSite;

    private String secFetchUser;

    private String token;

    private String userAgent;

    private String xRequestedWith;

    private String xClientData;

    private String acceptRanges;

    private String contentSecurityPolicy;

    private String date;

    private String etag;

    private String server;

    private String expires;

    private String lastModified;

    private String setCookie;

    private String strictTransportSecurity;

    private String xcontentTypeOptions;

    private String frameOptions;

    private String xxssProtection;
    private Map<String, String> sourceMap;

    public Map<String, String> getSourceMap() {
        return sourceMap;
    }

    public void setSourceMap(Map<String, String> sourceMap) {
        this.sourceMap = sourceMap;
    }


    public HttpHeader() {
    }

    public HttpHeader(String strHeader) {
        Map<String, Consumer<String>> map = new HashMap<>();

        sourceMap = new HashMap<>();

        map.put("ACCEPT", this::setAccept);
        map.put("ACCEPT-ENCODING", this::setAcceptEncoding);
        map.put("ACCEPT-LANGUAGE", this::setAcceptLanguage);
        map.put("CACHE-CONTROL", this::setCacheControl);
        map.put("CONNECTION", this::setConnection);
        map.put("CONTENT-TYPE", this::setContentType);
        map.put("CONTENT-LENGTH", this::setContentLength);
        map.put("TRANSFER-ENCODING", this::setTransferEncoding);
        map.put("COOKIE", this::setCookie);
        map.put("ORIGIN", this::setOrigin);
        map.put("HOST", this::setHost);
        map.put("PRAGMA", this::setPragma);
        map.put("REFERER", this::setReferer);
        map.put("SEC-FETCH-DEST", this::setSecFetchDest);
        map.put("SEC-FETCH-SITE", this::setSecFetchSite);
        map.put("SEC-FETCH-USER", this::setSecFetchUser);
        map.put("SEC-FETCH-MODE", this::setSecFetchMode);
        map.put("TOKEN", this::setToken);
        map.put("USER-AGENT", this::setUserAgent);
        map.put("X-REQUESTED-WITH", this::setxRequestedWith);
        map.put("X-CLIENT-DATA", this::setxClientData);
        map.put("ACCEPT-RANGES", this::setAcceptRanges);
        map.put("CONTENT-SECURITY-POLICY", this::setContentSecurityPolicy);
        map.put("DATE", this::setDate);
        map.put("ETAG", this::setEtag);
        map.put("SERVER", this::setServer);
        map.put("EXPIRES", this::setExpires);
        map.put("LAST-MODIFIED", this::setLastModified);
        map.put("SET-COOKIE", this::setSetCookie);
        map.put("STRICT-TRANSPORT-SECURITY", this::setStrictTransportSecurity);
        map.put("X-CONTENT-TYPE-OPTIONS", this::setXcontentTypeOptions);
        map.put("FRAME-OPTIONS", this::setFrameOptions);
        map.put("X-XSS-PROTECTION", this::setXxssProtection);
        map.put("CONTENT-ENCODING", this::setContentEncoding);
        String[] arr = strHeader.split("\r\n");
        for (String kv : arr) {
            int i = kv.indexOf(":");
            if (i != -1) {
                String key = kv.substring(0, i)
                               .trim();
                String value = kv.substring(i + 1)
                                 .trim();

                Consumer<String> consumer = map.get(key.toUpperCase());
                if (consumer != null) {
                    consumer.accept(value);
                }

                sourceMap.put(key, value);
            }
        }
    }

    /**
     * 获取原始map
     *
     * @return
     */

    public String getAccept() {
        return accept;
    }

    public void setAccept(String accept) {
        this.accept = accept;
    }

    public String getAcceptEncoding() {
        return acceptEncoding;
    }

    public void setAcceptEncoding(String acceptEncoding) {
        this.acceptEncoding = acceptEncoding;
    }

    public String getAcceptLanguage() {
        return acceptLanguage;
    }

    public void setAcceptLanguage(String acceptLanguage) {
        this.acceptLanguage = acceptLanguage;
    }

    public String getCacheControl() {
        return cacheControl;
    }

    public void setCacheControl(String cacheControl) {
        this.cacheControl = cacheControl;
    }

    public String getConnection() {
        return connection;
    }

    public void setConnection(String connection) {
        this.connection = connection;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getContentLength() {
        return contentLength;
    }

    public void setContentLength(String contentLength) {
        this.contentLength = contentLength;
    }

    public String getTransferEncoding() {
        return transferEncoding;
    }

    public void setTransferEncoding(String transferEncoding) {
        this.transferEncoding = transferEncoding;
    }

    public String getCookie() {
        return cookie;
    }

    public void setCookie(String cookie) {
        this.cookie = cookie;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getPragma() {
        return pragma;
    }

    public void setPragma(String pragma) {
        this.pragma = pragma;
    }

    public String getReferer() {
        return referer;
    }

    public void setReferer(String referer) {
        this.referer = referer;
    }

    public String getSecFetchDest() {
        return secFetchDest;
    }

    public void setSecFetchDest(String secFetchDest) {
        this.secFetchDest = secFetchDest;
    }

    public String getSecFetchMode() {
        return secFetchMode;
    }

    public void setSecFetchMode(String secFetchMode) {
        this.secFetchMode = secFetchMode;
    }

    public String getSecFetchSite() {
        return secFetchSite;
    }

    public void setSecFetchSite(String secFetchSite) {
        this.secFetchSite = secFetchSite;
    }

    public String getSecFetchUser() {
        return secFetchUser;
    }

    public void setSecFetchUser(String secFetchUser) {
        this.secFetchUser = secFetchUser;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUserAgent() {
        return userAgent;
    }

    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }

    public String getxRequestedWith() {
        return xRequestedWith;
    }

    public void setxRequestedWith(String xRequestedWith) {
        this.xRequestedWith = xRequestedWith;
    }

    public String getxClientData() {
        return xClientData;
    }

    public void setxClientData(String xClientData) {
        this.xClientData = xClientData;
    }

    public String getAcceptRanges() {
        return acceptRanges;
    }

    public void setAcceptRanges(String acceptRanges) {
        this.acceptRanges = acceptRanges;
    }

    public String getContentSecurityPolicy() {
        return contentSecurityPolicy;
    }

    public void setContentSecurityPolicy(String contentSecurityPolicy) {
        this.contentSecurityPolicy = contentSecurityPolicy;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getEtag() {
        return etag;
    }

    public void setEtag(String etag) {
        this.etag = etag;
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }

    public String getExpires() {
        return expires;
    }

    public void setExpires(String expires) {
        this.expires = expires;
    }

    public String getLastModified() {
        return lastModified;
    }

    public void setLastModified(String lastModified) {
        this.lastModified = lastModified;
    }

    public String getSetCookie() {
        return setCookie;
    }

    public void setSetCookie(String setCookie) {
        this.setCookie = setCookie;
    }

    public String getStrictTransportSecurity() {
        return strictTransportSecurity;
    }

    public void setStrictTransportSecurity(String strictTransportSecurity) {
        this.strictTransportSecurity = strictTransportSecurity;
    }

    public String getXcontentTypeOptions() {
        return xcontentTypeOptions;
    }

    public void setXcontentTypeOptions(String xcontentTypeOptions) {
        this.xcontentTypeOptions = xcontentTypeOptions;
    }

    public String getFrameOptions() {
        return frameOptions;
    }

    public void setFrameOptions(String frameOptions) {
        this.frameOptions = frameOptions;
    }

    public String getXxssProtection() {
        return xxssProtection;
    }

    public void setXxssProtection(String xxssProtection) {
        this.xxssProtection = xxssProtection;
    }

    public String getContentEncoding() {
        return contentEncoding;
    }

    public void setContentEncoding(String contentEncoding) {
        this.contentEncoding = contentEncoding;
    }
}
