package com.ssa.modelBean;

import java.util.HashMap;

/**
 * @author : hld
 * @Date ： 2021/4/21
 * @Time : 19:23
 * @role ：
 */
public class ModelBean {
    /**
     * pst条件概率
     */
    private HashMap<String, HashMap<String, Double>> pstMap;
    /**
     * 基线
     */
    private HashMap<String, Double> baselineMap;
    /**
     * 事件符号映射
     */
    private HashMap<String, String> eventSymbolMap;

    private String eventKey;

    private Integer pstDepth;
    private Double pstThd;

    private String timeKey;

    private String objectKey;


    public ModelBean() {
    }

    public HashMap<String, HashMap<String, Double>> getPstMap() {
        return pstMap;
    }

    public void setPstMap(HashMap<String, HashMap<String, Double>> pstMap) {
        this.pstMap = pstMap;
    }

    public String getEventKey() {
        return eventKey;
    }

    public void setEventKey(String eventKey) {
        this.eventKey = eventKey;
    }

    public HashMap<String, Double> getBaselineMap() {
        return baselineMap;
    }

    public void setBaselineMap(HashMap<String, Double> baselineMap) {
        this.baselineMap = baselineMap;
    }

    public HashMap<String, String> getEventSymbolMap() {
        return eventSymbolMap;
    }

    public void setEventSymbolMap(HashMap<String, String> eventSymbolMap) {
        this.eventSymbolMap = eventSymbolMap;
    }

    public Integer getPstDepth() {
        return pstDepth;
    }

    public void setPstDepth(Integer pstDepth) {
        this.pstDepth = pstDepth;
    }

    public Double getPstThd() {
        return pstThd;
    }

    public void setPstThd(Double pstThd) {
        this.pstThd = pstThd;
    }

    public String getObjectKey() {
        return objectKey;
    }

    public void setObjectKey(String objectKey) {
        this.objectKey = objectKey;
    }

    public String getTimeKey() {
        return timeKey;
    }

    public void setTimeKey(String timeKey) {
        this.timeKey = timeKey;
    }
}
