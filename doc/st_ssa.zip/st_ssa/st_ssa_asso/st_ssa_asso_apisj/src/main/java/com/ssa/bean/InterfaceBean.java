package com.ssa.bean;

import com.secsmart.sensitive.AlgInfo;

import java.util.List;

public class InterfaceBean {
    private Long id;
    private String url;
    private String name;
    private String ip;
    private String port;
    /**
     * 1-普通接口,2-附件接口,3-登录接口
     */
    private List<Integer> types;

    /**
     * 是否敏感接口
     */
    private Boolean sensitiveFlag;
    private String groupId;
    /**
     * 账号参数名
     */
    private String accountParam;
    /**
     * 参数位置 1-请求头,2-cookie,3-请求内容
     */
    private String accountLocation;
    private String pwdParam;
    /**
     * 参数位置 1-请求头,2-cookie,3-请求内容
     */
    private String pwdLocation;
    private String reqSessionidParam;
    /**
     * 参数位置 1-请求头,2-cookie,3-请求内容
     */
    private String reqSessionidLocation;
    private String resSessionidParam;
    /**
     * 参数位置 1-请求头,2-cookie,3-请求内容
     */
    private String resSessionidLocation;

    /**
     * sessionId参数名
     */
    private Long appId;
    /**
     * 请求头需要识别的敏感数据类型列表
     */
    private List<AlgInfo> reqHeaderSensitives;
    /**
     * 请求体需要识别的敏感数据类型列表
     */
    private List<AlgInfo> reqBodySensitives;
    /**
     * 响应头需要识别的敏感数据类型列表
     */
    private List<AlgInfo> resHeaderSensitives;
    /**
     * 响应体需要识别的敏感数据类型列表
     */
    private List<AlgInfo> resBodySensitives;

    /**
     * 是否启用 1-启用,0-不启用
     */
    private String enable;

    /**
     * 是否记录全部信息
     */
    private Boolean isFullText;

    /**
     * 请求方法 GET\POST
     */
    private String method;

    /**
     * 已经识别的敏感数据
     */
    private List<String> markedSensitives;

    /**
     * 域名
     */
    private String domain;

    /**
     * 请求头发现的敏感数据
     */
    private List<String> reqHeaderSensitiveLabels;

    /**
     * 请求体发现的敏感数据
     */
    private List<String> reqBodySensitiveLabels;

    /**
     * 响应头发现的敏感数据
     */
    private List<String> resHeaderSensitiveLabels;

    /**
     * 响应体发现的敏感数据
     */
    private List<String> resBodySensitiveLabels;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public List<Integer> getTypes() {
        return types;
    }

    public void setTypes(List<Integer> types) {
        this.types = types;
    }

    public Boolean getSensitiveFlag() {
        return sensitiveFlag;
    }

    public void setSensitiveFlag(Boolean sensitiveFlag) {
        this.sensitiveFlag = sensitiveFlag;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getAccountParam() {
        return accountParam;
    }

    public void setAccountParam(String accountParam) {
        this.accountParam = accountParam;
    }

    public String getAccountLocation() {
        return accountLocation;
    }

    public void setAccountLocation(String accountLocation) {
        this.accountLocation = accountLocation;
    }

    public Long getAppId() {
        return appId;
    }

    public void setAppId(Long appId) {
        this.appId = appId;
    }

    public List<AlgInfo> getReqHeaderSensitives() {
        return reqHeaderSensitives;
    }

    public void setReqHeaderSensitives(List<AlgInfo> reqHeaderSensitives) {
        this.reqHeaderSensitives = reqHeaderSensitives;
    }

    public List<AlgInfo> getReqBodySensitives() {
        return reqBodySensitives;
    }

    public void setReqBodySensitives(List<AlgInfo> reqBodySensitives) {
        this.reqBodySensitives = reqBodySensitives;
    }

    public List<AlgInfo> getResHeaderSensitives() {
        return resHeaderSensitives;
    }

    public void setResHeaderSensitives(List<AlgInfo> resHeaderSensitives) {
        this.resHeaderSensitives = resHeaderSensitives;
    }

    public List<AlgInfo> getResBodySensitives() {
        return resBodySensitives;
    }

    public void setResBodySensitives(List<AlgInfo> resBodySensitives) {
        this.resBodySensitives = resBodySensitives;
    }

    public String getPwdParam() {
        return pwdParam;
    }

    public void setPwdParam(String pwdParam) {
        this.pwdParam = pwdParam;
    }

    public String getPwdLocation() {
        return pwdLocation;
    }

    public void setPwdLocation(String pwdLocation) {
        this.pwdLocation = pwdLocation;
    }

    public String getReqSessionidParam() {
        return reqSessionidParam;
    }

    public void setReqSessionidParam(String reqSessionidParam) {
        this.reqSessionidParam = reqSessionidParam;
    }

    public String getReqSessionidLocation() {
        return reqSessionidLocation;
    }

    public void setReqSessionidLocation(String reqSessionidLocation) {
        this.reqSessionidLocation = reqSessionidLocation;
    }

    public String getResSessionidParam() {
        return resSessionidParam;
    }

    public void setResSessionidParam(String resSessionidParam) {
        this.resSessionidParam = resSessionidParam;
    }

    public String getResSessionidLocation() {
        return resSessionidLocation;
    }

    public void setResSessionidLocation(String resSessionidLocation) {
        this.resSessionidLocation = resSessionidLocation;
    }

    public String getEnable() {
        return enable;
    }

    public void setEnable(String enable) {
        this.enable = enable;
    }

    public Boolean getFullText() {
        return isFullText;
    }

    public void setFullText(Boolean fullText) {
        isFullText = fullText;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public List<String> getMarkedSensitives() {
        return markedSensitives;
    }

    public void setMarkedSensitives(List<String> markedSensitives) {
        this.markedSensitives = markedSensitives;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public List<String> getReqHeaderSensitiveLabels() {
        return reqHeaderSensitiveLabels;
    }

    public void setReqHeaderSensitiveLabels(List<String> reqHeaderSensitiveLabels) {
        this.reqHeaderSensitiveLabels = reqHeaderSensitiveLabels;
    }

    public List<String> getReqBodySensitiveLabels() {
        return reqBodySensitiveLabels;
    }

    public void setReqBodySensitiveLabels(List<String> reqBodySensitiveLabels) {
        this.reqBodySensitiveLabels = reqBodySensitiveLabels;
    }

    public List<String> getResHeaderSensitiveLabels() {
        return resHeaderSensitiveLabels;
    }

    public void setResHeaderSensitiveLabels(List<String> resHeaderSensitiveLabels) {
        this.resHeaderSensitiveLabels = resHeaderSensitiveLabels;
    }

    public List<String> getResBodySensitiveLabels() {
        return resBodySensitiveLabels;
    }

    public void setResBodySensitiveLabels(List<String> resBodySensitiveLabels) {
        this.resBodySensitiveLabels = resBodySensitiveLabels;
    }
}
