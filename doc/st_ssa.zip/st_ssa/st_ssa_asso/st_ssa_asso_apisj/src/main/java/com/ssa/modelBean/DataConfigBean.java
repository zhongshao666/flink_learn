package com.ssa.modelBean;

/**
 * @author : hld
 * @Date ： 2021/4/27
 * @Time : 10:16
 * @role ：
 */
public class DataConfigBean {
    /**
     * max_time_interval : 10
     * min_time_interval : 1
     * ratio : 0.7
     * group_length : 30
     * group_thd : 10
     * anomaly_thd : 0.01
     * baseline_thd : 75
     */

    private String max_time_interval;
    private String min_time_interval;
    private String ratio;
    private String group_length;
    private String group_thd;
    private String anomaly_thd;
    private String baseline_thd;

    public String getMax_time_interval() {
        return max_time_interval;
    }

    public void setMax_time_interval(String max_time_interval) {
        this.max_time_interval = max_time_interval;
    }

    public String getMin_time_interval() {
        return min_time_interval;
    }

    public void setMin_time_interval(String min_time_interval) {
        this.min_time_interval = min_time_interval;
    }

    public String getRatio() {
        return ratio;
    }

    public void setRatio(String ratio) {
        this.ratio = ratio;
    }

    public String getGroup_length() {
        return group_length;
    }

    public void setGroup_length(String group_length) {
        this.group_length = group_length;
    }

    public String getGroup_thd() {
        return group_thd;
    }

    public void setGroup_thd(String group_thd) {
        this.group_thd = group_thd;
    }

    public String getAnomaly_thd() {
        return anomaly_thd;
    }

    public void setAnomaly_thd(String anomaly_thd) {
        this.anomaly_thd = anomaly_thd;
    }

    public String getBaseline_thd() {
        return baseline_thd;
    }

    public void setBaseline_thd(String baseline_thd) {
        this.baseline_thd = baseline_thd;
    }
}
