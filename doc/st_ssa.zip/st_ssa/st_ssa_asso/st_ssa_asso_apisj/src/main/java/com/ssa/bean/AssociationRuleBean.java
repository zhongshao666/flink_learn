package com.ssa.bean;

/**
 * @author : hld
 * @Date ： 2021/4/28
 * @Time : 15:14
 * @role ：
 */
public class AssociationRuleBean {
    private Double recordThreshold;
    private Double abnormalThreshold;

    {
        recordThreshold = 0.001;
        abnormalThreshold = 0.2;
    }

    public AssociationRuleBean() {
    }

    public AssociationRuleBean(Double recoredThreshold, Double abnormalThreshold) {
        this.recordThreshold = recoredThreshold;
        this.abnormalThreshold = abnormalThreshold;
    }

    public Double getRecordThreshold() {
        return recordThreshold;
    }

    public void setRecordThreshold(Double recordThreshold) {
        this.recordThreshold = recordThreshold;
    }

    public Double getAbnormalThreshold() {
        return abnormalThreshold;
    }

    public void setAbnormalThreshold(Double abnormalThreshold) {
        this.abnormalThreshold = abnormalThreshold;
    }
}
