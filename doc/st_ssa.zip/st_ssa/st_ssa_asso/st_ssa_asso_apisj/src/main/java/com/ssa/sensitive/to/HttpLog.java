package com.ssa.sensitive.to;

import java.util.List;
import java.util.Map;

/**
 * @author qsj
 * @since 2021/1/13
 */
public class HttpLog {

    /**
     * 请求时间:时间戳 ms
     */
    private Long requestTime;

    /**
     * 耗时 ms
     */
    private Long costTime;

    /**
     * 会话ID (sessionID,token)
     */
    private String sessionId;

    /**
     * host 名称
     */
    private String hostName;

    /**
     * 请求方法
     */
    private String httpMethod;

    /**
     * 请求URL
     */
    private String requestUrl;

    /**
     * http版本
     */
    private String httpVersion;

    /**
     * 状态码
     */
    private Integer statusCode;

    /**
     * 状态消息
     */
    private String statusMsg;

    /**
     * 客户端mac
     */
    private String clientMac;

    /**
     * 客户端ip
     */
    private String clientIp;

    /**
     * 客户端端口
     */
    private String clientPort;

    /**
     * 服务端mac
     */
    private String serverMac;

    /**
     * 服务端IP
     */
    private String serverIp;

    /**
     * 服务器端口
     */
    private String serverPort;

    /**
     * 请求头
     */
    private String requestHeader;

    /**
     * 请求体
     */
    private String requestBody;

    /**
     * 响应头
     */
    private String responseHeader;

    /**
     * 响应体
     */
    private String responseBody;

    /**
     * 请求流量大小 单位b
     */
    private Long httpTraffic;

    /**
     * 请求头对象
     */
    private HttpHeader reqHeader;
    /**
     * 响应头对象
     */
    private HttpHeader resHeader;
    /**
     * 用户名
     */
    private String userName;

    /**
     * 应用ID
     */
    private Long appId;

    /**
     * 应用名称
     */
    private String appName;

    /**
     * 应用域名
     */
    private String appDomain;

    /**
     * 接口ID
     */
    private Long interfaceId;

    /**
     * 接口名称
     */
    private String interfaceName;

    /**
     * 接口URL
     */
    private String interfaceUrl;

    /**
     * 是否新接口
     */
    private Boolean isnewInterface;

    /**
     * 是否新用户
     */
    private Boolean isnewUser;

    /**
     * 日志ID
     */
    private Long logId;

    /**
     * 创建时间
     */
    private Long createTime;
    /**
     * 是否包含敏感数据
     */
    private Boolean hasSensitive;
    /**
     * 1-登录事件,2-访问事件
     */
    private Integer eventType;
    /**
     * 敏感数据标签列表
     */
    private String sensitiveLabelField;
    /**
     * 敏感数据记录
     */
    private List<CkHttpSensitiveRecord> sensitiveRecords;
    /**
     * 原始敏感记录
     */
    private Map<Integer, Map<String, String>> sourceSensitiveMap;

    /**
     * 敏感等级
     */
    private String sensitiveLevel;

    /**
     * 请求状态，（status_code首位数字）
     */
    private Integer requestStatus;

    /**
     * 审阅状态
     */
    private boolean reviewed;

    /**
     * 审阅意见
     */
    private String reviewedComment;

    /**
     * 客户端工具
     */
    private String clientTool;

    /**
     * 风险类型
     */
    private String riskType;

    /**
     * 风险等级
     */
    private Integer riskLevel;

    /**
     * 策略名称
     */
    private String strategyName;

    /**
     * 策略id
     */
    private String strategyId;
    /**
     *模型标签
     */
    private Integer isModelLabel;
    /**
     * 设置具体请求
     * @param i
     * @param val
     */
    public void setIndex(int i, String val) {
        switch (i) {
            case 0:
                setRequestTime(Long.parseLong(val));
                break;
            case 1:
                setCostTime(Long.parseLong(val));
                break;
            case 2:
                setSessionId(val);
                break;
            case 3:
                setHostName(val);
                break;
            case 4:
                setHttpMethod(val);
                break;
            case 5:
                setRequestUrl(val);
                break;
            case 6:
                setHttpVersion(val);
                break;
            case 7:
                setStatusCode(Integer.parseInt(val));
                break;
            case 8:
                setStatusMsg(val);
                break;

            case 9:
                setClientMac(val);
                break;
            case 10:
                setClientIp(val);
                break;
            case 11:
                setClientPort(val);
                break;
            case 12:
                setServerMac(val);
                break;
            case 13:
                setServerIp(val);
                break;
            case 14:
                setServerPort(val);
                break;
            case 15:
                setRequestHeader(val);
                break;
            case 16:
                setRequestBody(val);
                break;
            case 17:
                setResponseHeader(val);
                break;
            case 18:
                setResponseBody(val);
                break;
            case 19:
                setHttpTraffic(Long.parseLong(val));
                break;
            default:
                throw new RuntimeException("暂不支持该参数,index:%s,val:%s");
        }
    }


    public void setIsnewInterface(Boolean isnewInterface) {
        this.isnewInterface = isnewInterface;
    }

    public void setIsnewUser(Boolean isnewUser) {
        this.isnewUser = isnewUser;
    }

    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    public Long getLogId() {
        return logId;
    }

    public void setLogId(Long logId) {
        this.logId = logId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Long getAppId() {
        return appId;
    }

    public void setAppId(Long appId) {
        this.appId = appId;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppDomain() {
        return appDomain;
    }

    public void setAppDomain(String appDomain) {
        this.appDomain = appDomain;
    }

    public Long getInterfaceId() {
        return interfaceId;
    }

    public void setInterfaceId(Long interfaceId) {
        this.interfaceId = interfaceId;
    }

    public String getInterfaceName() {
        return interfaceName;
    }

    public void setInterfaceName(String interfaceName) {
        this.interfaceName = interfaceName;
    }

    public String getInterfaceUrl() {
        return interfaceUrl;
    }

    public void setInterfaceUrl(String interfaceUrl) {
        this.interfaceUrl = interfaceUrl;
    }

    public Boolean getHasSensitive() {
        return hasSensitive;
    }

    public void setHasSensitive(Boolean hasSensitive) {
        this.hasSensitive = hasSensitive;
    }

    public Integer getEventType() {
        return eventType;
    }

    public void setEventType(Integer eventType) {
        this.eventType = eventType;
    }

    public String getSensitiveLabelField() {
        return sensitiveLabelField;
    }

    public void setSensitiveLabelField(String sensitiveLabelField) {
        this.sensitiveLabelField = sensitiveLabelField;
    }

    public List<CkHttpSensitiveRecord> getSensitiveRecords() {
        return sensitiveRecords;
    }

    public void setSensitiveRecords(List<CkHttpSensitiveRecord> sensitiveRecords) {
        this.sensitiveRecords = sensitiveRecords;
    }

    public HttpHeader getReqHeader() {
        return reqHeader;
    }

    public void setReqHeader(HttpHeader reqHeader) {
        this.reqHeader = reqHeader;
    }

    public HttpHeader getResHeader() {
        return resHeader;
    }

    public void setResHeader(HttpHeader resHeader) {
        this.resHeader = resHeader;
    }

    public Long getRequestTime() {
        return requestTime;
    }

    public void setRequestTime(Long requestTime) {
        this.requestTime = requestTime;
    }

    public Long getCostTime() {
        return costTime;
    }

    public void setCostTime(Long costTime) {
        this.costTime = costTime;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getHostName() {
        return hostName;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    public String getRequestUrl() {
        return requestUrl;
    }

    public void setRequestUrl(String requestUrl) {
        this.requestUrl = requestUrl;
    }

    public String getClientMac() {
        return clientMac;
    }

    public void setClientMac(String clientMac) {
        this.clientMac = clientMac;
    }

    public String getClientIp() {
        return clientIp;
    }

    public void setClientIp(String clientIp) {
        this.clientIp = clientIp;
    }

    public String getClientPort() {
        return clientPort;
    }

    public void setClientPort(String clientPort) {
        this.clientPort = clientPort;
    }

    public String getServerMac() {
        return serverMac;
    }

    public void setServerMac(String serverMac) {
        this.serverMac = serverMac;
    }

    public String getServerIp() {
        return serverIp;
    }

    public void setServerIp(String serverIp) {
        this.serverIp = serverIp;
    }

    public String getServerPort() {
        return serverPort;
    }

    public void setServerPort(String serverPort) {
        this.serverPort = serverPort;
    }

    public String getRequestHeader() {
        return requestHeader;
    }

    public void setRequestHeader(String requestHeader) {
        this.requestHeader = requestHeader;
    }

    public String getRequestBody() {
        return requestBody;
    }

    public void setRequestBody(String requestBody) {
        this.requestBody = requestBody;
    }

    public String getResponseHeader() {
        return responseHeader;
    }

    public void setResponseHeader(String responseHeader) {
        this.responseHeader = responseHeader;
    }

    public String getResponseBody() {
        return responseBody;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }


    public String getHttpMethod() {
        return httpMethod;
    }

    public void setHttpMethod(String httpMethod) {
        this.httpMethod = httpMethod;
    }

    public String getHttpVersion() {
        return httpVersion;
    }

    public void setHttpVersion(String httpVersion) {
        this.httpVersion = httpVersion;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusMsg() {
        return statusMsg;
    }

    public void setStatusMsg(String statusMsg) {
        this.statusMsg = statusMsg;
    }

    public Boolean getIsnewInterface() {
        return isnewInterface;
    }

    public void setIsnewInterface(boolean isnewInterface) {
        this.isnewInterface = isnewInterface;
    }

    public Boolean getIsnewUser() {
        return isnewUser;
    }

    public void setIsnewUser(boolean isnewUser) {
        this.isnewUser = isnewUser;
    }

    public Map<Integer, Map<String, String>> getSourceSensitiveMap() {
        return sourceSensitiveMap;
    }

    public void setSourceSensitiveMap(Map<Integer, Map<String, String>> sourceSensitiveMap) {
        this.sourceSensitiveMap = sourceSensitiveMap;
    }

    public String getSensitiveLevel() {
        return sensitiveLevel;
    }

    public void setSensitiveLevel(String sensitiveLevel) {
        this.sensitiveLevel = sensitiveLevel;
    }

    public Integer getRequestStatus() {
        return requestStatus;
    }

    public void setRequestStatus(Integer requestStatus) {
        this.requestStatus = requestStatus;
    }

    public boolean isReviewed() {
        return reviewed;
    }

    public void setReviewed(boolean reviewed) {
        this.reviewed = reviewed;
    }

    public String getReviewedComment() {
        return reviewedComment;
    }

    public void setReviewedComment(String reviewedComment) {
        this.reviewedComment = reviewedComment;
    }

    public String getClientTool() {
        return clientTool;
    }

    public void setClientTool(String clientTool) {
        this.clientTool = clientTool;
    }

    public String getRiskType() {
        return riskType;
    }

    public void setRiskType(String riskType) {
        this.riskType = riskType;
    }

    public Integer getRiskLevel() {
        return riskLevel;
    }


    public void setRiskLevel(Integer riskLevel) {
        this.riskLevel = riskLevel;
    }

    public String getStrategyName() {
        return strategyName;
    }

    public void setStrategyName(String strategyName) {
        this.strategyName = strategyName;
    }

    public String getStrategyId() {
        return strategyId;
    }

    public void setStrategyId(String strategyId) {
        this.strategyId = strategyId;
    }

    public Long getHttpTraffic() {
        return httpTraffic;
    }

    public void setHttpTraffic(Long httpTraffic) {
        this.httpTraffic = httpTraffic;
    }

    public Integer getIsModelLabel() {
        return isModelLabel;
    }

    public void setIsModelLabel(Integer isModelLabel) {
        this.isModelLabel = isModelLabel;
    }
}
