package com.ssa.modelBean;

/**
 * @author : hld
 * @Date ： 2021/4/27
 * @Time : 10:15
 * @role ：
 */
public class PstConfigBean {
    /**
     * c : 0
     * k : 0.001
     * l : 3
     * p : 0.00001
     * r : 1.05
     */

    private String c;
    private String k;
    private String l;
    private String p;
    private String r;

    public String getC() {
        return c;
    }

    public void setC(String c) {
        this.c = c;
    }

    public String getK() {
        return k;
    }

    public void setK(String k) {
        this.k = k;
    }

    public String getL() {
        return l;
    }

    public void setL(String l) {
        this.l = l;
    }

    public String getP() {
        return p;
    }

    public void setP(String p) {
        this.p = p;
    }

    public String getR() {
        return r;
    }

    public void setR(String r) {
        this.r = r;
    }
}
