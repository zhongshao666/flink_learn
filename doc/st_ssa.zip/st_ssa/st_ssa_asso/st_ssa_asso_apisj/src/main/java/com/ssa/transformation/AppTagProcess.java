package com.ssa.transformation;

import com.alibaba.fastjson.JSON;
import com.ssa.ApisjMain;
import com.ssa.bean.AppBean;
import com.ssa.bean.IpBean;
import com.ssa.bean.IpPortBean;
import com.ssa.bean.PortBean;
import com.ssa.sensitive.constants.CommonConstants;
import com.ssa.sensitive.parse.HttpLogParse;
import com.ssa.sensitive.to.HttpLog;
import com.ssa.sensitive.util.IdWorker;
import com.ssa.utils.IPUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.BroadcastProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.util.*;

import static com.ssa.sensitive.constants.CommonConstants.*;


/**
 * @author admin
 */
public class AppTagProcess extends BroadcastProcessFunction<String, Tuple4<Integer, Integer, String, String>, HttpLog> {

    private static final Logger logger = LoggerFactory.getLogger(AppTagProcess.class);
    Map<String, AppBean> appBeanMap;
    Map<String, String> appIdDomainMap;
    List<IpBean> ipBeanList;
    List<PortBean> portBeanList;
    boolean logKafkaMsg;

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        appBeanMap = new HashMap<>();
        appIdDomainMap = new HashMap<>();
        ipBeanList = new ArrayList<>();
        portBeanList = new ArrayList<>();

        ParameterTool parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig()
                                                                         .getGlobalJobParameters();
        String logKafkaMsgSource = parameterTool.get("logKafkaMsg");
        logKafkaMsg = logKafkaMsgSource != null;
    }

    @Override
    public void processElement(String info, ReadOnlyContext readOnlyContext, Collector<HttpLog> collector) throws Exception {
        long logId = IdWorker.getInstance()
                             .nextId();
        if (logKafkaMsg) {
            logger.info("begin handle data logId:{} , source data: {}", logId, info);
        }

        HttpLog httpLog = HttpLogParse.streamParse(new ByteArrayInputStream(info.getBytes()), logId);
        if (Objects.isNull(httpLog)) {
            logger.error("http log data logId:{},source data:{} parse error not go on!", logId, info);
            return;
        }
        logger.info("http log data logId:{},requestUrl:{},serverIp:{},serverPort:{},clientIp:{},clientPort:{},costTime:{}", httpLog.getLogId(), httpLog.getRequestUrl(), httpLog.getServerIp(), httpLog.getServerPort(), httpLog.getClientIp(), httpLog.getClientPort(), httpLog.getCostTime());

        AppBean appBean = appBeanMap.get(httpLog.getHostName());
        if (appBean != null) {
            logger.info("http log logId:{},belong app:{},name:{}", httpLog.getLogId(), appBean.getId(), appBean.getName());
            if (Status.ENABLE.getVal()
                                             .equals(appBean.getEnable())) {
                httpLog.setAppId(Long.valueOf(appBean.getId()));
                httpLog.setAppName(appBean.getName());
                collector.collect(httpLog);
            } else {
                logger.info("http log logId:{},belong app:{},app not enable ", httpLog.getLogId(), appBean.getId());
            }
        } else {
            //是否是监控的应用范围
            if (isNewApp(httpLog)) {
                logger.info("http log logId:{},match discovery app {}:{}", httpLog.getLogId(), httpLog.getServerIp(), httpLog.getServerPort());
                readOnlyContext.output(ApisjMain.apptags, httpLog);
            } else {
                logger.info("http log logId:{} cannot find app,please add or discovery", httpLog.getLogId());
            }
        }
    }

    @Override
    public void processBroadcastElement(Tuple4<Integer, Integer, String, String> integerIntegerStringStringTuple4, Context context, Collector<HttpLog> collector) throws Exception {

        if (integerIntegerStringStringTuple4.f0 == ZkDataType.APP_TYPE.getVal()) {
            initAppBeanMap(integerIntegerStringStringTuple4.f1, integerIntegerStringStringTuple4.f3);
        } else if (integerIntegerStringStringTuple4.f0 == ZkDataType.DISCOVERY_TYPE.getVal()) {
            initIpPortBeanMap(integerIntegerStringStringTuple4.f3);
        }
    }


    private void initIpPortBeanMap(String data) {
        ipBeanList.clear();
        portBeanList.clear();
        try {
            IpPortBean ipPortBean = JSON.parseObject(data, IpPortBean.class);
            initIpAndPortBeans(ipPortBean);
        } catch (Exception e) {
            logger.error(data + "parse error", e);
            ipBeanList.clear();
            portBeanList.clear();
        }
    }

    private void initAppBeanMap(int operateType, String data) {
        AppBean appBean = null;
        try {
            logger.info("integerIntegerStringStringTuple4 f3 value: {}", data);
            appBean = JSON.parseObject(data, AppBean.class);
        } catch (Exception e) {
            logger.error("Zookeeper parse 出错！！！", e);
            return;
        }
        if (operateType == OperateType.ADD.getVal() || operateType == OperateType.UPDATE.getVal()) {
            appBeanMap.put(appBean.getDomain(), appBean);
            appIdDomainMap.put(appBean.getId(), appBean.getDomain());
        } else if (operateType == OperateType.DELETE.getVal()) {
            final String appId = appBean.getId();
            String domain = appIdDomainMap.get(appId);
            Optional.ofNullable(domain)
                    .ifPresent(item -> {
                        appBeanMap.remove(item);
                        appIdDomainMap.remove(appId);
                    });

        }

    }

    private void initIpAndPortBeans(IpPortBean ipPortBean) {
        String[] ports = ipPortBean.getPorts()
                                   .split(CSV_SPLIT_CHAR);
        String[] ips = ipPortBean.getIp()
                                 .split(CSV_SPLIT_CHAR);

        for (String port : ports) {
            if (port.contains(ZONE_SPLIT_CHAR)) {
                String[] startAndEndPort = port.split(ZONE_SPLIT_CHAR);
                portBeanList.add(new PortBean(Integer.valueOf(startAndEndPort[0]), Integer.valueOf(startAndEndPort[1])));
            } else {
                portBeanList.add(new PortBean(Integer.valueOf(port)));
            }

        }
        for (String ip : ips) {
            if (ip.contains(ZONE_SPLIT_CHAR)) {
                String[] startAndEndIp = ip.split(ZONE_SPLIT_CHAR);
                ipBeanList.add(new IpBean(IPUtils.ip2Long(startAndEndIp[0]), IPUtils.ip2Long(startAndEndIp[1])));
            } else {
                ipBeanList.add(new IpBean(ip));
            }

        }
    }

    private Boolean isNewApp(HttpLog httpLog) {
        return (getPortFlag(httpLog.getServerPort()) && getIpFlag(httpLog.getServerIp()));
    }

    private boolean getIpFlag(String serverIp) {
        if (StringUtils.isBlank(serverIp)) {
            return false;
        }
        if (serverIp.contains(IPV6_SPLIT_CHAR)) {
            logger.warn("Server IP 格式为ipv6，暂不处理，ip为：{}", serverIp);
            return false;
        }
        long ipLong = IPUtils.ip2Long(serverIp);
        for (IpBean ipbean : ipBeanList) {
            if (ipbean.getSelfip() != null) {
                if (ipbean.getSelfip()
                          .equals(serverIp)) {
                    return true;
                }
            } else {
                if (ipLong <= ipbean.getEndip() && ipLong >= ipbean.getStartip()) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean getPortFlag(String stringServerPort) {
        if (StringUtils.isBlank(stringServerPort)) {
            return false;
        }

        Integer serverPort = Integer.valueOf(stringServerPort);
        for (PortBean portbean : portBeanList) {
            if (portbean.getSelfport() != null && portbean.getSelfport()
                                                          .equals(serverPort)) {
                return true;
            }

            if (Objects.nonNull(portbean.getStartport()) && Objects.nonNull(portbean.getEndport()) && serverPort >= portbean.getStartport() && serverPort <= portbean.getEndport()) {
                return true;
            }
        }

        return false;
    }
}
