package com.ssa.modelBean;

/**
 * @author : hld
 * @Date ： 2021/4/27
 * @Time : 10:14
 * @role ：
 */
public class CkConfigBean {
    /**
     * host : 192.168.18.73
     * port : 9999
     * user : default
     * password : 123456
     * database : ods_st_ssa
     * table : ods_id_dbsj_secsmart_audit_log_asset_log
     */

    private String host;
    private String port;
    private String user;
    private String password;
    private String database;
    private String table;

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDatabase() {
        return database;
    }

    public void setDatabase(String database) {
        this.database = database;
    }

    public String getTable() {
        return table;
    }

    public void setTable(String table) {
        this.table = table;
    }
}
