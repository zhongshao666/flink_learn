package com.ssa.source;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ssa.ApisjMain;
import com.ssa.bean.OfflineData;
import com.ssa.utils.CuratorOperator;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.CuratorFramework;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.recipes.cache.PathChildrenCache;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.recipes.cache.PathChildrenCacheEvent;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.recipes.cache.PathChildrenCacheListener;
import org.apache.flink.streaming.api.functions.source.RichSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import static com.ssa.sensitive.util.SystemConfig.*;

/**
 * @author Administrator
 * @sole ClickHouseZk离线数据源
 */
public class ClickHouseZkSource extends RichSourceFunction<OfflineData> {

    private static final Logger logger = LoggerFactory.getLogger(ClickHouseZkSource.class);
    CuratorOperator curatorOperator = null;
    SourceContext<OfflineData> sourceContext = null;

    @Override
    public void open(Configuration parameters) throws Exception {
        ParameterTool parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig()
                .getGlobalJobParameters();
        ApisjMain.setConfig(parameterTool);
        curatorOperator = new CuratorOperator(zookeeperUrl);
        Class.forName("ru.yandex.clickhouse.ClickHouseDriver");
    }

    @Override
    public void run(SourceContext<OfflineData> ctx) throws Exception {
        sourceContext = ctx;
        final PathChildrenCache pathChildrenCache = new PathChildrenCache(curatorOperator.client, clickHousePathInZookeeper, true);

        childrenListen(pathChildrenCache, clickHousePathInZookeeper);

        while (true) {
            Thread.sleep(10000);
        }
    }

    @Override
    public void cancel() {

    }

    public void childrenListen(PathChildrenCache pathChildrenCache, String nodepath) throws Exception {
        pathChildrenCache.start(PathChildrenCache.StartMode.POST_INITIALIZED_EVENT);
        pathChildrenCache.getListenable().addListener(new PathChildrenCacheListener() {
            @Override
            public void childEvent(CuratorFramework curatorFramework, PathChildrenCacheEvent event) throws Exception {

                if (event.getType().equals(PathChildrenCacheEvent.Type.INITIALIZED)) {
                    logger.info("初始化zookeeper监听完成.........");
                } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_ADDED)) {
                    jdbcConnectChilld(event);
                } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_REMOVED)) {
                } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_UPDATED)) {
                    jdbcConnectChilld(event);
                }
            }
        });
    }

    public void jdbcConnectChilld(PathChildrenCacheEvent event) {
        String zkData = new String(event.getData().getData());
        JSONObject obj = JSON.parseObject(zkData);
        String table = obj.getString("tableName");
        int status = obj.getInteger("status");
        if (status == 1) {

            String address = "jdbc:clickhouse://" + clickHouseUrl + "/" + database;

            try (Connection connection = DriverManager.getConnection(address, clickHouseUser, clickHousePassword);
                 Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery("select * from " + table)) {
                while (resultSet.next()) {
                    OfflineData offlineData = new OfflineData();

                    offlineData.setOfflineTableType(table);
                    offlineData.setAppId(resultSet.getLong("app_id"));
                    offlineData.setUserName(resultSet.getString("user_name"));
                    offlineData.setClientIp(resultSet.getString("client_ip"));
                    offlineData.setInterfaceId(resultSet.getLong("interface_id"));
                    offlineData.setSensitiveLabelField(resultSet.getString("sensitive_label_field"));
                    offlineData.setUserCountPercent(resultSet.getDouble("encoding_threshold"));
                    offlineData.setEventType(resultSet.getInt("event_type"));
                    offlineData.setRequestTime(resultSet.getString("request_time"));
                    offlineData.setAppIdPos(resultSet.getInt("app_id_pos"));
                    offlineData.setClientIpPos(resultSet.getInt("client_ip_pos"));
                    offlineData.setEventTypePos(resultSet.getInt("event_type_pos"));
                    offlineData.setRequestTimePos(resultSet.getInt("request_time_pos"));

                    sourceContext.collect(offlineData);
                }
            } catch (Exception e) {
                logger.error("query error", e);
            }
        }
    }

}
