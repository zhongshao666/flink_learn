package com.ssa.modelBean;

/**
 * @author : hld
 * @Date ： 2021/4/27
 * @Time : 10:16
 * @role ：
 */
public class KafkaConfigBean {
    /**
     * zk_cluster : zk_servers
     * bs_cluster : bs_cluster
     * kafka_group : pst
     * kafka_topic : test666
     */

    private String zk_cluster;
    private String bs_cluster;
    private String kafka_group;
    private String kafka_topic;

    public String getZk_cluster() {
        return zk_cluster;
    }

    public void setZk_cluster(String zk_cluster) {
        this.zk_cluster = zk_cluster;
    }

    public String getBs_cluster() {
        return bs_cluster;
    }

    public void setBs_cluster(String bs_cluster) {
        this.bs_cluster = bs_cluster;
    }

    public String getKafka_group() {
        return kafka_group;
    }

    public void setKafka_group(String kafka_group) {
        this.kafka_group = kafka_group;
    }

    public String getKafka_topic() {
        return kafka_topic;
    }

    public void setKafka_topic(String kafka_topic) {
        this.kafka_topic = kafka_topic;
    }
}
