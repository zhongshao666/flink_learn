package com.ssa.modelBean;

/**
 * @author : hld
 * @Date ： 2021/4/27
 * @Time : 10:09
 * @role ：
 */
public class ConfigDict {

    /**
     * field_config : {"object_field":"account","time_field":"request_time","date_field":"date_info","event_field":"operation_command"}
     * ck_config : {"host":"192.168.18.73","port":"9999","user":"default","password":"123456","database":"ods_st_ssa","table":"ods_id_dbsj_secsmart_audit_log_asset_log"}
     * hdfs_config : {"hdfs_url_python":"http://192.168.18.70:9870/","hdfs_file_path":"/home/secsmart/documents/pst_result.json","hdfs_hostname":"nn1","hdfs_url_scala":"hdfs://192.168.18.70:8020/"}
     * pst_config : {"c":"0","k":"0.001","l":"3","p":"0.00001","r":"1.05"}
     * data_config : {"max_time_interval":"10","min_time_interval":"1","ratio":"0.7","group_length":"30","group_thd":"10","anomaly_thd":"0.01","baseline_thd":"75"}
     * use_kerberos : true
     * kafka_config : {"zk_cluster":"zk_servers","bs_cluster":"bs_cluster","kafka_group":"pst","kafka_topic":"test666"}
     */

    private FieldConfigBean field_config;
    private CkConfigBean ck_config;
    private HdfsConfigBean hdfs_config;
    private PstConfigBean pst_config;
    private DataConfigBean data_config;
    private String use_kerberos;
    private KafkaConfigBean kafka_config;

    public FieldConfigBean getField_config() {
        return field_config;
    }

    public void setField_config(FieldConfigBean field_config) {
        this.field_config = field_config;
    }

    public CkConfigBean getCk_config() {
        return ck_config;
    }

    public void setCk_config(CkConfigBean ck_config) {
        this.ck_config = ck_config;
    }

    public HdfsConfigBean getHdfs_config() {
        return hdfs_config;
    }

    public void setHdfs_config(HdfsConfigBean hdfs_config) {
        this.hdfs_config = hdfs_config;
    }

    public PstConfigBean getPst_config() {
        return pst_config;
    }

    public void setPst_config(PstConfigBean pst_config) {
        this.pst_config = pst_config;
    }

    public DataConfigBean getData_config() {
        return data_config;
    }

    public void setData_config(DataConfigBean data_config) {
        this.data_config = data_config;
    }

    public String getUse_kerberos() {
        return use_kerberos;
    }

    public void setUse_kerberos(String use_kerberos) {
        this.use_kerberos = use_kerberos;
    }

    public KafkaConfigBean getKafka_config() {
        return kafka_config;
    }

    public void setKafka_config(KafkaConfigBean kafka_config) {
        this.kafka_config = kafka_config;
    }
}