package com.ssa.sensitive.match;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static com.google.gson.stream.JsonToken.END_DOCUMENT;

/**
 * @author qsj
 * @since 2021/1/24
 */
public class RequestBodyParse extends AbstractParse {

    private static final Logger logger = LoggerFactory.getLogger(RequestBodyParse.class);

    @Override
    public List<String> parseData(String body) {
        List<String> valueList = Lists.newArrayList();
        if (isJson(body)) {
            jsonParse(body, valueList);
        } else {
            formKvParse(body, valueList);
        }
        return valueList;
    }

    @Override
    public Map<String,String> parseMapData(String body){
        Map<String,String> map = Maps.newHashMap();
        if (isJson(body)) {
            jsonParse(body, map);
        } else {
            formKvParse(body, map);
        }
        return map;
    }

    /**
     * json解析并识别
     *
     * @param body
     */
    private void jsonParse(String body,Map<String,String> map) {
        try (InputStream inputStream = new ByteArrayInputStream(body.getBytes());
             InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
             JsonReader reader = new DefaultJsonReader(inputStreamReader)) {

            reader.setLenient(true);
            JsonToken token;
            String currentName = null;
            while ((token = reader.peek()) != END_DOCUMENT) {
                switch (token) {
                    case BEGIN_ARRAY:
                        reader.beginArray();
                        break;
                    case END_ARRAY:
                        reader.endArray();
                        break;
                    case BEGIN_OBJECT:
                        reader.beginObject();
                        break;
                    case END_OBJECT:
                        reader.endObject();
                        break;
                    case NAME:
                        currentName = reader.nextName();
                        break;

                    case STRING:
                    case NUMBER:
                        String value = reader.nextString();
                        if(Objects.nonNull(currentName)) {
                            map.put(currentName, value);
                        }
                        break;

                    case BOOLEAN:
                        reader.nextBoolean();
                        break;

                    case NULL:
                        reader.nextNull();
                        break;
                    default:
                        break;
                }
            }

        } catch (Exception e) {
            logger.error("json parse error",e);
        }
    }

    /**
     * form表单 kv结构解析
     * @param body
     * @param map
     */
    protected void formKvParse(String body,Map<String,String> map){
        String[] arr = body.split("&");
        for (String kv : arr) {
            String[] kvArr = kv.split("=");
            if(kvArr.length == 2){
                map.put(kvArr[0],kvArr[1]);
            }
        }
    }
}
