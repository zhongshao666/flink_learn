package com.ssa;


import com.google.common.collect.Maps;
import com.ssa.algorithmmodel.AssociationRuleProcess;
import com.ssa.bean.AccountBean;
import com.ssa.bean.OfflineData;
import com.ssa.keys.HttpKeySelector;
import com.ssa.sensitive.to.HttpLog;
import com.ssa.sensitive.util.SystemConfig;
import com.ssa.source.ClickHouseZkSource;
import com.ssa.source.SecZookeeperSourceUpdate;
import com.ssa.transformation.*;
import com.ssa.utils.KafkaSinkProp;
import com.ssa.utils.KafkaSourceProp;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.datastream.*;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer011;
import org.apache.flink.util.OutputTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.ivi.opensource.flinkclickhousesink.model.ClickHouseClusterSettings;
import ru.ivi.opensource.flinkclickhousesink.model.ClickHouseSinkConst;

import java.util.Map;
import java.util.Properties;

import static com.ssa.sensitive.util.SystemConfig.*;

/**
 * @author : hld
 * @Date ： 2021/4/8
 * @Time : 15:56
 * @role ：
 */
public class ApisjMain {
    private static final Logger logger = LoggerFactory.getLogger(ApisjMain.class);

    public static OutputTag<HttpLog> apptags = new OutputTag<HttpLog>("apptags") {
    };
    public static OutputTag<HttpLog> interfacetags = new OutputTag<HttpLog>("interfacetags") {
    };
    public static OutputTag<AccountBean> usertags = new OutputTag<AccountBean>("usertags") {
    };
    public static OutputTag<String> sensitivedata = new OutputTag<String>("sensitivedata") {
    };
    public static OutputTag<String> sensitivelabels = new OutputTag<String>("sensitivelabels") {
    };

    private static MapStateDescriptor<String, Tuple4<Integer, Integer, String, String>> zookeeperConfig = new MapStateDescriptor<>("zookeeperConfig", BasicTypeInfo.STRING_TYPE_INFO, Types.TUPLE(BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO));


    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment streamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment();
        //   streamExecutionEnvironment.setRestartStrategy(RestartStrategies.fixedDelayRestart(5, Time.seconds(10)));
        ParameterTool parameterTool = ParameterTool.fromArgs(args);
        streamExecutionEnvironment.getConfig()
                .setGlobalJobParameters(parameterTool);
        streamExecutionEnvironment.setParallelism(6);


        //设置入参  args
        setConfig(parameterTool);

        //获取clickhouse sink 配置
        ParameterTool clickHouseSinkGlobalParam = getClickHouseSinkGlobalParam(clickHouseUrl, clickHouseUser, clickHousePassword);
        streamExecutionEnvironment.getConfig()
                .setGlobalJobParameters(parameterTool.mergeWith(clickHouseSinkGlobalParam));

        //创建datasource消费者 从kafka 消费数据
        FlinkKafkaConsumer011<String> stringFlinkKafkaConsumer011 = new FlinkKafkaConsumer011<>(kafkaTopicCollectHttp, new SimpleStringSchema(), getKafkaSourceProp().getProp());

        //创建datasink生产者 将新的应用推送给rt_app_audit_appres
        FlinkKafkaProducer011<String> appFlinkSinkProducer = new FlinkKafkaProducer011<>(kafkaTopicNewApp, new SimpleStringSchema(), getKafkaSinkProp().getProp2());

        //创建datasink生产者，将新的用户推送给rt_app_audit_accountres
        FlinkKafkaProducer011<String> accountFlinkSinkProducer = new FlinkKafkaProducer011<>(kafkaTopicNewAccount, new SimpleStringSchema(), getKafkaSinkProp().getProp2());

        DataStreamSource<Tuple4<Integer, Integer, String, String>> tuple2DataStreamSource = streamExecutionEnvironment.addSource(new SecZookeeperSourceUpdate())
                .setParallelism(1);

        //zookeeper的配置广播流配置
        BroadcastStream<Tuple4<Integer, Integer, String, String>> broadcast = tuple2DataStreamSource.broadcast(zookeeperConfig);

        //从kafka获取数据
        DataStreamSource<String> stringDataStreamSource = streamExecutionEnvironment.addSource(stringFlinkKafkaConsumer011)
                .setParallelism(4);

        //join 数据广播流
        BroadcastConnectedStream<String, Tuple4<Integer, Integer, String, String>> broadcastConnectedStream = stringDataStreamSource.connect(broadcast);
        //应用发现
        SingleOutputStreamOperator<HttpLog> appDiscovery = broadcastConnectedStream.process(new AppTagProcess())
                .name("应用发现")
                .setParallelism(4);
        //应用写入到kafka中
        appDiscovery.getSideOutput(apptags)
                .map(new AppBean2StringMap())
                .addSink(appFlinkSinkProducer)
                .name("应用写入到kafka中");
        //http分组识别，发现新用户，用户打标，新接口标记
        SingleOutputStreamOperator<HttpLog> httpTagLater = appDiscovery.keyBy(new HttpKeySelector())
                .connect(broadcast)
                .process(new UserTagProcess())
                .name("http分组识别，发现新用户，用户打标，新接口标记");

        //新用户写入kafka中
        httpTagLater.getSideOutput(usertags)
                .map(new AccountBean2StringMap())
                .addSink(accountFlinkSinkProducer)
                .name("新用户写入kafka中");

        //敏感数据识别标记
        SingleOutputStreamOperator<HttpLog> sensitiveAnallyLater = httpTagLater.connect(broadcast)
                .process(new SensitiveAnalysisProcess())
                .name("敏感数据识别标记");


        //获取ck数据
        DataStreamSource<OfflineData> offlineDataDataStreamSource = streamExecutionEnvironment.addSource(new ClickHouseZkSource())
                .setParallelism(1);

        sensitiveAnallyLater.print();
        //庆仕的关联规则
        BroadcastStream<Tuple2<OfflineData, String>> assoRuleBroadcast = offlineDataDataStreamSource.connect(broadcast)
                .process(new AlgorithOutputTag()).broadcast(new AssociationRuleProcess().associationRule());
        sensitiveAnallyLater.keyBy(HttpLog::getUserName).connect(assoRuleBroadcast).process(new AssociationRuleProcess());

        //执行任务
        streamExecutionEnvironment.execute("api_audit_flink_job");
    }

    /**
     * 获取kafka sink配置
     *
     * @return
     */
    private static KafkaSinkProp getKafkaSinkProp() {
        KafkaSinkProp kafkaSinkProp = new KafkaSinkProp();
        kafkaSinkProp.setBOOTSTRAP_SERVERS_CONFIG(SystemConfig.kafkaUrl);
        return kafkaSinkProp;
    }

    /**
     * 获取 kafka consumer配置
     *
     * @return
     */
    private static KafkaSourceProp getKafkaSourceProp() {
        KafkaSourceProp kafkaSourceProp = new KafkaSourceProp();
        kafkaSourceProp.setBOOTSTRAP_SERVERS_CONFIG(SystemConfig.kafkaUrl);
        return kafkaSourceProp;
    }

    /**
     * 设置传入配置
     *
     * @param parameterTool
     */
    public static void setConfig(ParameterTool parameterTool) {

        String kafkaAddr = parameterTool.get("kafkaAddr");
        if (kafkaAddr != null) {
            SystemConfig.kafkaUrl = kafkaAddr;
        }
        String zkAddr = parameterTool.get("zkAddr");
        if (zkAddr != null) {
            zookeeperUrl = zkAddr;
        }

        String ckAddr = parameterTool.get("ckAddr");
        if (ckAddr != null) {
            clickHouseUrl = ckAddr;
        }

        String ckUser = parameterTool.get("ckUser");
        if (ckUser != null) {
            clickHouseUser = ckUser;
        }

        String ckPassword = parameterTool.get("ckPassword");
        if (ckPassword != null) {
            clickHousePassword = "__NO_VALUE_KEY".equals(ckPassword) ? "" : ckPassword;
        }

        String ckdb = parameterTool.get("ckdb");
        if (ckdb != null) {
            database = ckdb;
        }

//        logger.info("config kafka addr {} init zk addr {} clickhouse addr {} clickHouseUser {} clickHousePassword {} database {}", kafkaUrl, zookeeperUrl, clickHouseUrl, clickHouseUser, clickHousePassword, database);
    }

    /**
     * 设置clickhouse的sink参数
     *
     * @param host
     * @param user
     * @param password
     */
    private static ParameterTool getClickHouseSinkGlobalParam(String host, String user, String password) {
        Map<String, String> globalParameters = Maps.newHashMap();
        globalParameters.put(ClickHouseClusterSettings.CLICKHOUSE_HOSTS, host);
        globalParameters.put(ClickHouseClusterSettings.CLICKHOUSE_USER, user);
        globalParameters.put(ClickHouseClusterSettings.CLICKHOUSE_PASSWORD, password);
        globalParameters.put(ClickHouseSinkConst.TIMEOUT_SEC, clickHouseTimeoutSec);
        globalParameters.put(ClickHouseSinkConst.NUM_WRITERS, clickHouseNumWriters);
        globalParameters.put(ClickHouseSinkConst.NUM_RETRIES, clickHouseNumRetries);
        globalParameters.put(ClickHouseSinkConst.QUEUE_MAX_CAPACITY, clickHouseMaxQueueSize);
        globalParameters.put(ClickHouseSinkConst.IGNORING_CLICKHOUSE_SENDING_EXCEPTION_ENABLED, clickHouseIgnoreExceptionEnable);
        globalParameters.put(ClickHouseSinkConst.FAILED_RECORDS_PATH, clickHouseFailRecordPath);

        return ParameterTool.fromMap(globalParameters);
    }

    /**
     * http_log ck config
     *
     * @return
     */
    private static Properties getHttpLogCkProp(String ckDb) {
        Properties properties = new Properties();
        properties.put(ClickHouseSinkConst.TARGET_TABLE_NAME, ckDb + ".http_log");
        properties.put(ClickHouseSinkConst.MAX_BUFFER_SIZE, clickHouseMaxBufferSize);
        return properties;
    }

    /**
     * http_sensitive_record ck config
     *
     * @return
     */
    private static Properties getHttpSensitiveRecordCkProp(String ckDb) {
        Properties properties = new Properties();
        properties.put(ClickHouseSinkConst.TARGET_TABLE_NAME, ckDb + ".http_sensitive_record");
        properties.put(ClickHouseSinkConst.MAX_BUFFER_SIZE, clickHouseMaxBufferSize);
        return properties;
    }

}