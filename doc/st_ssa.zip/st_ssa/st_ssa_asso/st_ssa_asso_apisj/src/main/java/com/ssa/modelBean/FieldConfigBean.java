package com.ssa.modelBean;

/**
 * @author : hld
 * @Date ： 2021/4/27
 * @Time : 10:13
 * @role ：
 */
public class FieldConfigBean {
    /**
     * object_field : account
     * time_field : request_time
     * date_field : date_info
     * event_field : operation_command
     */

    private String object_field;
    private String time_field;
    private String date_field;
    private String event_field;

    public String getObject_field() {
        return object_field;
    }

    public void setObject_field(String object_field) {
        this.object_field = object_field;
    }

    public String getTime_field() {
        return time_field;
    }

    public void setTime_field(String time_field) {
        this.time_field = time_field;
    }

    public String getDate_field() {
        return date_field;
    }

    public void setDate_field(String date_field) {
        this.date_field = date_field;
    }

    public String getEvent_field() {
        return event_field;
    }

    public void setEvent_field(String event_field) {
        this.event_field = event_field;
    }
}
