package com.ssa.sensitive.constants;

/**
 * @author qsj
 * @since 2021/1/24
 */
public class CommonConstants {
    /**
     * csv 分隔符
     */
    public static final String CSV_SPLIT_CHAR = ",";

    /**
     * 区间范围分割符
     */
    public static final String ZONE_SPLIT_CHAR = "-";

    /**
     * ipv6 分隔符
     */
    public static final String IPV6_SPLIT_CHAR = ":";

    /**
     * 请求时间格式化-yyyy-MM-dd HH:mm:ss.SSS
     */
    public static final String REQUEST_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";

    /**
     * 敏感数据位置
     */
    public enum SensitiveLocation{
        /**
         * 请求头-1
         */
        REQ_HEADER(1),
        /**
         * 请求体-2
         */
        REQ_BODY(2),
        /**
         * 响应头-3
         */
        RES_HEADER(3),
        /**
         * 响应体-4
         */
        RES_BODY(4);

        private int val;
        SensitiveLocation(int val){
            this.val = val;
        }
        public int getVal(){
            return this.val;
        }
    }

    /**
     * 接口类型
     */
    public enum InterfaceType{
        /**
         * 普通接口
         */
        NORMAL(1),
        /**
         * 文件接口
         */
        FILE(2),
        /**
         * 登录接口
         */
        LOGIN(3);

        private int val;
        InterfaceType(int val){
            this.val = val;
        }
        public int getVal(){
            return this.val;
        }
    }

    /**
     * 风险策略类型
     */
    public enum StrategyType{
        /**
         *@Author 赵臻柄
         *@Date 2021/3/23 10:28
         *@Method
         *@功能描述 白名单策略类型
         *@Param
         *@Return
        */
        WHITELIST("whitelist"),
        /**
         *@Author 赵臻柄
         *@Date 2021/3/23 10:28
         *@Method
         *@功能描述 黑名单策略类型
         *@Param
         *@Return
        */
        BLACKLIST("blacklist"),
        
        /**
         *@Author 赵臻柄
         *@Date 2021/3/23 10:30
         *@Method 
         *@功能描述 用户自定义策略类型
         *@Param 
         *@Return 
        */
        USERDEFINED("userdefined"),

        /**
         *@Author 赵臻柄
         *@Date 2021/3/23 15:25
         *@Method
         *@功能描述 非工作时间
         *@Param
         *@Return
        */
        NONWORKING("nonworking"),

        /**
         *@Author 赵臻柄
         *@Date 2021/3/23 15:25
         *@Method
         *@功能描述 登录破解
         *@Param
         *@Return
        */
        LOGINCRACK("logincrack"),

        /**
         *@Author 赵臻柄
         *@Date 2021/3/23 15:25
         *@Method
         *@功能描述 异常操作
         *@Param
         *@Return
        */
        ABNORMALOPERATION("abnormaloperation"),

        /**
         *@Author 赵臻柄
         *@Date 2021/3/23 15:26
         *@Method 
         *@功能描述 默认高权限
         *@Param 
         *@Return 
        */
        HIGHPRIVILEGEUSER("highprivilegeuser"),
        
        /**
         *@Author 赵臻柄
         *@Date 2021/3/23 15:26
         *@Method 
         *@功能描述 高频访问
         *@Param 
         *@Return 
        */
        HIGHFREQUENCYACCESS("highfrequencyaccess"),

        /**
         *@Author 赵臻柄
         *@Date 2021/3/23 15:26
         *@Method 
         *@功能描述 垂直越权
         *@Param 
         *@Return 
        */
        VERTICALOVERREACH("verticaloverreach");


        private String val;
        StrategyType(String val){this.val = val;}
        public String getVal(){return this.val;}

    }


     /**
     * 账号位置
     */
    public enum AccountLocation{
        /**
         * 请求头
         */
        REQ_HEADER("1"),
        /**
         * cookie
         */
        COOKIE("5"),
        /**
         * 请求体
         */
        REQ_BODY("2");

        private String val;
        AccountLocation(String val){
            this.val = val;
        }
        public String getVal(){
            return this.val;
        }
    }

    /**
     * 状态
     */
    public enum Status{
        /**
         * 启用
         */
        ENABLE("1"),
        /**
         * 不启用
         */
        DISALE("0");

        private String val;
        Status(String val){
            this.val = val;
        }
        public String getVal(){
            return this.val;
        }
    }

    /**
     * zk数据类型:接口\应用\自动发现
     */
    public enum ZkDataType{
        /**
         * 接口类型
         */
        INTERFACE_TYPE(1),

        /**
         * 应用类型
         */
        APP_TYPE(2),

        /**
         * 自动发现类型
         */
        DISCOVERY_TYPE(3),

        /**
         * 敏感标签类型
         */
        SENSITIVE_LABEL(4),
        /**
         * 全局策略开关类型
         */
        STRATEGY_CONFIG(5),
        /**
         * 黑白名单列表类型
         */
        BW_LIST_TYPE(6),
        /**
         * 用户自定义标签类型
         */
        USER_DEFINE_TYPE(7),
        /**
         * 风险策略类型
         */
        RISK_TYPE(8),
        /**
         * 概率后缀树zk配置地址
         */
        PST_ZK_CONFIG(9),
        /**
         * 概率后缀树监控hdfs的zk节点
         */
        PST_LISTEN_CHILD(10),
        /**
         * 关联规则检测
         */
        ASSO_RULE(11);

        private int val;
        ZkDataType(int val){
            this.val = val;
        }
        public int getVal(){
            return this.val;
        }
    }

    /**
     *@Author 赵臻柄
     *@Date 2021/2/3 15:12
     *@Method 
     *@功能描述  从zookeeper获取的数据操作类型
     *@Param 
     *@Return 
    */
    public enum OperateType{
        /**
         * 添加
         */
        ADD(1),
        /**
         * 删除
         */
        DELETE(-1),
        /**
         * 更新
         */
         UPDATE(2),
        /**
         * 其他类型
         */
        OTHER(0);

        private int val;
        OperateType(int val){
            this.val = val;
        }
        public int getVal(){
            return this.val;
        }

        public static OperateType valueFor(int v){
            for (OperateType value : OperateType.values()) {
                if(value.getVal() == v){
                    return value;
                }
            }
            return OTHER;
        }
    }
    /**
     *@Author 赵臻柄
     *@Date 2021/2/3 15:18
     *@Method 
     *@功能描述  事件访问类型，分为登入事件和访问事件
     *@Param 
     *@Return 
    */
    public enum EventType{
        /**
         * 登入事件
         */
        LOGIN(1),
        /**
         * 访问事件
         */
        ACCESS(2);

        private int val;
        EventType(int val){
            this.val = val;
        }
        public int getVal()

        {
            return this.val;
        }
    }

    /**
     * 离线表
     */
    public enum OfflineTableType {
        /**
         * 敏感数据异常操作表
         */
        SENSITIVE_OPERTOR("dm_normal_a_sj_log_sensitive_operator"),
        /**
         * 敏感数据垂直越权访问表
         */
        SENSITIVE_VISIT("dm_a_sj_log_vertical_unauthorized_aggregation"),
        /**
         * 关联规则用户count表
         */
        ASSO_RULE("dm_nml_ueba_apisj_assorule_usercount"),
        /**
         * 关联规则编码表
         */
        ASSO_RULE_ENCODE("dm_nml_ueba_apisj_assorule_encoding");
        private String val;
        OfflineTableType(String val){
            this.val = val;
        }
        public String getVal(){
            return this.val;
        }
    }
}
