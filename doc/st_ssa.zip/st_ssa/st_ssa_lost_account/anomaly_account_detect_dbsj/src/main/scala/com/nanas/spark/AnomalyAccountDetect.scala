package com.nanas.spark

import java.io.{BufferedInputStream, ByteArrayInputStream}
import java.util.Properties

import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import com.nanas.util.ZKUtil
import com.alibaba.fastjson.{JSON, JSONObject}
import org.apache.log4j.{Level, Logger}
import com.nanas.util.ParameterTool
import org.I0Itec.zkclient.ZkClient

object AnomalyAccountDetect {
  //屏蔽日志
//  Logger.getLogger("org.apache.spark").setLevel(Level.WARN)
//  Logger.getLogger("org.eclipse.jetty.server").setLevel(Level.OFF)

  def main(args: Array[String]): Unit = {
    // 创建SparkSession实例
    val ss = SparkSession.builder().appName("AnomalyAccountDetect_dbsj").getOrCreate()

    val parameter_tool = new ParameterTool
    val map = parameter_tool.fromArgs(args)
    val properties = new Properties
    val zk_client = ZKUtil.get_zk_client(map.getOrElse("zkAddr", ""))
    val prop_str: String = zk_client.readData(map.getOrElse("zkPath", ""))
    properties.load(new ByteArrayInputStream(prop_str.getBytes()))

    // 获取zk参数
    val zk_listen_path: String = properties.getProperty("zookeeper.model.blacklist.listen.path") + "/010502"

    val config_str: String = zk_client.readData(properties.getProperty("zookeeper.model.dbsj.lost.account.path"))
    val config_json: JSONObject = JSON.parseObject(config_str)
    // 数据长度
    val max_date_length = config_json.getIntValue("max_date_length")
    val min_date_length = config_json.getIntValue("min_date_length")
    // 孤立森林参数
    val num_trees = config_json.getJSONObject("isolation_forest").getIntValue("num_trees")
    val max_samples = config_json.getJSONObject("isolation_forest").getDoubleValue("max_samples")
    val max_features = config_json.getJSONObject("isolation_forest").getDoubleValue("max_features")
    val max_depth = config_json.getJSONObject("isolation_forest").getIntValue("max_depth")
    val contamination = config_json.getJSONObject("isolation_forest").getDoubleValue("contamination")
    val bootstrap = config_json.getJSONObject("isolation_forest").getBooleanValue("bootstrap")
    val seed = config_json.getJSONObject("isolation_forest").getLongValue("seed")
    val threshold = config_json.getJSONObject("isolation_forest").getDoubleValue("threshold")
    // clickhouse参数
    val ck_url = "jdbc:clickhouse://" + properties.getProperty("clickhouse.host") + ":" + properties.getProperty("clickhouse.port") + "/" + properties.getProperty("clickhouse.dm.database")
    val ck_user = properties.getProperty("clickhouse.access.user")
    val ck_password = properties.getProperty("clickhouse.access.password")
    val ck_table = properties.getProperty("clickhouse.lost.account.table")
    // mysql参数
    val mysql_url = "jdbc:mysql://" + properties.getProperty("mysql.host") + ":" + properties.getProperty("mysql.port") + "/" + properties.getProperty("mysql.dm.database") + "?useSSL=false"
    val mysql_user = properties.getProperty("mysql.user")
    val mysql_password = properties.getProperty("mysql.password")
    val mysql_table = properties.getProperty("mysql.blacklist.table")

    println("config: " + config_str)

    if (max_date_length >= min_date_length && min_date_length > 0) {
      // 提取指标
      val ti = new TestIndex(ss, max_date_length, min_date_length, ck_url, ck_user, ck_password, ck_table)
      val (all_index_history, all_index_yesterday, day_length) = ti.get_all_index()
      if (all_index_history != null && all_index_yesterday != null) {
        println("----history data and yesterday data----")
        all_index_history.show()
        all_index_yesterday.show()
        if (all_index_yesterday.count() >= 2) {
          val join_df = all_index_history.join(all_index_yesterday, Seq("account"), "inner")
          val stat_anomaly_df = JudgeAnomaly.judge_anomaly(join_df, ss, day_length) // 根据自身历史行为判断异常
          val if_anomaly_df = IsolationForest.isolation_forest(all_index_yesterday,
                                                               ss,
                                                               num_trees,
                                                               max_samples,
                                                               max_features,
                                                               max_depth,
                                                               contamination,
                                                               bootstrap,
                                                               seed) // 根据孤立森林判断异常
          val anomaly_df = stat_anomaly_df.join(if_anomaly_df, Seq("account"), "inner")
          println("----anomaly dataFrame----")
          anomaly_df.show()
          val anomaly_account = get_anomaly_account(anomaly_df, ss, threshold)
          println("----anomaly account----")
          anomaly_account.show()

          if (!anomaly_account.head(1).isEmpty) {
            // 保存异常账号到mysql
            println("----save data to mysql----")
            val prop = new Properties()
            prop.setProperty("driver", "com.mysql.jdbc.Driver")
            prop.setProperty("user", mysql_user)
            prop.setProperty("password", mysql_password)
            anomaly_account.write.mode(SaveMode.Append).jdbc(mysql_url, mysql_table, prop)
            // 更新zk
            if (!zk_client.exists(zk_listen_path)) {
              zk_client.createPersistent(zk_listen_path, true)
            }
            val result = new JSONObject()
            result.put("indexID", "010502")
            result.put("dateTime", System.currentTimeMillis())
            result.put("status", 1)
            result.put("dbtype", "01")
            zk_client.writeData(zk_listen_path, result.toJSONString)
          }
        } else {
          println("the data size of yesterday is less than 2")
        }
      } else {
        println("the length of data is smaller than min time interval")
      }

    } else {
      println("max time interval or min time interval do not meet the requirements.")
    }
  }

  def get_anomaly_account(df: DataFrame, ss: SparkSession, thd: Double): DataFrame = {
    df.createOrReplaceTempView("dfView")
    val anomaly_account = ss.sql(
      s"""
         |select
         |"01" as dataType,
         |"05" as modelType,
         |"02" as blackType,
         |account as typeValue,
         |cast(current_date as string) as updateDate
         |from dfView
         |where (operation_time_anomaly = true or login_times_anomaly = true or operation_ip_anomaly = true or operation_times_anomaly = true) and
         |(visit_asset_anomaly = true or operation_type_anomaly = true or
         |high_risk_operation_times_anomaly = true or visit_sensitive_table_times_anomaly = true or
         |visit_sensitive_table_row_num_anomaly = true or visit_sensitive_column_num_anomaly = true) and
         |anomalyScore > $thd
         |""".stripMargin)

    anomaly_account
  }
}
