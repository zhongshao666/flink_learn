package com.nanas.util

import org.I0Itec.zkclient.ZkClient
import com.nanas.spark.MyZkSerializer

object ZKUtil {
  def get_zk_client(zk_servers: String): ZkClient = {
    val zk_client = new ZkClient(zk_servers)
    zk_client.setZkSerializer(new MyZkSerializer)
    zk_client
  }
}
