package com.nanas.spark

import java.io.ByteArrayInputStream
import java.text.SimpleDateFormat
import java.util.{Calendar, Date, Properties}

import com.alibaba.fastjson.{JSON, JSONObject}
import com.nanas.util.ZKUtil
import org.I0Itec.zkclient.ZkClient


object test {
  def main(args: Array[String]): Unit = {

    val ck_host: String = "192.168.24.73"
    val ck_port: String = "8123"
    val ck_database: String = "dm_st_ssa"
    val ck_url = "jdbc:clickhouse://" + ck_host + ":" + ck_port + "/" + ck_database
    println(ck_url)


  }

}
