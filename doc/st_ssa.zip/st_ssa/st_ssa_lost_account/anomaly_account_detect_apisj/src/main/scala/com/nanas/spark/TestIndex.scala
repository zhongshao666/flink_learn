package com.nanas.spark

import java.sql.Date
import java.text.SimpleDateFormat
import java.util.Calendar

import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * author：ylh
 * description：统计账号的各种指标
 */

class TestIndex(ss: SparkSession,
                max_date_length: Int,
                min_date_length: Int,
                ck_url: String,
                ck_user: String,
                ck_password: String,
                ck_table: String) {
  val spark_session: SparkSession = ss  // SparkSession实例
  val max_time_interval: Int = max_date_length  // 最大时间区间
  val min_time_interval: Int = min_date_length  // 最小时间区间
  val url: String = ck_url  // ck的url
  val user: String = ck_user  // ck的用户
  val password: String = ck_password  // ck的密码
  val table: String = ck_table  // ck的表
  val time_format = new SimpleDateFormat("yyyy-MM-dd")  // 时间格式
  var time_start_history: String = _  // 获取昨天之前max_time_interval天数据的开始时间
  var time_end_history: String = _  // 获取昨天之前max_time_interval天数据的截止时间
  var time_start_yesterday: String = _  // 获取昨天数据的开始时间
  var time_end_yesterday: String = _  // 获取昨天数据的截止时间

  // 获取数据
  def get_df(): (DataFrame, DataFrame) = {
    val time_now = Calendar.getInstance()

    time_end_yesterday = time_format.format(time_now.getTime)
    time_now.add(Calendar.DATE, -1)
    time_start_yesterday = time_format.format(time_now.getTime)

    time_end_history = time_start_yesterday
    time_now.add(Calendar.DATE, -1 * max_time_interval)
    time_start_history = time_format.format(time_now.getTime)

    println("the start time of the history access behavior: " + time_start_history)
    println("the end time of the history access behavior: " + time_end_history)
    println("the start time of the yesterday access behavior: " + time_start_yesterday)
    println("the end time of the yesterday access behavior: " + time_end_yesterday)

    // 获取所有数据
    val all_data_df = spark_session.read
      .format("jdbc")
      .option("driver", "ru.yandex.clickhouse.ClickHouseDriver")
      .option("url", url)
      .option("user", user)
      .option("password", password)
      .option("dbtable", table)
      .load()

    // 获取历史数据
    val all_data_df_history = all_data_df
      .where(s"""data_date >= "$time_start_history" and data_date < "$time_end_history" and data_type = "02"""")

    // 获取昨天数据
    val all_data_df_yesterday = all_data_df
      .where(s"""data_date >= "$time_start_yesterday" and data_date < "$time_end_yesterday" and data_type = "02"""")

    (all_data_df_history, all_data_df_yesterday)
  }

  // 判断数据是否满足最小时间区间要求
  def judge_time_interval(all_data_df_history: DataFrame): Int = {
    if (!all_data_df_history.head(1).isEmpty) {
      all_data_df_history.createOrReplaceTempView("allDataDfHistory")
      // 找到数据中最早日期
      val min_date_df = spark_session.sql(
        s"""
           |select
           |min(data_date) as min_date
           |from allDataDfHistory
           |""".stripMargin)
      val timestamp_end = time_format.parse(time_end_history).getTime / 1000  // 数据截止时间戳
      val min_date = min_date_df.head(1)(0).getAs[Date]("min_date").toString  // 最早日期
      val min_timestamp = time_format.parse(min_date).getTime / 1000  // 最早日期时间戳
      val day_length = (timestamp_end - min_timestamp) / 86400  // 时间跨度
      println("history access behavior time span: " + day_length.toString)

      day_length.toInt
    } else {
      0
    }
  }

  // 统计指标
  def stat_index(df_history: DataFrame, df_yesterday: DataFrame): (DataFrame, DataFrame) = {
    df_history.createOrReplaceTempView("dfHistory")
    df_yesterday.createOrReplaceTempView("dfYesterday")

    // 统计操作时间
    val operation_time_history_df = spark_session.sql(
      """
        |select
        |account,
        |concat_ws(",", collect_set(feature_value)) as operation_time_history
        |from dfHistory
        |where feature = "operation_time"
        |group by account
        |""".stripMargin)

    val operation_time_yesterday_df = spark_session.sql(
      """
        |select
        |account,
        |concat_ws(",", collect_set(feature_value)) as operation_time_yesterday
        |from dfYesterday
        |where feature = "operation_time"
        |group by account
        |""".stripMargin)

    // 统计登陆APP
//    val login_app_history_df = spark_session.sql(
//      """
//        |select
//        |account,
//        |concat_ws(",", collect_set(feature_value)) as login_app_history
//        |from dfHistory
//        |where feature = "login_app"
//        |group by account
//        |""".stripMargin)
//
//    val login_app_yesterday_df = spark_session.sql(
//      """
//        |select
//        |account,
//        |concat_ws(",", collect_set(feature_value)) as login_app_yesterday
//        |from dfYesterday
//        |where feature = "login_app"
//        |group by account
//        |""".stripMargin)

    // 统计登陆次数
    val login_times_history_df = spark_session.sql(
      """
        |select
        |account,
        |concat_ws(",", collect_list(feature_value)) as login_times_history
        |from dfHistory
        |where feature = "login_times"
        |group by account
        |""".stripMargin)

    val login_times_yesterday_df = spark_session.sql(
      """
        |select
        |account,
        |feature_value as login_times_yesterday
        |from dfYesterday
        |where feature = "login_times"
        |""".stripMargin)

    // 统计操作IP
    val operation_ip_history_df = spark_session.sql(
      """
        |select
        |account,
        |concat_ws(",", collect_set(feature_value)) as operation_ip_history
        |from dfHistory
        |where feature = "operation_ip"
        |group by account
        |""".stripMargin)

    val operation_ip_yesterday_df = spark_session.sql(
      """
        |select
        |account,
        |concat_ws(",", collect_set(feature_value)) as operation_ip_yesterday
        |from dfYesterday
        |where feature = "operation_ip"
        |group by account
        |""".stripMargin)

    // 统计访问次数
    val operation_times_history_df = spark_session.sql(
      """
        |select
        |account,
        |concat_ws(",", collect_list(feature_value)) as operation_times_history
        |from dfHistory
        |where feature = "operation_times"
        |group by account
        |""".stripMargin)

    val operation_times_yesterday_df = spark_session.sql(
      """
        |select
        |account,
        |feature_value as operation_times_yesterday
        |from dfYesterday
        |where feature = "operation_times"
        |""".stripMargin)

    // 统计请求方式
    val req_method_history_df = spark_session.sql(
      """
        |select
        |account,
        |concat_ws(",", collect_set(feature_value)) as req_method_history
        |from dfHistory
        |where feature = "req_method"
        |group by account
        |""".stripMargin)

    val req_method_yesterday_df = spark_session.sql(
      """
        |select
        |account,
        |concat_ws(",", collect_set(feature_value)) as req_method_yesterday
        |from dfYesterday
        |where feature = "req_method"
        |group by account
        |""".stripMargin)



    // 统计敏感数据访问次数
    val visit_sensitive_data_times_history_df = spark_session.sql(
      """
        |select
        |account,
        |concat_ws(",", collect_list(feature_value)) as visit_sensitive_data_times_history
        |from dfHistory
        |where feature = "visit_sensitive_data_times"
        |group by account
        |""".stripMargin)

    val visit_sensitive_data_times_yesterday_df = spark_session.sql(
      """
        |select
        |account,
        |feature_value as visit_sensitive_data_times_yesterday
        |from dfYesterday
        |where feature = "visit_sensitive_data_times"
        |""".stripMargin)

    // 统计访问接口
    val interface_id_history_df = spark_session.sql(
      """
        |select
        |account,
        |concat_ws(",", collect_set(feature_value)) as interface_id_history
        |from dfHistory
        |where feature = "interface_id"
        |group by account
        |""".stripMargin)

    val interface_id_yesterday_df = spark_session.sql(
      """
        |select
        |account,
        |concat_ws(",", collect_set(feature_value)) as interface_id_yesterday
        |from dfYesterday
        |where feature = "interface_id"
        |group by account
        |""".stripMargin)

    // 统计总流量
    val sum_traffic_history_df = spark_session.sql(
      """
        |select
        |account,
        |concat_ws(",", collect_list(feature_value)) as sum_traffic_history
        |from dfHistory
        |where feature = "sum_traffic"
        |group by account
        |""".stripMargin)

    val sum_traffic_yesterday_df = spark_session.sql(
      """
        |select
        |account,
        |feature_value as sum_traffic_yesterday
        |from dfYesterday
        |where feature = "sum_traffic"
        |""".stripMargin)


    // 连接所有指标
    val history_df_array = Array(login_times_history_df,
      operation_ip_history_df,
      operation_times_history_df,
      req_method_history_df,
      visit_sensitive_data_times_history_df,
      interface_id_history_df,
      sum_traffic_history_df
    )
    val yesterday_df_array = Array(login_times_yesterday_df,
      operation_ip_yesterday_df,
      operation_times_yesterday_df,
      req_method_yesterday_df,
      visit_sensitive_data_times_yesterday_df,
      interface_id_yesterday_df,
      sum_traffic_yesterday_df
    )
    var all_index_history_df: DataFrame = operation_time_history_df
    var all_index_yesterday_df: DataFrame = operation_time_yesterday_df
    for (df_history <- history_df_array) {
      all_index_history_df = all_index_history_df.join(df_history, Seq("account"), "outer")
    }
    for (df_yesterday <- yesterday_df_array) {
      all_index_yesterday_df = all_index_yesterday_df.join(df_yesterday, Seq("account"), "outer")
    }

    (all_index_history_df, all_index_yesterday_df)
  }


  // 统计所有指标
  def get_all_index(): (DataFrame, DataFrame, Int) = {  // 修改
    val (all_data_df_history, all_data_df_yesterday) = get_df()
    val day_length = judge_time_interval(all_data_df_history)
    if (day_length >= min_time_interval){
      val (all_index_history, all_index_yesterday) = stat_index(all_data_df_history, all_data_df_yesterday)

      (all_index_history, all_index_yesterday, day_length)
    }else{
      (null, null, 0)
    }
  }
}
