package com.nanas.util

import org.apache.commons.lang3.math.NumberUtils
import scala.collection.mutable

/**
 * @author : hld
 * @Date ： 2021/4/23
 * @Time : 14:30
 * @role ： 
 */
class ParameterTool {

  val NO_VALUE_KEY: String = "__NO_VALUE_KEY";

  def fromArgs(args: Array[String]): mutable.HashMap[String, String] = {
    val map = new mutable.HashMap[String, String]()

    var i = 0
    while (i < args.length) {
      val key: String = getKeyFromArgs(args, i);

      if (key.isEmpty) {
        throw new IllegalArgumentException(
          "The input " + args.toString + " contains an empty argument");
      }

      i += 1; // try to find the value

      if (i >= args.length) {
        map.put(key, NO_VALUE_KEY);
      } else if (NumberUtils.isNumber(args(i))) {
        map.put(key, args(i));
        i += 1;
      } else if (args(i).startsWith("--") || args(i).startsWith("-")) {
        // the argument cannot be a negative number because we checked earlier
        // -> the next argument is a parameter name
        map.put(key, NO_VALUE_KEY);
      } else {
        map.put(key, args(i));
        i += 1;
      }
    }
    map
  }


  def getKeyFromArgs(args: Array[String], index: Int): String = {
    var key: String = null
    if (args(index).startsWith("--")) {
      key = args(index).substring(2);
    } else if (args(index).startsWith("-")) {
      key = args(index).substring(1);
    } else {
      throw new IllegalArgumentException(
        String.format("Error parsing arguments '%s' on '%s'. Please prefix keys with -- or -.",
          args.mkString("Array(", ", ", ")")))
    }

    if (key.isEmpty) {
      throw new IllegalArgumentException(
        "The input " + args.mkString("Array(", ", ", ")") + " contains an empty argument");
    }

    key
  }

}
