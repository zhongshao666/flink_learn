package com.nanas.spark
import java.io.ByteArrayInputStream

import com.nanas.util.{ParameterTool, ZKUtil}
import java.util.Properties

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import com.alibaba.fastjson.{JSON, JSONObject}

object AnomalyAccountDetect {
  //屏蔽日志
  Logger.getLogger("org.apache.spark").setLevel(Level.WARN)
  Logger.getLogger("org.eclipse.jetty.server").setLevel(Level.OFF)

  def main(args: Array[String]): Unit = {
    println("task start......")
    // 创建SparkSession实例
    val ss = SparkSession.builder().appName("AnomalyAccountDetect").getOrCreate()
//    val ss = SparkSession.builder().appName("AnomalyAccountDetect").master("local[*]").getOrCreate()

    // 定义模型中的常量
    val data_type = "02"  // 时间序列的数据源，01为数据库审计，02为API审计
    val model_type = "05"  // 模型类型，01为复杂网络，02为横向移动攻击，03为时间序列总流量，04为时间序列敏感数据流量，05为失陷账号检测
    val obj_type = "account"  // 第二种黑名单对象，包括ip，账号，MAC，HOST
    val obj_code = "02"  // 黑名单对象的编码
    val db_type = "01"  // 更新的表所在的数据库类型，01为MySQL，02为ClickHouse
    val status = 1  // 0表示失败，1表示成功

    // 从ZK获取项目的公共配置
    val parameter_tool = new ParameterTool
    val map = parameter_tool.fromArgs(args)
    val properties = new Properties
    val zk_public_client = ZKUtil.get_zk_client(map.getOrElse("zkAddr", ""))
    val prop_str: String = zk_public_client.readData(map.getOrElse("zkPath", ""))
    properties.load(new ByteArrayInputStream(prop_str.getBytes()))

    val ck_host: String = properties.getProperty("clickhouse.host")
    val ck_port: String = properties.getProperty("clickhouse.port")
    val ck_user: String = properties.getProperty("clickhouse.access.user")
    val ck_password: String = properties.getProperty("clickhouse.access.password")
    val ck_database: String = properties.getProperty("clickhouse.dm.database")
    val ck_table: String = properties.getProperty("clickhouse.lost.account.table")

    val mysql_host: String = properties.getProperty("mysql.host")
    val mysql_port: String = properties.getProperty("mysql.port")
    val mysql_user: String = properties.getProperty("mysql.user")
    val mysql_password: String = properties.getProperty("mysql.password")
    val mysql_database: String = properties.getProperty("mysql.dm.database")
    val mysql_table: String = properties.getProperty("mysql.blacklist.table")

    val zk_private_host: String = properties.getProperty("zookeeper.url")
    val zk_private_path: String = properties.getProperty("zookeeper.model.apisj.lost.account.path")
    val zk_notice_path: String = properties.getProperty("zookeeper.model.blacklist.listen.path")

    // 从ZK获取模型的特有参数
//    val zk_private_host: String = "192.168.24.73:2181"
//    val zk_private_path: String = "/apisj_audit/apisj/model/sxzh"
    val zk_private_client = ZKUtil.get_zk_client(zk_private_host)
    val config_str: String = zk_private_client.readData(zk_private_path)
    val config_json = JSON.parseObject(config_str)
    // 数据长度
    val data_config = config_json.getJSONObject("data_config")
    val max_date_length = data_config.getIntValue("max_date_length")
    val min_date_length = data_config.getIntValue("min_date_length")
    // 孤立森林参数
    val iforest_config = config_json.getJSONObject("iforest_config")
    val num_trees = iforest_config.getIntValue("num_trees")
    val max_samples = iforest_config.getDoubleValue("max_samples")
    val max_features = iforest_config.getDoubleValue("max_features")
    val max_depth = iforest_config.getIntValue("max_depth")
    val contamination = iforest_config.getDoubleValue("contamination")
    val bootstrap = iforest_config.getBooleanValue("bootstrap")
    val seed = iforest_config.getLongValue("seed")
    // 判断参数
    val judge_config = config_json.getJSONObject("judge_config")
    val threshold = judge_config.getDoubleValue("threshold")

    // 执行处理逻辑
    if (max_date_length >= min_date_length && min_date_length > 0) {
      // 提取指标
      val ck_url = "jdbc:clickhouse://" + ck_host + ":" + ck_port + "/" + ck_database
      val ti = new TestIndex(ss, max_date_length, min_date_length, ck_url, ck_user, ck_password, ck_table)
      val (all_index_history, all_index_yesterday, day_length) = ti.get_all_index()

      if (all_index_history != null && all_index_yesterday != null) {
        println("----all_index_history----")
        all_index_history.show(20)
        println("----all_index_yesterday----")
        all_index_yesterday.show(20)
        if (all_index_yesterday.count >= 2) {
          val join_df = all_index_history.join(all_index_yesterday, Seq("account"), "inner")
          val stat_anomaly_df = JudgeAnomaly.judge_anomaly(join_df, ss, day_length) // 根据自身历史行为判断异常
          val if_anomaly_df = IsolationForest.isolation_forest(all_index_yesterday,
            ss,
            num_trees,
            max_samples,
            max_features,
            max_depth,
            contamination,
            bootstrap,
            seed) // 根据孤立森林判断异常
          val anomaly_df = stat_anomaly_df.join(if_anomaly_df, Seq("account"), "inner")
          println("----stat_anomaly_df----")
          stat_anomaly_df.show(20)
          println("----if_anomaly_df----")
          if_anomaly_df.show(20)

          val anomaly_account = get_anomaly_account(anomaly_df, ss, data_type, model_type, obj_code, threshold)
          anomaly_account.show(20)

          if (!anomaly_account.head(1).isEmpty) {
            // 保存异常账号到mysql
            println("----save data to mysql----")
//            val prop = new Properties()
//            prop.setProperty("user", mysql_user)
//            prop.setProperty("password", mysql_password)
//            anomaly_account.write.mode(SaveMode.Append).jdbc(mysql_url, mysql_table, prop)
            val mysql_url = "jdbc:mysql://" + mysql_host + ":" + mysql_port + "/" + mysql_database
            anomaly_account.write.format("jdbc")
              .option("url", mysql_url)
              .option("dbtable",  mysql_table)
              .option("driver", "com.mysql.jdbc.Driver")
              .option("user", mysql_user)
              .option("password", mysql_password)
              .mode(SaveMode.Append)
              .save()
            println("----save succeed----")
            // 更新zk
            println("----update zk----")
            val index_id = data_type + model_type + obj_code
            if (!zk_private_client.exists(zk_notice_path + "/" + index_id)) {
              zk_private_client.createPersistent(zk_notice_path, true)
            }
            val result = new JSONObject()
            result.put("indexID", "020502")
            result.put("dateTime", System.currentTimeMillis())
            result.put("status", status)
            result.put("dbtype", db_type)
            zk_private_client.writeData(zk_notice_path, result.toJSONString)
            println("----update succeed----")
          }
        } else {
          println("the count of account is only one.")
        }
      } else {
        println("the length of data is smaller than min time interval.")
      }
    } else {
      println("max time interval or min time interval do not meet the requirements.")
    }
    println("task is finished!")
  }

  def get_anomaly_account(df: DataFrame, ss: SparkSession, data_type: String, model_type: String,
                          obj_code: String, thd: Double): DataFrame = {
    df.createOrReplaceTempView("dfView")
    val anomaly_account = ss.sql(
      s"""
         |select
         |${data_type} as dataType,
         |${model_type} as modelType,
         |${obj_code} as blackType,
         |account as typeValue,
         |cast(current_date as string) as updateDate
         |from dfView
         |where (operation_time_anomaly = true or login_times_anomaly = true or operation_ip_anomaly = true or
         |operation_times_anomaly = true) and (req_method_anomaly = true or visit_sensitive_data_times_anomaly = true or
         |interface_id_anomaly = true or sum_traffic_anomaly = true)
         |and anomalyScore > ${thd}
         |""".stripMargin)

    anomaly_account
  }
}
