package com.nanas.util

import org.apache.spark.sql.DataFrame
import redis.clients.jedis.Jedis


object RedisUtil {
  def getRedisConn(redis_args: Array[String]): Jedis = {
    val host = redis_args(0)
    val port = redis_args(1)
    val database = redis_args(2)
    val password = "secsmart"
    val redis = new Jedis(host, port.toInt)
    redis.auth(password)
    redis.select(database.toInt)  // 选择database
    redis
  }


  def save_df_to_redis(df: DataFrame, redis_args: Array[String], is_expire: Boolean, expire_time: Int): Unit = {
    df.foreachPartition(partition => {
      var conn:Jedis = null
      try {
        conn = getRedisConn(redis_args)
        partition.foreach(row => {
          val super_type = row.getAs[String]("super_type")
          val sub_type = row.getAs[String]("sub_type")
          val time_flag = row.getAs[String]("time_flag")
          val client_info = row.getAs[String]("client_info")
          val dataentity = row.getAs[String]("dataentity")
          val key = super_type + "&_" + sub_type + "&_" + time_flag + "&_" + client_info
          conn.set(key, dataentity)
          if (is_expire) {
            conn.expire(key, expire_time)  // 设置过期时间
          }
        })
      }
      catch {
        case e: Exception =>
          e.printStackTrace()
      }
      finally {
        if (conn != null) {
          conn.disconnect()
        }
      }
    })
  }

}