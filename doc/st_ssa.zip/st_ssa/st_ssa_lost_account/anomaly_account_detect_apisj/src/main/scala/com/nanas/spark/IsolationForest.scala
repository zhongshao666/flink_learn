package com.nanas.spark

import org.apache.spark.ml.Pipeline
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.ml.iforest.IForest
import org.apache.spark.sql.{DataFrame, SparkSession}

// 使用孤立森林算法进行训练
object IsolationForest {
  def isolation_forest(dataset: DataFrame,
                       ss: SparkSession,
                       num_trees: Int,
                       max_samples: Double,
                       max_features: Double,
                       max_depth: Int,
                       contamination: Double,
                       bootstrap: Boolean,
                       seed: Long): DataFrame = {
    val processed_dataset = process_data(dataset, ss)  // 特征提取
    val columns = processed_dataset.columns  // 获取列名
    val feature_columns = (columns.toBuffer - "account").toArray  // 提取特征列

    // 输入到孤立森林模型的数据必须有features列或者VectorAssembler得到的列
    val assembler = new VectorAssembler()
      .setInputCols(feature_columns)
      .setOutputCol("features")

    // 设置模型参数
    val if_model = new IForest()
      .setNumTrees(num_trees)
      .setMaxSamples(max_samples)
      .setMaxFeatures(max_features)
      .setMaxDepth(max_depth)
      .setContamination(contamination)
      .setBootstrap(bootstrap)
      .setSeed(seed)


    // 设置pipeline
    val pipeline = new Pipeline().setStages(Array(assembler, if_model))

    // 训练模型

    val model = pipeline.fit(processed_dataset)

    // 模型预测
    val predictions = model.transform(processed_dataset)

    predictions
  }
  
  def process_data(df: DataFrame, ss: SparkSession): DataFrame = {
    import ss.implicits._
    val processed_df = df.map(row => {
      val account = row.getAs[String]("account")
      val operation_time_yesterday = row.getAs[String]("operation_time_yesterday")
//      val login_app_yesterday = row.getAs[String]("login_app_yesterday")
      val login_times_yesterday = row.getAs[String]("login_times_yesterday")
      val operation_ip_yesterday = row.getAs[String]("operation_ip_yesterday")
      val operation_times_yesterday = row.getAs[String]("operation_times_yesterday")
      val req_method_yesterday = row.getAs[String]("req_method_yesterday")
      val visit_sensitive_data_times_yesterday = row.getAs[String]("visit_sensitive_data_times_yesterday")

      
      val operation_time_count = if (operation_time_yesterday != null) {operation_time_yesterday.split(",").length} else {0}
//      val login_app_count = if (login_app_yesterday != null) {login_app_yesterday.split(",").length} else {0}
      val login_times_count = if (login_times_yesterday != null) {login_times_yesterday.toInt} else {0}
      val operation_ip_count = if (operation_ip_yesterday != null) {operation_ip_yesterday.split(",").length} else {0}
      val operation_times_count = if (operation_times_yesterday != null) {operation_times_yesterday.toInt} else {0}
      val req_method_yesterday_count = if (req_method_yesterday != null) {req_method_yesterday.length} else {0}
      val visit_sensitive_data_times_count = if (visit_sensitive_data_times_yesterday != null) {visit_sensitive_data_times_yesterday.toInt} else {0}

      (account, operation_time_count, login_times_count, operation_ip_count, operation_times_count,
        req_method_yesterday_count, visit_sensitive_data_times_count)
    }).toDF("account", "operation_time_count", "login_times_count", "operation_ip_count",
      "operation_times_count", "req_method_yesterday_count", "visit_sensitive_data_times_count")

    processed_df
  }
}
