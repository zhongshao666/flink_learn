package com.nanas.spark

import com.alibaba.fastjson.JSONObject
import org.I0Itec.zkclient.ZkClient

object zkParameter {
  def main(args: Array[String]): Unit = {
    //以Json格式定义参数
    val params = new JSONObject()

    val data_config = new JSONObject()
    data_config.put("max_date_length", 90)  // 历史数据的最大日期长度，以天为单位
    data_config.put("min_date_length", 1)  // 历史数据的最小日期长度，以天为单位
    val iforest_config = new JSONObject()
    iforest_config.put("num_trees", 128)  // 孤立森林中树的数量
    iforest_config.put("max_samples", 1) // 训练树的最大样本量所占的比例，范围[0,1]
    iforest_config.put("max_features", 0.8)  // 训练树的最大特征量所占的比例，范围[0,1]
    iforest_config.put("max_depth", 20)  // 树的最大深度
    iforest_config.put("contamination", 0.1)  // 数据集中异常值的比例，范围[0,1]
    iforest_config.put("bootstrap", "false")  // 是否采取自助采样法，true, false
    iforest_config.put("seed", 1)  // 随机种子，Long型
    val judge_config = new JSONObject()
    judge_config.put("threshold", 0.5)  // 异常分数的阈值，范围(0, 1)
    val ck_config = new JSONObject()
    ck_config.put("ck_url", "jdbc:clickhouse://192.168.24.73:8123/dm_st_ssa")  // 连接ck的url
    ck_config.put("ck_user", "default")  // ck用户名
    ck_config.put("ck_password", "123456")  // ck密码
    ck_config.put("ck_table", "dm_nml_ueba_sxzh")  // ck表名
    val mysql_config = new JSONObject()
    mysql_config.put("mysql_url", "jdbc:mysql://192.168.24.40:3306/dm_st_ssa")  // 连接mysql的url
    mysql_config.put("mysql_user", "root")  // mysql用户名
    mysql_config.put("mysql_password", "zzb503399!")  // mysql密码
    mysql_config.put("mysql_table", "dm_nml_ueba_blacklist")  // mysql表名

    params.put("data_config", data_config)
    params.put("iforest_config", iforest_config)
    params.put("judge_config", judge_config)
    params.put("ck_config", ck_config)
    params.put("mysql_config", mysql_config)

    val otherParas = params.toString()

    //将参数直接作为ZooKeeper节点
    val zk_host = "192.168.24.73:2181"
    val zk_params_path: String = "/apisj_audit/apisj/model/sxzh"
    val zkClient = new ZkClient(zk_host)
    zkClient.setZkSerializer(new MyZkSerializer)
    if (! zkClient.exists(zk_params_path)) {
      zkClient.createPersistent(zk_params_path, true)
    }
    zkClient.writeData(zk_params_path, otherParas)
  }

}
