package com.nanas.util

import com.nanas.spark.MyZkSerializer
import org.I0Itec.zkclient.ZkClient

object ZKUtil {
  def get_zk_client(zk_host: String): ZkClient = {
    val zk_client = new ZkClient(zk_host)
    zk_client.setZkSerializer(new MyZkSerializer)
    zk_client
  }
}
