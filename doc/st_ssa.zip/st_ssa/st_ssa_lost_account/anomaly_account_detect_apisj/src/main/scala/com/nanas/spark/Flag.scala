package com.nanas.spark

object Flag {
  private var argsMap = Map[String, Any]()
  var argsNum = 0

  // 解析参数
  def Parse(args: Array[String]): Unit = {
    var flag = false
    for (argLine <- args) {
      val argArr = argLine.split("=")
      if (argLine.startsWith("-") && argArr.length == 2) {
        flag = true
        argsMap += (argArr(0).drop(2) -> argArr(1))
      }
    }
    argsNum = this.argsMap.count(_ => true)
  }

  // 获取Int型参数
  def GetInt(key: String, default: Any = 0): Int = {
    argsMap.getOrElse(key, default).toString.toInt
  }

  // 获取Long型参数
  def GetLong(key: String, default: Any = 0): Long = {
    argsMap.getOrElse(key, default).toString.toLong
  }

  // 获取Double型参数
  def GetDouble(key: String, default: Any = 0): Double = {
    argsMap.getOrElse(key, default).toString.toDouble
  }

  // 获取Boolean型参数
  def GetBoolean(key: String, default: Any = 0): Boolean = {
    argsMap.getOrElse(key, default).toString.toBoolean
  }

  // 获取String型参数
  def GetString(key: String, default: Any = 0): String = {
    argsMap.getOrElse(key, default).toString
  }

}
