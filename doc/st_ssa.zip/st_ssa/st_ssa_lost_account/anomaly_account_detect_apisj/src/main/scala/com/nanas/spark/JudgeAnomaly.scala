package com.nanas.spark

import org.apache.spark.sql.{DataFrame, SparkSession}

object JudgeAnomaly {
  // 根据自身历史行为判断异常
  def judge_anomaly(all_df: DataFrame, ss: SparkSession, day_length: Int): DataFrame = {
    import ss.implicits._
    val anomaly_df = all_df.map(row => {
      val account = row.getAs[String]("account")
      val operation_time_history = row.getAs[String]("operation_time_history")
//      val login_app_history = row.getAs[String]("login_app_history")
      val login_times_history = row.getAs[String]("login_times_history")
      val operation_ip_history = row.getAs[String]("operation_ip_history")
      val operation_times_history = row.getAs[String]("operation_times_history")
      val req_method_history = row.getAs[String]("req_method_history")
      val visit_sensitive_data_times_history = row.getAs[String]("visit_sensitive_data_times_history")
      val interface_id_history = row.getAs[String]("interface_id_history")
      val sum_traffic_history = row.getAs[String]("sum_traffic_history")
      
      val operation_time_yesterday = row.getAs[String]("operation_time_yesterday")
//      val login_app_yesterday = row.getAs[String]("login_app_yesterday")
      val login_times_yesterday = row.getAs[String]("login_times_yesterday")
      val operation_ip_yesterday = row.getAs[String]("operation_ip_yesterday")
      val operation_times_yesterday = row.getAs[String]("operation_times_yesterday")
      val req_method_yesterday = row.getAs[String]("req_method_yesterday")
      val visit_sensitive_data_times_yesterday = row.getAs[String]("visit_sensitive_data_times_yesterday")
      val interface_id_yesterday = row.getAs[String]("interface_id_yesterday")
      val sum_traffic_yesterday = row.getAs[String]("sum_traffic_yesterday")

      // 判断登录时间是否异常
      val operation_time_anomaly = judge_in_anomaly(operation_time_history, operation_time_yesterday)
      
      // 判断登录APP是否异常
//      val login_app_anomaly = judge_in_anomaly(login_app_history, login_app_yesterday)

      // 判断登录次数是否异常
      val login_times_anomaly = judge_threshold_anomaly(login_times_history, login_times_yesterday, day_length)

      // 判断登录IP是否异常
      val operation_ip_anomaly = judge_in_anomaly(operation_ip_history, operation_ip_yesterday)

      // 判断访问次数是否异常
      val operation_times_anomaly = judge_threshold_anomaly(operation_times_history, operation_times_yesterday, day_length)

      // 判断请求方式是否异常
      val req_method_anomaly = judge_in_anomaly(req_method_history, req_method_yesterday)

      // 判断敏感数据访问次数是否异常
      val visit_sensitive_data_times_anomaly = judge_threshold_anomaly(visit_sensitive_data_times_history, visit_sensitive_data_times_yesterday, day_length)

      // 判断访问接口是否异常
      val interface_id_anomaly = judge_in_anomaly(interface_id_history, interface_id_yesterday)

      // 判断总流量是否异常
      val sum_traffic_anomaly = judge_threshold_anomaly(sum_traffic_history, sum_traffic_yesterday, day_length)

      (account, operation_time_anomaly, login_times_anomaly, operation_ip_anomaly, operation_times_anomaly,
        req_method_anomaly, visit_sensitive_data_times_anomaly, interface_id_anomaly, sum_traffic_anomaly)
    }).toDF("account", "operation_time_anomaly", "login_times_anomaly", "operation_ip_anomaly",
      "operation_times_anomaly", "req_method_anomaly", "visit_sensitive_data_times_anomaly", "interface_id_anomaly",
      "sum_traffic_anomaly")

    anomaly_df
  }


  // 判断昨天的行为是否在历史行为中的那些异常
  def judge_in_anomaly(string_history: String, string_yesterday: String): Boolean = {
    if (string_history == null || string_yesterday == null) {
      false
    } else {
      val set_history = string_history.split(",").toSet
      val set_yesterday = string_yesterday.split(",").toSet
      val set_diff = set_yesterday.diff(set_history)

      set_diff.nonEmpty
    }
  }


  // 判断基于历史行为设置阈值的那些异常
  def judge_threshold_anomaly(string_history: String, string_yesterday: String, day_length: Int): Boolean = {
    if (string_history == null || string_yesterday == null) {
      false
    } else {
      var all_array_history: Array[Int] = null
      val array_history = string_history.split(",").map(_.toInt)
      val diff_length = day_length - array_history.length
      if (diff_length > 0) {
        all_array_history = array_history.++(Array.fill(diff_length)(0))
      } else {
        all_array_history = array_history
      }
      val threshold_history = get_index_threshold(all_array_history)

      string_yesterday.toInt > threshold_history
    }
  }

  // 计算指标异常阈值
  def get_index_threshold(index_array: Array[Int]): Int = {
    try{
      val quantile1 = get_percentile(index_array, 0.25)
      val quantile2 = get_percentile(index_array, 0.75)
      (quantile2 + 1.5 * (quantile2 - quantile1)).toInt
    }
    catch{
      case e: Exception =>
        e.printStackTrace()
        val max_value = index_array.max
        (max_value * 1.5).toInt
    }
  }

  // 计算分位数
  def get_percentile(index_array: Array[Int], percentile: Double): Double = {
    if (index_array.length == 1) {
      index_array(0)
    }
    else {
      val sorted_array = index_array.sortWith(_<_)
      val percentile_ind = (index_array.length - 1) * percentile
      val percentile_int = math.floor(percentile_ind).toInt
      val percentile_remainder = percentile_ind - percentile_int

      sorted_array(percentile_int) + percentile_remainder * (sorted_array(percentile_int + 1) - sorted_array(percentile_int))
    }
  }
}
