package com.secsmart;

import com.alibaba.fastjson.JSON;
import com.secsmart.bean.AssetLog1;
import com.secsmart.transforms.MyMapJin2Json;
import com.secsmart.utils.CuratorOperator;
import com.secsmart.utils.KafkaSinkProp;
import com.secsmart.utils.KafkaSourceProp;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.api.GetDataBuilder;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer011;

import java.io.ByteArrayInputStream;
import java.util.Map;
import java.util.Properties;

public class DbsjTransformMain {

    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment executionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment();
        executionEnvironment.setRestartStrategy(RestartStrategies.fixedDelayRestart(1000,Time.seconds(3)));

//        String alarmslogs = "alarmlog";
//        String sourceurl = "192.168.24.201:9092";
//        String alarmslogsjson = "test";
//        String sinkurl = "192.168.24.75:9092,192.168.24.74:9092,192.168.24.73:9092";
//        String groupid = "nanas114";


        ParameterTool map = ParameterTool.fromArgs(args);
        Properties properties = new Properties();
        CuratorOperator mcto = null;
//        mcto = new CuratorOperator("192.168.24.73:2181");
        mcto = new CuratorOperator(map.get("zkAddr"));
        GetDataBuilder data = mcto.client.getData();
//        properties.load(new ByteArrayInputStream(data.forPath("/dbsj_audit/dbsj/job/config/riskflinkjob")));
        properties.load(new ByteArrayInputStream(data.forPath(map.get("zkPath"))));
        ParameterTool parameterTool = ParameterTool.fromMap((Map) properties);

        KafkaSinkProp kafkaSinkProp = new KafkaSinkProp();
        kafkaSinkProp.setBOOTSTRAP_SERVERS_CONFIG(parameterTool.get("kafka.sink.url"));

        KafkaSourceProp kafkaSourceProp = new KafkaSourceProp();

        kafkaSourceProp.setBOOTSTRAP_SERVERS_CONFIG(parameterTool.get("kafka.source.url"));
        kafkaSourceProp.setGROUP_ID_CONFIG( parameterTool.get("kafka.source.groupId"));

        FlinkKafkaConsumer011<String> flinkKafkaConsumer011 = new FlinkKafkaConsumer011<String>(parameterTool.get("kafka.source.topic"),new SimpleStringSchema(),kafkaSourceProp.getProp());

        FlinkKafkaProducer011<String> flinkKafkaProducer011 = new FlinkKafkaProducer011<String>(parameterTool.get("kafka.sink.topic"),new SimpleStringSchema(),kafkaSinkProp.getProp2());

        executionEnvironment.addSource(flinkKafkaConsumer011).map(new MyMapJin2Json()).addSink(flinkKafkaProducer011);

        executionEnvironment.execute("nanastransform");
    }
}
