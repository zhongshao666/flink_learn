package com.secsmart.transforms;

import com.alibaba.fastjson.JSON;
import com.secsmart.bean.AssetLog;
import com.secsmart.bean.AssetLog1;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.annotation.JsonAlias;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MyMapJin2Json implements MapFunction<String, String> {
    Logger logger = LoggerFactory.getLogger(MyMapJin2Json.class);

    public String map(String s) throws Exception {
        s=s.concat("#,#end");
        String[] values = s.split("#,#");
        AssetLog1 assetLog1 = new AssetLog1();
        assetLog1.setFirstId(Long.valueOf(values[0]));
        assetLog1.setSecondId(Long.valueOf(values[1]));
        assetLog1.setAssetId(Integer.valueOf(values[2]));
        assetLog1.setLogVersion(Integer.valueOf(values[3]));
        assetLog1.setSessionId(values[4]);

        assetLog1.setClientMac(values[5]);
        assetLog1.setClientIp(values[6]);
        assetLog1.setClientPort(Integer.valueOf(values[7]));
        assetLog1.setServerMac(values[8]);

        assetLog1.setServerIp(values[9]);
        assetLog1.setServerPort(Integer.valueOf(values[10]));
        assetLog1.setRequestTime(Long.valueOf(values[11]));
        assetLog1.setRequestTimeUsec(Integer.valueOf(values[12]));
        assetLog1.setMinuteTime(Integer.valueOf(values[13]));
        assetLog1.setRequestMicrosecond(Long.valueOf(values[14]));

        assetLog1.setExecuteTime(Long.valueOf(values[15]));
        assetLog1.setRequestStatus("".equals(values[16])?0:Integer.parseInt(values[16]));
        assetLog1.setAccount(values[17]);
        assetLog1.setOsUserName(values[18]);
        assetLog1.setRiskType(values[19]);
        List<String> lists1 = JSON.parseArray(values[20],String.class);
        assetLog1.setMatchedRules(lists1);
        assetLog1.setRiskLevel(Integer.valueOf(values[21]));
        assetLog1.setProtectOperate(Integer.valueOf(values[22]));
        assetLog1.setInstanceName(values[23]);
        assetLog1.setClientApp(values[24]);
        assetLog1.setClientHost(values[25]);
        assetLog1.setOperationStatement(values[26]);
        List<List> lists2 = JSON.parseArray(values[27], List.class);
        assetLog1.setBindingVariables(lists2);

        assetLog1.setStatementPattern(values[28]);
        List<List> lists = JSON.parseArray(values[29], List.class);
        assetLog1.setReply(lists);
        assetLog1.setErrorReply(values[30]);
        assetLog1.setRowsAffected(Integer.valueOf(values[31]));
        assetLog1.setOperationType(Integer.valueOf(values[32]));
        assetLog1.setOperationCommand(values[33]);

        assetLog1.setOperandType(values[34]);
        if(values[35]!=null&&!"".equals(values[35])){
            assetLog1.setOperandName(Arrays.asList(values[35].split(",")));
        }else{
            assetLog1.setOperandName(new ArrayList<>());
        }
        if(values[36]!=null&&!"".equals(values[36])){
            assetLog1.setSecondOperandName(Arrays.asList(values[36].split(",")));
        }else{
            assetLog1.setSecondOperandName(new ArrayList<>());
        }

        assetLog1.setWebUserName(values[37]);
        assetLog1.setWebUrl(values[38]);
        return JSON.toJSONString(assetLog1);
    }
}
