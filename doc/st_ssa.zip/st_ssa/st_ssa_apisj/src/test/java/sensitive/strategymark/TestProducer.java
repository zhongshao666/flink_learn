package sensitive.strategymark;

import com.alibaba.fastjson.JSON;
import com.ssa.sensitive.to.HttpLog;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.junit.Ignore;
import org.junit.Test;

import java.util.Properties;

@Ignore
public class TestProducer {

    private static Properties kafkaProps;

    private static void initKafka() {
        kafkaProps = new Properties();
        // broker url
        //在默认kafka的单节点配置时，不能使用IP，而是使用localhost进行连接，否则会连接异常。
        //用于初始化时建立链接到kafka集群，以host:port形式，多个以逗号分隔host1:port1,host2:port2；
        kafkaProps.put("bootstrap.servers", "192.168.24.251:9092"); //,192.168.216.139:9092,192.168.216.140:9092
        // 请求需要验证
        //生产者需要server端在接收到消息后，进行反馈确认的尺度，主要用于消息的可靠性传输；acks=0表示生产者不需要来自server的确认；acks=1表示server端将消息保存后即可发送ack，而不必等到其他follower角色的都收到了该消息；acks=all(or acks=-1)意味着server端将等待所有的副本都被接收后才发送确认。
        kafkaProps.put("acks", "all");
        // 请求失败的尝试次数
        //:生产者发送失败后，重试的次数 batch.size:当多条消息发送到同一个partition时
        kafkaProps.put("retries", 0);
        // 缓存大小
        kafkaProps.put("batch.size", 65536);
        //:默认情况下缓冲区的消息会被立即发送到服务端，即使缓冲区的空间并没有被用完。可以将该值设置为大于0的值，这样发送者将等待一段时间后，再向服务端发送请求，以实现每次请求可以尽可能多的发送批量消息。
        kafkaProps.put("linger.ms", 1);
        //生产者缓冲区的大小，保存的是还未来得及发送到server端的消息，如果生产者的发送速度大于消息被提交到server端的速度，该缓冲区将被耗尽。
        kafkaProps.put("buffer.memory", 134217728);//33554432
        //定义的key和value序列化器
        //说明了使用何种序列化方式将用户提供的key和vaule值序列化成
        kafkaProps.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        kafkaProps.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
    }

    @Test
    @Ignore
    public  void testProducer() {

        initKafka();
        Producer<String, String> producer = new KafkaProducer<>(kafkaProps);


        HttpLog httpLog = new HttpLog();
        httpLog.setAppId(22810L);
        httpLog.setEventType(1);
        httpLog.setHasSensitive(true);
        httpLog.setUserName("root");
        httpLog.setInterfaceId(System.currentTimeMillis());
        httpLog.setInterfaceId(1309L);
        httpLog.setHttpMethod("POST");
        httpLog.setHasSensitive(true);
        httpLog.setRequestBody("password  Building CXX object shadow reply sensitive CMakeFiles");
        httpLog.setRequestTime(System.currentTimeMillis());  //1618200233000L
        httpLog.setClientTool("jdbc");
        httpLog.setSensitiveLabelField("china_name,cell_phone,mtp_for_hkmacao");
        httpLog.setSensitiveLevel("S1");

        String s = JSON.toJSONString(httpLog);

        HttpLog httpLog1 = JSON.parseObject(s, HttpLog.class);
        System.out.println(httpLog1);

        producer.send(new ProducerRecord<String, String>("test1", s));
        producer.close();


        System.out.println("success");
    }
}

