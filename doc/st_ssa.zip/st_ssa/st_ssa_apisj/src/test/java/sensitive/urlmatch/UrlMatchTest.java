package sensitive.urlmatch;

import com.google.common.base.Stopwatch;
import com.ssa.sensitive.urlmatch.UrlMatch;
import org.junit.Test;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author qsj
 * @since 2021/1/20
 */
public class UrlMatchTest {
    @Test
    public void testMatch() {
        AtomicInteger count = new AtomicInteger(0);
        UrlMatch urlMatch = new UrlMatch();
        for (int i = 0; i < 200; i++) {
            urlMatch.addInterface("/admin" + i + "/test" + i + "/add", count.getAndIncrement());
            urlMatch.addInterface("/admin" + i + "/test" + i + "/modify", count.getAndIncrement());
            urlMatch.addInterface("/admin" + i + "/test" + i + "/del", count.getAndIncrement());
            urlMatch.addInterface("/admin" + i + "/test" + i + "/search", count.getAndIncrement());
            urlMatch.addInterface("/admin" + i + "/test" + i + "/get", count.getAndIncrement());
        }

        urlMatch.addInterface("/admin*/test*/sss",5000);

        Stopwatch stopwatch = Stopwatch.createStarted();
        for (int i = 0; i < 20; i++) {
            System.out.println(urlMatch.match("/admin119/test11/search"));
        }
        stopwatch.stop();
        System.out.println(stopwatch.elapsed(TimeUnit.MILLISECONDS));

    }
}
