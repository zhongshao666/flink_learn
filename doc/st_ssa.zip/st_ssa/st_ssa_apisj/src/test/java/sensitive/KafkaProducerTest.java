/*
package sensitive;


import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.PartitionInfo;
import org.junit.Ignore;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.concurrent.TimeUnit;

*/
/**
 * @author qsj
 * @since 2021/1/26
 *//*

public class KafkaProducerTest {

    @Test
    @Ignore
    public void  testKafkaProduce(){
        KafkaSinkProp sinkProp = new KafkaSinkProp();
        sinkProp.setBOOTSTRAP_SERVERS_CONFIG("192.168.24.251:9092");

        String topic = "rt_http_log_bd";

        Producer<String,String> producer = new KafkaProducer<>(sinkProp.getProp());

        for (int i = 0; i < 10; i++) {
            ProducerRecord<String,String> msg = new ProducerRecord<>(topic,getValueFromFile());
            producer.send(msg);
        }


        List<PartitionInfo> partitionInfos = producer.partitionsFor(topic);
        for (PartitionInfo info : partitionInfos) {
            System.out.println(info);
        }

        producer.close(100, TimeUnit.MILLISECONDS);
        System.out.println("ignore test");
    }

    private String getValueFromFile(){
        StringBuilder sb = new StringBuilder();
        try (InputStream in = new FileInputStream("C:\\Users\\admin\\Desktop\\test-json.txt"); InputStreamReader inputStreamReader = new InputStreamReader(in); BufferedReader bufferedReader = new BufferedReader(inputStreamReader)) {
            int current;
            while ((current = bufferedReader.read()) != -1) {
                char currentChar = (char) current;
                sb.append(currentChar);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return sb.toString();
    }


    public void getKafkaStatus(){
        KafkaSinkProp sinkProp = new KafkaSinkProp();
        sinkProp.setBOOTSTRAP_SERVERS_CONFIG("192.168.24.251:9092");

        String topic = "rt_http_log_bd";
    }
}
*/
