package sensitive.match;

import com.google.common.base.Stopwatch;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.secsmart.sensitive.discovery.MultiMatch;
import com.secsmart.sensitive.discovery.MultiMatchImpl;
import com.ssa.sensitive.match.DefaultJsonReader;
import com.ssa.sensitive.match.TagMaskVisitor;
import com.ssa.sensitive.parse.HttpLogParse;
import com.ssa.sensitive.to.HttpLog;
import jodd.lagarto.LagartoParser;
import org.junit.Ignore;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static com.google.gson.stream.JsonToken.END_DOCUMENT;


/**
 * @author qsj
 * @since 2021/1/13
 */
public class HttpMatchTest {

    public static Map<String, AtomicInteger> counterMap = Maps.newHashMap();

    @Test
    @Ignore
    public void testMatch() {
        doMatch();
    }

    private void doMatch() {

        try (InputStream in = new FileInputStream("C:\\Users\\admin\\Desktop\\202101\\testjson-2.txt")) {
            HttpLog httpLog = HttpLogParse.streamParse(in, 1L);

            MultiMatch match = new MultiMatchImpl();
            //解析并识别response
            Stopwatch stopwatch = Stopwatch.createStarted();
            for (int i = 0; i < 1000; i++) {
                parseAndMatchData(httpLog, match);
            }
            stopwatch.stop();
            System.out.println(stopwatch.elapsed(TimeUnit.MILLISECONDS));
            System.out.println(counterMap);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * 每一种类型进行测试优化
     */
    @Test
    public void testMulitMatch() {
        MultiMatch match = new MultiMatchImpl();

//        ArrayList<String> list = Lists.newArrayList("张三", "13685771245", "浙江省杭州市余杭区未来科技城1号", "zhangsan@secsmart.com","杭州通讯研究会","J4JHFVHP9PR53CW6D");
        ArrayList<String> list = Lists.newArrayList("0572-8979888");
//        ArrayList<String> list = Lists.newArrayList("张三", "13685771245", "浙江省杭州市余杭区未来科技城1号", "zhangsan@secsmart.com");

        Stopwatch stopwatch = Stopwatch.createStarted();
        for (int i = 0; i < 1; i++) {

            for (String s : list) {
                System.out.println(s + ":" + match.match(s));
            }
        }
        stopwatch.stop();
        System.out.println(stopwatch.elapsed(TimeUnit.MILLISECONDS));
        System.out.println(counterMap);
    }

    private void parseAndMatchData(HttpLog httpLog, MultiMatch matchAll) {
        if (isJson(httpLog.getResponseBody())) {
            jsonParse(httpLog, matchAll);
        } else {
            htmlParse(httpLog, matchAll);
        }
    }

    /**
     * 判断内容第一个字符是否符合json格式符合则使用json进行解析
     *
     * @param val
     * @return
     */
    private boolean isJson(String val) {
        for (char c : val.toCharArray()) {
            if (c == ' ') {
                continue;
            }
            if (c == '\r') {
                continue;
            }
            if (c == '\n') {
                continue;
            }
            return c == '{' || c == '[';
        }
        return false;
    }

    /**
     * html 解析并识别
     *
     * @param httpLog
     * @param matchAll
     */
    private void htmlParse(HttpLog httpLog, MultiMatch matchAll) {
        LagartoParser lagartoParser = new LagartoParser(httpLog.getResponseBody());
        TagMaskVisitor visitor = new TagMaskVisitor();
        lagartoParser.parse(visitor);
        visitor.getValueList()
               .forEach(matchAll::match);
    }

    /**
     * json解析并识别
     *
     * @param httpLog
     * @param matchAll
     */
    private void jsonParse(HttpLog httpLog, MultiMatch matchAll) {
        try (InputStream inputStream = new ByteArrayInputStream(httpLog.getResponseBody()
                                                                       .getBytes());
             InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
             JsonReader reader = new DefaultJsonReader(inputStreamReader)) {

            reader.setLenient(true);
            JsonToken token;
            while ((token = reader.peek()) != END_DOCUMENT) {
                switch (token) {
                    case BEGIN_ARRAY:
                        reader.beginArray();
                        break;
                    case END_ARRAY:
                        reader.endArray();
                        break;
                    case BEGIN_OBJECT:
                        reader.beginObject();
                        break;
                    case END_OBJECT:
                        reader.endObject();
                        break;
                    case NAME:
                        reader.nextName();
                        break;

                    case STRING:
                    case NUMBER:
                        String value = reader.nextString();
                        matchAll.match(value);
                        break;

                    case BOOLEAN:
                        reader.nextBoolean();
                        break;

                    case NULL:
                        reader.nextNull();
                        break;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
