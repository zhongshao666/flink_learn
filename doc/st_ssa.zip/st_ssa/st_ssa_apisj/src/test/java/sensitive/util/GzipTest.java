package sensitive.util;

import com.ssa.sensitive.util.GzipUtils;
import org.junit.Test;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Optional;

/**
 * @author qsj
 * @since 2021/2/1
 */
public class GzipTest {

    @Test
    public void testGzUngz(){
        String test = "{ \"data\":[ { \"id\":1, \"name\":\"张三\", \"phone\":\"13685771245\", \"address\":\"浙江省杭州市余杭区未来科技城1号\", \"email\":\"zhangsan@secsmart.com\" }, { \"id\":2, \"name\":\"张三是\", \"phone\":\"13685771246\", \"address\":\"浙江省杭州市余杭区未来科技城2号\", \"email\":\"zhangsanshi@secsmart.com\" }]}";

        byte[] compress = GzipUtils.compress(test,StandardCharsets.UTF_8);
        Optional.ofNullable(compress).ifPresent(item->System.out.println(new String(item)));
        String s = Base64.getEncoder()
                         .encodeToString(compress);
        System.out.println(s);
        byte[] uncompress = GzipUtils.uncompress(Base64.getDecoder().decode(s));
        Optional.ofNullable(uncompress).ifPresent(item-> System.out.println(new String(item)));
    }

    @Test
    public void testBase64DecodeUncompress(){
        String dd = "H4sIAAAAAAAAA62VS4+bVhTH9/kUrqXpzjP3Xh42nfFUNjYY2/gBBoOjyOJlbAMGGwzYX6dfIItkZlF1M8kyVdQki2oWrdSq6qZSF+2iy17PpIqqTqKROoh74J5zQPf/O+fCWewWkl3kVIugWDC21eI8SaL4i5OTLMuO49ANt8dWGJzEbvil7+VV8LkRRKd+HtrVYsHB6e/njlGlS6jElCA4hsfgmCQJUCJKbI8gACzBEsCjTLMURCyqUxUS1Tm2SUDYqNUQgSDNkix+liL/ef26ahfPH505ePiFebUIiwX7Zonp5uZya+ObQHKwODEpJNGNGy8LTGlyCqclOL1dsbPGuYU4qxZTWe7Ocj1aHSGOqFvdLJQSWlowTsao1NqIWn1ophITEmKaRkli7DQ1D3gQVnC+nDUWuZAY+FbUN1t2HDDGShKXTZKv2BnLtYWy39+ygS2Q8WZk0rMuzuRahDCU5zV/i7xla7HvBTDRAqK8QpKG4Ho/OUL1fGmH85lzuOtnR0QDn7caSxAVz8+yg9JTeHpz4Plnj9lGbVR7/Pz6zddRlLz86ukv3/714qfL715fvfv+yZPzs5MMjwQzOfEPxvk/KOFHUYJxs4GXrPiMZ8m+KkQ1heTyuaxB1YeKF8Wiika2j1OslYVJKK3FiId4Gixn2OpoFmZLstEjQ22cj0Xsisp+t80rJiHWFo7uzNFSlE3sF3ma4oXhyMv65lICH/Awn6Dz7PeX1++uX/+YBGFoPTQVdEsFgftS0bBkLsIBiYkHO301pzhBNDPRqNWCXbrq40iz0W8ZMKvTcAAMiTRn9YCsgO4Gh5Y83dcEw8l7tX+1x6e646D/oWUTU7yFp2BK/Uc2qZjqwJ97O2NtMMDj67SMcmCjhjDhWiMrpBzBNDXZJ72+mEZtpccPJWrDeYyzMmkrGGI6rqzactMbAXIiE/zOh8l620kE05ZmS2pT1qxwu8dptr9puh8QkJ9AcHF59cOzP66+eWgMuPSVu6svVALU3DqEppm9hZQwIBjykd336NhvtX3WnQlDH5WZ3NAOfY0ifzVvLLaTzmDEQeLgGnNL1eyNZ0aYpA0qFNNcGYc5nGT3rvvF5dufH1owdSv4jo+AKwyaXUVXOwyb+U1FVGmOY3v7PlirO5hncEIJDU5Ck1xPO2BXTixpCOZcJu/T7o5cDGxbJ6IJGHRYZJYHqT0ZDMKczMqu0Cq36nxOxTA0eq14P47j+9X8+a9vn7767dWLh0ZAv2/9uxh0aF93yiOqvmD0zZ6Mhm0rDqwNYceonUsqaNeysc+Zbp1V1LrI7nTcxt7EyejVhK7ESz6hLMol2dZw6IYUbgLXWw8yJdbvv9kvLt78+RHF+Od9/uhv";
        byte[] uncompress = GzipUtils.uncompress(Base64.getDecoder().decode(dd));
        Optional.ofNullable(uncompress).ifPresent(item-> System.out.println(new String(item)));

        String test = "eyJpbmZvIjp7Im5hbWUiOiJnaXRsYWItY2ktbXVsdGktcnVubmVyIiwidmVyc2lvbiI6IjkuNS4xIiwicmV2aXNpb24iOiI5NmIzNGNjIiwicGxhdGZvcm0iOiJsaW51eCIsImFyY2hpdGVjdHVyZSI6ImFtZDY0IiwiZXhlY3V0b3IiOiJzaGVsbCIsImZlYXR1cmVzIjp7InZhcmlhYmxlcyI6dHJ1ZSwiaW1hZ2UiOmZhbHNlLCJzZXJ2aWNlcyI6ZmFsc2UsImZlYXR1cmVzIjpmYWxzZSwiY2FjaGUiOmZhbHNlfX0sInRva2VuIjoiWDYxZzVldXdoR1JSeTdCN3Nfa0MiLCJsYXN0X3VwZGF0ZSI6ImNhOGJiZGY3OWU3NzllZDkxYzEwMWI2NzBmNWY0YzVmIn0=";
        byte[] decode = Base64.getDecoder()
                              .decode(test);
        Optional.ofNullable(decode).ifPresent(item-> System.out.println(new String(item)));
    }


    @Test
    public void testBase64Decode(){
        String tt = "H4sIAAAAAAAAAKtWUEpJLElUsopWqFZQykxRsjLUUVDKS8xNVbJSerpnwZMdnUpAgYKM/DyQiKGxmYWpubmhkYkpSDgxJaUotbgYKPFs68xnG+c/n9P4bO7ap9vnPd3R9GTvTBC7Z9ezOauezV36fPnEZ10NT+f3GT7t3w7Sm5qbmJkD1FmVkZiXXpyY51Ccmlycm1hUopecn6ukUKsDc5ARuoOezViP3U1m5LrJCIebijMy0Z0VWwsAV5EAeTMBAAA=";
        byte[] compress = GzipUtils.compress("{hhhhh}", StandardCharsets.UTF_8);
        System.out.println(new String(compress));
    }
}
