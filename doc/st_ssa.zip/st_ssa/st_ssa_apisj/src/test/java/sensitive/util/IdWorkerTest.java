package sensitive.util;

import com.ssa.sensitive.util.IdWorker;
import org.junit.Test;

import java.util.UUID;

/**
 * @author qsj
 * @since 2021/1/26
 */
public class IdWorkerTest {

    @Test
    public void testIdGen(){
            for (int i = 0; i < 30; i++) {
                System.out.println(IdWorker.getInstance().nextId());
            }
    }

    @Test
    public void getRandomId(){
        for (int i = 0; i < 30; i++) {
            System.out.println((UUID.randomUUID().hashCode() &Integer.MAX_VALUE) % 32);
        }

    }
}
