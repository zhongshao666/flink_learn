package sensitive.parse;

import com.google.common.base.Stopwatch;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.ssa.sensitive.match.RequestBodyParse;
import com.ssa.sensitive.parse.HttpLogParse;
import com.ssa.sensitive.to.HttpLog;
import cz.mallat.uasparser.BrowserFamilyParser;
import cz.mallat.uasparser.OnlineUpdater;
import cz.mallat.uasparser.UASparser;
import cz.mallat.uasparser.UserAgentInfo;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

import java.io.*;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * @author qsj
 * @since 2021/1/13
 */
public class HttpLogParseTest {
    @Test
    @Ignore
    public void testParse() {
        try (InputStream in = new FileInputStream("C:\\Users\\admin\\Desktop\\202104\\login.txt")) {
            HttpLog httpLog = HttpLogParse.streamParse(in,1L);
            System.out.println(httpLog.toString());
//            System.out.println(Objects.nonNull(tuple2.f1) ? String.join("\r\n", tuple2.f1) : "");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * 常规解析
     *
     * @throws IOException
     */
    private void normalTest() throws IOException {

        HttpLog httpLog = new HttpLog();

        try (InputStream in = new FileInputStream("C:\\Users\\admin\\Desktop\\202101\\test.html"); InputStreamReader inputStreamReader = new InputStreamReader(in); BufferedReader bufferedReader = new BufferedReader(inputStreamReader)) {
            Stopwatch stopwatch = Stopwatch.createStarted();
            StringBuilder source = new StringBuilder();
            char[] buffer = new char[1];
            while (bufferedReader.read(buffer) != -1) {
                source.append(buffer[0]);
            }

            int beginIndex = 0;
            int length = 0;
            boolean readFlag = false;
            int fieldIndex = 0;
            for (int i = 0; i < source.length(); i++) {
                if (!readFlag && source.charAt(i) == ',') {
                    readFlag = true;
                    length = Integer.parseInt(source.substring(beginIndex, i));
                    httpLog.setIndex(fieldIndex, source.substring(i + 1, i + length + 1));
                    fieldIndex++;
                    beginIndex = i + length + 2;
                }
                if (beginIndex == i) {
                    readFlag = false;
                }
            }
            stopwatch.stop();
            System.out.println(stopwatch.elapsed(TimeUnit.NANOSECONDS));
        }


        System.out.println(httpLog);
    }

    @Test
    public void parseHeaderTest() {
        //\r\nReferer: http://192.168.20.23:8001/\r\nUser-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36\r\n
        StringBuilder sb = new StringBuilder();
        sb.append("Accept: application/json, text/json").append('\r').append('\n')
          .append("User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36").append('\r').append('\n');
        System.out.println(sb.toString());
        System.out.println(sb.length());
        System.out.println(sb.toString().split("\r\n"));

    }

    @Test
    @Ignore
    public void openCsvTest() {
        try (InputStream in = new FileInputStream("C:\\Users\\admin\\Desktop\\202101\\testjson-1.txt");) {
            HttpLog httpLog = HttpLogParse.streamParse(in,1L);
//            List<String> list = httpLog.getCkHttpCsvLine();
//            System.out.println(CsvUtils.convertToCsvFormatByList(list));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Test
    public void urlhandleTest(){
        String requestUrl = "http://192.168.20.51:19090/view/tde/ajaxExecutors?xxxx";
        int index = requestUrl.indexOf("://");
        if(StringUtils.isNotBlank(requestUrl)&&index!=-1){
            String left = requestUrl.substring(index + 3);
            int first = left.indexOf("/");
            int param = left.indexOf("?");
            System.out.println(left.substring(first,param));
        }
    }

    @Test
    public void reqBodyParseTest(){
        RequestBodyParse requestBodyParse = new RequestBodyParse();
        Map<String, String> map = requestBodyParse.parseMapData("{\"userName\":\"admin\",\"userPwd\":\"bc15a2eb889f77d3f0213236baccab86\",\"randomId\":\"8478315681614676703694\"}");
        System.out.println(map.get("userName"));
    }

    @Test
    public void uaParse() throws IOException {
        UASparser uaSparser = new UASparser(OnlineUpdater.getVendoredInputStream());
        UserAgentInfo parse = uaSparser.parse("Apache-HttpClient/4.5.8 (Java/1.8.0_102)");
        System.out.println(parse.getUaFamily());
        Stopwatch stopwatch = Stopwatch.createStarted();
        BrowserFamilyParser browserFamilyParser = new BrowserFamilyParser(OnlineUpdater.getVendoredInputStream());
        for (int i = 0; i <10000 ; i++) {

            browserFamilyParser.parseBrowserFamily("Apache-HttpClient/4.5.8 (Java/1.8.0_102)");
        }

        stopwatch.stop();
        System.out.println(stopwatch.elapsed(TimeUnit.MILLISECONDS));
        System.out.println(browserFamilyParser.parseBrowserFamily("Apache-HttpClient/4.5.8 (Java/1.8.0_102)"));
    }

    @Test
    public void testCache(){
        Cache<String, String> sessionNameCache = CacheBuilder.newBuilder()
                                                             .maximumSize(10)
                                                             .expireAfterWrite(2, TimeUnit.HOURS)
                                                             .build();
        for (int i = 0; i < 11; i++) {
            sessionNameCache.put(i+"",i+"ss");
        }

        Assert.assertEquals(10, sessionNameCache.size());
    }
}
