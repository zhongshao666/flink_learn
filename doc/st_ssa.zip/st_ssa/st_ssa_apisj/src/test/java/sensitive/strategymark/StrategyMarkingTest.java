package sensitive.strategymark;

import com.alibaba.fastjson.JSON;
import com.ssa.bean.OfflineData;
import com.ssa.keys.AppIdKeySelector;
import com.ssa.map.HighFrequencyAlarmKeySelector;
import com.ssa.sensitive.to.HttpLog;
import com.ssa.source.ClickHouseZkSource;
import com.ssa.source.SecZookeeperSourceUpdate;
import com.ssa.strategy.StrategyConfig;
import com.ssa.strategy.StrategyMatch;
import com.ssa.transformation.*;
import com.ssa.utils.KafkaSourceProp;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.tuple.Tuple5;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.datastream.*;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.apache.flink.util.OutputTag;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

/**
 * @author : hld
 * @Date ： 2021/4/6
 * @Time : 9:46
 * @role ： 单元测试策略
 */

@Ignore
public class StrategyMarkingTest {

    StreamExecutionEnvironment env;
    BroadcastStream<Tuple4<Integer, Integer, String, String>> broadcast;
    SingleOutputStreamOperator<HttpLog> test;
    DataStreamSource<OfflineData> offlineDataDataStreamSource;

    public static OutputTag<Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig>> filterVertical = new OutputTag<Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig>>("filterVertical") {
    };

    @Test
    @Before
    @Ignore
    public void registeredStart() {
        env = StreamExecutionEnvironment.getExecutionEnvironment();

        MapStateDescriptor<String, Tuple4<Integer, Integer, String, String>> zookeeperconfig = new MapStateDescriptor<>("zookeeperconfig", BasicTypeInfo.STRING_TYPE_INFO, Types.TUPLE(BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO));

        DataStreamSource<Tuple4<Integer, Integer, String, String>> tuple2DataStreamSource = env.addSource(new SecZookeeperSourceUpdate())
                .setParallelism(1);

        String[] args = {};

        ParameterTool parameterTool = ParameterTool.fromArgs(args);
        env.getConfig()
                .setGlobalJobParameters(parameterTool);

        //zookeeper的配置广播流配置
        broadcast = tuple2DataStreamSource.broadcast(zookeeperconfig);

        //获取ck数据
        offlineDataDataStreamSource = env.addSource(new ClickHouseZkSource())
                .setParallelism(1);


//        test = env.addSource(new FlinkKafkaConsumer011<>("test1", new SimpleStringSchema(), getKafkaSourceProp().getProp()))
//                .map(item -> JSON.parseObject(item, HttpLog.class));

    }


    @Test
    @Ignore

    public void testRule(){
        test.keyBy(new AppIdKeySelector())
                .connect(broadcast)
                .process(new CustomRuleProcess())
                .setParallelism(6)
                .name("自定义规则").print();
    }

    @Test
    @Ignore
    public void testLoginCrac() {
        //获取访问事件
        SingleOutputStreamOperator<HttpLog> eventTypeSingleOutputStreamOperator = test.process(new EventTypeProcessFunction());

        //处理暴力登录破解
        eventTypeSingleOutputStreamOperator.keyBy(HttpLog::getUserName)
                .connect(broadcast)
                .process(new LoginCrackProcess())
                .name("处理暴力登录破解").print();
    }

    @Test
    @Ignore
    public void testHighPrivilege() {
        //默认高权限用户
        test.connect(broadcast)
                .process(new HighPrivilegeProcess())
                .name("默认高权限用户").print();
    }

    @Test
    @Ignore
    public void testVerticalUnauthorized() {
        //垂直越权访问
        //垂直越权访问
        SingleOutputStreamOperator<Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig>> tuple3SingleOutputStreamOperator = offlineDataDataStreamSource.connect(broadcast)
                .process(new VerticalConnectZkCoProcess())
                .name("垂直越权访问zk流合并");
        ConnectedStreams<HttpLog, Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig>> httpLogTuple5ConnectedStreams = test.keyBy(HttpLog::getAppId)
                .connect(tuple3SingleOutputStreamOperator.keyBy(item -> item.f2));
        httpLogTuple5ConnectedStreams.process(new VerticalUnauthorizedProcess())
                .name("垂直越权访问").print();

    }

    @Test
    @Ignore
    public void testHighFrequencyAccess() {

        //过滤没敏感数据的httplog
        SingleOutputStreamOperator<HttpLog> hasSensitiveDataStream = test.process(new FilterNonSensitiveProcess())
                .name("过滤没敏感数据的httplog");

        //敏感数据高频访问
        KeyedStream<HttpLog, Tuple2<Long, String>> highFrequencyAlarmKeyedStream = hasSensitiveDataStream.keyBy(new HighFrequencyAlarmKeySelector());
        highFrequencyAlarmKeyedStream.connect(broadcast)
                .process(new HighFrequencyAccessProcess())
                .name("敏感数据高频访问").print();
    }

    @Test
    @Ignore
    public void testSensitiveAbnormal() {
        SingleOutputStreamOperator<Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig>> tuple3SingleOutputStreamOperator = offlineDataDataStreamSource.connect(broadcast)
                .process(new VerticalConnectZkCoProcess())
                .name("垂直越权访问zk流合并");
        //处理敏感数据异常操作
        DataStream<Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig>> vertivalOutputDataStream = tuple3SingleOutputStreamOperator.getSideOutput(filterVertical);
        ConnectedStreams<HttpLog, Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig>> logTuple3ConnectedStreams = test.keyBy(HttpLog::getAppId)
                .connect(vertivalOutputDataStream.keyBy(item -> item.f2));
        logTuple3ConnectedStreams.process(new SensitiveAbnormalProcess())
                .name("处理敏感数据异常操作").print();
    }

    @Test
    @Ignore
    public void testNonWorking(){

        test.keyBy(new AppIdKeySelector())
                .connect(broadcast)
                .process(new NonWorkingTimeProcess())
                .name("非工作时间访问").print();

    }

    @Test
    @After
    @Ignore
    public void registeredEnd() throws Exception {
        env.execute("test job");
    }

//    @Ignore
//    private static KafkaSourceProp getKafkaSourceProp() {
//        KafkaSourceProp kafkaSourceProp = new KafkaSourceProp();
//        kafkaSourceProp.setBOOTSTRAP_SERVERS_CONFIG(SystemConfig.kafkaUrl);
//        return kafkaSourceProp;
//    }
}
