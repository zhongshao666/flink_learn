package sensitive.test_rule;

import com.ssa.logic.Rule;
import com.ssa.sensitive.to.HttpHeader;
import com.ssa.sensitive.to.HttpLog;
import com.ssa.strategy.*;
import org.junit.Ignore;
import org.junit.Test;

import java.util.ArrayList;

//黑白名单、自定义规则测试
public class RuleTest {


    //测试ip匹配
    @Test
    @Ignore
    public void testClientIPCheck() {
        //模拟httpLog
        HttpLog httpLog = new HttpLog();
        httpLog.setClientIp("192.168.18.251");

        //配置策略
        StrategyMatch strategyMatch = new StrategyMatch();
        StrategyMatchCondition strategyMatchCondition = new StrategyMatchCondition();
        strategyMatch.setStrategyMatchCondition(strategyMatchCondition);

        ConditionToTuple2ListTools conditionToTuple2ListTools = new ConditionToTuple2ListTools();
        ArrayList<String> ipList = new ArrayList<>();
        ipList.add("192.168.18.249-192.168.18.250");
        ipList.add("192.168.18.251");
        conditionToTuple2ListTools.setToolList(ipList);
        conditionToTuple2ListTools.setInclude(1);

        strategyMatch.getStrategyMatchCondition().setClientAllIps(conditionToTuple2ListTools);

        //测试
        Rule rule = new Rule();
        rule.clientCheck(strategyMatchCondition, httpLog.getClientIp());
        System.out.println(rule.isClientIpBool());

    }

    //测试用户匹配
    @Test
    @Ignore
    public void testAccountCheck() {
        //模拟httpLog
        HttpLog httpLog = new HttpLog();
        httpLog.setUserName("admin");
        //配置策略
        StrategyMatch strategyMatch = new StrategyMatch();
        StrategyMatchCondition strategyMatchCondition = new StrategyMatchCondition();
        strategyMatch.setStrategyMatchCondition(strategyMatchCondition);

        ConditionToStringListTools conditionToStringListTools = new ConditionToStringListTools();
        ArrayList<String> accList = new ArrayList<>();
        accList.add("admin");
        conditionToStringListTools.setInclude(1);
        conditionToStringListTools.setToolList(accList);

        strategyMatch.getStrategyMatchCondition().setUserAccount(conditionToStringListTools);

        //测试
        Rule rule = new Rule();
        rule.accountCheck(strategyMatchCondition, httpLog.getUserName());
        System.out.println(rule.isAccountBool());

    }


    //测试接口匹配
    @Test
    @Ignore
    public void testInterfaceCheck() {
        //模拟httpLog
        HttpLog httpLog = new HttpLog();
        httpLog.setInterfaceId(6666L);
        //配置策略
        StrategyMatch strategyMatch = new StrategyMatch();
        StrategyMatchCondition strategyMatchCondition = new StrategyMatchCondition();
        strategyMatch.setStrategyMatchCondition(strategyMatchCondition);

        ConditionToLongListTools conditionToLongListTools = new ConditionToLongListTools();
        ArrayList<Long> list = new ArrayList<>();
        list.add(6666L);
        list.add(66L);
        conditionToLongListTools.setLongList(list);
        conditionToLongListTools.setInclude(1);
        strategyMatch.getStrategyMatchCondition().setInterfaceIds(conditionToLongListTools);

        //测试
        Rule rule = new Rule();
        rule.interfaceCheck(strategyMatchCondition, httpLog.getInterfaceId());
        System.out.println(rule.isInterfaceBool());

    }


    //测试请求方法匹配
    @Test
    @Ignore
    public void testMethodCheck() {
        //模拟httpLog
        HttpLog httpLog = new HttpLog();
        httpLog.setHttpMethod("GET");
        //配置策略
        StrategyMatch strategyMatch = new StrategyMatch();
        StrategyMatchCondition strategyMatchCondition = new StrategyMatchCondition();
        strategyMatch.setStrategyMatchCondition(strategyMatchCondition);

        ConditionToStringListTools conditionToStringListTools = new ConditionToStringListTools();
        ArrayList<String> accList = new ArrayList<>();
        accList.add("admin");
        conditionToStringListTools.setInclude(1);
        conditionToStringListTools.setToolList(accList);

        strategyMatch.getStrategyMatchCondition().setUserAccount(conditionToStringListTools);

        //测试
        Rule rule = new Rule();
        rule.accountCheck(strategyMatchCondition, httpLog.getUserName());
        System.out.println(rule.isAccountBool());
    }


    //测试请求关键字
    @Test
    @Ignore
    public void testReqKeywordCheck() {
        //模拟httpLog
        HttpLog httpLog = new HttpLog();
        httpLog.setRequestHeader("6666666666666666666");
        httpLog.setRequestBody("777777admin777777777777");

        //配置策略
        StrategyMatch strategyMatch = new StrategyMatch();
        StrategyMatchCondition strategyMatchCondition = new StrategyMatchCondition();
        strategyMatch.setStrategyMatchCondition(strategyMatchCondition);

        ConditionToStringListTools conditionToStringListTools = new ConditionToStringListTools();
        ArrayList<String> accList = new ArrayList<>();
        accList.add("admin");
        conditionToStringListTools.setInclude(1);
        conditionToStringListTools.setToolList(accList);

        strategyMatch.getStrategyMatchCondition().setReqKeywords(conditionToStringListTools);

        //测试
        Rule rule = new Rule();
//        rule.reqKeywordCheck(strategyMatchCondition, httpLog.getRequestHeader(), httpLog.getRequestBody());
        System.out.println(rule.isReqKeywordBool());

    }


    //测试请求状态
    @Test
    @Ignore
    public void testReqStatusCheck() {
        //模拟httpLog
        HttpLog httpLog = new HttpLog();
        httpLog.setRequestStatus(200);
        //配置策略
        StrategyMatch strategyMatch = new StrategyMatch();
        StrategyMatchCondition strategyMatchCondition = new StrategyMatchCondition();
        strategyMatch.setStrategyMatchCondition(strategyMatchCondition);

        strategyMatch.getStrategyMatchCondition().setReqStatus(200);

        //测试
        Rule rule = new Rule();
        rule.reqStatusCheck(strategyMatchCondition, httpLog.getRequestStatus());
        System.out.println(rule.isReqStatusBool());

    }

    //测试状态码
    @Test
    @Ignore
    public void testStatusCodeCheck() {
        //模拟httpLog
        HttpLog httpLog = new HttpLog();
        httpLog.setStatusCode(888);
        //配置策略
        StrategyMatch strategyMatch = new StrategyMatch();
        StrategyMatchCondition strategyMatchCondition = new StrategyMatchCondition();
        strategyMatch.setStrategyMatchCondition(strategyMatchCondition);
        ArrayList<Integer> list = new ArrayList<>();
        list.add(666);
        list.add(777);
        list.add(888);
        strategyMatch.getStrategyMatchCondition().setStatusCode(list);

        //测试
        Rule rule = new Rule();
        rule.statusCodeCheck(strategyMatchCondition, httpLog.getStatusCode());
        System.out.println(rule.isStatusCodeBool());

    }


    //测试url
    @Test
    @Ignore
    public void testUrlCheck() {
        //模拟httpLog
        HttpLog httpLog = new HttpLog();
        httpLog.setRequestUrl("http://192.168.20.28/dashboard/projects");
        //配置策略
        StrategyMatch strategyMatch = new StrategyMatch();
        StrategyMatchCondition strategyMatchCondition = new StrategyMatchCondition();
        strategyMatch.setStrategyMatchCondition(strategyMatchCondition);


        UrlContent urlContent = new UrlContent("http://192.168.20.28/dashboard/projects", 1);
        ArrayList<UrlContent> list = new ArrayList<>();
        list.add(urlContent);

        UrlParsingTool urlParsingTool = new UrlParsingTool();
        urlParsingTool.setUrlList(list);

        strategyMatch.getStrategyMatchCondition().setUrlParsingTool(urlParsingTool);

        //测试
        Rule rule = new Rule();
        rule.urlCheck(strategyMatchCondition, httpLog.getRequestUrl());
        System.out.println(rule.isUrlBool());

    }

    //测试时间范围
    @Test
    @Ignore
    public void testTimestampCheck() {
        //模拟httpLog
        HttpLog httpLog = new HttpLog();
        httpLog.setRequestTime(System.currentTimeMillis());

        //配置策略
        StrategyMatch strategyMatch = new StrategyMatch();
        StrategyMatchCondition strategyMatchCondition = new StrategyMatchCondition();
        strategyMatch.setStrategyMatchCondition(strategyMatchCondition);

        DateTime dateTime = new DateTime();
        dateTime.setMin(1617206400L);
        dateTime.setMax(1617379200L);  //   1617298000L   1617379200L

        strategyMatch.getStrategyMatchCondition().setDateTime(dateTime);

        //测试
        Rule rule = new Rule();
        rule.timestampCheck(strategyMatchCondition, httpLog.getRequestTime());
        System.out.println(rule.isTimestampBool());

    }

    //测试月
    @Test
    @Ignore
    public void testMouthCheck() {
        //模拟httpLog
        HttpLog httpLog = new HttpLog();
        httpLog.setRequestTime(System.currentTimeMillis());

        //配置策略
        StrategyMatch strategyMatch = new StrategyMatch();
        StrategyMatchCondition strategyMatchCondition = new StrategyMatchCondition();
        strategyMatch.setStrategyMatchCondition(strategyMatchCondition);

        ArrayList<Integer> list = new ArrayList<>();
        list.add(1);
//        list.add(2);

        ConditionToIntegerListTools conditionToIntegerListTools = new ConditionToIntegerListTools();
        conditionToIntegerListTools.setIntList(list);
        conditionToIntegerListTools.setInclude(1);

        strategyMatch.getStrategyMatchCondition().setMonthTime(conditionToIntegerListTools);

        //测试
        Rule rule = new Rule();
        rule.mouthCheck(strategyMatchCondition, httpLog.getRequestTime());
        System.out.println(rule.isMouthTimeBool());

    }


    //测试week
    @Test
    @Ignore
    public void testWeekCheck() {
        //模拟httpLog
        HttpLog httpLog = new HttpLog();
        httpLog.setRequestTime(System.currentTimeMillis());

        //配置策略
        StrategyMatch strategyMatch = new StrategyMatch();
        StrategyMatchCondition strategyMatchCondition = new StrategyMatchCondition();
        strategyMatch.setStrategyMatchCondition(strategyMatchCondition);

        ArrayList<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(5);

        ConditionToIntegerListTools conditionToIntegerListTools = new ConditionToIntegerListTools();
        conditionToIntegerListTools.setIntList(list);
        conditionToIntegerListTools.setInclude(1);

        strategyMatch.getStrategyMatchCondition().setWeekTime(conditionToIntegerListTools);

        //测试
        Rule rule = new Rule();
        rule.weekCheck(strategyMatchCondition, httpLog.getRequestTime());
        System.out.println(rule.isWeekTimeBool());

    }


    //测试day
    @Test
    @Ignore
    public void testHourCheck() {
        //模拟httpLog
        HttpLog httpLog = new HttpLog();
        httpLog.setRequestTime(System.currentTimeMillis());

        //配置策略
        StrategyMatch strategyMatch = new StrategyMatch();
        StrategyMatchCondition strategyMatchCondition = new StrategyMatchCondition();
        strategyMatch.setStrategyMatchCondition(strategyMatchCondition);

        ArrayList<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(14);

        ConditionToIntegerListTools conditionToIntegerListTools = new ConditionToIntegerListTools();
        conditionToIntegerListTools.setIntList(list);
        conditionToIntegerListTools.setInclude(1);

        strategyMatch.getStrategyMatchCondition().setDateTimeDay(conditionToIntegerListTools);

        //测试
        Rule rule = new Rule();
        rule.hourCheck(strategyMatchCondition, httpLog.getRequestTime());
        System.out.println(rule.isDayTimeBool());

    }

    //测试客户端工具
    @Test
    @Ignore
    public void testClientToolCheck() {
        //模拟httpLog
        HttpLog httpLog = new HttpLog();
        httpLog.setClientTool("jdbc");
        //配置策略
        StrategyMatch strategyMatch = new StrategyMatch();
        StrategyMatchCondition strategyMatchCondition = new StrategyMatchCondition();
        strategyMatch.setStrategyMatchCondition(strategyMatchCondition);

        ConditionToStringListTools conditionToStringListTools = new ConditionToStringListTools();
        ArrayList<String> accList = new ArrayList<>();
        accList.add("jdbc");
        conditionToStringListTools.setInclude(1);
        conditionToStringListTools.setToolList(accList);

        strategyMatch.getStrategyMatchCondition().setClientTools(conditionToStringListTools);

        //测试
        Rule rule = new Rule();
        rule.clientToolCheck(strategyMatchCondition, httpLog.getClientTool());
        System.out.println(rule.isClientToolBool());
    }

    //测试cookie关键字
    @Test
    @Ignore
    public void testCookieKeywordCheck() {
        //模拟httpLog
        HttpLog httpLog = new HttpLog();
        HttpHeader httpHeader = new HttpHeader();
        httpHeader.setCookie("666666666666admin66666666666");
        httpLog.setReqHeader(httpHeader);

        //配置策略
        StrategyMatch strategyMatch = new StrategyMatch();
        StrategyMatchCondition strategyMatchCondition = new StrategyMatchCondition();
        strategyMatch.setStrategyMatchCondition(strategyMatchCondition);

        ConditionToStringListTools conditionToStringListTools = new ConditionToStringListTools();
        ArrayList<String> accList = new ArrayList<>();
        accList.add("admin");
        conditionToStringListTools.setInclude(1);
        conditionToStringListTools.setToolList(accList);

        strategyMatch.getStrategyMatchCondition().setCookieKeywords(conditionToStringListTools);
        //测试
        Rule rule = new Rule();
        rule.cookieKeywordCheck(strategyMatchCondition, httpLog.getReqHeader().getCookie());
        System.out.println(rule.isCookieKeywordBool());

    }

    //测试敏感数据标签
    @Test
    @Ignore
    public void testSensitiveDataLabelCheck() {
        //模拟httpLog
        HttpLog httpLog = new HttpLog();
        httpLog.setSensitiveLabelField("aa,bb,admin");

        //配置策略
        StrategyMatch strategyMatch = new StrategyMatch();
        StrategyMatchCondition strategyMatchCondition = new StrategyMatchCondition();
        strategyMatch.setStrategyMatchCondition(strategyMatchCondition);

        ConditionToStringListTools conditionToStringListTools = new ConditionToStringListTools();
        ArrayList<String> accList = new ArrayList<>();
        accList.add("admin");
        conditionToStringListTools.setInclude(1);
        conditionToStringListTools.setToolList(accList);

        strategyMatch.getStrategyMatchCondition().setLabelCode(accList);
        //测试
        Rule rule = new Rule();
        rule.sensitiveDataLabelCheck(strategyMatchCondition, httpLog.getSensitiveLabelField());
        System.out.println(rule.isSensitiveDataLabelBool());

    }

    //测试敏感等级
    @Test
    @Ignore
    public void testSensitiveLevelCheck() {
        //模拟httpLog
        HttpLog httpLog = new HttpLog();
        httpLog.setSensitiveLevel("S1");

        //配置策略
        StrategyMatch strategyMatch = new StrategyMatch();
        StrategyMatchCondition strategyMatchCondition = new StrategyMatchCondition();
        strategyMatch.setStrategyMatchCondition(strategyMatchCondition);

        ConditionToStringListTools conditionToStringListTools = new ConditionToStringListTools();
        ArrayList<String> accList = new ArrayList<>();
//        accList.add("S1");
        accList.add("S2");
        accList.add("S3");
        conditionToStringListTools.setInclude(1);
        conditionToStringListTools.setToolList(accList);

        strategyMatch.getStrategyMatchCondition().setSensitiveLevel(accList);
        //测试
        Rule rule = new Rule();
        rule.sensitiveLevelCheck(strategyMatchCondition, httpLog.getSensitiveLevel());
        System.out.println(rule.isSensitiveLevelBool());

    }

}
