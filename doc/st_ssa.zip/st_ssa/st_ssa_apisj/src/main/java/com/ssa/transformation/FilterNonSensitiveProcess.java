package com.ssa.transformation;

import com.ssa.ApisjMain;
import com.ssa.sensitive.to.HttpLog;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;

/**
 * @author : yang
 * @role ：过滤是否包含敏感数据
 */
public class FilterNonSensitiveProcess extends ProcessFunction<HttpLog, HttpLog> {
    @Override
    public void processElement(HttpLog value, Context ctx, Collector<HttpLog> out) throws Exception {
        if (value.getHasSensitive() != null && value.getHasSensitive()) {
            out.collect(value);
        } else {
            ctx.output(ApisjMain.nonSentitive, value);
        }
    }
}
