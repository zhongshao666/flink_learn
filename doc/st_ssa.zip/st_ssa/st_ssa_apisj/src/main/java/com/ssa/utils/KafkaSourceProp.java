package com.ssa.utils;
import org.apache.kafka.clients.consumer.ConsumerConfig;

import java.util.Properties;

//======================================================================
//*@类名 KafkaSourceProp
//*@包名 
//*@功能描述：
//*     1.
//*     2.
//*     3.
//*@Version：
//*@创建时间：2020/7/30 11:57
//*@修改时间：2020/7/30 11:57
//*@修改版本号记录：
//*       1. VersionID:
//*          修改内容:
//*          修改原因:
//*       2. VersionID:
//*          修改内容:
//*          修改原因:
//*       3. VersionID:
//*          修改内容:
//*          修改原因:
//*@所属公司： 闪捷科技有限公司
//*@Author:   赵臻柄
//======================================================================
public class KafkaSourceProp {
    private String BOOTSTRAP_SERVERS_CONFIG = "192.168.24.251:9092";
    private String KEY_DESERIALIZER_CLASS_CONFIG= "org.apache.kafka.common.serialization.StringDeserializer";
    private String VALUE_DESERIALIZER_CLASS_CONFIG= "org.apache.kafka.common.serialization.StringDeserializer";
    private String GROUP_ID_CONFIG = "flinkaaa5";
    private String AUTO_OFFSET_RESET_CONFIG = "earliest";
    private Boolean ENABLE_AUTO_COMMIT_CONFIG = true;
    private Properties prop;
    public KafkaSourceProp(){
        super();
    }

    public String getBOOTSTRAP_SERVERS_CONFIG() {
        return BOOTSTRAP_SERVERS_CONFIG;
    }

    public void setBOOTSTRAP_SERVERS_CONFIG(String BOOTSTRAP_SERVERS_CONFIG) {
        this.BOOTSTRAP_SERVERS_CONFIG = BOOTSTRAP_SERVERS_CONFIG;
    }

    public String getKEY_DESERIALIZER_CLASS_CONFIG() {
        return KEY_DESERIALIZER_CLASS_CONFIG;
    }

    public void setKEY_DESERIALIZER_CLASS_CONFIG(String KEY_DESERIALIZER_CLASS_CONFIG) {
        this.KEY_DESERIALIZER_CLASS_CONFIG = KEY_DESERIALIZER_CLASS_CONFIG;
    }

    public String getVALUE_DESERIALIZER_CLASS_CONFIG() {
        return VALUE_DESERIALIZER_CLASS_CONFIG;
    }

    public void setVALUE_DESERIALIZER_CLASS_CONFIG(String VALUE_DESERIALIZER_CLASS_CONFIG) {
        this.VALUE_DESERIALIZER_CLASS_CONFIG = VALUE_DESERIALIZER_CLASS_CONFIG;
    }

    public String getGROUP_ID_CONFIG() {
        return GROUP_ID_CONFIG;
    }

    public void setGROUP_ID_CONFIG(String GROUP_ID_CONFIG) {
        this.GROUP_ID_CONFIG = GROUP_ID_CONFIG;
    }

    public String getAUTO_OFFSET_RESET_CONFIG() {
        return AUTO_OFFSET_RESET_CONFIG;
    }

    public void setAUTO_OFFSET_RESET_CONFIG(String AUTO_OFFSET_RESET_CONFIG) {
        this.AUTO_OFFSET_RESET_CONFIG = AUTO_OFFSET_RESET_CONFIG;
    }

    public Boolean getENABLE_AUTO_COMMIT_CONFIG() {
        return ENABLE_AUTO_COMMIT_CONFIG;
    }

    public void setENABLE_AUTO_COMMIT_CONFIG(Boolean ENABLE_AUTO_COMMIT_CONFIG) {
        this.ENABLE_AUTO_COMMIT_CONFIG = ENABLE_AUTO_COMMIT_CONFIG;
    }

    public Properties getProp() {
        prop = new Properties();
        prop.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,BOOTSTRAP_SERVERS_CONFIG);
        prop.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,KEY_DESERIALIZER_CLASS_CONFIG);
        prop.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,VALUE_DESERIALIZER_CLASS_CONFIG);
        prop.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG,ENABLE_AUTO_COMMIT_CONFIG);
        prop.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,AUTO_OFFSET_RESET_CONFIG);
        prop.put(ConsumerConfig.GROUP_ID_CONFIG,GROUP_ID_CONFIG);
        return prop;
    }


//    public KafkaSourceProp initByRedis(){
//
//        if(RedisEtcUtils.etckeys.contains("4002&_02&_ff&_bootstrap_servers_config")){
//            BOOTSTRAP_SERVERS_CONFIG = RedisEtcUtils.etcmap.get("4002&_02&_ff&_bootstrap_servers_config");
//        }
//        if(RedisEtcUtils.etckeys.contains("4002&_02&_ff&_key_deserializer_class_config")){
//            KEY_DESERIALIZER_CLASS_CONFIG = RedisEtcUtils.etcmap.get("4002&_02&_ff&_key_deserializer_class_config");
//        }
//        if(RedisEtcUtils.etckeys.contains("4002&_02&_ff&_value_deserializer_class_config")){
//            VALUE_DESERIALIZER_CLASS_CONFIG = RedisEtcUtils.etcmap.get("4002&_02&_ff&_value_deserializer_class_config");
//        }
//        if(RedisEtcUtils.etckeys.contains("4002&_02&_ff&_alarmgroup")){
//            GROUP_ID_CONFIG = RedisEtcUtils.etcmap.get("4002&_02&_ff&_alarmgroup");
//        }
//        if(RedisEtcUtils.etckeys.contains("4002&_02&_ff&_auto_offset_reset_config")){
//            AUTO_OFFSET_RESET_CONFIG = RedisEtcUtils.etcmap.get("4002&_02&_ff&_auto_offset_reset_config");
//        }
//        if(RedisEtcUtils.etckeys.contains("4002&_02&_ff&_enable_auto_commit_config")){
//            ENABLE_AUTO_COMMIT_CONFIG = RedisEtcUtils.etcmap.get("4002&_02&_ff&_enable_auto_commit_config").equals("0")?false:true;
//        }
//        return this;
//    }

    public void setProp(Properties prop) {
        this.prop = prop;
    }


}
