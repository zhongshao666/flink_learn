package com.ssa.utils;

import org.apache.flink.shaded.curator4.org.apache.curator.RetryPolicy;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.CuratorFramework;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.flink.shaded.curator4.org.apache.curator.retry.RetryNTimes;

public class CuratorOperator {

    public  CuratorFramework client = null;

    public CuratorOperator(String zookeeperpath){

        RetryPolicy retryPolicy = new RetryNTimes(3,10000);

        client = CuratorFrameworkFactory.builder().connectString(zookeeperpath).sessionTimeoutMs(10000).retryPolicy(retryPolicy).build();

        client.start();
    }
}
