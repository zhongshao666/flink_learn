package com.ssa.bean;

public class IpBean {
    private String selfip;
    private Long startip;
    private Long endip;


    public String getSelfip() {
        return selfip;
    }

    public void setSelfip(String selfip) {
        this.selfip = selfip;
    }

    public Long getStartip() {
        return startip;
    }

    public void setStartip(Long startip) {
        this.startip = startip;
    }

    public Long getEndip() {
        return endip;
    }

    public void setEndip(Long endip) {
        this.endip = endip;
    }

    public IpBean(String selfip) {
        this.selfip = selfip;
    }

    public IpBean(Long startip, Long endip) {
        this.startip = startip;
        this.endip = endip;
    }

    public IpBean() {
    }
}
