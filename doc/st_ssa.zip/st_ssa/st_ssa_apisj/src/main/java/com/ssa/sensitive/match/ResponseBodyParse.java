package com.ssa.sensitive.match;

import com.google.common.collect.Lists;

import java.util.List;

/**
 * @author qsj
 * @since 2021/1/21
 */
public class ResponseBodyParse extends AbstractParse {

    /**
     * 解析并数据
     *
     * @param body
     * @return
     */
    @Override
    public List<String> parseData(String body) {
        List<String> valueList = Lists.newArrayList();
        if (isJson(body)) {
            jsonParse(body, valueList);
        } else {
            htmlParse(body, valueList);
        }
        return valueList;
    }


}
