package com.ssa.transformation;

import com.ssa.map.ConditionTOMarking;
import com.ssa.map.ParsingZkConfigSource;
import com.ssa.map.ParsingZkSource;
import com.ssa.strategy.StrategyConfig;
import com.ssa.strategy.StrategyMatch;
import com.ssa.sensitive.constants.CommonConstants;
import com.ssa.sensitive.to.HttpLog;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.BroadcastProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Administrator
 * @role 敏感数据高频访问processfunction
 */
public class HighPrivilegeProcess extends BroadcastProcessFunction<HttpLog, Tuple4<Integer, Integer, String, String>, HttpLog> {

    private static final Logger logger = LoggerFactory.getLogger(HighPrivilegeProcess.class);

    private Map<String, StrategyMatch> strategyMatchMap;
    private Map<Long, StrategyConfig> strategyConfigMap;
    private ParsingZkSource parsingZkSource = new ParsingZkSource();

    @Override
    public void open(Configuration parameters) throws Exception {

        strategyMatchMap = new HashMap<>();
        strategyConfigMap = new HashMap<>();
    }

    @Override
    public void processElement(HttpLog value, ReadOnlyContext ctx, Collector<HttpLog> out) throws Exception {

        if (strategyMatchMap.get(value.getUserName()) != null &&
                strategyConfigMap.get(value.getAppId()) != null
                && strategyMatchMap.get(value.getUserName()).getEnable() &&
                strategyConfigMap.get(value.getAppId()).getRiskPolicyEnable() &&
                strategyMatchMap.get(value.getUserName()).getAppIds().contains(value.getAppId())) {

            logger.info("http log marking highprivilegeuser logid:{}, userName:{}", value.getLogId(), value.getUserName());
            ConditionTOMarking.setStrategy(value, strategyMatchMap.get(value.getUserName()));
        }

        out.collect(value);
    }

    @Override
    public void processBroadcastElement(Tuple4<Integer, Integer, String, String> value, Context ctx, Collector<HttpLog> out) throws Exception {
        String filterStrategy = CommonConstants.StrategyType.HIGHPRIVILEGEUSER.getVal();
        if (value.f0 == CommonConstants.ZkDataType.RISK_TYPE.getVal()) {
            StrategyMatch strategyMatchs = parsingZkSource.parsingZkJson(value.f3);
            if (strategyMatchs.getAppIds().size() > 0 && value.f1 == CommonConstants.OperateType.UPDATE.getVal() || value.f1 == CommonConstants.OperateType.ADD.getVal()) {
                if (filterStrategy.equals(strategyMatchs.getStrategy())) {
                    for (String maxAuthor : strategyMatchs.getStrategyMatchCondition().getMaximumAuthorityAccount()) {
                        strategyMatchMap.put(maxAuthor, strategyMatchs);
                    }
                }
            } else if (strategyMatchs.getAppIds().size() > 0 && value.f1 == CommonConstants.OperateType.DELETE.getVal()) {
                if (filterStrategy.equals(strategyMatchs.getStrategy())) {
                    for (String maxAuthor : strategyMatchs.getStrategyMatchCondition().getMaximumAuthorityAccount()) {
                        strategyMatchMap.remove(maxAuthor, strategyMatchs);
                    }
                }
            }
        }

        if (value.f0 == CommonConstants.ZkDataType.STRATEGY_CONFIG.getVal()) {
            if ( value.f1 == CommonConstants.OperateType.DELETE.getVal()) {
                StrategyConfig strategyConfig = ParsingZkConfigSource.parsingZkConfigSource(value.f3);
                strategyConfigMap.remove(strategyConfig.getAppId());
            } else  {
                StrategyConfig strategyConfig = ParsingZkConfigSource.parsingZkConfigSource(value.f3);
                strategyConfigMap.put(strategyConfig.getAppId(), strategyConfig);
            }
        }
    }
}
