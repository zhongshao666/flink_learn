package com.ssa.strategy;

import lombok.Data;

@Data
public class ConditionToFrequencyTools {
    private Integer time;
    private String unit;
    private Integer times;
}
