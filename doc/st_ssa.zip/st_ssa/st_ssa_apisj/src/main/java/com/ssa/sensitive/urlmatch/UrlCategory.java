package com.ssa.sensitive.urlmatch;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

import java.util.Objects;

/**
 * @author qsj
 * @since 2021/1/19
 */
public class UrlCategory {
    private Multimap<String,UrlNode> normalNodeMap;
    private Multimap<String,UrlNode> wildcardNodeMap;

    public void addNode(UrlNode urlNode){
        if (urlNode.isWildcardFlag()) {
            if (Objects.isNull(wildcardNodeMap)) {
                wildcardNodeMap = ArrayListMultimap.create();
            }
            wildcardNodeMap.put(urlNode.getValue(),urlNode);
        }else{
            if (Objects.isNull(normalNodeMap)) {
                normalNodeMap = ArrayListMultimap.create();
            }
            normalNodeMap.put(urlNode.getValue(),urlNode);
        }
    }

    public Multimap<String, UrlNode> getNormalNodeMap() {
        return normalNodeMap;
    }

    public void setNormalNodeMap(Multimap<String, UrlNode> normalNodeMap) {
        this.normalNodeMap = normalNodeMap;
    }

    public Multimap<String, UrlNode> getWildcardNodeMap() {
        return wildcardNodeMap;
    }

    public void setWildcardNodeMap(Multimap<String, UrlNode> wildcardNodeMap) {
        this.wildcardNodeMap = wildcardNodeMap;
    }
}
