package com.ssa.strategy;

import lombok.Data;

/**
 * @author Administrator
 */
@Data
public class CostTime {
    private Integer number;
    private Integer relation;
}
