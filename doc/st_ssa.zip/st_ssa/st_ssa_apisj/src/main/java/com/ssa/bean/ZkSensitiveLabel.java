package com.ssa.bean;

/**
 * @author qsj
 * @since 2021/3/19
 */
public class ZkSensitiveLabel {

    /**
     * 敏感标签ID
     */
    private Long id;
    /**
     * 敏感标签code
     */
    private String code;
    /**
     * 敏感等级 s1\s2\s3
     */
    private String sensitiveLevel;
    /**
     * 规则类型:1-正则,2-关键字
     */
    private Integer ruleType;
    /**
     * 规则内容
     */
    private String ruleContent;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getSensitiveLevel() {
        return sensitiveLevel;
    }

    public void setSensitiveLevel(String sensitiveLevel) {
        this.sensitiveLevel = sensitiveLevel;
    }

    public Integer getRuleType() {
        return ruleType;
    }

    public void setRuleType(Integer ruleType) {
        this.ruleType = ruleType;
    }

    public String getRuleContent() {
        return ruleContent;
    }

    public void setRuleContent(String ruleContent) {
        this.ruleContent = ruleContent;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
