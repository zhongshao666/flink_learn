package com.ssa.sensitive.to;

/**
 * @author qsj
 * @since 2021/1/21
 */
public class CkHttpLog {
    private Long logId;
    private Long requestTime;
    private Long costTime;
    private String userName;
    private String sessionId;
    private String hostName;
    private String requestUrl;
    private String clientMac;
    private String clientIp;
    private Integer clientPort;
    private String serverMac;
    private String serverIp;
    private Integer serverPort;
    private String reqHeader;
    private String reqBody;
    private String resHeader;
    private String resBody;
    private String httpVersion;
    private String requestMethod;
    private String statusCode;
    private String remoteAddress;
    private String referrerPolicy;
    private String reqAccept;
    private String reqAcceptEncoding;
    private String reqAcceptLanguage;
    private String reqCacheControl;
    private String reqConnection;
    private String reqContentType;
    private String reqTransferEncoding;
    private String reqCookie;
    private String reqOrigin;
    private String reqHost;
    private String reqPragma;
    private String reqReferer;
    private String reqSecFetchDest;
    private String reqSecFetchMode;
    private String reqSecFetchSite;
    private String reqSecFetchUser;
    private String reqToken;
    private String reqUserAgent;
    private String reqXRequestedWith;
    private String reqXClientData;
    private String resAcceptRanges;
    private String resCacheControl;
    private String resContentSecurityPolicy;
    private String resContentLength;
    private String resContentType;
    private String resDate;
    private String resEtag;
    private String resServer;
    private String resExpires;
    private String resLastModified;
    private String resPragma;
    private String resSetCookie;
    private String resStrictTransportSecurity;
    private String resTransferEncoding;
    private String resXContentTypeOptions;
    private String resFrameOptions;
    private String resXXssProtection;
    private Long createTime;
    private Boolean hasSensitive;
    private String riskType;
    private Integer riskLevel;
    private Integer eventType;
    private Long strategyId;
    private String strategyName;
    private Long appId;
    private String appName;
    private String appDomain;
    private Long interfaceId;
    private String interfaceName;
    private String interfaceUrl;

    public Long getLogId() {
        return logId;
    }

    public void setLogId(Long logId) {
        this.logId = logId;
    }

    public Long getRequestTime() {
        return requestTime;
    }

    public void setRequestTime(Long requestTime) {
        this.requestTime = requestTime;
    }

    public Long getCostTime() {
        return costTime;
    }

    public void setCostTime(Long costTime) {
        this.costTime = costTime;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getHostName() {
        return hostName;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    public String getRequestUrl() {
        return requestUrl;
    }

    public void setRequestUrl(String requestUrl) {
        this.requestUrl = requestUrl;
    }

    public String getClientMac() {
        return clientMac;
    }

    public void setClientMac(String clientMac) {
        this.clientMac = clientMac;
    }

    public String getClientIp() {
        return clientIp;
    }

    public void setClientIp(String clientIp) {
        this.clientIp = clientIp;
    }

    public Integer getClientPort() {
        return clientPort;
    }

    public void setClientPort(Integer clientPort) {
        this.clientPort = clientPort;
    }

    public String getServerMac() {
        return serverMac;
    }

    public void setServerMac(String serverMac) {
        this.serverMac = serverMac;
    }

    public String getServerIp() {
        return serverIp;
    }

    public void setServerIp(String serverIp) {
        this.serverIp = serverIp;
    }

    public Integer getServerPort() {
        return serverPort;
    }

    public void setServerPort(Integer serverPort) {
        this.serverPort = serverPort;
    }

    public String getReqHeader() {
        return reqHeader;
    }

    public void setReqHeader(String reqHeader) {
        this.reqHeader = reqHeader;
    }

    public String getReqBody() {
        return reqBody;
    }

    public void setReqBody(String reqBody) {
        this.reqBody = reqBody;
    }

    public String getResHeader() {
        return resHeader;
    }

    public void setResHeader(String resHeader) {
        this.resHeader = resHeader;
    }

    public String getResBody() {
        return resBody;
    }

    public void setResBody(String resBody) {
        this.resBody = resBody;
    }

    public String getHttpVersion() {
        return httpVersion;
    }

    public void setHttpVersion(String httpVersion) {
        this.httpVersion = httpVersion;
    }

    public String getRequestMethod() {
        return requestMethod;
    }

    public void setRequestMethod(String requestMethod) {
        this.requestMethod = requestMethod;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getRemoteAddress() {
        return remoteAddress;
    }

    public void setRemoteAddress(String remoteAddress) {
        this.remoteAddress = remoteAddress;
    }

    public String getReferrerPolicy() {
        return referrerPolicy;
    }

    public void setReferrerPolicy(String referrerPolicy) {
        this.referrerPolicy = referrerPolicy;
    }

    public String getReqAccept() {
        return reqAccept;
    }

    public void setReqAccept(String reqAccept) {
        this.reqAccept = reqAccept;
    }

    public String getReqAcceptEncoding() {
        return reqAcceptEncoding;
    }

    public void setReqAcceptEncoding(String reqAcceptEncoding) {
        this.reqAcceptEncoding = reqAcceptEncoding;
    }

    public String getReqAcceptLanguage() {
        return reqAcceptLanguage;
    }

    public void setReqAcceptLanguage(String reqAcceptLanguage) {
        this.reqAcceptLanguage = reqAcceptLanguage;
    }

    public String getReqCacheControl() {
        return reqCacheControl;
    }

    public void setReqCacheControl(String reqCacheControl) {
        this.reqCacheControl = reqCacheControl;
    }

    public String getReqConnection() {
        return reqConnection;
    }

    public void setReqConnection(String reqConnection) {
        this.reqConnection = reqConnection;
    }

    public String getReqContentType() {
        return reqContentType;
    }

    public void setReqContentType(String reqContentType) {
        this.reqContentType = reqContentType;
    }

    public String getReqTransferEncoding() {
        return reqTransferEncoding;
    }

    public void setReqTransferEncoding(String reqTransferEncoding) {
        this.reqTransferEncoding = reqTransferEncoding;
    }

    public String getReqCookie() {
        return reqCookie;
    }

    public void setReqCookie(String reqCookie) {
        this.reqCookie = reqCookie;
    }

    public String getReqOrigin() {
        return reqOrigin;
    }

    public void setReqOrigin(String reqOrigin) {
        this.reqOrigin = reqOrigin;
    }

    public String getReqHost() {
        return reqHost;
    }

    public void setReqHost(String reqHost) {
        this.reqHost = reqHost;
    }

    public String getReqPragma() {
        return reqPragma;
    }

    public void setReqPragma(String reqPragma) {
        this.reqPragma = reqPragma;
    }

    public String getReqReferer() {
        return reqReferer;
    }

    public void setReqReferer(String reqReferer) {
        this.reqReferer = reqReferer;
    }

    public String getReqSecFetchDest() {
        return reqSecFetchDest;
    }

    public void setReqSecFetchDest(String reqSecFetchDest) {
        this.reqSecFetchDest = reqSecFetchDest;
    }

    public String getReqSecFetchMode() {
        return reqSecFetchMode;
    }

    public void setReqSecFetchMode(String reqSecFetchMode) {
        this.reqSecFetchMode = reqSecFetchMode;
    }

    public String getReqSecFetchSite() {
        return reqSecFetchSite;
    }

    public void setReqSecFetchSite(String reqSecFetchSite) {
        this.reqSecFetchSite = reqSecFetchSite;
    }

    public String getReqSecFetchUser() {
        return reqSecFetchUser;
    }

    public void setReqSecFetchUser(String reqSecFetchUser) {
        this.reqSecFetchUser = reqSecFetchUser;
    }

    public String getReqToken() {
        return reqToken;
    }

    public void setReqToken(String reqToken) {
        this.reqToken = reqToken;
    }

    public String getReqUserAgent() {
        return reqUserAgent;
    }

    public void setReqUserAgent(String reqUserAgent) {
        this.reqUserAgent = reqUserAgent;
    }

    public String getReqXRequestedWith() {
        return reqXRequestedWith;
    }

    public void setReqXRequestedWith(String reqXRequestedWith) {
        this.reqXRequestedWith = reqXRequestedWith;
    }

    public String getReqXClientData() {
        return reqXClientData;
    }

    public void setReqXClientData(String reqXClientData) {
        this.reqXClientData = reqXClientData;
    }

    public String getResAcceptRanges() {
        return resAcceptRanges;
    }

    public void setResAcceptRanges(String resAcceptRanges) {
        this.resAcceptRanges = resAcceptRanges;
    }

    public String getResCacheControl() {
        return resCacheControl;
    }

    public void setResCacheControl(String resCacheControl) {
        this.resCacheControl = resCacheControl;
    }

    public String getResContentSecurityPolicy() {
        return resContentSecurityPolicy;
    }

    public void setResContentSecurityPolicy(String resContentSecurityPolicy) {
        this.resContentSecurityPolicy = resContentSecurityPolicy;
    }

    public String getResContentLength() {
        return resContentLength;
    }

    public void setResContentLength(String resContentLength) {
        this.resContentLength = resContentLength;
    }

    public String getResContentType() {
        return resContentType;
    }

    public void setResContentType(String resContentType) {
        this.resContentType = resContentType;
    }

    public String getResDate() {
        return resDate;
    }

    public void setResDate(String resDate) {
        this.resDate = resDate;
    }

    public String getResEtag() {
        return resEtag;
    }

    public void setResEtag(String resEtag) {
        this.resEtag = resEtag;
    }

    public String getResServer() {
        return resServer;
    }

    public void setResServer(String resServer) {
        this.resServer = resServer;
    }

    public String getResExpires() {
        return resExpires;
    }

    public void setResExpires(String resExpires) {
        this.resExpires = resExpires;
    }

    public String getResLastModified() {
        return resLastModified;
    }

    public void setResLastModified(String resLastModified) {
        this.resLastModified = resLastModified;
    }

    public String getResPragma() {
        return resPragma;
    }

    public void setResPragma(String resPragma) {
        this.resPragma = resPragma;
    }

    public String getResSetCookie() {
        return resSetCookie;
    }

    public void setResSetCookie(String resSetCookie) {
        this.resSetCookie = resSetCookie;
    }

    public String getResStrictTransportSecurity() {
        return resStrictTransportSecurity;
    }

    public void setResStrictTransportSecurity(String resStrictTransportSecurity) {
        this.resStrictTransportSecurity = resStrictTransportSecurity;
    }

    public String getResTransferEncoding() {
        return resTransferEncoding;
    }

    public void setResTransferEncoding(String resTransferEncoding) {
        this.resTransferEncoding = resTransferEncoding;
    }

    public String getResXContentTypeOptions() {
        return resXContentTypeOptions;
    }

    public void setResXContentTypeOptions(String resXContentTypeOptions) {
        this.resXContentTypeOptions = resXContentTypeOptions;
    }

    public String getResFrameOptions() {
        return resFrameOptions;
    }

    public void setResFrameOptions(String resFrameOptions) {
        this.resFrameOptions = resFrameOptions;
    }

    public String getResXXssProtection() {
        return resXXssProtection;
    }

    public void setResXXssProtection(String resXXssProtection) {
        this.resXXssProtection = resXXssProtection;
    }

    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    public Boolean getHasSensitive() {
        return hasSensitive;
    }

    public void setHasSensitive(Boolean hasSensitive) {
        this.hasSensitive = hasSensitive;
    }

    public String getRiskType() {
        return riskType;
    }

    public void setRiskType(String riskType) {
        this.riskType = riskType;
    }

    public Integer getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(Integer riskLevel) {
        this.riskLevel = riskLevel;
    }

    public Integer getEventType() {
        return eventType;
    }

    public void setEventType(Integer eventType) {
        this.eventType = eventType;
    }

    public Long getStrategyId() {
        return strategyId;
    }

    public void setStrategyId(Long strategyId) {
        this.strategyId = strategyId;
    }

    public String getStrategyName() {
        return strategyName;
    }

    public void setStrategyName(String strategyName) {
        this.strategyName = strategyName;
    }

    public Long getAppId() {
        return appId;
    }

    public void setAppId(Long appId) {
        this.appId = appId;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppDomain() {
        return appDomain;
    }

    public void setAppDomain(String appDomain) {
        this.appDomain = appDomain;
    }

    public Long getInterfaceId() {
        return interfaceId;
    }

    public void setInterfaceId(Long interfaceId) {
        this.interfaceId = interfaceId;
    }

    public String getInterfaceName() {
        return interfaceName;
    }

    public void setInterfaceName(String interfaceName) {
        this.interfaceName = interfaceName;
    }

    public String getInterfaceUrl() {
        return interfaceUrl;
    }

    public void setInterfaceUrl(String interfaceUrl) {
        this.interfaceUrl = interfaceUrl;
    }
}
