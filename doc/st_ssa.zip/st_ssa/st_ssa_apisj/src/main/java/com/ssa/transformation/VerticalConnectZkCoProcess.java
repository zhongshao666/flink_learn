package com.ssa.transformation;

import com.ssa.ApisjMain;
import com.ssa.bean.OfflineData;
import com.ssa.map.ParsingZkConfigSource;
import com.ssa.map.ParsingZkSource;
import com.ssa.strategy.StrategyConfig;
import com.ssa.strategy.StrategyMatch;
import com.ssa.sensitive.constants.CommonConstants;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.tuple.Tuple5;
import org.apache.flink.streaming.api.functions.co.BroadcastProcessFunction;
import org.apache.flink.util.Collector;

import java.util.Optional;

/**
 * @author Administrator
 * @role 链接zk广播流和离线数据流处理垂直越权访问
 */
public class VerticalConnectZkCoProcess extends BroadcastProcessFunction<OfflineData, Tuple4<Integer, Integer, String, String>, Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig>> {

    private ParsingZkSource parsingZkSource = new ParsingZkSource();

    @Override
    public void processElement(OfflineData value, ReadOnlyContext ctx, Collector<Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig>> out) throws Exception {
        if (CommonConstants.OfflineTableType.SENSITIVE_VISIT.getVal().equals(value.getOfflineTableType())) {
            out.collect(new Tuple5<>(value, -100, value.getAppId(), null, null));
        } else {
            ctx.output(ApisjMain.filterVertical, new Tuple5<>(value, -100, value.getAppId(), null, null));
        }
    }

    @Override
    public void processBroadcastElement(Tuple4<Integer, Integer, String, String> value, Context ctx, Collector<Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig>> out) throws Exception {
        String filterStrategy = CommonConstants.StrategyType.VERTICALOVERREACH.getVal();
        if (value.f0 == CommonConstants.ZkDataType.RISK_TYPE.getVal()) {
            StrategyMatch strategyMatch = parsingZkSource.parsingZkJson(value.f3);
            if (filterStrategy.equals(strategyMatch.getStrategy())) {
                Optional.ofNullable(strategyMatch.getAppIds()).ifPresent(item -> {
                    for (Long aLong : item) {
                        out.collect(new Tuple5<>(null, value.f1, aLong, strategyMatch, null));
                    }
                });
            } else {
                Optional.ofNullable(strategyMatch.getAppIds()).ifPresent(item -> {
                    for (Long aLong : item) {
                        ctx.output(ApisjMain.filterVertical,new Tuple5<>(null, value.f1, aLong, strategyMatch, null));
                    }
                });
            }
        }
        if (value.f0 == CommonConstants.ZkDataType.STRATEGY_CONFIG.getVal()) {
            StrategyConfig strategyConfig = ParsingZkConfigSource.parsingZkConfigSource(value.f3);
            out.collect(new Tuple5<>(null, value.f1, strategyConfig.getAppId(), null, strategyConfig));
            ctx.output(ApisjMain.filterVertical, new Tuple5<>(null, value.f1, strategyConfig.getAppId(), null, strategyConfig));
        }
    }
}
