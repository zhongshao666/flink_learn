package com.ssa.sensitive.match;

import com.google.gson.stream.JsonReader;

import java.io.Reader;
import java.lang.reflect.Array;
import java.lang.reflect.Field;

/**
 * @author qsj
 * @since 2021/1/14
 */
public class DefaultJsonReader  extends JsonReader {

    private static Field stackSizeField;

    private static Field stackField;

    private static Field pathNames;

    static {

        try {
            stackSizeField = JsonReader.class.getDeclaredField("stackSize");
            stackSizeField.setAccessible(true);

            stackField = JsonReader.class.getDeclaredField("stack");
            stackField.setAccessible(true);

            pathNames = JsonReader.class.getDeclaredField("pathNames");
            pathNames.setAccessible(true);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public DefaultJsonReader(Reader in) {
        super(in);

        Field f = null;
    }

    private int stackSize() {

        try {
            return (Integer) stackSizeField.get(this);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private int stack(int index) {

        try {
            return Array.getInt(stackField.get(this), index);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private String pathNames(int index) {

        try {
            return (String) Array.get(pathNames.get(this), index);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public String getPath() {

        StringBuilder result = new StringBuilder().append('$');
        for (int i = 0, size = stackSize(); i < size; i++) {
            switch (stack(i)) {
                case JsonScope.EMPTY_ARRAY:
                case JsonScope.NONEMPTY_ARRAY:
                    result.append('[').append("*").append(']');
                    break;

                case JsonScope.EMPTY_OBJECT:
                case JsonScope.DANGLING_NAME:
                case JsonScope.NONEMPTY_OBJECT:
                    result.append('.');
                    if (pathNames(i) != null) {
                        result.append(pathNames(i));
                    }
                    break;

                case JsonScope.NONEMPTY_DOCUMENT:
                case JsonScope.EMPTY_DOCUMENT:
                case JsonScope.CLOSED:
                    break;
            }
        }
        return result.toString();
    }


    final class JsonScope {

        /**
         * An array with no elements requires no separators or newlines before
         * it is closed.
         */
        static final int EMPTY_ARRAY = 1;

        /**
         * A array with at least one value requires a comma and newline before
         * the next element.
         */
        static final int NONEMPTY_ARRAY = 2;

        /**
         * An object with no name/value pairs requires no separators or newlines
         * before it is closed.
         */
        static final int EMPTY_OBJECT = 3;

        /**
         * An object whose most recent element is a key. The next element must
         * be a value.
         */
        static final int DANGLING_NAME = 4;

        /**
         * An object with at least one name/value pair requires a comma and
         * newline before the next element.
         */
        static final int NONEMPTY_OBJECT = 5;

        /**
         * No object or array has been started.
         */
        static final int EMPTY_DOCUMENT = 6;

        /**
         * A document with at an array or object.
         */
        static final int NONEMPTY_DOCUMENT = 7;

        /**
         * A document that's been closed and cannot be accessed.
         */
        static final int CLOSED = 8;
    }
}
