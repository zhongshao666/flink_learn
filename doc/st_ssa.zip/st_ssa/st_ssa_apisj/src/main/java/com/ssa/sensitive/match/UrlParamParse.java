package com.ssa.sensitive.match;

import com.google.common.collect.Maps;
import com.ssa.sensitive.constants.CommonConstants;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Map;

/**
 * @author qsj
 * @since 2021/5/11
 */
public class UrlParamParse extends AbstractParse {
    @Override
    public List<String> parseData(String body) {
        return null;
    }

    @Override
    public Map<String, String> parseMapData(String url) {
        Map<String, String> map = Maps.newHashMap();
        if (StringUtils.isNotBlank(url) && url.contains(CommonConstants.URL_PARAM_START_CHAR)) {
            int i = url.indexOf(CommonConstants.URL_PARAM_START_CHAR);
            if ((i + 1) <= url.length()) {
                String params = url.substring(i + 1);
                formKvParse(params, map);
            }
        }
        return map;
    }
}
