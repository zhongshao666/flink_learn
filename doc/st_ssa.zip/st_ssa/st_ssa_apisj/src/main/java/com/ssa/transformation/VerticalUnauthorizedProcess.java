package com.ssa.transformation;

import com.ssa.bean.OfflineData;
import com.ssa.map.ConditionTOMarking;
import com.ssa.strategy.StrategyConfig;
import com.ssa.strategy.StrategyMatch;
import com.ssa.sensitive.constants.CommonConstants;
import com.ssa.sensitive.to.HttpLog;
import org.apache.flink.api.java.tuple.Tuple5;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.KeyedCoProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * @author Administrator
 * @role 垂直越权访问processfunction
 */
public class VerticalUnauthorizedProcess extends KeyedCoProcessFunction<Long, HttpLog, Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig>, HttpLog> {

    private static Logger logger = LoggerFactory.getLogger(VerticalUnauthorizedProcess.class);

    private Map<String, LinkedList<Long>> userQueueAccessTime;
    private Map<Long, HashSet<Long>> strategyMatchMap;
    private Map<Long, StrategyMatch> strategyMatch;
    private Map<Long, StrategyConfig> strategyConfig;

    @Override
    public void open(Configuration parameters) throws Exception {

        userQueueAccessTime = new HashMap<>();
        strategyMatchMap = new HashMap<>();
        strategyMatch = new HashMap<>();
        strategyConfig = new HashMap<>();
    }


    @Override
    public void processElement1(HttpLog value, Context ctx, Collector<HttpLog> out) throws Exception {

        Long currentKey = ctx.getCurrentKey();
        if (strategyMatchMap.get(currentKey) != null &&
                strategyConfig.get(currentKey) != null &&
                strategyMatch.get(currentKey) != null &&
                !strategyMatchMap.get(currentKey).contains(value.getInterfaceId()) &&
                strategyMatch.get(currentKey).getEnable() &&
                strategyConfig.get(currentKey).getRiskPolicyEnable() &&
                strategyMatch.get(currentKey).getStrategyMatchCondition().getTriggerFrequency() != null) {
            int size = 0;
            if (userQueueAccessTime.get(value.getUserName()) != null) {
                size = userQueueAccessTime.get(value.getUserName()).size();
            }
            int times = strategyMatch.get(currentKey).getStrategyMatchCondition().getTriggerFrequency().getTimes();

            if (userQueueAccessTime.get(value.getUserName()) == null || userQueueAccessTime.get(value.getUserName()).size() < strategyMatch.get(currentKey).getStrategyMatchCondition().getTriggerFrequency().getTimes()) {
                if (userQueueAccessTime.get(value.getUserName()) == null) {
                    LinkedList<Long> queue = new LinkedList<>();
                    queue.addLast(value.getRequestTime());
                    userQueueAccessTime.put(value.getUserName(), queue);
                } else {
                    userQueueAccessTime.get(value.getUserName()).addLast(value.getRequestTime());
                }
            } else if (size > times) {
                ConditionTOMarking.reSetFrequencyAlarmModule(userQueueAccessTime.get(value.getUserName()), size - times);
            }


            if (size == times) {
                if (value.getRequestTime() - userQueueAccessTime.get(value.getUserName()).getFirst() <
                        ConditionTOMarking.transFromationTime(strategyMatch.get(currentKey).getStrategyMatchCondition().getTriggerFrequency().getTime(),
                                strategyMatch.get(currentKey).getStrategyMatchCondition().getTriggerFrequency().getUnit())) {
                    logger.info("http log marking verticaloverreach logid:{}", value.getLogId());
                    ConditionTOMarking.setStrategy(value, strategyMatch.get(currentKey));
                }
            }
        }
        out.collect(value);
    }


    @Override
    public void processElement2(Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig> value, Context ctx, Collector<HttpLog> out) throws Exception {
        Long currentKey = ctx.getCurrentKey();
        if (value.f0 != null) {
            if (strategyMatchMap.get(currentKey) == null) {
                HashSet<Long> hashSet = new HashSet<>();
                hashSet.add(value.f0.getInterfaceId());
                strategyMatchMap.put(currentKey, hashSet);
            } else {
                strategyMatchMap.get(currentKey).add(value.f0.getInterfaceId());
            }
        }
        if (value.f3 != null && value.f1 == CommonConstants.OperateType.DELETE.getVal()) {
            strategyMatch.remove(value.f2);
        } else if (value.f3 != null) {
            strategyMatch.put(value.f2, value.f3);
        }

        if (value.f4 != null && value.f1 == CommonConstants.OperateType.DELETE.getVal()) {
            strategyConfig.remove(value.f2);
        } else if (value.f4 != null) {
            strategyConfig.put(value.f2, value.f4);
        }
    }
}
