package com.ssa.transformation;


import com.ssa.bean.OfflineData;
import com.ssa.map.ConditionTOMarking;
import com.ssa.strategy.StrategyConfig;
import com.ssa.strategy.StrategyMatch;
import com.ssa.sensitive.constants.CommonConstants;
import com.ssa.sensitive.to.HttpLog;
import org.apache.flink.api.java.tuple.Tuple5;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.KeyedCoProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author Administrator
 * @role 敏感数据异常操作processfuntion
 */
public class SensitiveAbnormalProcess extends KeyedCoProcessFunction<Long, HttpLog, Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig>, HttpLog> {

    private Map<Long, StrategyConfig> strategyConfigs;
    private Map<String, HashSet<Long>> strategyMatchMap;
    private Map<Long, StrategyMatch> strategyMatchs;
    private static Logger logger = LoggerFactory.getLogger(HighFrequencyAccessProcess.class);


    @Override
    public void open(Configuration parameters) throws Exception {
        strategyConfigs = new HashMap<>();
        strategyMatchs = new HashMap<>();
        strategyMatchMap = new HashMap<>();

    }

    @Override
    public void processElement1(HttpLog value, Context ctx, Collector<HttpLog> out) throws Exception {


        StrategyMatch strategyMatch = strategyMatchs.get(value.getAppId());
        StrategyConfig strategyConfig = strategyConfigs.get(value.getAppId());

        if (strategyMatch != null && strategyConfig != null &&
                strategyConfig.getRiskPolicyEnable() && strategyMatch.getEnable()) {
            Optional.ofNullable(value.getSensitiveLabelField()).ifPresent(item -> {
                String[] split = item.split(CommonConstants.CSV_SPLIT_CHAR);
                AtomicBoolean flag = new AtomicBoolean(true);
                for (String sensitiveLabel : split) {
                    Optional.ofNullable(strategyMatchMap.get(sensitiveLabel)).ifPresent(temp -> {
                        if (temp.contains(value.getInterfaceId())) {
                            flag.set(false);
                        }
                    });
                }
                if (flag.get()) {
                    logger.info("http log marking highfrequencyaccess logid:{}", value.getLogId());
                    ConditionTOMarking.setStrategy(value, strategyMatch);
                }
            });
        }
        out.collect(value);
    }

    @Override
    public void processElement2(Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig> value, Context ctx, Collector<HttpLog> out) throws Exception {

        if (value.f0 != null) {
            if (strategyMatchMap.get(value.f0.getSensitiveLabelField()) == null) {
                HashSet<Long> hashSet = new HashSet<>();
                hashSet.add(value.f0.getInterfaceId());
                strategyMatchMap.put(value.f0.getSensitiveLabelField(), hashSet);
            } else {
                strategyMatchMap.get(value.f0.getSensitiveLabelField()).add(value.f0.getInterfaceId());
            }
        }
        if (value.f3 != null && value.f1 == CommonConstants.OperateType.DELETE.getVal()) {
            strategyMatchs.remove(value.f2);
        } else if (value.f3 != null) {
            strategyMatchs.put(value.f2, value.f3);
        }

        if (value.f4 != null && value.f1 == CommonConstants.OperateType.DELETE.getVal()) {
            strategyConfigs.remove(value.f2);
        } else if (value.f4 != null) {
            strategyConfigs.put(value.f2, value.f4);
        }
    }
}
