package com.ssa.strategy;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Administrator
 */
@Data
public class UrlParsingTool {
    private List<UrlContent> urlList = new ArrayList<>();
}
