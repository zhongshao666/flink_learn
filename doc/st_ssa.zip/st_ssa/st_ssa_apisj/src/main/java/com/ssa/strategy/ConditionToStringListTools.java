package com.ssa.strategy;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;


@Data
public class ConditionToStringListTools {
    private List<String> toolList = new ArrayList<>();
    private Integer include;
}
