package com.ssa.map;

import com.ssa.strategy.StrategyMatch;
import com.ssa.sensitive.to.HttpLog;
import com.ssa.sensitive.constants.CommonConstants;

import java.util.LinkedList;

/**
 * @author Administrator
 * @sole strategy打标以及时间转换
 */
public class ConditionTOMarking {

    /**
     * n分钟出现m次告警
     * 当出现次数变小时，缩小linkedList长度
     */
    public static void reSetFrequencyAlarmModule(LinkedList<Long> linkedList, Integer size) {
        for (int i = 0; i < size; i++) {
            linkedList.poll();
        }
    }

    /**
     * 打标
     */
    public static void setStrategy(HttpLog httpLog, StrategyMatch strategyMatch) {

        if (httpLog.getRiskType() == null) {
            httpLog.setRiskType(strategyMatch.getRiskType());
        } else {
            httpLog.setRiskType(httpLog.getRiskType() + "," + strategyMatch.getRiskType());
        }
        if (httpLog.getRiskLevel() == null) {
            httpLog.setRiskLevel(strategyMatch.getRiskLevel());
        } else {
            httpLog.setRiskLevel(Math.max(httpLog.getRiskLevel(), strategyMatch.getRiskLevel()));
        }
        if (httpLog.getStrategyName() == null) {
            httpLog.setStrategyName(strategyMatch.getName());
        } else {
            httpLog.setStrategyName(httpLog.getStrategyName() + "," + strategyMatch.getName());
        }
        if (httpLog.getStrategyId() == null) {
            httpLog.setStrategyId(strategyMatch.getId().toString());
        } else {
            httpLog.setStrategyId(httpLog.getStrategyId() + "," + strategyMatch.getId());
        }
        if (httpLog.getStrategyType() == null) {
            httpLog.setStrategyType(strategyMatch.getStrategyType());
        } else {
            httpLog.setStrategyType(httpLog.getStrategyType() + "," + strategyMatch.getStrategyType());
        }

    }

    /**
     * 窗口多少分钟
     */
    public static Integer transFromationTime(Integer time, String unit) {
        int longTime = 0;
        if ((CommonConstants.MILLISECOND_SHORT.equals(unit))) {
            longTime = time;
        } else if (CommonConstants.SECOND_SHORT.equals(unit)) {
            longTime = time * 1000;
        } else if (CommonConstants.MINUTE_SHORT.equals(unit)) {
            longTime = time * 1000 * 60;
        }

        return longTime;
    }
}
