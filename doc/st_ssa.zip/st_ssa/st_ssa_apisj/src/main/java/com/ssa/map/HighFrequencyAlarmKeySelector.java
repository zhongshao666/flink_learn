package com.ssa.map;

import com.ssa.sensitive.to.HttpLog;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;

public class HighFrequencyAlarmKeySelector implements KeySelector<HttpLog, Tuple2<Long,String>> {
    @Override
    public Tuple2<Long,String> getKey(HttpLog httpLog) throws Exception {
        return new Tuple2<>(httpLog.getAppId(),httpLog.getUserName());
    }
}
