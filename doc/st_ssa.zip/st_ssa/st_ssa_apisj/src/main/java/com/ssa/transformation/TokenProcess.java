package com.ssa.transformation;

import com.ssa.utils.CustomThreadPoolExecutor;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 令牌桶限流
 *
 * @author
 */
public class TokenProcess extends ProcessFunction<String, String> {
    private static final Logger logger = LoggerFactory.getLogger(TokenProcess.class);
    AtomicInteger counter = new AtomicInteger(0);
    int maxCount ;

    public TokenProcess(Integer defaultCountNum) {
        this.maxCount = defaultCountNum;
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        ScheduledExecutorService executorService = CustomThreadPoolExecutor.newScheduledThreadPool(1, "tokenProcess");

        executorService.scheduleAtFixedRate(() -> counter.set(0), 1000,1000, TimeUnit.MILLISECONDS);
    }

    @Override
    public void processElement(String s, Context context, Collector<String> collector) throws Exception {
        if (counter.incrementAndGet() <= maxCount) {
            collector.collect(s);
        } else {
            logger.info("dataflow is too large ,drop the kafka data: {}", s);
        }
    }
}
