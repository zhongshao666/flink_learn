package com.ssa.transformation;

import com.ssa.logic.Rule;
import com.ssa.map.ConditionTOMarking;

import com.ssa.strategy.StrategyConfig;
import com.ssa.strategy.StrategyMatch;
import com.ssa.sensitive.constants.CommonConstants;
import com.ssa.sensitive.to.HttpLog;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.BroadcastProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.util.*;

/**
 * 自定义规则算子
 */
public class CustomRuleProcess extends BroadcastProcessFunction<HttpLog, Tuple4<Integer, Integer, String, String>, HttpLog> {
    private static final Logger logger = LoggerFactory.getLogger(CustomRuleProcess.class);

    //自定义规则逻辑
    private Rule customRule;
    //存储zkSource规则
    private Map<Integer, StrategyMatch> matchMap;
    //存储zkSource规则   appId开关
    private Map<Long, StrategyConfig> appIdMap;
    //zkSource工具类
    private StrategyProcessElementTool strategyProcessElementTool;


    //中间变量
    StrategyMatch value;
    boolean b;

    @Override

    public void open(Configuration parameters) throws Exception {
        customRule = new Rule();
        strategyProcessElementTool = new StrategyProcessElementTool();
        matchMap = new HashMap<>();
        appIdMap = new HashMap<>();

    }

    @Override
    public void processElement(HttpLog httpLog, ReadOnlyContext readOnlyContext, Collector<HttpLog> collector) throws Exception {

        if (appIdMap.get(httpLog.getAppId()) != null
                && appIdMap.get(httpLog.getAppId()).getRiskPolicyEnable()){
            for (Map.Entry<Integer, StrategyMatch> entry : matchMap.entrySet()) {
                value = entry.getValue();
                //先判断是否启用
                if (value.getEnable()) {
                    //判断资产id  资产id为必填项
                    if (value.getAppIds().contains(httpLog.getAppId())) {
                        b = customRule.checkCustom(value, httpLog);
                        customRule.reset();
                        if (b) {
                            logger.info("http log marking customRule logid:{}", httpLog.getLogId());
                            //打标后
                            ConditionTOMarking.setStrategy(httpLog, value);
                        }
                    }
                }
            }
        }

/*        for (Map.Entry<Long, StrategyConfig> entryAppId : appIdMap.entrySet()) {
            //判断资产id总开关
            if (entryAppId.getKey().equals(httpLog.getAppId()) && entryAppId.getValue().getUserDefinedEnable()) {

                break;
            }
        }*/

        collector.collect(httpLog);
    }

    // tuple4<策略类型，增删改，zk路径，内容>
    @Override
    public void processBroadcastElement(Tuple4<Integer, Integer, String, String> integerIntegerStringStringTuple4, Context context, Collector<HttpLog> collector) throws Exception {
        String filterStrategy = CommonConstants.StrategyType.USERDEFINED.getVal();

        if (integerIntegerStringStringTuple4.f0 == CommonConstants.ZkDataType.USER_DEFINE_TYPE.getVal()) {
            strategyProcessElementTool.initStrategyMatch(integerIntegerStringStringTuple4.f1, filterStrategy, integerIntegerStringStringTuple4.f3, matchMap);
        }
        if (integerIntegerStringStringTuple4.f0 == CommonConstants.ZkDataType.STRATEGY_CONFIG.getVal()) {
            strategyProcessElementTool.modifyAppIdConfig(integerIntegerStringStringTuple4.f1, integerIntegerStringStringTuple4.f3, appIdMap);
        }
    }

}
