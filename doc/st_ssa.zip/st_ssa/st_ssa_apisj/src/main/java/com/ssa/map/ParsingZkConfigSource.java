package com.ssa.map;

import com.alibaba.fastjson.JSON;
import com.ssa.strategy.StrategyConfig;

public class ParsingZkConfigSource {
    public static StrategyConfig parsingZkConfigSource(String str) {
        return JSON.parseObject(str, StrategyConfig.class);
    }
}
