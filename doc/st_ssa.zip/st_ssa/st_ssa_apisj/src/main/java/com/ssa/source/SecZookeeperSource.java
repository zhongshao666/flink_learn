package com.ssa.source;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.ssa.bean.AppBean;
import com.ssa.bean.InterfaceBean;
import com.ssa.bean.ZkSensitiveLabel;
import com.ssa.serializer.MyZkSerializer;
import com.ssa.sensitive.constants.CommonConstants;
import org.I0Itec.zkclient.IZkDataListener;
import org.I0Itec.zkclient.ZkClient;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.source.RichSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;


/**
 * @author admin
 */
public class SecZookeeperSource extends RichSourceFunction<Tuple4<Integer, Integer, String, String>> {

    private static final Logger logger = LoggerFactory.getLogger(SecZookeeperSource.class);

    ZkClient zkClient = null;
    SourceContext<Tuple4<Integer, Integer, String, String>> sourceContextGlobal = null;
    List<String> initInterfaceKeys;
    List<String> initAppKeys;
    List<String> initSensitiveLabelKeys;
    ParameterTool parameterTool;

    @Override
    public void open(Configuration parameters) throws Exception {
        System.setProperty("zookeeper.sasl.client", "false");
        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig()
                .getGlobalJobParameters();
        String zkAddr = parameterTool.get("zookeeper.url");

        logger.info("zookeeper init client url:{}", parameterTool.get("zookeeper.url"));
        zkClient = new ZkClient(parameterTool.get("zookeeper.url"), parameterTool.getInt("zookeeper.timeout"));
        zkClient.setZkSerializer(new MyZkSerializer());

        initInterfaceKeys = new ArrayList<>();
        initAppKeys = new ArrayList<>();
        initSensitiveLabelKeys = Lists.newArrayList();


        zkClient.subscribeChildChanges(parameterTool.get("zookeeper.interface.data.path"), (arg0, arg1) -> {
            logger.info("zookeeper interface chg  arg0:{},arg1:{}", arg0, arg1.size());

            for (String argString : arg1) {
                if (!initInterfaceKeys.contains(argString)) {
                    String nodeValue = zkClient.readData(parameterTool.get("zookeeper.interface.data.path") + "/" + argString);
                    if (StringUtils.isNotBlank(nodeValue)) {
                        sourceContextGlobal.collect(new Tuple4<>(CommonConstants.ZkDataType.INTERFACE_TYPE.getVal(), CommonConstants.OperateType.ADD.getVal(), argString, nodeValue));
                    }
                }
            }
            for (String key : initInterfaceKeys) {
                if (!arg1.contains(key)) {
                    InterfaceBean interfaceBean = new InterfaceBean();
                    interfaceBean.setId(Long.valueOf(key));
                    sourceContextGlobal.collect(new Tuple4<>(CommonConstants.ZkDataType.INTERFACE_TYPE.getVal(), CommonConstants.OperateType.DELETE.getVal(), key, JSON.toJSONString(interfaceBean)));
                }
            }

            initInterfaceKeys.clear();
            initInterfaceKeys.addAll(arg1);


        });

        zkClient.subscribeChildChanges(parameterTool.get("zookeeper.app.data.path"), (arg0, arg1) -> {
            logger.info("zookeeper app chg  arg0:{},arg1:{}", arg0, arg1.size());

            for (String argString : arg1) {
                if (!initAppKeys.contains(argString)) {
                    sourceContextGlobal.collect(new Tuple4<>(CommonConstants.ZkDataType.APP_TYPE.getVal(), CommonConstants.OperateType.ADD.getVal(), argString, zkClient.readData(parameterTool.get("zookeeper.app.data.path") + "/" + argString)));
                }
            }
            for (String key : initAppKeys) {
                if (!arg1.contains(key)) {
                    AppBean appBean = new AppBean();
                    appBean.setId(key);
                    sourceContextGlobal.collect(new Tuple4<>(CommonConstants.ZkDataType.APP_TYPE.getVal(), CommonConstants.OperateType.DELETE.getVal(), key, JSON.toJSONString(appBean)));
                }
            }

            initAppKeys.clear();
            initAppKeys.addAll(arg1);

        });

        zkClient.subscribeChildChanges(parameterTool.get("zookeeper.sensitive.label.data.path"), (path, valList) -> {
            logger.info("zookeeper sensitive label chg  arg0:{},arg1:{}", path, valList.size());

            for (String id : valList) {
                if (!initAppKeys.contains(id)) {
                    sourceContextGlobal.collect(new Tuple4<>(CommonConstants.ZkDataType.SENSITIVE_LABEL.getVal(), CommonConstants.OperateType.ADD.getVal(), id, zkClient.readData(parameterTool.get("zookeeper.sensitive.label.data.path") + "/" + id)));
                }
            }
            for (String key : initSensitiveLabelKeys) {
                if (!valList.contains(key)) {
                    ZkSensitiveLabel sensitiveLabel = new ZkSensitiveLabel();
                    sensitiveLabel.setId(Long.parseLong(key));
                    sourceContextGlobal.collect(new Tuple4<>(CommonConstants.ZkDataType.SENSITIVE_LABEL.getVal(), CommonConstants.OperateType.DELETE.getVal(), key, JSON.toJSONString(sensitiveLabel)));
                }
            }
            initSensitiveLabelKeys.clear();
            initSensitiveLabelKeys.addAll(valList);
        });

        zkClient.subscribeDataChanges(parameterTool.get("zookeeper.app.discovery.path"), new IZkDataListener() {
            @Override
            public void handleDataChange(String s, Object o) throws Exception {
                logger.info("zookeeper discover chg  arg0:{},arg1:{}", s, o.toString());
                sourceContextGlobal.collect(new Tuple4<>(CommonConstants.ZkDataType.DISCOVERY_TYPE.getVal(), CommonConstants.OperateType.ADD.getVal(), s, o.toString()));
            }

            @Override
            public void handleDataDeleted(String s) throws Exception {
                logger.info("zookeeper discover delete  arg0:{}", s);
                sourceContextGlobal.collect(new Tuple4<>(CommonConstants.ZkDataType.DISCOVERY_TYPE.getVal(), CommonConstants.OperateType.DELETE.getVal(), s, "delete"));
            }

        });
    }

    @Override
    public void run(SourceContext<Tuple4<Integer, Integer, String, String>> sourceContext) throws Exception {
        sourceContextGlobal = sourceContext;
        List<String> interfaceNodes = zkClient.getChildren(parameterTool.get("zookeeper.interface.data.path"));
        List<String> appNodes = zkClient.getChildren(parameterTool.get("zookeeper.app.data.path"));
        String discoveryNode = zkClient.readData(parameterTool.get("zookeeper.app.discovery.path"));

        logger.info("zookeeper load data info interface:{},app:{},discovery:{}", interfaceNodes.size(), appNodes.size(), discoveryNode);

        for (String item : interfaceNodes) {
            initInterfaceKeys.add(item);
            String nodeValue = zkClient.readData(parameterTool.get("zookeeper.interface.data.path") + "/" + item);

            if (StringUtils.isNotBlank(nodeValue)) {
                sourceContextGlobal.collect(new Tuple4<>(CommonConstants.ZkDataType.INTERFACE_TYPE.getVal(), CommonConstants.OperateType.ADD.getVal(), item, nodeValue));
            }
        }
        for (String item : appNodes) {
            initAppKeys.add(item);
            String nodeValue = zkClient.readData(parameterTool.get("zookeeper.app.data.path") + "/" + item);

            if (StringUtils.isNotBlank(nodeValue)) {
                sourceContextGlobal.collect(new Tuple4<>(CommonConstants.ZkDataType.APP_TYPE.getVal(), CommonConstants.OperateType.ADD.getVal(), item, nodeValue));
            }
        }

        if (StringUtils.isNotBlank(discoveryNode)) {

            sourceContextGlobal.collect(new Tuple4<>(CommonConstants.ZkDataType.DISCOVERY_TYPE.getVal(), CommonConstants.OperateType.ADD.getVal(), parameterTool.get("zookeeper.app.discovery.path"), discoveryNode));
        }

        while (true) {
            Thread.sleep(500);
        }
    }

    @Override
    public void close() throws Exception {
        super.close();
    }

    @Override
    public void cancel() {

    }


}
