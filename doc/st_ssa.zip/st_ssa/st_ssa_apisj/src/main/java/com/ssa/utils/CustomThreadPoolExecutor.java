package com.ssa.utils;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author qsj
 * @since 2020/2/27
 * 自定义线程池
 */
public class CustomThreadPoolExecutor {

    /**
     * 定时执行线程池
     * @param coreSize
     * @param threadNamePre
     * @return
     */
    public static ScheduledExecutorService newScheduledThreadPool(int coreSize,String threadNamePre){
        return new ScheduledThreadPoolExecutor(coreSize,getCustomThreadFactory(threadNamePre));
    }

    /**
     * 固定长度线程池
     * @param nThreads
     * @return
     */
    public static ExecutorService newFixedThreadPool(int nThreads,String threadNamePre){
        return new ThreadPoolExecutor(nThreads, nThreads,
                0L, TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<Runnable>(),
                getCustomThreadFactory(threadNamePre));
    }

    /**
     * 指定增长线程池
     * @param coreSize
     * @param maxSize
     * @param threadNamePre
     * @return
     */
    public static ExecutorService newGrowThreadPool(int coreSize,int maxSize, String threadNamePre){
        return new ThreadPoolExecutor(coreSize, maxSize,
                60L, TimeUnit.SECONDS,
                new SynchronousQueue<Runnable>(),
                getCustomThreadFactory(threadNamePre));
    }
    /**
     * 获取threadFactory
     * @param threadNamePre
     * @return
     */
    private static ThreadFactory getCustomThreadFactory(String threadNamePre){
        return new ThreadFactory() {
            private AtomicInteger count = new AtomicInteger(0);
            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r);
                String threadName = threadNamePre + "-"+CustomThreadPoolExecutor.class.getSimpleName() + "-"+count.addAndGet(1);
                t.setName(threadName);
                return t;
            }
        };
    }
}
