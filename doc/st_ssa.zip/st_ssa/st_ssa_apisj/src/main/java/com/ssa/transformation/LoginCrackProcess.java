package com.ssa.transformation;

import com.ssa.map.ConditionTOMarking;
import com.ssa.map.ParsingZkConfigSource;
import com.ssa.map.ParsingZkSource;
import com.ssa.strategy.StrategyConfig;
import com.ssa.strategy.StrategyMatch;
import com.ssa.sensitive.constants.CommonConstants;
import com.ssa.sensitive.to.HttpLog;
import org.apache.flink.api.common.state.*;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.KeyedBroadcastProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

/**
 * @author Administrator
 * @role 暴力登录破解processfuntion
 */
public class LoginCrackProcess extends KeyedBroadcastProcessFunction<String, HttpLog, Tuple4<Integer, Integer, String, String>, HttpLog> {

    private static final Logger logger = LoggerFactory.getLogger(LoginCrackProcess.class);

    private ValueState<LinkedList<Long>> userQueueAccessTime;
    private ParsingZkSource parsingZkSource = new ParsingZkSource();

    private Map<Long, StrategyMatch> strategyMatchMap;
    private Map<Long, StrategyConfig> strategyConfigMap;

    @Override
    public void open(Configuration parameters) throws Exception {

        StateTtlConfig stateTtlConfig = StateTtlConfig.newBuilder(Time.minutes(30))
                .setUpdateType(StateTtlConfig.UpdateType.OnCreateAndWrite)
                .setStateVisibility(StateTtlConfig.StateVisibility.NeverReturnExpired)
                .disableCleanupInBackground()
                .cleanupFullSnapshot()
                .build();

        ValueStateDescriptor<LinkedList<Long>> userLoginQueueTimea = new ValueStateDescriptor<>("userQueueAccessTime", TypeInformation.of(new TypeHint<LinkedList<Long>>() {
        }));
        userQueueAccessTime = getRuntimeContext().getState(userLoginQueueTimea);
        userLoginQueueTimea.enableTimeToLive(stateTtlConfig);

        strategyMatchMap = new HashMap<>();
        strategyConfigMap = new HashMap<>();

    }

    @Override
    public void processElement(HttpLog value, ReadOnlyContext ctx, Collector<HttpLog> out) throws Exception {

        StrategyMatch strategyMatch = strategyMatchMap.get(value.getAppId());
        StrategyConfig strategyConfig = strategyConfigMap.get(value.getAppId());

        if (strategyMatch != null && strategyConfig != null && strategyMatch.getEnable() && strategyConfig.getRiskPolicyEnable()) {
            int times = strategyMatchMap.get(value.getAppId()).getStrategyMatchCondition().getLoginFrequency().getTimes();
            if (userQueueAccessTime.value() == null) {
                LinkedList<Long> queue = new LinkedList<>();
                queue.addLast(value.getRequestTime());
                userQueueAccessTime.update(queue);
            } else {
                LinkedList<Long> value1 = userQueueAccessTime.value();
                value1.addLast(value.getRequestTime());
                userQueueAccessTime.update(value1);
            }
            if (userQueueAccessTime.value().size() > times) {
                ConditionTOMarking.reSetFrequencyAlarmModule(userQueueAccessTime.value(), userQueueAccessTime.value().size() - times);
            }

            if (userQueueAccessTime.value().size() == times) {
                if (value.getRequestTime() - userQueueAccessTime.value().getFirst() <
                        ConditionTOMarking.transFromationTime(strategyMatch.getStrategyMatchCondition().getLoginFrequency().getTime(),
                                strategyMatch.getStrategyMatchCondition().getLoginFrequency().getUnit())) {
                    logger.info("http log marking logincrack logid:{}, userName:{}", value.getLogId(), value.getUserName());
                    ConditionTOMarking.setStrategy(value, strategyMatch);
                }

            }
        }
        out.collect(value);

    }

    @Override
    public void processBroadcastElement(Tuple4<Integer, Integer, String, String> value, Context ctx, Collector<HttpLog> out) throws Exception {

        String filterStrategy = CommonConstants.StrategyType.LOGINCRACK.getVal();
        if (value.f0 == CommonConstants.ZkDataType.RISK_TYPE.getVal()) {
            StrategyMatch strategyMatchs = parsingZkSource.parsingZkJson(value.f3);
            if (strategyMatchs.getAppIds().size() > 0 && value.f1 == CommonConstants.OperateType.UPDATE.getVal() || value.f1 == CommonConstants.OperateType.ADD.getVal()) {
                if (filterStrategy.equals(strategyMatchs.getStrategy())) {
                    for (Long appId : strategyMatchs.getAppIds()) {
                        strategyMatchMap.put(appId, strategyMatchs);
                    }
                }
            } else if (value.f1 == CommonConstants.OperateType.DELETE.getVal() && strategyMatchs.getAppIds().size() > 0) {
                if (filterStrategy.equals(strategyMatchs.getStrategy())) {
                    for (Long appId : strategyMatchs.getAppIds()) {
                        strategyMatchMap.remove(appId);
                    }
                }
            }
        }
        if (value.f0 == CommonConstants.ZkDataType.STRATEGY_CONFIG.getVal()) {
            if (value.f1 == CommonConstants.OperateType.DELETE.getVal()) {
                StrategyConfig strategyConfig = ParsingZkConfigSource.parsingZkConfigSource(value.f3);
                strategyConfigMap.remove(strategyConfig.getAppId());
            } else {
                StrategyConfig strategyConfig = ParsingZkConfigSource.parsingZkConfigSource(value.f3);
                strategyConfigMap.put(strategyConfig.getAppId(), strategyConfig);
            }
        }
    }
}