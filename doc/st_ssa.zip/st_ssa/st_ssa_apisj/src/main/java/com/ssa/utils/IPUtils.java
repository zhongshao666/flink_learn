package com.ssa.utils;

import java.util.ArrayList;
import java.util.List;

public class IPUtils {

    public static String long2Ip(Long num) {
        String ip = "";
        for (int i = 3; i >= 0; i--) {
            ip += String.valueOf((num & 0xff));
            if (i != 0) {
                ip += ".";
            }
            num = num >> 8;
        }
        return ip;
    }

    public static long ip2Long(String ip) {
        String[] ipArray = ip.split("\\.");
        List<Long> ipNums = new ArrayList<Long>();
        for (int i = 0; i < 4; ++i) {
            ipNums.add(Long.parseLong(ipArray[i].trim()));
        }
        return ipNums.get(0) * 16777216L + ipNums.get(1) * 65536L + ipNums.get(2) * 256L + ipNums.get(3);
    }
}
