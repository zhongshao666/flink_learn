package com.ssa.transformation;

import com.alibaba.fastjson.JSON;
import com.ssa.bean.AppBean;
import com.ssa.sensitive.to.HttpLog;
import org.apache.flink.api.common.functions.MapFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author admin
 */
public class AppBean2StringMap implements MapFunction<HttpLog,String> {
    private static final Logger logger = LoggerFactory.getLogger(AppBean2StringMap.class);
    @Override
    public String map(HttpLog httpLog) throws Exception {
        AppBean appBean = new AppBean();
        appBean.setIp(httpLog.getServerIp());
        appBean.setPort(httpLog.getServerPort());
        appBean.setDomain(httpLog.getHostName());
        String res = JSON.toJSONString(appBean);
        logger.info("logId:{},app discovery {}",httpLog.getLogId(),res);
        return res;
    }
}