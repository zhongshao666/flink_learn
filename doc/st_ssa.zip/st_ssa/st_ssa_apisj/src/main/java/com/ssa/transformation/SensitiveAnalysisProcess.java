package com.ssa.transformation;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.ssa.ApisjMain;
import com.ssa.bean.InterfaceBean;
import com.ssa.bean.SensitiveLabel;
import com.ssa.bean.SensitiveLabelsBean;
import com.ssa.bean.ZkSensitiveLabel;
import com.secsmart.sensitive.AlgInfo;
import com.ssa.sensitive.constants.CommonConstants;
import com.secsmart.sensitive.discovery.MultiMatch;
import com.secsmart.sensitive.discovery.MultiMatchImpl;
import com.ssa.sensitive.match.RequestBodyParse;
import com.ssa.sensitive.match.ResponseBodyParse;
import com.ssa.sensitive.to.CkHttpSensitiveRecord;
import com.ssa.sensitive.to.HttpHeader;
import com.ssa.sensitive.to.HttpLog;
import com.ssa.sensitive.util.IdWorker;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.BroadcastProcessFunction;
import org.apache.flink.util.CollectionUtil;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;

/**
 * 敏感数据识别进程
 *
 * @author qsj
 */
public class SensitiveAnalysisProcess extends BroadcastProcessFunction<HttpLog, Tuple4<Integer, Integer, String, String>, HttpLog> {
    private static final Logger logger = LoggerFactory.getLogger(SensitiveAnalysisProcess.class);
    Map<Long, InterfaceBean> interfaceBeanMap = new HashMap<>();
    Map<Long, String> zkSensitiveIdCodeMap = Maps.newHashMap();
    Map<String, String> sensitiveCodeLevelMap = Maps.newHashMap();



    RequestBodyParse requestBodyParse;
    ResponseBodyParse responseBodyParse;

    MultiMatch multiMatch;

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        requestBodyParse = new RequestBodyParse();
        responseBodyParse = new ResponseBodyParse();
        multiMatch = new MultiMatchImpl();
    }

    @Override
    public void processElement(HttpLog httpLog, ReadOnlyContext readOnlyContext, Collector<HttpLog> collector) throws Exception {

        if (httpLog.getIsnewInterface()) {
            //新接口全部进行敏感数据识别
            allMatchWithDefaultAlgs(httpLog);
            readOnlyContext.output(ApisjMain.interfacetags, httpLog);
        } else {
            InterfaceBean interfaceBean = interfaceBeanMap.get(httpLog.getInterfaceId());
            if(Objects.nonNull(interfaceBean)) {
                //敏感接口基于接口配置进行识别
                if (Optional.ofNullable(interfaceBean.getSensitiveFlag())
                            .orElse(false)) {
                    //匹配敏感数据
                    allMatchWithInterfaceConfigAlgs(httpLog, interfaceBean);

                    //未缓存的标签重新识别
                    markSensitiveLabel(httpLog, readOnlyContext, interfaceBean);
                }

                collector.collect(httpLog);
            }else{
                logger.warn("http log data logId:{},app id:{}, interface id:{},zk interface cache error,stop stream",httpLog.getLogId(),httpLog.getAppId(),httpLog.getInterfaceId());
            }
        }


    }

    /**
     * 对于未打标的数据重新打标
     *
     * @param httpLog
     * @param readOnlyContext
     * @param interfaceBean
     */
    private void markSensitiveLabel(HttpLog httpLog, ReadOnlyContext readOnlyContext, InterfaceBean interfaceBean) {
        if (httpLog.getHasSensitive() && Objects.nonNull(httpLog.getSourceSensitiveMap())) {
            List<SensitiveLabel> sensitiveLabels = getUnmarkedSensitiveLabels(httpLog, interfaceBean);

            if (sensitiveLabels.size() > 0) {
                SensitiveLabelsBean labelsBean = getSensitiveLabelsBean(httpLog, sensitiveLabels);
                readOnlyContext.output(ApisjMain.sensitivelabels, JSON.toJSONString(labelsBean));

            }
        }
    }

    /**
     * 获取敏感数据对象
     *
     * @param httpLog
     * @param sensitiveLabels
     * @return
     */
    private SensitiveLabelsBean getSensitiveLabelsBean(HttpLog httpLog, List<SensitiveLabel> sensitiveLabels) {
        SensitiveLabelsBean labelsBean = new SensitiveLabelsBean();
        labelsBean.setSensitiveLabels(sensitiveLabels);
        labelsBean.setAppId(httpLog.getAppId());
        labelsBean.setInterfaceId(httpLog.getInterfaceId());
        return labelsBean;
    }

    /**
     * 获取打标的敏感数据
     *
     * @param httpLog
     * @param interfaceBean
     * @return
     */
    private List<SensitiveLabel> getUnmarkedSensitiveLabels(HttpLog httpLog, InterfaceBean interfaceBean) {
        List<SensitiveLabel> sensitiveLabels = Lists.newArrayList();
        Map<Integer, Map<String, String>> sourceSensitiveMap = httpLog.getSourceSensitiveMap();

        for (Map.Entry<Integer, Map<String, String>> entry : sourceSensitiveMap.entrySet()) {
            Integer location = entry.getKey();
            Map<String, String> sensitiveMap = entry.getValue();

            for (Map.Entry<String, String> valueEntry : sensitiveMap.entrySet()) {
                String data = valueEntry.getKey();
                String label = valueEntry.getValue();

                boolean markedFlag = Optional.ofNullable(interfaceBean.getMarkedSensitives())
                                             .map(list -> list.contains(label))
                                             .orElse(false);
                if (!markedFlag) {
                    SensitiveLabel sensitiveLabel = new SensitiveLabel();
                    sensitiveLabel.setData(data);
                    sensitiveLabel.setLogId(httpLog.getLogId());
                    sensitiveLabel.setLabel(label);
                    sensitiveLabel.setLocation(location);
                    sensitiveLabels.add(sensitiveLabel);

                }
            }
        }
        return sensitiveLabels;
    }

    /**
     * 基于接口配置进行敏感数据识别
     *
     * @param httpLog
     * @param interfaceBean
     */
    private void allMatchWithInterfaceConfigAlgs(HttpLog httpLog, InterfaceBean interfaceBean) {
        Set<String> sensitiveSet = Sets.newHashSet();
        //请求头识别
        if (!CollectionUtil.isNullOrEmpty(interfaceBean.getReqHeaderSensitives()) && Optional.of(httpLog)
                                                                                             .map(HttpLog::getReqHeader)
                                                                                             .map(HttpHeader::getSourceMap)
                                                                                             .isPresent()) {
            List<String> reqHeaderValues = Lists.newArrayList(httpLog.getReqHeader()
                                                                     .getSourceMap()
                                                                     .values());
            sensitiveSet.addAll(getSensitiveSet(reqHeaderValues, httpLog, CommonConstants.SensitiveLocation.REQ_HEADER.getVal(), interfaceBean.getReqHeaderSensitives()));
        }

        //请求体识别
        if (!CollectionUtil.isNullOrEmpty(interfaceBean.getReqBodySensitives()) && Optional.ofNullable(httpLog.getRequestBody())
                                                                                           .filter(StringUtils::isNotBlank)
                                                                                           .isPresent()) {
            List<String> reqBodyValues = requestBodyParse.parseData(httpLog.getRequestBody());
            sensitiveSet.addAll(getSensitiveSet(reqBodyValues, httpLog, CommonConstants.SensitiveLocation.REQ_BODY.getVal(), interfaceBean.getReqBodySensitives()));
        }

        //响应头识别
        if (!CollectionUtil.isNullOrEmpty(interfaceBean.getResHeaderSensitives()) && Optional.of(httpLog)
                                                                                             .map(HttpLog::getResHeader)
                                                                                             .map(HttpHeader::getSourceMap)
                                                                                             .isPresent()) {
            List<String> resHeaderValues = Lists.newArrayList(httpLog.getResHeader()
                                                                     .getSourceMap()
                                                                     .values());
            sensitiveSet.addAll(getSensitiveSet(resHeaderValues, httpLog, CommonConstants.SensitiveLocation.RES_HEADER.getVal(), interfaceBean.getResHeaderSensitives()));
        }

        //响应体识别
        if (!CollectionUtil.isNullOrEmpty(interfaceBean.getResBodySensitives()) && Optional.ofNullable(httpLog.getResponseBody())
                                                                                           .filter(StringUtils::isNotBlank)
                                                                                           .isPresent()) {
            List<String> resBodyValues = responseBodyParse.parseData(httpLog.getResponseBody());
            sensitiveSet.addAll(getSensitiveSet(resBodyValues, httpLog, CommonConstants.SensitiveLocation.RES_BODY.getVal(), interfaceBean.getResBodySensitives()));
        }

        List<String> sensitiveCodeList = Lists.newArrayList(sensitiveSet);
        httpLog.setSensitiveLabelField(String.join(CommonConstants.CSV_SPLIT_CHAR, sensitiveCodeList));
        httpLog.setSensitiveLevel(sensitiveCodeList.stream().map(code->sensitiveCodeLevelMap.get(code)).collect(Collectors.joining(CommonConstants.CSV_SPLIT_CHAR)));
    }

    /**
     * 基于默认算法进行全部匹配
     *
     * @param httpLog
     */
    private void allMatchWithDefaultAlgs(HttpLog httpLog) {
        Set<String> sensitiveSet = Sets.newHashSet();
        if (StringUtils.isNotBlank(httpLog.getResponseBody())) {
            List<String> resBodyValues = responseBodyParse.parseData(httpLog.getResponseBody());
            sensitiveSet.addAll(getSensitiveSet(resBodyValues, httpLog, CommonConstants.SensitiveLocation.RES_BODY.getVal(), null));

        }

        if (StringUtils.isNotBlank(httpLog.getRequestBody())) {
            List<String> reqBodyValues = requestBodyParse.parseData(httpLog.getRequestBody());
            sensitiveSet.addAll(getSensitiveSet(reqBodyValues, httpLog, CommonConstants.SensitiveLocation.REQ_BODY.getVal(), null));

        }

        if (Optional.of(httpLog)
                    .map(HttpLog::getReqHeader)
                    .map(HttpHeader::getSourceMap)
                    .isPresent()) {
            List<String> reqHeaderValues = Lists.newArrayList(httpLog.getReqHeader()
                                                                     .getSourceMap()
                                                                     .values());
            sensitiveSet.addAll(getSensitiveSet(reqHeaderValues, httpLog, CommonConstants.SensitiveLocation.REQ_HEADER.getVal(), null));

        }

        if (Optional.of(httpLog)
                    .map(HttpLog::getResHeader)
                    .map(HttpHeader::getSourceMap)
                    .isPresent()) {
            List<String> resHeaderValues = Lists.newArrayList(httpLog.getResHeader()
                                                                     .getSourceMap()
                                                                     .values());
            sensitiveSet.addAll(getSensitiveSet(resHeaderValues, httpLog, CommonConstants.SensitiveLocation.RES_HEADER.getVal(), null));

        }

        List<String> sensitiveCodeList = Lists.newArrayList(sensitiveSet);
        httpLog.setSensitiveLabelField(String.join(CommonConstants.CSV_SPLIT_CHAR, sensitiveCodeList));
        httpLog.setSensitiveLevel(sensitiveCodeList.stream().map(code->sensitiveCodeLevelMap.get(code)).collect(Collectors.joining(CommonConstants.CSV_SPLIT_CHAR)));
    }

    /**
     * 获取敏感set
     *
     * @param list
     * @param httpLog
     * @param location
     * @param selAlgs
     * @return
     */
    private Set<String> getSensitiveSet(List<String> list, HttpLog httpLog, Integer location, List<AlgInfo> selAlgs) {
        Set<String> sensitiveLabel = Sets.newHashSet();

        Map<String, String> matchDataMap = getMatchMap(list, getValidAlgInfo(selAlgs));

        if (matchDataMap.size() > 0) {
            httpLog.setHasSensitive(true);

            List<CkHttpSensitiveRecord> records = getCkHttpSensitiveRecords(httpLog, matchDataMap, location);
            if (Objects.nonNull(httpLog.getSensitiveRecords())) {
                httpLog.getSensitiveRecords()
                       .addAll(records);
            } else {
                httpLog.setSensitiveRecords(records);
            }

            for (Map.Entry<String, String> entry : matchDataMap.entrySet()) {
                sensitiveLabel.add(entry.getValue());
            }

            if (httpLog.getSourceSensitiveMap() != null) {
                httpLog.getSourceSensitiveMap()
                       .put(location, matchDataMap);
            } else {
                Map<Integer, Map<String, String>> sourceMap = new HashMap<>();
                sourceMap.put(location, matchDataMap);
                httpLog.setSourceSensitiveMap(sourceMap);
            }
        }
        return sensitiveLabel;
    }

    /**
     * 获取有效的算法信息
     * @param selAlgs
     * @return
     */
    private List<AlgInfo> getValidAlgInfo(List<AlgInfo> selAlgs) {
        return Optional.ofNullable(selAlgs)
                       .map(items -> items.stream()
                                          .filter(item -> sensitiveCodeLevelMap.containsKey(item.getAlgCode()))
                                          .collect(Collectors.toList()))
                       .orElse(sensitiveCodeLevelMap.keySet()
                                                    .stream()
                                                    .filter(item -> !item.startsWith("code_2"))
                                                    .map(item -> new AlgInfo(item, 1, ""))
                                                    .collect(Collectors.toList()));
    }

    /**
     * 组装敏感数据记录
     *
     * @param httpLog
     * @param matchDataMap
     * @param location
     * @return
     */
    private List<CkHttpSensitiveRecord> getCkHttpSensitiveRecords(HttpLog httpLog, Map<String, String> matchDataMap, Integer location) {
        List<CkHttpSensitiveRecord> recordList = Lists.newArrayList();
        for (Map.Entry<String, String> entry : matchDataMap.entrySet()) {
            String value = entry.getKey();
            String matchType = entry.getValue();

            CkHttpSensitiveRecord sensitiveRecord = new CkHttpSensitiveRecord();
            setSensitiveValue(sensitiveRecord, matchType, value);
            sensitiveRecord.setSensitiveLocation(location);
            sensitiveRecord.setAppId(httpLog.getAppId());
            sensitiveRecord.setInterfaceId(httpLog.getInterfaceId());
            sensitiveRecord.setLogId(httpLog.getLogId());
            sensitiveRecord.setSensitiveId(IdWorker.getInstance()
                                                   .nextId());
            sensitiveRecord.setRequestTime(httpLog.getRequestTime());
            sensitiveRecord.setCreateTime(httpLog.getCreateTime());
            recordList.add(sensitiveRecord);
        }
        return recordList;
    }

    /**
     * 设置敏感数据值
     * @param sensitiveRecord
     * @param matchType
     * @param value
     */
    private void setSensitiveValue(CkHttpSensitiveRecord sensitiveRecord, String matchType, String value) {
        Map<String, Consumer<String>> map = getSensitiveSetMap(sensitiveRecord);
        if (map.get(matchType) != null) {
            map.get(matchType)
               .accept(value);
        }
    }

    /**
     * 获取敏感值设置方法
     * @param sensitiveRecord
     * @return
     */
    private Map<String, Consumer<String>> getSensitiveSetMap(CkHttpSensitiveRecord sensitiveRecord) {
        Map<String, Consumer<String>> map = Maps.newHashMap();
        map.put("cell_phone", sensitiveRecord::setCellPhone);
        map.put("bank_account", sensitiveRecord::setBankAccount);
        map.put("business_name", sensitiveRecord::setBusinessName);
        map.put("bus_number", sensitiveRecord::setBusNumber);
        map.put("china_name", sensitiveRecord::setChinaName);
        map.put("chinese_address", sensitiveRecord::setChineseAddress);
        map.put("email", sensitiveRecord::setEmail);
        map.put("id_card", sensitiveRecord::setIdCard);
        map.put("mtp_for_hkmacao", sensitiveRecord::setMtpForHkmacao);
        map.put("mtp_for_taiwai", sensitiveRecord::setMtpForTaiwai);
        map.put("officer_number", sensitiveRecord::setOfficerNumber);
        map.put("passport_code", sensitiveRecord::setPassportCode);
        map.put("phone_number", sensitiveRecord::setPhoneNumber);
        map.put("post_code", sensitiveRecord::setPostCode);
        map.put("three_in_one", sensitiveRecord::setThreeInOne);
        map.put("vic_number", sensitiveRecord::setVicNumber);
        map.put("code_201", sensitiveRecord::setCode_201);
        map.put("code_202", sensitiveRecord::setCode_202);
        map.put("code_203", sensitiveRecord::setCode_203);
        map.put("code_204", sensitiveRecord::setCode_204);
        map.put("code_205", sensitiveRecord::setCode_205);
        map.put("code_206", sensitiveRecord::setCode_206);
        map.put("code_207", sensitiveRecord::setCode_207);
        map.put("code_208", sensitiveRecord::setCode_208);
        map.put("code_209", sensitiveRecord::setCode_209);
        map.put("code_210", sensitiveRecord::setCode_210);
        map.put("code_211", sensitiveRecord::setCode_211);
        map.put("code_212", sensitiveRecord::setCode_212);
        map.put("code_213", sensitiveRecord::setCode_213);
        map.put("code_214", sensitiveRecord::setCode_214);
        map.put("code_215", sensitiveRecord::setCode_215);
        map.put("code_216", sensitiveRecord::setCode_216);
        map.put("code_217", sensitiveRecord::setCode_217);
        map.put("code_218", sensitiveRecord::setCode_218);
        map.put("code_219", sensitiveRecord::setCode_219);
        map.put("code_220", sensitiveRecord::setCode_220);
        map.put("code_221", sensitiveRecord::setCode_221);
        map.put("code_222", sensitiveRecord::setCode_222);
        map.put("code_223", sensitiveRecord::setCode_223);
        map.put("code_224", sensitiveRecord::setCode_224);
        map.put("code_225", sensitiveRecord::setCode_225);
        map.put("code_226", sensitiveRecord::setCode_226);
        map.put("code_227", sensitiveRecord::setCode_227);
        map.put("code_228", sensitiveRecord::setCode_228);
        map.put("code_229", sensitiveRecord::setCode_229);
        map.put("code_230", sensitiveRecord::setCode_230);
        map.put("code_231", sensitiveRecord::setCode_231);
        map.put("code_232", sensitiveRecord::setCode_232);
        map.put("code_233", sensitiveRecord::setCode_233);
        map.put("code_234", sensitiveRecord::setCode_234);
        map.put("code_235", sensitiveRecord::setCode_235);
        map.put("code_236", sensitiveRecord::setCode_236);
        map.put("code_237", sensitiveRecord::setCode_237);
        map.put("code_238", sensitiveRecord::setCode_238);
        map.put("code_239", sensitiveRecord::setCode_239);
        map.put("code_240", sensitiveRecord::setCode_240);
        map.put("code_241", sensitiveRecord::setCode_241);
        map.put("code_242", sensitiveRecord::setCode_242);
        map.put("code_243", sensitiveRecord::setCode_243);
        map.put("code_244", sensitiveRecord::setCode_244);
        map.put("code_245", sensitiveRecord::setCode_245);
        map.put("code_246", sensitiveRecord::setCode_246);
        map.put("code_247", sensitiveRecord::setCode_247);
        map.put("code_248", sensitiveRecord::setCode_248);
        map.put("code_249", sensitiveRecord::setCode_249);
        map.put("code_250", sensitiveRecord::setCode_250);
        return map;
    }


    /**
     * 获取匹配map
     *
     * @param list
     * @param selAlgs
     * @return
     */
    private Map<String, String> getMatchMap(List<String> list, List<AlgInfo> selAlgs) {

        return list.stream()
                   .map(val -> matchValue(val, selAlgs))
                   .filter(Objects::nonNull)
                   .collect(Collectors.toMap((kv) -> kv.f0, (kv) -> kv.f1, (k1, k2) -> k1));
    }


    /**
     * 匹配敏感数据
     *
     * @param val
     * @return
     */
    private Tuple2<String, String> matchValue(String val, List<AlgInfo> selAlgs) {
        Tuple2<String, String> kv = null;
        if (StringUtils.isNotBlank(val) && selAlgs.size() > 0) {
            String match = multiMatch.match(selAlgs, val);
            if (match != null) {
                kv = new Tuple2<>(val, match);
            }
        }
        return kv;
    }

    @Override
    public void processBroadcastElement(Tuple4<Integer, Integer, String, String> config, Context context, Collector<HttpLog> collector) throws Exception {
        if (config.f0 == CommonConstants.ZkDataType.INTERFACE_TYPE.getVal()) {
            InterfaceBean interfaceBean = JSON.parseObject(config.f3, InterfaceBean.class);
            if (config.f1 == CommonConstants.OperateType.ADD.getVal()||config.f1 == CommonConstants.OperateType.UPDATE.getVal()) {
                interfaceBeanMap.put(interfaceBean.getId(), interfaceBean);
            } else {
                interfaceBeanMap.remove(interfaceBean.getId());
            }
        }

        if (config.f0 == CommonConstants.ZkDataType.SENSITIVE_LABEL.getVal()) {
            ZkSensitiveLabel zkSensitiveLabel = JSON.parseObject(config.f3, ZkSensitiveLabel.class);
            if (config.f1 == CommonConstants.OperateType.ADD.getVal()) {
                zkSensitiveIdCodeMap.put(zkSensitiveLabel.getId(), zkSensitiveLabel.getCode());
                sensitiveCodeLevelMap.put(zkSensitiveLabel.getCode(), zkSensitiveLabel.getSensitiveLevel());
            } else {
                String existCode = zkSensitiveIdCodeMap.get(zkSensitiveLabel.getId());
                Optional.ofNullable(existCode)
                        .ifPresent(code -> {
                            sensitiveCodeLevelMap.remove(code);
                            zkSensitiveIdCodeMap.remove(zkSensitiveLabel.getId());
                        });

            }
        }
    }
}
