package com.ssa.logic;

import com.ssa.strategy.StrategyMatch;
import com.ssa.strategy.StrategyMatchCondition;
import com.ssa.strategy.UrlContent;
import com.ssa.utils.IPUtils;
import com.ssa.sensitive.to.HttpLog;
import org.apache.flink.api.java.tuple.Tuple2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.util.Calendar;
import java.util.Objects;


/**
 * 黑白名单、自定义规则
 */

public class Rule {

    private static final Logger logger = LoggerFactory.getLogger(Rule.class);

    boolean clientIpBool = false;
    boolean accountBool = false;
    boolean interfaceBool = false;
    boolean methodBool = false;
    boolean reqKeywordBool = false;
    boolean reqStatusBool = false;
    boolean statusCodeBool = false;
    boolean urlBool = false;
    boolean dateTimeBool = false;
    boolean clientToolBool = false;
    boolean cookieKeywordBool = false;
    boolean sensitiveDataLabelBool = false;
    boolean sensitiveLevelBool = false;

    boolean timestampBool = false;
    boolean mouthTimeBool = false;
    boolean weekTimeBool = false;
    boolean dayTimeBool = false;

    boolean flag;

    Calendar calendar = Calendar.getInstance();

    public boolean isClientIpBool() {
        return clientIpBool;
    }

    public boolean isAccountBool() {
        return accountBool;
    }

    public boolean isInterfaceBool() {
        return interfaceBool;
    }

    public boolean isMethodBool() {
        return methodBool;
    }

    public boolean isReqKeywordBool() {
        return reqKeywordBool;
    }

    public boolean isReqStatusBool() {
        return reqStatusBool;
    }

    public boolean isStatusCodeBool() {
        return statusCodeBool;
    }

    public boolean isUrlBool() {
        return urlBool;
    }

    public boolean isDateTimeBool() {
        return dateTimeBool;
    }

    public boolean isClientToolBool() {
        return clientToolBool;
    }

    public boolean isCookieKeywordBool() {
        return cookieKeywordBool;
    }

    public boolean isSensitiveDataLabelBool() {
        return sensitiveDataLabelBool;
    }

    public boolean isSensitiveLevelBool() {
        return sensitiveLevelBool;
    }

    public boolean isTimestampBool() {
        return timestampBool;
    }

    public boolean isMouthTimeBool() {
        return mouthTimeBool;
    }

    public boolean isWeekTimeBool() {
        return weekTimeBool;
    }

    public boolean isDayTimeBool() {
        return dayTimeBool;
    }

    public boolean isFlag() {
        return flag;
    }

    public Rule clientCheck(StrategyMatchCondition strategyMatchCondition, String ClientIp) {
        //过滤客户端ip
        if (strategyMatchCondition.getClientAllIps() != null) {
            if (strategyMatchCondition.getClientAllIps().getToolList().size() != 0) {
                if (ClientIp != null) {
                    long httpClientIp = IPUtils.ip2Long(ClientIp);
                    for (Tuple2<Long, Long> tuple2 : strategyMatchCondition.getClientAllIps().getToolList()) {
                        if (httpClientIp >= tuple2.f0 && httpClientIp <= tuple2.f1) {
                            clientIpBool = true;
                            break;
                        }
                    }
                }
            } else {
                clientIpBool = true;
            }
            //取反
            if (strategyMatchCondition.getClientAllIps().getInclude() == 0) {
                clientIpBool = !clientIpBool;
            }
        } else {
            clientIpBool = true;
        }
        return this;
    }

    public Rule accountCheck(StrategyMatchCondition strategyMatchCondition, String UserName) {
        //过滤应用账号
        if (strategyMatchCondition.getUserAccount() != null) {
            if (strategyMatchCondition.getUserAccount().getToolList().size() != 0) {
                if (UserName != null) {
                    if (strategyMatchCondition.getUserAccount().getToolList().contains(UserName)) {
                        this.accountBool = true;
                    }
                }
            } else {
                accountBool = true;
            }
            if (strategyMatchCondition.getUserAccount().getInclude() == 0) {
                accountBool = !accountBool;
            }
        } else {
            accountBool = true;
        }
        return this;
    }

    public Rule interfaceCheck(StrategyMatchCondition strategyMatchCondition, Long InterfaceId) {
        //过滤接口
        if (strategyMatchCondition.getInterfaceIds() != null) {
            if (strategyMatchCondition.getInterfaceIds().getLongList().size() != 0) {
                if (InterfaceId != null) {
                    if (strategyMatchCondition.getInterfaceIds().getLongList().contains(InterfaceId)) {
                        interfaceBool = true;
                    }
                }
            } else {
                interfaceBool = true;
            }
            if (strategyMatchCondition.getInterfaceIds().getInclude() == 0) {
                interfaceBool = !interfaceBool;
            }
        } else {
            interfaceBool = true;
        }
        return this;
    }

    public Rule methodCheck(StrategyMatchCondition strategyMatchCondition, String HttpMethod) {
        //过滤请求方法
        if (strategyMatchCondition.getReqMethod() != null) {
            if (strategyMatchCondition.getReqMethod().getToolList().size() != 0) {
                if (HttpMethod != null) {
                    if (strategyMatchCondition.getReqMethod().getToolList().contains(HttpMethod)) {
                        methodBool = true;
                    }
                }
            } else {
                methodBool = true;
            }
            if (strategyMatchCondition.getReqMethod().getInclude() == 0) {
                methodBool = !methodBool;
            }
        } else {
            methodBool = true;
        }
        return this;
    }

    public Rule reqKeywordCheck(StrategyMatchCondition strategyMatchCondition, String requestHeader, String requestBody,String url) {
        //过滤请求关键字
        if (strategyMatchCondition.getReqKeywords() != null) {
            if (strategyMatchCondition.getReqKeywords().getToolList().size() != 0) {
                if (requestHeader != null) {
                    for (String key : strategyMatchCondition.getReqKeywords().getToolList()) {
                        if (requestHeader.contains(key)) {
                            reqKeywordBool = true;
                            break;
                        }
                    }
                }
                if (requestBody != null) {
                    for (String key : strategyMatchCondition.getReqKeywords().getToolList()) {
                        if (requestBody.contains(key)) {
                            reqKeywordBool = true;
                            break;
                        }
                    }
                }
                if (url != null) {
                    for (String key : strategyMatchCondition.getReqKeywords().getToolList()) {
                        if (url.contains(key)) {
                            reqKeywordBool = true;
                            break;
                        }
                    }
                }

            } else {
                reqKeywordBool = true;
            }
            if (strategyMatchCondition.getReqKeywords().getInclude() == 0) {
                reqKeywordBool = !reqKeywordBool;
            }
        } else {
            reqKeywordBool = true;
        }
        return this;
    }

    public Rule reqStatusCheck(StrategyMatchCondition strategyMatchCondition, Integer RequestStatus) {
        //过滤请求状态
        if (strategyMatchCondition.getReqStatus() != null) {
            if (strategyMatchCondition.getReqStatus().equals(RequestStatus)) {
                reqStatusBool = true;
            }
        } else {
            reqStatusBool = true;
        }
        return this;
    }

    public Rule statusCodeCheck(StrategyMatchCondition strategyMatchCondition, Integer StatusCode) {
        //过滤状态码
        if (strategyMatchCondition.getStatusCode() != null) {
            if (strategyMatchCondition.getStatusCode().size() != 0) {
                if (StatusCode != null) {
                    if (strategyMatchCondition.getStatusCode().contains(StatusCode)) {
                        statusCodeBool = true;
                    }
                }
            } else {
                statusCodeBool = true;
            }
        } else {
            statusCodeBool = true;
        }

        return this;
    }

    public Rule urlCheck(StrategyMatchCondition strategyMatchCondition, String RequestUrl) {
        //过滤url
        if (strategyMatchCondition.getUrlParsingTool() != null) {
            if (strategyMatchCondition.getUrlParsingTool().getUrlList().size() != 0) {
                if (RequestUrl != null) {
                    for (UrlContent urlContent : strategyMatchCondition.getUrlParsingTool().getUrlList()) {
                        if (urlContent.getReg() == 1) {
                            if (RequestUrl.matches(urlContent.getContent())) {
                                urlBool = true;
                            }
                        } else if (urlContent.getReg() == 0) {
                            if (urlContent.getContent().equals(RequestUrl)) {
                                urlBool = true;
                            }
                        }
                    }
                }
            } else {
                urlBool = true;
            }
        } else {
            urlBool = true;
        }
        return this;
    }

    public Rule dateTimeCheck(StrategyMatchCondition strategyMatchCondition) {
        if (strategyMatchCondition.getDateTime() == null && strategyMatchCondition.getMonthTime() == null && strategyMatchCondition.getWeekTime() == null && strategyMatchCondition.getDateTimeDay() == null) {
            dateTimeBool = true;
        }
        if (timestampBool || mouthTimeBool || weekTimeBool || dayTimeBool) {
            dateTimeBool = true;
        }

        return this;
    }


    //时间戳范围
    public Rule timestampCheck(StrategyMatchCondition strategyMatchCondition, Long reqTime) {
        if (strategyMatchCondition.getDateTime() != null) {
            if (reqTime != null) {
                reqTime = reqTime / 1000;
                if (reqTime >= strategyMatchCondition.getDateTime().getMin() && reqTime <= strategyMatchCondition.getDateTime().getMax()) {
                    timestampBool = true;
                }
            }
        }

        return this;
    }

    public Rule mouthCheck(StrategyMatchCondition strategyMatchCondition, Long reqTime) {
        //月
        if (strategyMatchCondition.getMonthTime() != null) {
            if (reqTime != null) {
                calendar.setTimeInMillis(reqTime);
                if (strategyMatchCondition.getMonthTime().getIntList().size() != 0) {
                    if (strategyMatchCondition.getMonthTime().getIntList().contains(calendar.get(Calendar.DAY_OF_MONTH))) {
                        mouthTimeBool = true;
                    }
                }
            }
            if (strategyMatchCondition.getMonthTime().getInclude() == 0) {
                mouthTimeBool = !mouthTimeBool;
            }
        }
        return this;
    }

    public Rule weekCheck(StrategyMatchCondition strategyMatchCondition, Long reqTime) {
        //周
        if (strategyMatchCondition.getWeekTime() != null) {
            if (reqTime != null) {
                calendar.setTimeInMillis(reqTime);
                if (strategyMatchCondition.getWeekTime().getIntList().size() != 0) {
                    if (strategyMatchCondition.getWeekTime().getIntList().contains(calendar.get(Calendar.DAY_OF_WEEK) - 1)) {
                        weekTimeBool = true;
                    }
                }
            }
            if (strategyMatchCondition.getWeekTime().getInclude() == 0) {
                weekTimeBool = !weekTimeBool;
            }
        }
        return this;
    }

    public Rule hourCheck(StrategyMatchCondition strategyMatchCondition, Long reqTime) {
        //小时
        if (strategyMatchCondition.getDateTimeDay() != null) {
            if (reqTime != null) {
                calendar.setTimeInMillis(reqTime);
                if (strategyMatchCondition.getDateTimeDay().getIntList().size() != 0) {
                    if (strategyMatchCondition.getDateTimeDay().getIntList().contains(calendar.get(Calendar.HOUR_OF_DAY))) {
                        dayTimeBool = true;
                    }
                }
            }
            if (strategyMatchCondition.getDateTimeDay().getInclude() == 0) {
                dayTimeBool = !dayTimeBool;
            }
        }
        return this;
    }

    //客户端工具
    public Rule clientToolCheck(StrategyMatchCondition strategyMatchCondition, String clientTool) {
        if (strategyMatchCondition.getClientTools() != null) {
            if (strategyMatchCondition.getClientTools().getToolList().size() != 0) {
                if (clientTool != null) {
                    if (strategyMatchCondition.getClientTools().getToolList().contains(clientTool)) {
                        clientToolBool = true;
                    }
                }
            } else {
                clientToolBool = true;
            }
            if (strategyMatchCondition.getClientTools().getInclude() == 0) {
                clientToolBool = !clientToolBool;
            }
        } else {
            clientToolBool = true;
        }
        return this;
    }

    //cookie关键字
    public Rule cookieKeywordCheck(StrategyMatchCondition strategyMatchCondition, String cookie) {
        if (strategyMatchCondition.getCookieKeywords() != null) {
            if (strategyMatchCondition.getCookieKeywords().getToolList().size() != 0) {
                if (cookie != null) {
                    for (String key : strategyMatchCondition.getCookieKeywords().getToolList()) {
                        if (cookie.contains(key)) {
                            cookieKeywordBool = true;
                            break;
                        }
                    }
                }
            } else {
                cookieKeywordBool = true;
            }
            if (strategyMatchCondition.getCookieKeywords().getInclude() == 0) {
                cookieKeywordBool = !cookieKeywordBool;
            }
        } else {
            cookieKeywordBool = true;
        }
        return this;
    }


    //敏感数据标签
    public Rule sensitiveDataLabelCheck(StrategyMatchCondition strategyMatchCondition, String sensitiveLabelField) {
        if (strategyMatchCondition.getLabelCode() != null) {
            if (strategyMatchCondition.getLabelCode().size() != 0) {
                if (sensitiveLabelField != null) {
                    String[] split = sensitiveLabelField.split(",");
                    for (String s : split) {
                        if (strategyMatchCondition.getLabelCode().contains(s)) {
                            sensitiveDataLabelBool = true;
                            break;
                        }
                    }
                }
            } else {
                sensitiveDataLabelBool = true;
            }
        } else {
            sensitiveDataLabelBool = true;
        }
        return this;
    }

    //敏感等级
    public Rule sensitiveLevelCheck(StrategyMatchCondition strategyMatchCondition, String SensitiveLevel) {
        if (strategyMatchCondition.getSensitiveLevel() != null) {
            if (strategyMatchCondition.getSensitiveLevel().size() != 0) {
                if (SensitiveLevel != null) {
                    String[] split = SensitiveLevel.split(",");
                    for (String s : split) {
                        if (strategyMatchCondition.getSensitiveLevel().contains(s)) {
                            sensitiveLevelBool = true;
                            break;
                        }
                    }
                }
            } else {
                sensitiveLevelBool = true;
            }
        } else {
            sensitiveLevelBool = true;
        }
        return this;
    }

    public boolean customAndAnd(HttpLog value) {
//        logger.info("http log marking rule logid:{},  clientIpBool:{}", value.getLogId(), clientIpBool);
//        logger.info("accountBool:" + accountBool);
//        logger.info("interfaceBool" + interfaceBool);
//        logger.info("methodBool" + methodBool);
//        logger.info("reqKeywordBool" + reqKeywordBool);
//        logger.info("reqStatusBool" + reqStatusBool);//
//        logger.info("statusCodeBool" + statusCodeBool);//
//        logger.info("urlBool" + urlBool);//
//        logger.info("dateTimeBool" + dateTimeBool);
//        logger.info("mouthTimeBool" + mouthTimeBool);
//        logger.info("weekTimeBool" + weekTimeBool);
//        logger.info("dayTimeBool" + dayTimeBool);
//        logger.info("clientToolBool" + clientToolBool);
//        logger.info("cookieKeywordBool" + cookieKeywordBool);
//        logger.info("sensitiveDataLabelBool" + sensitiveDataLabelBool);
//        logger.info("sensitiveLevelBool" + sensitiveLevelBool);
        flag = clientIpBool && accountBool && interfaceBool && methodBool && reqKeywordBool && reqStatusBool && statusCodeBool
                && urlBool && dateTimeBool && clientToolBool && cookieKeywordBool && sensitiveDataLabelBool && sensitiveLevelBool;
        logger.info("http log marking rule logid:{},  customAndAnd:{}", value.getLogId(), flag);
        return flag;
    }

    public boolean BWListAndAnd(HttpLog value) {
//        logger.info("clientIp:" + value.getClientIp());
//        logger.info("clientIpBool:" + clientIpBool);
//        logger.info("accountBool:" + accountBool);
//        logger.info("interfaceBool" + interfaceBool);
//        logger.info("methodBool" + methodBool);
//        logger.info("reqKeywordBool" + reqKeywordBool);
//        logger.info("reqStatusBool" + reqStatusBool);//
//        logger.info("statusCodeBool" + statusCodeBool);//
//        logger.info("urlBool" + urlBool);//
//        logger.info("dateTimeBool" + dateTimeBool);
//        logger.info("mouthTimeBool" + mouthTimeBool);
//        logger.info("weekTimeBool" + weekTimeBool);
//        logger.info("dayTimeBool" + dayTimeBool);
//        logger.info("---------------");

        flag = clientIpBool && accountBool && interfaceBool && methodBool && reqKeywordBool && reqStatusBool && statusCodeBool && urlBool && dateTimeBool;
        logger.info("http log marking rule logid:{},  BWListAndAnd:{}", value.getLogId(), flag);
        return flag;
    }

    public void reset() {
        this.clientIpBool = false;
        this.accountBool = false;
        this.interfaceBool = false;
        this.methodBool = false;
        this.reqKeywordBool = false;
        this.reqStatusBool = false;
        this.statusCodeBool = false;
        this.urlBool = false;
        this.dateTimeBool = false;
        this.clientToolBool = false;
        this.cookieKeywordBool = false;
        this.sensitiveDataLabelBool = false;
        this.sensitiveLevelBool = false;
        this.timestampBool = false;
        this.mouthTimeBool = false;
        this.weekTimeBool = false;
        this.dayTimeBool = false;
    }

    /**
     * 自定义规则
     *
     * @param value
     * @param httpLog
     * @return
     */
    public boolean checkCustom(StrategyMatch value, HttpLog httpLog) {
        return Objects.nonNull(value.getStrategyMatchCondition()) && this.clientCheck(value.getStrategyMatchCondition(), httpLog.getClientIp())
                .accountCheck(value.getStrategyMatchCondition(), httpLog.getUserName())
                .interfaceCheck(value.getStrategyMatchCondition(), httpLog.getInterfaceId())
                .methodCheck(value.getStrategyMatchCondition(), httpLog.getHttpMethod())
                .reqKeywordCheck(value.getStrategyMatchCondition(), httpLog.getRequestHeader(), httpLog.getRequestBody(),httpLog.getRequestUrl())
                .reqStatusCheck(value.getStrategyMatchCondition(), httpLog.getRequestStatus())
                .statusCodeCheck(value.getStrategyMatchCondition(), httpLog.getStatusCode())
                .urlCheck(value.getStrategyMatchCondition(), httpLog.getRequestUrl())
                .timestampCheck(value.getStrategyMatchCondition(), httpLog.getRequestTime())
                .mouthCheck(value.getStrategyMatchCondition(), httpLog.getRequestTime())
                .weekCheck(value.getStrategyMatchCondition(), httpLog.getRequestTime())
                .hourCheck(value.getStrategyMatchCondition(), httpLog.getRequestTime())
                .dateTimeCheck(value.getStrategyMatchCondition())
                .clientToolCheck(value.getStrategyMatchCondition(), httpLog.getClientTool())
                .cookieKeywordCheck(value.getStrategyMatchCondition(), httpLog.getReqHeader()
                        .getCookie())
                .sensitiveDataLabelCheck(value.getStrategyMatchCondition(), httpLog.getSensitiveLabelField())
                .sensitiveLevelCheck(value.getStrategyMatchCondition(), httpLog.getSensitiveLevel())
                .customAndAnd(httpLog);
    }

    /**
     * 黑白名单规则
     *
     * @param value
     * @param httpLog
     * @return
     */
    public boolean checkBW(StrategyMatch value, HttpLog httpLog) {
        return Objects.nonNull(value.getStrategyMatchCondition()) && this.clientCheck(value.getStrategyMatchCondition(), httpLog.getClientIp())
                .accountCheck(value.getStrategyMatchCondition(), httpLog.getUserName())
                .interfaceCheck(value.getStrategyMatchCondition(), httpLog.getInterfaceId())
                .methodCheck(value.getStrategyMatchCondition(), httpLog.getHttpMethod())
                .reqKeywordCheck(value.getStrategyMatchCondition(), httpLog.getRequestHeader(), httpLog.getRequestBody(),httpLog.getRequestUrl())
                .reqStatusCheck(value.getStrategyMatchCondition(), httpLog.getRequestStatus())
                .statusCodeCheck(value.getStrategyMatchCondition(), httpLog.getStatusCode())
                .urlCheck(value.getStrategyMatchCondition(), httpLog.getRequestUrl())
                .timestampCheck(value.getStrategyMatchCondition(), httpLog.getRequestTime())
                .mouthCheck(value.getStrategyMatchCondition(), httpLog.getRequestTime())
                .weekCheck(value.getStrategyMatchCondition(), httpLog.getRequestTime())
                .hourCheck(value.getStrategyMatchCondition(), httpLog.getRequestTime())
                .dateTimeCheck(value.getStrategyMatchCondition())
                .BWListAndAnd(httpLog);
    }
}
