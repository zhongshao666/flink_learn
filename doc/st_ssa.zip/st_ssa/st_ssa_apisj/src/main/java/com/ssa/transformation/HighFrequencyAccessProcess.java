package com.ssa.transformation;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Maps;
import com.ssa.bean.ZkSensitiveLabel;
import com.ssa.map.ConditionTOMarking;
import com.ssa.map.ParsingZkConfigSource;
import com.ssa.map.ParsingZkSource;
import com.ssa.strategy.StrategyConfig;
import com.ssa.strategy.StrategyMatch;
import com.ssa.sensitive.constants.CommonConstants;
import com.ssa.sensitive.to.HttpLog;
import org.apache.flink.api.common.state.*;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.KeyedBroadcastProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;


/**
 * @author Administrator
 * @role 敏感数据高频访问processfunction
 */
public class HighFrequencyAccessProcess extends KeyedBroadcastProcessFunction<Tuple2<Long, String>, HttpLog, Tuple4<Integer, Integer, String, String>, HttpLog> {

    private static Logger logger = LoggerFactory.getLogger(HighFrequencyAccessProcess.class);

    /**
     * 时间队列
     */
    private ValueState<LinkedList<Long>> userQueueAccessTime;
    private Map<Long, StrategyMatch> strategyMatchMap;
    private Map<Long, StrategyConfig> strategyConfigMap;
    private final Map<Long, ZkSensitiveLabel> zkSensitiveLabelMap = Maps.newHashMap();
    private final Map<String, String> sensitiveCodeLevelMap = Maps.newHashMap();
    private ParsingZkSource parsingZkSource = new ParsingZkSource();

    @Override
    public void open(Configuration parameters) throws Exception {
        StateTtlConfig stateTtlConfig = StateTtlConfig.newBuilder(Time.minutes(30))
                .setUpdateType(StateTtlConfig.UpdateType.OnCreateAndWrite)
                .setStateVisibility(StateTtlConfig.StateVisibility.NeverReturnExpired)
                .disableCleanupInBackground()
                .cleanupFullSnapshot()
                .build();

        ValueStateDescriptor<LinkedList<Long>> userQueueAccessTimea = new ValueStateDescriptor<>("userQueueAccessTime", TypeInformation.of(new TypeHint<LinkedList<Long>>() {
        }));
        userQueueAccessTimea.enableTimeToLive(stateTtlConfig);
        userQueueAccessTime = getRuntimeContext().getState(userQueueAccessTimea);

        strategyMatchMap = new HashMap<>();
        strategyConfigMap = new HashMap<>();
    }

    @Override
    public void processElement(HttpLog value, ReadOnlyContext ctx, Collector<HttpLog> out) throws Exception {

        boolean flag = false;

        StrategyMatch strategyMatch = strategyMatchMap.get(value.getAppId());
        StrategyConfig strategyConfig = strategyConfigMap.get(value.getAppId());

        if (strategyMatch != null) {

            List<String> sensitiveLabelCode = strategyMatch.getStrategyMatchCondition().getLabelCode();
            List<String> sensitiveLevel = strategyMatch.getStrategyMatchCondition().getSensitiveLevel();

            if (sensitiveLabelCode != null && sensitiveLevel != null && sensitiveLabelCode.size() > 0 && sensitiveLevel.size() > 0) {
                if (value.getHasSensitive()) {
                    flag = true;
                }
            }
        }

        if (flag && strategyConfig != null && strategyMatch.getEnable() && strategyConfig.getRiskPolicyEnable()) {

            int times = strategyMatch.getStrategyMatchCondition().getTriggerFrequency().getTimes();

            if (userQueueAccessTime.value() == null) {

                LinkedList<Long> queue = new LinkedList<>();
                queue.addLast(value.getRequestTime());
                userQueueAccessTime.update(queue);

            } else {

                LinkedList<Long> value1 = userQueueAccessTime.value();
                value1.addLast(value.getRequestTime());
                userQueueAccessTime.update(value1);

            }

            if (userQueueAccessTime.value().size() > times) {
                ConditionTOMarking.reSetFrequencyAlarmModule(userQueueAccessTime.value(), userQueueAccessTime.value().size() - times);
            }

            if (userQueueAccessTime.value().size() == times) {
                if (value.getRequestTime() - userQueueAccessTime.value().getFirst() <
                        ConditionTOMarking.transFromationTime(strategyMatch.getStrategyMatchCondition().getTriggerFrequency().getTime(),
                                strategyMatch.getStrategyMatchCondition().getTriggerFrequency().getUnit())) {
                    logger.info("http log marking highfrequencyaccess logid:{}", value.getLogId());
                    ConditionTOMarking.setStrategy(value, strategyMatch);
                }
            }
        }
        out.collect(value);
    }

    @Override
    public void processBroadcastElement(Tuple4<Integer, Integer, String, String> value, Context ctx, Collector<HttpLog> out) throws Exception {

        String filterStrategy = CommonConstants.StrategyType.HIGHFREQUENCYACCESS.getVal();

        if (value.f0 == CommonConstants.ZkDataType.RISK_TYPE.getVal()) {
            StrategyMatch strategyMatchs = parsingZkSource.parsingZkJson(value.f3);
            if (filterStrategy.equals(strategyMatchs.getStrategy()) &&
                    strategyMatchs.getAppIds() != null &&
                    strategyMatchs.getAppIds().size() > 0) {
                if (value.f1 == CommonConstants.OperateType.UPDATE.getVal() || value.f1 == CommonConstants.OperateType.ADD.getVal()) {
                    for (Long appId : strategyMatchs.getAppIds()) {
                        strategyMatchMap.put(appId, strategyMatchs);
                    }
                } else if (value.f1 == CommonConstants.OperateType.DELETE.getVal()) {
                    for (Long appId : strategyMatchs.getAppIds()) {
                        strategyMatchMap.remove(appId, strategyMatchs);
                    }
                }
            }
        }

        if (value.f0 == CommonConstants.ZkDataType.STRATEGY_CONFIG.getVal()) {
            if (value.f1 == CommonConstants.OperateType.DELETE.getVal()) {
                StrategyConfig strategyConfig = ParsingZkConfigSource.parsingZkConfigSource(value.f3);
                strategyConfigMap.remove(strategyConfig.getAppId());
            } else {
                StrategyConfig strategyConfig = ParsingZkConfigSource.parsingZkConfigSource(value.f3);
                strategyConfigMap.put(strategyConfig.getAppId(), strategyConfig);
            }
        }

        if (value.f0 == CommonConstants.ZkDataType.SENSITIVE_LABEL.getVal()) {
            ZkSensitiveLabel zkSensitiveLabel = JSON.parseObject(value.f3, ZkSensitiveLabel.class);
            if (value.f1 == CommonConstants.OperateType.ADD.getVal()) {
                zkSensitiveLabelMap.put(zkSensitiveLabel.getId(), zkSensitiveLabel);
                sensitiveCodeLevelMap.put(zkSensitiveLabel.getCode(), zkSensitiveLabel.getSensitiveLevel());
            } else {
                ZkSensitiveLabel existLabel = zkSensitiveLabelMap.get(zkSensitiveLabel.getId());
                Optional.ofNullable(existLabel)
                        .ifPresent(label -> {
                            sensitiveCodeLevelMap.remove(label.getCode());
                            zkSensitiveLabelMap.remove(label.getId());
                        });

            }
        }
    }
}