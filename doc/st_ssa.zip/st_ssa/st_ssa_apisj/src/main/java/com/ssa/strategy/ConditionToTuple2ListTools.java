package com.ssa.strategy;


import com.ssa.utils.IPUtils;
import org.apache.flink.api.java.tuple.Tuple2;

import java.util.ArrayList;
import java.util.List;


public class ConditionToTuple2ListTools {
    private List<Tuple2<Long,Long>> toolList = new ArrayList<>();
    private Integer include;

    public List<Tuple2<Long, Long>> getToolList() {
        return toolList;
    }

    public void setToolList(List<String> toolList) {
        for (String s:toolList) {
            String[] split = s.split("[-]");
            if (split.length == 1) {
                this.toolList.add(new Tuple2<>(IPUtils.ip2Long(s), IPUtils.ip2Long(s)));
            }else {
                this.toolList.add(new Tuple2<>(IPUtils.ip2Long(split[0]), IPUtils.ip2Long(split[1])));
            }
        }
    }

    public Integer getInclude() {
        return include;
    }

    public void setInclude(Integer include) {
        this.include = include;
    }

    public ConditionToTuple2ListTools() {
    }

    public ConditionToTuple2ListTools(List<Tuple2<Long, Long>> toolList, Integer include) {
        this.toolList = toolList;
        this.include = include;
    }
}
