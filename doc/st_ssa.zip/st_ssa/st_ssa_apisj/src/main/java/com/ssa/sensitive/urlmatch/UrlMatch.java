package com.ssa.sensitive.urlmatch;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import org.apache.commons.lang3.StringUtils;

import java.util.Collection;
import java.util.Objects;
import java.util.Optional;

/**
 * @author qsj
 * @since 2021/1/19
 */
public class UrlMatch {

    UrlCategory cacheStructure = new UrlCategory();

    public static final String URL_SPLIT_CHAR = "/";
    public static final String WILDCARD_CHAR = "\\*";

    /**
     * 添加接口
     *
     * @param url
     * @param interfaceId
     */
    public void addInterface(String url, long interfaceId) {
        if (url.startsWith(URL_SPLIT_CHAR)) {
            url = url.substring(1);
        }
        String[] array = url.split(URL_SPLIT_CHAR);

        int i = 0;
        UrlNode curNode = null;
        for (String path : array) {
            boolean endFlag = (array.length - 1) == i;
            UrlNode tmpNode = new UrlNode(path, i, endFlag, path.contains("*"), path.contains("**"), interfaceId);
            if (i == 0) {
                cacheStructure.addNode(tmpNode);
            } else {
                curNode.setNextNode(tmpNode);
            }
            curNode = tmpNode;
            i++;
        }
    }

    /**
     * 删除接口
     * @param interfaceId
     */
    public void removeInterface(long interfaceId) {
        if (Objects.nonNull(cacheStructure.getWildcardNodeMap())) {
            for (String key : cacheStructure.getWildcardNodeMap()
                                            .keySet()) {
                Collection<UrlNode> urlNodes = cacheStructure.getWildcardNodeMap()
                                                             .get(key);
                for (UrlNode urlNode : urlNodes) {
                    if (urlNode.getInterfaceId() == interfaceId) {
                        urlNodes.remove(urlNode);
                        break;
                    }
                }
            }
        }
    }

    /**
     * 匹配url
     *
     * @param url
     * @return
     */
    public Long match(String url) {
        if(StringUtils.isBlank(url)){
            return null;
        }
        if (url.startsWith(URL_SPLIT_CHAR)) {
            url = url.substring(1);
        }
        String[] array = url.split(URL_SPLIT_CHAR);
        UrlCategory urlCategory = cacheStructure;
        UrlCategory nextCategory = new UrlCategory();
        LongWrap interfaceId = new LongWrap();
        for (int i = 0; i < array.length; i++) {
            boolean matched = false;
            String path = array[i];
            if (normalNodeMatch(urlCategory, path, interfaceId, array, nextCategory, i)) {
                matched = true;
            }
            if (wildcardNodeMatch(array, urlCategory, nextCategory, interfaceId, i, path)) {
                matched = true;
            }
            if (!matched) {
                return interfaceId.getValue();
            }
            urlCategory = nextCategory;
        }
        return interfaceId.getValue();
    }

    /**
     * 统配符匹配
     * @param array
     * @param urlCategory
     * @param nextCategory
     * @param interfaceId
     * @param i
     * @param path
     * @return
     */
    private boolean wildcardNodeMatch(String[] array, UrlCategory urlCategory, UrlCategory nextCategory, LongWrap interfaceId, int i, String path) {
        if (Objects.nonNull(urlCategory.getWildcardNodeMap())) {
            for (String wildcardKey : urlCategory.getWildcardNodeMap().keySet()) {
                String[] arr = wildcardKey.split(WILDCARD_CHAR);
                if (arr.length == 1) {
                    if (path.startsWith(arr[0])) {
                        Collection<UrlNode> urlNodes = urlCategory.getWildcardNodeMap().get(wildcardKey);
                        interfaceId.setValue(doMatch(array, nextCategory, i, urlNodes, true));
                        if (interfaceId.getValue() != null) {
                            break;
                        }
                        return true;
                    }
                }
                if (arr.length == 2) {
                    if (path.startsWith(arr[0]) && path.endsWith(arr[1])) {
                        Collection<UrlNode> urlNodes = urlCategory.getWildcardNodeMap().get(wildcardKey);
                        interfaceId.setValue(doMatch(array, nextCategory, i, urlNodes, true));
                        if (interfaceId.getValue() != null) {
                            break;
                        }
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * 通用匹配
     * @param urlCategory
     * @param path
     * @param interfaceId
     * @param array
     * @param nextCategory
     * @param i
     * @return
     */
    private boolean normalNodeMatch(UrlCategory urlCategory, String path, LongWrap interfaceId, String[] array, UrlCategory nextCategory, int i) {
        if (Objects.nonNull(urlCategory.getNormalNodeMap()) && urlCategory.getNormalNodeMap().containsKey(path)) {
            Collection<UrlNode> urlNodes = urlCategory.getNormalNodeMap().get(path);
            interfaceId.setValue(doMatch(array, nextCategory, i, urlNodes, false));
            return true;
        }
        return false;
    }

    /**
     * 执行匹配
     * @param array
     * @param nextCategory
     * @param i
     * @param urlNodes
     * @param b
     * @return
     */
    private Long doMatch(String[] array, UrlCategory nextCategory, int i, Collection<UrlNode> urlNodes, boolean b) {
        if (i == array.length - 1) {
            return findInterfaceId(urlNodes);
        } else {
            nodeChg(nextCategory, urlNodes, b);
        }
        return null;
    }

    /**
     * 查询interfaceId
     * @param urlNodes
     * @return
     */
    private Long findInterfaceId(Collection<UrlNode> urlNodes) {
        for (UrlNode urlNode : urlNodes) {
            if (urlNode.isEndFlag()) {
                return urlNode.getInterfaceId();
            }
        }
        return null;
    }

    /**
     * 节点转移
     * @param nextCategory
     * @param urlNodes
     * @param isWildCard
     */
    private void nodeChg(UrlCategory nextCategory, Collection<UrlNode> urlNodes, boolean isWildCard) {
        Multimap<String, UrlNode> map = ArrayListMultimap.create();
        for (UrlNode urlNode : urlNodes) {
            if (Optional.ofNullable(urlNode).map(UrlNode::getNextNode).map(UrlNode::getValue).isPresent()) {
                map.put(urlNode.getNextNode().getValue(), urlNode.getNextNode());
            }
        }
        if (isWildCard) {
            nextCategory.setWildcardNodeMap(map);
        } else {
            nextCategory.setNormalNodeMap(map);
        }
    }

    static class LongWrap {
        Long value;

        public Long getValue() {
            return value;
        }

        public void setValue(Long value) {
            this.value = value;
        }
    }
}
