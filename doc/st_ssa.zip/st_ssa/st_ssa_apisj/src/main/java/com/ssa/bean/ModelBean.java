package com.ssa.bean;

import java.util.HashMap;

/**
 * @author : hld
 * @Date ： 2021/4/21
 * @Time : 19:23
 * @role ：
 */
public class ModelBean {
    /**
     * pst条件概率
     */
    private HashMap<String, HashMap<String, Double>> pstMap;
    /**
     * 基线
     */
    private HashMap<String, Double> baselineMap;
    /**
     * 事件符号映射
     */
    private HashMap<String, String> eventSymbolMap;


    private Double baselineRatio;


    public HashMap<String, HashMap<String, Double>> getPstMap() {
        return pstMap;
    }

    public void setPstMap(HashMap<String, HashMap<String, Double>> pstMap) {
        this.pstMap = pstMap;
    }

    public HashMap<String, Double> getBaselineMap() {
        return baselineMap;
    }

    public void setBaselineMap(HashMap<String, Double> baselineMap) {
        this.baselineMap = baselineMap;
    }

    public HashMap<String, String> getEventSymbolMap() {
        return eventSymbolMap;
    }

    public void setEventSymbolMap(HashMap<String, String> eventSymbolMap) {
        this.eventSymbolMap = eventSymbolMap;
    }

    public Double getBaselineRatio() {
        return baselineRatio;
    }

    public void setBaselineRatio(Double baselineRatio) {
        this.baselineRatio = baselineRatio;
    }
}
