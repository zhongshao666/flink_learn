package com.ssa.transformation;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ssa.bean.InterfaceBean;
import com.ssa.sensitive.constants.CommonConstants;
import com.ssa.sensitive.to.HttpLog;
import org.apache.flink.api.common.functions.MapFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashSet;
import java.util.Map;

/**
 * @author admin
 */
public class InterfaceBean2StringMap implements MapFunction<HttpLog, String> {
    private static final Logger logger = LoggerFactory.getLogger(InterfaceBean2StringMap.class);

    @Override
    public String map(HttpLog httpLog) throws Exception {
        InterfaceBean interfaceBean = new InterfaceBean();
        interfaceBean.setAppId(httpLog.getAppId());
        interfaceBean.setUrl(httpLog.getInterfaceUrl());
        interfaceBean.setSensitiveFlag(httpLog.getHasSensitive());
        interfaceBean.setMethod(httpLog.getHttpMethod());
        interfaceBean.setTypes(Lists.newArrayList(1));
        setSensitiveLabels(httpLog, interfaceBean);
        String res = JSON.toJSONString(interfaceBean);
        logger.info("logId:{} interface discovery {}",httpLog.getLogId(), res);
        return res;
    }

    /**
     * 设置新发现的敏感标签
     * @param httpLog
     * @param interfaceBean
     */
    private void setSensitiveLabels(HttpLog httpLog, InterfaceBean interfaceBean) {
        if (httpLog.getSourceSensitiveMap() != null && httpLog.getSourceSensitiveMap()
                                                              .size() > 0) {
            for (Map.Entry<Integer, Map<String, String>> entry : httpLog.getSourceSensitiveMap()
                                                                        .entrySet()) {
                Integer location = entry.getKey();
                Map<String, String> values = entry.getValue();
                if(values!=null && values.size()>0) {
                    HashSet<String> types = Sets.newHashSet(values.values());

                    if (location == CommonConstants.SensitiveLocation.REQ_HEADER.getVal()) {
                        interfaceBean.setReqHeaderSensitiveLabels(Lists.newArrayList(types));
                    }
                    if (location == CommonConstants.SensitiveLocation.REQ_BODY.getVal()) {
                        interfaceBean.setReqBodySensitiveLabels(Lists.newArrayList(types));
                    }
                    if (location == CommonConstants.SensitiveLocation.RES_HEADER.getVal()) {
                        interfaceBean.setResHeaderSensitiveLabels(Lists.newArrayList(types));
                    }
                    if (location == CommonConstants.SensitiveLocation.RES_BODY.getVal()) {
                        interfaceBean.setResBodySensitiveLabels(Lists.newArrayList(types));
                    }
                }
            }
        }
    }
}
