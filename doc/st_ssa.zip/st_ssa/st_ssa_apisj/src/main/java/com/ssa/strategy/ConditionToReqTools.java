package com.ssa.strategy;

import lombok.Data;

@Data
public class ConditionToReqTools {
    private Integer number;
    private String unit;
    private Integer relation;
}
