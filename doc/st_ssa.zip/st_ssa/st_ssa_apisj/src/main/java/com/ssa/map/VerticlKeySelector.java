package com.ssa.map;

import com.ssa.bean.OfflineData;
import com.ssa.strategy.StrategyConfig;
import com.ssa.strategy.StrategyMatch;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple5;

public class VerticlKeySelector implements KeySelector<Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig>, Long> {
    @Override
    public Long getKey(Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig> value) throws Exception {
       return value.f2;
    }
}
