package com.ssa.transformation;

import com.ssa.map.ConditionTOMarking;
import com.ssa.map.ParsingZkConfigSource;
import com.ssa.map.ParsingZkSource;
import com.ssa.strategy.StrategyConfig;
import com.ssa.strategy.StrategyMatch;
import com.ssa.sensitive.constants.CommonConstants;
import com.ssa.sensitive.to.HttpLog;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.BroadcastProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 非工作时间访问算子
 */
public class NonWorkingTimeProcess extends BroadcastProcessFunction<HttpLog, Tuple4<Integer, Integer, String, String>, HttpLog> {
    private static final Logger logger = LoggerFactory.getLogger(NonWorkingTimeProcess.class);

    //存储zkSource规则
    private Map<Long, StrategyMatch> matchMap;
    //存储zkSource规则   appId开关
    private Map<Long, StrategyConfig> appIdMap;
    //zkSource工具类
    private StrategyProcessElementTool strategyProcessElementTool;
    private ParsingZkSource parsingZkSource = new ParsingZkSource();


    Date date;
    SimpleDateFormat simpleDateFormat;
    Calendar calendar;
    //httpLog string date
    String sd;
    //httpLog HH:mm
    Date dateN;
    //httpLog 周
    int week;

    //时间转换中间变量
    String s1;
    String s2;
    Date dateBefore;
    Date dateAfter;

    @Override
    public void open(Configuration parameters) throws Exception {
        simpleDateFormat = new SimpleDateFormat("HH:mm");
        calendar = Calendar.getInstance();
        matchMap = new HashMap<>();
        appIdMap = new HashMap<>();
        strategyProcessElementTool = new StrategyProcessElementTool();

    }


    @Override
    public void processElement(HttpLog httpLog, ReadOnlyContext ctx, Collector<HttpLog> collector) throws Exception {

        date = new Date(httpLog.getRequestTime());
        sd = simpleDateFormat.format(date);
        dateN = simpleDateFormat.parse(sd);
        calendar.setTimeInMillis(httpLog.getRequestTime());

        week = calendar.get(Calendar.DAY_OF_WEEK) - 1;

        boolean flag = false;
        StrategyMatch value = matchMap.get(httpLog.getAppId());
        //先遍历appId开关 , 遍历规则
        if (appIdMap.get(httpLog.getAppId()) != null
                && appIdMap.get(httpLog.getAppId()).getRiskPolicyEnable() &&
                matchMap.get(httpLog.getAppId()) != null && matchMap.get(httpLog.getAppId()).getEnable()) {


            s1 = value.getStrategyMatchCondition().getWrokingTimeToday().getTimeBegin();
            s2 = value.getStrategyMatchCondition().getWrokingTimeToday().getTimeEnd();
            //上班时间
            dateBefore = simpleDateFormat.parse(s1);
            //下班时间
            dateAfter = simpleDateFormat.parse(s2);
            if (value.getStrategyMatchCondition().getWeekTime() != null) {
                //已配置周几，但不在周几
                if (value.getStrategyMatchCondition().getWeekTime().getIntList().size() != 0 && !value.getStrategyMatchCondition().getWeekTime().getIntList().contains(week)) {
                    //非工作时间访问 打标
                    logger.info("http log marking nonWorking logid:{}", httpLog.getLogId());
                    flag = true;
                }
                //已配置周几，且在周几
                else if (value.getStrategyMatchCondition().getWeekTime().getIntList().contains(week)) {
                    //匹配每天时间段
                    if (dateN.before(dateBefore) || dateN.after(dateAfter)) {
                        logger.info("http log marking nonWorking logid:{}", httpLog.getLogId());
                        //非工作时间访问  打标
                        flag = true;
                    }
                }
                //未配置周几
                else if (value.getStrategyMatchCondition().getWeekTime().getIntList().size() == 0) {
                    //匹配每天时间段
                    if (dateN.before(dateBefore) || dateN.after(dateAfter)) {
                        logger.info("http log marking nonWorking logid:{}", httpLog.getLogId());
                        //非工作时间访问 打标
                        flag = true;
                    }
                }
            }
            //未配置周几
            else if (value.getStrategyMatchCondition().getWeekTime() == null) {
                //匹配每天时间段
                if (dateN.before(dateBefore) || dateN.after(dateAfter)) {
                    logger.info("http log marking nonWorking logid:{}", httpLog.getLogId());
                    //非工作时间访问 打标
                    flag = true;
                }
            }
        }

        if (flag) {
            if (Optional.ofNullable(value.getName()).isPresent()) {
                if (Optional.ofNullable(httpLog.getStrategyName()).isPresent()) {
                    if (!httpLog.getStrategyName().contains(value.getName())) {
                        ConditionTOMarking.setStrategy(httpLog, value);
                    }
                }else {
                    ConditionTOMarking.setStrategy(httpLog, value);
                }
            }
        }
        //value可能为null
/*        if (flag && value != null && !httpLog.getStrategyName().contains(value.getName())) {
            ConditionTOMarking.setStrategy(httpLog, value);
        }*/

        collector.collect(httpLog);

    }

    @Override
    public void processBroadcastElement(Tuple4<Integer, Integer, String, String> value, Context ctx, Collector<HttpLog> out) throws Exception {

        String filterStrategy = CommonConstants.StrategyType.NONWORKING.getVal();

        if (value.f0 == CommonConstants.ZkDataType.RISK_TYPE.getVal()) {
            StrategyMatch strategyMatchs = parsingZkSource.parsingZkJson(value.f3);
            if (strategyMatchs.getAppIds().size() > 0 && value.f1 == CommonConstants.OperateType.UPDATE.getVal() || value.f1 == CommonConstants.OperateType.ADD.getVal()) {
                if (filterStrategy.equals(strategyMatchs.getStrategy())) {
                    for (Long appId : strategyMatchs.getAppIds()) {
                        matchMap.put(appId, strategyMatchs);
                    }
                }
            } else if (value.f1 == CommonConstants.OperateType.DELETE.getVal() && strategyMatchs.getAppIds().size() > 0) {
                if (filterStrategy.equals(strategyMatchs.getStrategy())) {
                    for (Long appId : strategyMatchs.getAppIds()) {
                        matchMap.remove(appId);
                    }
                }
            }
        }
        if (value.f0 == CommonConstants.ZkDataType.STRATEGY_CONFIG.getVal()) {
            if (value.f1 == CommonConstants.OperateType.DELETE.getVal()) {
                StrategyConfig strategyConfig = ParsingZkConfigSource.parsingZkConfigSource(value.f3);
                appIdMap.remove(strategyConfig.getAppId());
            } else {
                StrategyConfig strategyConfig = ParsingZkConfigSource.parsingZkConfigSource(value.f3);
                appIdMap.put(strategyConfig.getAppId(), strategyConfig);
            }
        }
    }


}
