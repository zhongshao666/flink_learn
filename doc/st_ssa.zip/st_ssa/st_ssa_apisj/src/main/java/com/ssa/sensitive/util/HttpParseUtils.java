package com.ssa.sensitive.util;

import cz.mallat.uasparser.BrowserFamilyParser;
import cz.mallat.uasparser.OnlineUpdater;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 * @author qsj
 * @since 2021/3/18
 */
public class HttpParseUtils {
    private static final Logger logger = LoggerFactory.getLogger(HttpParseUtils.class);

    static BrowserFamilyParser browserFamilyParser;
    static {
        try {
            browserFamilyParser = new BrowserFamilyParser(OnlineUpdater.getVendoredInputStream());
        } catch (IOException e) {
            logger.error("Browser Family init error",e);
        }
    }

    /**
     * 获取客户端工具
     * @param userAgent
     * @return
     */
    public static String getBrowserFamily(String userAgent){
        if(StringUtils.isNotBlank(userAgent)){
            return browserFamilyParser.parseBrowserFamily(userAgent);
        }
        return "unknown";
    }
}
