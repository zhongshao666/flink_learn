package com.ssa.sensitive.match;

import jodd.lagarto.Doctype;
import jodd.lagarto.Tag;
import jodd.lagarto.TagVisitor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static jodd.util.StringUtil.isBlank;

/**
 * @author qsj
 * @since 2021/1/18
 */
public class TagMaskVisitor implements TagVisitor {

    private List<String> valueList;

    public TagMaskVisitor() {
        valueList = new ArrayList<>();
    }

    public List<String> getValueList() {
        return this.valueList;
    }

    @Override
    public void start() {

    }

    @Override
    public void end() {

    }

    @Override
    public void doctype(Doctype doctype) {

    }

    @Override
    public void tag(Tag tag) {
        for (int i = 0; i < tag.getAttributeCount(); i++) {
            CharSequence attributeValue = tag.getAttributeValue(i);
            if (!isBlank(attributeValue)) {
                valueList.add(attributeValue.toString());
            }
        }
    }

    @Override
    public void script(Tag tag, CharSequence charSequence) {

    }

    @Override
    public void comment(CharSequence charSequence) {

    }

    @Override
    public void text(CharSequence charSequence) {
        if (!isBlank(charSequence)) {
            valueList.add(charSequence.toString());
        }
    }

    @Override
    public void condComment(CharSequence charSequence, boolean b, boolean b1, boolean b2) {

    }

    @Override
    public void xml(CharSequence charSequence, CharSequence charSequence1, CharSequence charSequence2) {

    }

    @Override
    public void cdata(CharSequence charSequence) {

    }

    @Override
    public void error(String s) {

    }
}
