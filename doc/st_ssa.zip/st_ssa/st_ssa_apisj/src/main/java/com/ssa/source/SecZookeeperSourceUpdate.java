package com.ssa.source;

import com.ssa.ApisjMain;
import com.ssa.utils.CuratorOperator;
import com.ssa.sensitive.constants.CommonConstants;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.CuratorFramework;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.recipes.cache.*;
import org.apache.flink.streaming.api.functions.source.RichSourceFunction;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SecZookeeperSourceUpdate extends RichSourceFunction<Tuple4<Integer, Integer, String, String>> {

    private static final Logger logger = LoggerFactory.getLogger(SecZookeeperSourceUpdate.class);

    CuratorOperator cto = null;
    SourceFunction.SourceContext<Tuple4<Integer, Integer, String, String>> sourceContextGlobal = null;
    ParameterTool parameterTool;

    @Override
    public void open(Configuration parameters) throws Exception {
        System.setProperty("zookeeper.sasl.client", "false");
         parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig()
                                                                         .getGlobalJobParameters();

        cto = new CuratorOperator(parameterTool.get("zookeeper.url"));
    }

    private void nodeListen(NodeCache nodeCache) throws Exception {
        nodeCache.start(true);
        if(nodeCache.getCurrentData()!=null&&nodeCache.getCurrentData().getData()!=null){
            sourceContextGlobal.collect(new Tuple4<>(CommonConstants.ZkDataType.DISCOVERY_TYPE.getVal(), CommonConstants.OperateType.ADD.getVal(), parameterTool.get("zookeeper.app.discovery.path"), new String(nodeCache.getCurrentData().getData())));
        }

        nodeCache.getListenable().addListener(new NodeCacheListener() {
            @Override
            public void nodeChanged() throws Exception {
                if(nodeCache.getCurrentData()!=null&&nodeCache.getCurrentData().getData()!=null){
                    sourceContextGlobal.collect(new Tuple4<>(CommonConstants.ZkDataType.DISCOVERY_TYPE.getVal(), CommonConstants.OperateType.ADD.getVal(), parameterTool.get("zookeeper.app.discovery.path"), new String(nodeCache.getCurrentData().getData())));
                }
            }
        });
    }

    private void childrenListen(PathChildrenCache pathChildrenCache,int type,String nodepath) throws Exception {
        pathChildrenCache.start(PathChildrenCache.StartMode.POST_INITIALIZED_EVENT);
        pathChildrenCache.getListenable().addListener(new PathChildrenCacheListener() {
            @Override
            public void childEvent(CuratorFramework curatorFramework, PathChildrenCacheEvent event) throws Exception {
                if(event.getType().equals(PathChildrenCacheEvent.Type.INITIALIZED)){
                    logger.info("初始化zookeeper监听完成.........");
                }else if(event.getType().equals(PathChildrenCacheEvent.Type.CHILD_ADDED)){
                    String path = event.getData().getPath();
                    if(path.startsWith(nodepath)){
                        sourceContextGlobal.collect(new Tuple4<>(type,CommonConstants.OperateType.ADD.getVal(),path,new String(event.getData().getData())));
                        logger.info("create "+ path+"----"+new String(event.getData().getData()));
                    }
                }else if(event.getType().equals(PathChildrenCacheEvent.Type.CHILD_REMOVED)){
                    sourceContextGlobal.collect(new Tuple4<>(type,CommonConstants.OperateType.DELETE.getVal(),event.getData().getPath(), new String(event.getData().getData())));
                    logger.info("remove "+ event.getData().getPath()+"----"+new String(event.getData().getData()));
                }else if(event.getType().equals(PathChildrenCacheEvent.Type.CHILD_UPDATED)){
                    sourceContextGlobal.collect(new Tuple4<>(type,CommonConstants.OperateType.UPDATE.getVal(),event.getData().getPath(),new String(event.getData().getData())));
                    logger.info("update "+ event.getData().getPath());
                }
            }
        });

    }

    @Override
    public void run(SourceFunction.SourceContext<Tuple4<Integer, Integer, String, String>> sourceContext) throws Exception {
        sourceContextGlobal = sourceContext;

        final PathChildrenCache childrenCacheInterface = new PathChildrenCache(cto.client, parameterTool.get("zookeeper.interface.data.path"),true);
        final PathChildrenCache childrenCacheApp = new PathChildrenCache(cto.client, parameterTool.get("zookeeper.app.data.path"),true);
        final PathChildrenCache childrenSensitiveLabel = new PathChildrenCache(cto.client,parameterTool.get("zookeeper.sensitive.label.data.path"),true);

        final PathChildrenCache childrenBWList = new PathChildrenCache(cto.client, parameterTool.get("zookeeper.bw.list.data.path"),true);

        final PathChildrenCache childrenUserDefine = new PathChildrenCache(cto.client, parameterTool.get("zookeeper.userdefine.data.path"), true);

        final PathChildrenCache childrenRisk = new PathChildrenCache(cto.client, parameterTool.get("zookeeper.risk.data.path"), true);

        final PathChildrenCache childrenStrategyConfig = new PathChildrenCache(cto.client, parameterTool.get("zookeeper.strategy.config.data.path"), true);

        final NodeCache nodeCache = new NodeCache(cto.client, parameterTool.get("zookeeper.app.discovery.path"));

        //添加对节点的监听
        nodeListen(nodeCache);
        //对zookeeper的接口的路径监听

        childrenListen(childrenCacheInterface,CommonConstants.ZkDataType.INTERFACE_TYPE.getVal(),  parameterTool.get("zookeeper.interface.data.path"));

        childrenListen(childrenCacheApp,CommonConstants.ZkDataType.APP_TYPE.getVal(), parameterTool.get("zookeeper.app.data.path"));

        childrenListen(childrenSensitiveLabel,CommonConstants.ZkDataType.SENSITIVE_LABEL.getVal(),parameterTool.get("zookeeper.sensitive.label.data.path"));

        childrenListen(childrenBWList,CommonConstants.ZkDataType.BW_LIST_TYPE.getVal(), parameterTool.get("zookeeper.bw.list.data.path"));

        childrenListen(childrenUserDefine,CommonConstants.ZkDataType.USER_DEFINE_TYPE.getVal(),parameterTool.get("zookeeper.userdefine.data.path"));

        childrenListen(childrenRisk,CommonConstants.ZkDataType.RISK_TYPE.getVal(),  parameterTool.get("zookeeper.risk.data.path"));

        childrenListen(childrenStrategyConfig,CommonConstants.ZkDataType.STRATEGY_CONFIG.getVal(), parameterTool.get("zookeeper.strategy.config.data.path"));

        while (true){
            Thread.sleep(50000);
        }
    }

    @Override
    public void cancel() {

    }
}
