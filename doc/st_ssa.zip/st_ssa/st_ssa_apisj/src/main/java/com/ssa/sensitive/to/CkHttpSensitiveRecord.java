package com.ssa.sensitive.to;

/**
 * @author qsj
 * @since 2021/1/20
 */
public class CkHttpSensitiveRecord {
    private Long sensitiveId;
    private Long logId;
    private Long interfaceId;
    private Long appId;
    private Integer sensitiveLocation;
    private Long requestTime;
    private Long createTime;
    private String cellPhone;
    private String bankAccount;
    private String businessName;
    private String busNumber;
    private String chinaName;
    private String chineseAddress;
    private String email;
    private String idCard;
    private String mtpForHkmacao;
    private String mtpForTaiwai;
    private String officerNumber;
    private String passportCode;
    private String phoneNumber;
    private String postCode;
    private String threeInOne;
    private String vicNumber;
    private String code_201;
    private String code_202;
    private String code_203;
    private String code_204;
    private String code_205;
    private String code_206;
    private String code_207;
    private String code_208;
    private String code_209;
    private String code_210;
    private String code_211;
    private String code_212;
    private String code_213;
    private String code_214;
    private String code_215;
    private String code_216;
    private String code_217;
    private String code_218;
    private String code_219;
    private String code_220;
    private String code_221;
    private String code_222;
    private String code_223;
    private String code_224;
    private String code_225;
    private String code_226;
    private String code_227;
    private String code_228;
    private String code_229;
    private String code_230;
    private String code_231;
    private String code_232;
    private String code_233;
    private String code_234;
    private String code_235;
    private String code_236;
    private String code_237;
    private String code_238;
    private String code_239;
    private String code_240;
    private String code_241;
    private String code_242;
    private String code_243;
    private String code_244;
    private String code_245;
    private String code_246;
    private String code_247;
    private String code_248;
    private String code_249;
    private String code_250;



    public CkHttpSensitiveRecord(){
    }

    public Long getSensitiveId() {
        return sensitiveId;
    }

    public void setSensitiveId(Long sensitiveId) {
        this.sensitiveId = sensitiveId;
    }

    public Long getLogId() {
        return logId;
    }

    public void setLogId(Long logId) {
        this.logId = logId;
    }

    public Long getInterfaceId() {
        return interfaceId;
    }

    public void setInterfaceId(Long interfaceId) {
        this.interfaceId = interfaceId;
    }

    public Long getAppId() {
        return appId;
    }

    public void setAppId(Long appId) {
        this.appId = appId;
    }

    public Integer getSensitiveLocation() {
        return sensitiveLocation;
    }

    public void setSensitiveLocation(Integer sensitiveLocation) {
        this.sensitiveLocation = sensitiveLocation;
    }

    public Long getRequestTime() {
        return requestTime;
    }

    public void setRequestTime(Long requestTime) {
        this.requestTime = requestTime;
    }

    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    public String getCellPhone() {
        return cellPhone;
    }

    public void setCellPhone(String cellPhone) {
        this.cellPhone = cellPhone;
    }

    public String getBankAccount() {
        return bankAccount;
    }

    public void setBankAccount(String bankAccount) {
        this.bankAccount = bankAccount;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public String getBusNumber() {
        return busNumber;
    }

    public void setBusNumber(String busNumber) {
        this.busNumber = busNumber;
    }

    public String getChinaName() {
        return chinaName;
    }

    public void setChinaName(String chinaName) {
        this.chinaName = chinaName;
    }

    public String getChineseAddress() {
        return chineseAddress;
    }

    public void setChineseAddress(String chineseAddress) {
        this.chineseAddress = chineseAddress;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getMtpForHkmacao() {
        return mtpForHkmacao;
    }

    public void setMtpForHkmacao(String mtpForHkmacao) {
        this.mtpForHkmacao = mtpForHkmacao;
    }

    public String getMtpForTaiwai() {
        return mtpForTaiwai;
    }

    public void setMtpForTaiwai(String mtpForTaiwai) {
        this.mtpForTaiwai = mtpForTaiwai;
    }

    public String getOfficerNumber() {
        return officerNumber;
    }

    public void setOfficerNumber(String officerNumber) {
        this.officerNumber = officerNumber;
    }

    public String getPassportCode() {
        return passportCode;
    }

    public void setPassportCode(String passportCode) {
        this.passportCode = passportCode;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getPostCode() {
        return postCode;
    }

    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }

    public String getThreeInOne() {
        return threeInOne;
    }

    public void setThreeInOne(String threeInOne) {
        this.threeInOne = threeInOne;
    }

    public String getVicNumber() {
        return vicNumber;
    }

    public void setVicNumber(String vicNumber) {
        this.vicNumber = vicNumber;
    }

    public String getCode_201() {
        return code_201;
    }

    public void setCode_201(String code_201) {
        this.code_201 = code_201;
    }

    public String getCode_202() {
        return code_202;
    }

    public void setCode_202(String code_202) {
        this.code_202 = code_202;
    }

    public String getCode_203() {
        return code_203;
    }

    public void setCode_203(String code_203) {
        this.code_203 = code_203;
    }

    public String getCode_204() {
        return code_204;
    }

    public void setCode_204(String code_204) {
        this.code_204 = code_204;
    }

    public String getCode_205() {
        return code_205;
    }

    public void setCode_205(String code_205) {
        this.code_205 = code_205;
    }

    public String getCode_206() {
        return code_206;
    }

    public void setCode_206(String code_206) {
        this.code_206 = code_206;
    }

    public String getCode_207() {
        return code_207;
    }

    public void setCode_207(String code_207) {
        this.code_207 = code_207;
    }

    public String getCode_208() {
        return code_208;
    }

    public void setCode_208(String code_208) {
        this.code_208 = code_208;
    }

    public String getCode_209() {
        return code_209;
    }

    public void setCode_209(String code_209) {
        this.code_209 = code_209;
    }

    public String getCode_210() {
        return code_210;
    }

    public void setCode_210(String code_210) {
        this.code_210 = code_210;
    }

    public String getCode_211() {
        return code_211;
    }

    public void setCode_211(String code_211) {
        this.code_211 = code_211;
    }

    public String getCode_212() {
        return code_212;
    }

    public void setCode_212(String code_212) {
        this.code_212 = code_212;
    }

    public String getCode_213() {
        return code_213;
    }

    public void setCode_213(String code_213) {
        this.code_213 = code_213;
    }

    public String getCode_214() {
        return code_214;
    }

    public void setCode_214(String code_214) {
        this.code_214 = code_214;
    }

    public String getCode_215() {
        return code_215;
    }

    public void setCode_215(String code_215) {
        this.code_215 = code_215;
    }

    public String getCode_216() {
        return code_216;
    }

    public void setCode_216(String code_216) {
        this.code_216 = code_216;
    }

    public String getCode_217() {
        return code_217;
    }

    public void setCode_217(String code_217) {
        this.code_217 = code_217;
    }

    public String getCode_218() {
        return code_218;
    }

    public void setCode_218(String code_218) {
        this.code_218 = code_218;
    }

    public String getCode_219() {
        return code_219;
    }

    public void setCode_219(String code_219) {
        this.code_219 = code_219;
    }

    public String getCode_220() {
        return code_220;
    }

    public void setCode_220(String code_220) {
        this.code_220 = code_220;
    }

    public String getCode_221() {
        return code_221;
    }

    public void setCode_221(String code_221) {
        this.code_221 = code_221;
    }

    public String getCode_222() {
        return code_222;
    }

    public void setCode_222(String code_222) {
        this.code_222 = code_222;
    }

    public String getCode_223() {
        return code_223;
    }

    public void setCode_223(String code_223) {
        this.code_223 = code_223;
    }

    public String getCode_224() {
        return code_224;
    }

    public void setCode_224(String code_224) {
        this.code_224 = code_224;
    }

    public String getCode_225() {
        return code_225;
    }

    public void setCode_225(String code_225) {
        this.code_225 = code_225;
    }

    public String getCode_226() {
        return code_226;
    }

    public void setCode_226(String code_226) {
        this.code_226 = code_226;
    }

    public String getCode_227() {
        return code_227;
    }

    public void setCode_227(String code_227) {
        this.code_227 = code_227;
    }

    public String getCode_228() {
        return code_228;
    }

    public void setCode_228(String code_228) {
        this.code_228 = code_228;
    }

    public String getCode_229() {
        return code_229;
    }

    public void setCode_229(String code_229) {
        this.code_229 = code_229;
    }

    public String getCode_230() {
        return code_230;
    }

    public void setCode_230(String code_230) {
        this.code_230 = code_230;
    }

    public String getCode_231() {
        return code_231;
    }

    public void setCode_231(String code_231) {
        this.code_231 = code_231;
    }

    public String getCode_232() {
        return code_232;
    }

    public void setCode_232(String code_232) {
        this.code_232 = code_232;
    }

    public String getCode_233() {
        return code_233;
    }

    public void setCode_233(String code_233) {
        this.code_233 = code_233;
    }

    public String getCode_234() {
        return code_234;
    }

    public void setCode_234(String code_234) {
        this.code_234 = code_234;
    }

    public String getCode_235() {
        return code_235;
    }

    public void setCode_235(String code_235) {
        this.code_235 = code_235;
    }

    public String getCode_236() {
        return code_236;
    }

    public void setCode_236(String code_236) {
        this.code_236 = code_236;
    }

    public String getCode_237() {
        return code_237;
    }

    public void setCode_237(String code_237) {
        this.code_237 = code_237;
    }

    public String getCode_238() {
        return code_238;
    }

    public void setCode_238(String code_238) {
        this.code_238 = code_238;
    }

    public String getCode_239() {
        return code_239;
    }

    public void setCode_239(String code_239) {
        this.code_239 = code_239;
    }

    public String getCode_240() {
        return code_240;
    }

    public void setCode_240(String code_240) {
        this.code_240 = code_240;
    }

    public String getCode_241() {
        return code_241;
    }

    public void setCode_241(String code_241) {
        this.code_241 = code_241;
    }

    public String getCode_242() {
        return code_242;
    }

    public void setCode_242(String code_242) {
        this.code_242 = code_242;
    }

    public String getCode_243() {
        return code_243;
    }

    public void setCode_243(String code_243) {
        this.code_243 = code_243;
    }

    public String getCode_244() {
        return code_244;
    }

    public void setCode_244(String code_244) {
        this.code_244 = code_244;
    }

    public String getCode_245() {
        return code_245;
    }

    public void setCode_245(String code_245) {
        this.code_245 = code_245;
    }

    public String getCode_246() {
        return code_246;
    }

    public void setCode_246(String code_246) {
        this.code_246 = code_246;
    }

    public String getCode_247() {
        return code_247;
    }

    public void setCode_247(String code_247) {
        this.code_247 = code_247;
    }

    public String getCode_248() {
        return code_248;
    }

    public void setCode_248(String code_248) {
        this.code_248 = code_248;
    }

    public String getCode_249() {
        return code_249;
    }

    public void setCode_249(String code_249) {
        this.code_249 = code_249;
    }

    public String getCode_250() {
        return code_250;
    }

    public void setCode_250(String code_250) {
        this.code_250 = code_250;
    }
}
