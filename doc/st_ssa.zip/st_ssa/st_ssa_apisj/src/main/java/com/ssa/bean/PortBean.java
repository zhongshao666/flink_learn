package com.ssa.bean;

public class PortBean {
    private Integer selfport;
    private Integer startport;
    private Integer endport;

    public Integer getSelfport() {
        return selfport;
    }

    public void setSelfport(Integer selfport) {
        this.selfport = selfport;
    }

    public Integer getStartport() {
        return startport;
    }

    public void setStartport(Integer startport) {
        this.startport = startport;
    }

    public Integer getEndport() {
        return endport;
    }

    public void setEndport(Integer endport) {
        this.endport = endport;
    }

    public PortBean(Integer selfport) {
        this.selfport = selfport;
    }

    public PortBean(Integer startport, Integer endport) {
        this.startport = startport;
        this.endport = endport;
    }

    public PortBean() {
    }
}
