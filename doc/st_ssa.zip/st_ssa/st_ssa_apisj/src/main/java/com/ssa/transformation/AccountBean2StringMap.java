package com.ssa.transformation;

import com.alibaba.fastjson.JSON;
import com.ssa.bean.AccountBean;
import org.apache.flink.api.common.functions.MapFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author admin
 */
public class AccountBean2StringMap implements MapFunction<AccountBean, String> {
    private static final Logger logger = LoggerFactory.getLogger(AccountBean2StringMap.class);
    @Override
    public String map(AccountBean accountBean) throws Exception {
        String res = JSON.toJSONString(accountBean);
        logger.info("account discovery {}",res);
        return res;
    }
}
