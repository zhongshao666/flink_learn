package com.ssa.sensitive.util;

import java.util.List;
import java.util.Optional;

/**
 * @author qsj
 * @since 2021/1/31
 */
public class CsvUtils {
    private static final Character SEPARATOR = ',';
    private static final Character QUOTE_CHAR = '"';
    private static final Character ESCAPE_CHAR = '"';
    private static final Character LINE_END = '\n';
    private static final Character CARRIAGE_RETURN = '\r';

    /**
     * 将list转为csv格式string
     * @param list
     * @return
     */
    public static String convertToCsvFormatByList(List<String> list) {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < list.size(); i++) {
            if (i != 0) {
                sb.append(SEPARATOR);
            }

            sb.append(QUOTE_CHAR);
            Optional.ofNullable(list.get(i))
                    .ifPresent(item -> {
                        if (stringContainsSpecialCharacters(item)) {
                            processLine(item, sb);
                        } else {
                            sb.append(item);
                        }
                    });

            sb.append(QUOTE_CHAR);
        }

        sb.append(LINE_END);
        return sb.toString();
    }



    /**
     * 是否包含特殊值
     *
     * @param line
     * @return
     */
    private static boolean stringContainsSpecialCharacters(String line) {
        return line.indexOf(QUOTE_CHAR) != -1 || line.indexOf(ESCAPE_CHAR) != -1 || line.indexOf(SEPARATOR) != -1 || line.indexOf(LINE_END) != -1 || line.indexOf(CARRIAGE_RETURN) != -1;
    }

    /**
     * 处理值
     *
     * @param nextElement
     * @param appendable
     */
    protected static void processLine(String nextElement, StringBuilder appendable) {
        for (int j = 0; j < nextElement.length(); ++j) {
            char nextChar = nextElement.charAt(j);
            processCharacter(appendable, nextChar);
        }

    }

    /**
     * 处理具体的字符
     *
     * @param appendable
     * @param nextChar
     */
    protected static void processCharacter(StringBuilder appendable, char nextChar) {
        if (checkCharactersToEscape(nextChar)) {
            appendable.append(ESCAPE_CHAR);
        }

        appendable.append(nextChar);
    }

    /**
     * 判断是否要转义
     *
     * @param nextChar
     * @return
     */
    protected static boolean checkCharactersToEscape(char nextChar) {
        return nextChar == QUOTE_CHAR || nextChar == ESCAPE_CHAR;
    }



    public static final Character CK_QUOTE_CHAR = '\'';
    public static final Character CK_ESCAPE_CHAR = '\\';
    public static final Character CK_LINE_BEGIN = '(';
    public static final Character CK_LINE_END = ')';

    /**
     * 转换为ck符合的format
     * @param list
     * @return
     */
    public static String convertToCkCsvFormatByList(List<String> list) {
        StringBuilder sb = new StringBuilder();

        sb.append(CK_LINE_BEGIN);
        for (int i = 0; i < list.size(); i++) {
            if (i != 0) {
                sb.append(SEPARATOR);
            }

            sb.append(CK_QUOTE_CHAR);
            Optional.ofNullable(list.get(i))
                    .ifPresent(item -> {
                        if (item.indexOf(CK_QUOTE_CHAR)!=-1||item.indexOf(CK_ESCAPE_CHAR)!=-1) {
                            processCkLine(item, sb);
                        } else {
                            sb.append(item);
                        }
                    });

            sb.append(CK_QUOTE_CHAR);
        }

        sb.append(CK_LINE_END);
        return sb.toString();
    }

    /**
     * 处理ck line
     * @param nextElement
     * @param appendable
     */
    private static void processCkLine(String nextElement, StringBuilder appendable) {
        for (int j = 0; j < nextElement.length(); ++j) {
            char nextChar = nextElement.charAt(j);
            if (checkCkCharactersToEscape(nextChar)) {
                appendable.append(CK_ESCAPE_CHAR);
            }

            appendable.append(nextChar);
        }
    }

    /**
     * 检查是否需要转义
     * @param nextChar
     * @return
     */
    protected static boolean checkCkCharactersToEscape(char nextChar) {
        return nextChar == CK_QUOTE_CHAR || nextChar == CK_ESCAPE_CHAR;
    }
}
