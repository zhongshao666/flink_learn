package com.ssa.keys;

import com.ssa.sensitive.to.HttpLog;
import org.apache.flink.api.java.functions.KeySelector;

public class AppIdKeySelector implements KeySelector<HttpLog,Long> {
    @Override
    public Long getKey(HttpLog httpLog) throws Exception {
        return httpLog.getAppId();
    }
}
