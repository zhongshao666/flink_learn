package com.ssa.sensitive.match;

import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.ssa.sensitive.constants.CommonConstants;
import jodd.lagarto.LagartoParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Map;

import static com.google.gson.stream.JsonToken.END_DOCUMENT;

/**
 * @author qsj
 * @since 2021/1/24
 */
public abstract class AbstractParse {

    private static final Logger logger = LoggerFactory.getLogger(AbstractParse.class);

    /**
     * 解析数据
     *
     * @param body
     * @return
     */
    public abstract List<String> parseData(String body);

    /**
     * 解析数据为map
     *
     * @param body
     * @return
     */
    protected Map<String, String> parseMapData(String body) {
        return null;
    }

    /**
     * 判断内容第一个字符是否符合json格式符合则使用json进行解析
     *
     * @param val
     * @return
     */
    protected boolean isJson(String val) {
        for (char c : val.toCharArray()) {
            if (c == ' ') {
                continue;
            }
            if (c == '\r') {
                continue;
            }
            if (c == '\n') {
                continue;
            }
            return c == '{' || c == '[';
        }
        return false;
    }

    /**
     * html 解析并识别
     *
     * @param body
     */
    protected void htmlParse(String body, List<String> valueList) {
        LagartoParser lagartoParser = new LagartoParser(body);
        TagMaskVisitor tagMaskVisitor = new TagMaskVisitor();
        lagartoParser.parse(tagMaskVisitor);
        valueList.addAll(tagMaskVisitor.getValueList());

    }

    /**
     * json解析并识别
     *
     * @param body
     */
    protected void jsonParse(String body, List<String> valueList) {
        try (InputStream inputStream = new ByteArrayInputStream(body.getBytes());
             InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
             JsonReader reader = new DefaultJsonReader(inputStreamReader)) {

            reader.setLenient(true);
            JsonToken token;
            while ((token = reader.peek()) != END_DOCUMENT) {
                switch (token) {
                    case BEGIN_ARRAY:
                        reader.beginArray();
                        break;
                    case END_ARRAY:
                        reader.endArray();
                        break;
                    case BEGIN_OBJECT:
                        reader.beginObject();
                        break;
                    case END_OBJECT:
                        reader.endObject();
                        break;
                    case NAME:
                        reader.nextName();
                        break;

                    case STRING:
                    case NUMBER:
                        valueList.add(reader.nextString());
                        break;

                    case BOOLEAN:
                        reader.nextBoolean();
                        break;

                    case NULL:
                        reader.nextNull();
                        break;
                    default:
                        break;
                }
            }

        } catch (Exception e) {
            logger.error("json parse error, string is:" + body, e);
        }
    }

    /**
     * form表单 kv结构解析
     *
     * @param body
     * @param valueList
     */
    protected void formKvParse(String body, List<String> valueList) {
        String[] arr = body.split(CommonConstants.URL_PARAM_SPLIT_CHAR);
        for (String kv : arr) {
            String[] kvArr = kv.split(CommonConstants.URL_PARAM_ASSIGN_CHAR);
            if (kvArr.length == 2) {
                valueList.add(kvArr[1]);
            }
        }
    }

    /**
     * form表单 kv结构解析
     * @param body
     * @param map
     */
    protected void formKvParse(String body,Map<String,String> map){
        String[] arr = body.split(CommonConstants.URL_PARAM_SPLIT_CHAR);
        for (String kv : arr) {
            String[] kvArr = kv.split(CommonConstants.URL_PARAM_ASSIGN_CHAR);
            if(kvArr.length == 2){
                map.put(kvArr[0],kvArr[1]);
            }
        }
    }
}
