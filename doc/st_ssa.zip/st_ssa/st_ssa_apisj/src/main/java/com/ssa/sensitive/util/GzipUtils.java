package com.ssa.sensitive.util;

import com.google.common.base.Strings;
import com.nixxcode.jvmbrotli.common.BrotliLoader;
import com.nixxcode.jvmbrotli.dec.BrotliInputStream;
import com.nixxcode.jvmbrotli.enc.BrotliOutputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.Charset;
import java.util.zip.Deflater;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.util.zip.Inflater;

/**
 * @author qsj
 * @since 2021/2/1
 */
public class GzipUtils {
    private static final Logger logger = LoggerFactory.getLogger(GzipUtils.class);

    /**
     * gz压缩
     *
     * @param str
     * @param charset
     * @return
     */
    public static byte[] compress(String str, Charset charset) {
        if (Strings.isNullOrEmpty(str)) {
            return null;
        }

        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            try (GZIPOutputStream gzipOutputStream = new GZIPOutputStream(outputStream)){
                gzipOutputStream.write(str.getBytes(charset));
            }
            return outputStream.toByteArray();
        } catch (Exception e) {
            logger.error("gzip compress error", e);
        }

        return null;
    }

    /**
     * gz解压缩
     *
     * @param bytes
     * @return
     */
    public static byte[] uncompress(byte[] bytes) {
        if (bytes == null || bytes.length == 0) {
            return null;
        }

        try (ByteArrayOutputStream out = new ByteArrayOutputStream(); ByteArrayInputStream in = new ByteArrayInputStream(bytes); GZIPInputStream unzip = new GZIPInputStream(in)) {
            byte[] buffer = new byte[256];
            int n;
            while ((n = unzip.read(buffer)) >= 0) {
                out.write(buffer, 0, n);
            }
            return out.toByteArray();
        } catch (Exception e) {
            logger.error("gzip uncompress error", e);
        }

        return null;

    }

    /**
     * deflate 压缩
     * @param bytes
     * @return
     */
    public static byte[] deflateCompress(byte[] bytes){
        Deflater compress = new Deflater(1);
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()){
            compress.setInput(bytes);
            compress.finish();
            final byte[] buf = new byte[2048];
            while (!compress.finished()){
                int count = compress.deflate(buf);
                out.write(buf,0,count);
            }
            return out.toByteArray();
        }catch (Exception e){
            logger.error("deflate compress error", e);
        }finally {
            compress.end();
        }
        return null;
    }

    /**
     * deflate 解压
     * @param bytes
     * @return
     */
    public static byte[] deflateUnCompress(byte[] bytes){
        Inflater deCompress = new Inflater();
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()){
            deCompress.setInput(bytes);
            final byte[] buf = new byte[2048];
            while (!deCompress.finished()){
                int count = deCompress.inflate(buf);
                out.write(buf,0,count);
            }
            return out.toByteArray();
        }catch (Exception e){
            logger.error("deflate uncompress error", e);
        }finally {
            deCompress.end();
        }
        return null;
    }

    /**
     * brotli 压缩
     * @param bytes
     * @return
     */
    public static byte[] brotliCompress(byte[] bytes){
        BrotliLoader.isBrotliAvailable();
        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            try (BrotliOutputStream brotliOutputStream = new BrotliOutputStream(outputStream)){
                brotliOutputStream.write(bytes);
            }
            return outputStream.toByteArray();
        } catch (Exception e) {
            logger.error("brotli compress error", e);
        }
        return null;
    }

    /**
     * brotli 解压
     * @param bytes
     * @return
     */
    public static byte[] brotliUnCompress(byte[] bytes){
        BrotliLoader.isBrotliAvailable();
        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            try (ByteArrayInputStream in = new ByteArrayInputStream(bytes); BrotliInputStream brotliInputStream = new BrotliInputStream(in)){
                byte[] buffer = new byte[256];
                int n;
                while ((n = brotliInputStream.read(buffer)) >= 0) {
                    outputStream.write(buffer, 0, n);
                }
            }
            return outputStream.toByteArray();
        } catch (Exception e) {
            logger.error("brotli uncompress error", e);
        }
        return null;
    }


}
