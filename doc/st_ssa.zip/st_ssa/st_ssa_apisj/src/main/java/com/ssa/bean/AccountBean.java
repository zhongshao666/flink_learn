package com.ssa.bean;

public class AccountBean {
    private String account;
    private String pwd;
    private Long appId;
    private Long interfaceId;
    private String accountParam;
    private String pwdParam;
    private String accountLocation;
    private String method;

    public AccountBean() {
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public Long getAppId() {
        return appId;
    }

    public void setAppId(Long appId) {
        this.appId = appId;
    }

    public Long getInterfaceId() {
        return interfaceId;
    }

    public void setInterfaceId(Long interfaceId) {
        this.interfaceId = interfaceId;
    }

    public String getAccountParam() {
        return accountParam;
    }

    public void setAccountParam(String accountParam) {
        this.accountParam = accountParam;
    }

    public String getPwdParam() {
        return pwdParam;
    }

    public void setPwdParam(String pwdParam) {
        this.pwdParam = pwdParam;
    }

    public String getAccountLocation() {
        return accountLocation;
    }

    public void setAccountLocation(String accountLocation) {
        this.accountLocation = accountLocation;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }
}
