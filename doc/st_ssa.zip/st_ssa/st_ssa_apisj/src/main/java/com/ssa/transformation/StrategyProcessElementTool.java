package com.ssa.transformation;

import com.ssa.map.ConditionTOMarking;
import com.ssa.map.ParsingZkConfigSource;
import com.ssa.map.ParsingZkSource;
import com.ssa.strategy.StrategyConfig;
import com.ssa.strategy.StrategyMatch;
import com.ssa.sensitive.constants.CommonConstants;
import com.ssa.sensitive.to.HttpLog;
import org.apache.flink.api.common.state.BroadcastState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.streaming.api.functions.co.BaseBroadcastProcessFunction;
import org.apache.flink.streaming.api.functions.co.KeyedBroadcastProcessFunction;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.Map;

/**
 * @author : yang
 * 功能： 策略命中判断公共类
 */
public class StrategyProcessElementTool implements Serializable {

    private ParsingZkSource parsingZkSource = new ParsingZkSource();

    /**
     * 过滤广播流命中规则
     *
     * @param value
     * @param ctx
     * @param filterStrategy     策略规则命中的类型
     * @param strategyMatchState zk数据的state
     * @param strategyCfgState   策略总开关state
     * @param <T>                BaseBroadcastProcessFunction.Context泛型，适用当keyed流和nonkeyed流合并是判断
     * @throws Exception
     */
    public <T extends BaseBroadcastProcessFunction.Context>
    Tuple2<MapStateDescriptor<String, StrategyMatch>, MapStateDescriptor<Integer, StrategyConfig>> strategyBroadcastElement(Tuple4<Integer, Integer, String, String> value,
                                                                                                                                                                                    T ctx,
                                                                                                                                                                                    String filterStrategy,
                                                                                                                                                                                    MapStateDescriptor<String, StrategyMatch> strategyMatchState,
                                                                                                                                                                                    MapStateDescriptor<Integer, StrategyConfig> strategyCfgState) throws Exception {
        int globalInit = CommonConstants.ZkDataType.STRATEGY_CONFIG.getVal();

        if (value.f0 == CommonConstants.ZkDataType.RISK_TYPE.getVal()) {
            StrategyMatch strategyMatch = parsingZkSource.parsingZkJson(value.f3);
            if (filterStrategy.equals(strategyMatch.getStrategy())) {
                BroadcastState<String, StrategyMatch> broadcastState0 = ctx.getBroadcastState(strategyMatchState);
                broadcastState0.put(strategyMatch.getStrategy(), strategyMatch);
            }
        }
        if (value.f0.equals(globalInit)) {
            BroadcastState<Integer, StrategyConfig> broadcastState1 = ctx.getBroadcastState(strategyCfgState);
            StrategyConfig strategyConfig = ParsingZkConfigSource.parsingZkConfigSource(value.f3);
            broadcastState1.put(globalInit, strategyConfig);
        }

        return new Tuple2<>(strategyMatchState, strategyCfgState);
    }

    /**
     * windowing动态检测（多长时间内命中多少次）
     *
     * @param value
     * @param ctx
     * @param globalInit          广播变量map的key
     * @param userQueueAccessTime 历史数据只包含时间的队列
     * @param strategyMatch  zk数据的
     * @param strategyConfig 策略总开关
     * @throws Exception
     */
    public void strategyProcessElement(HttpLog value,
                                       KeyedBroadcastProcessFunction.ReadOnlyContext ctx,
                                       Integer globalInit,
                                       ValueState<LinkedList<Long>> userQueueAccessTime,
                                       StrategyMatch strategyMatch,
                                       StrategyConfig strategyConfig) throws Exception {

        if (strategyMatch.getEnable() && strategyConfig.getRiskPolicyEnable()) {
            int size = userQueueAccessTime.value().size();
            int times = strategyMatch.getStrategyMatchCondition().getLoginFrequency().getTimes();
            if (size < times) {
                userQueueAccessTime.value().add(value.getRequestTime());
            } else if (size > times) {
                ConditionTOMarking.reSetFrequencyAlarmModule(userQueueAccessTime.value(), size - times);
            }
            if (size == times) {
                if (value.getRequestTime() - userQueueAccessTime.value().getFirst() <
                        ConditionTOMarking.transFromationTime(strategyMatch.getStrategyMatchCondition().getTriggerFrequency().getTime(),
                                strategyMatch.getStrategyMatchCondition().getTriggerFrequency().getUnit())) {
                    ConditionTOMarking.setStrategy(value, strategyMatch);
                }
            }
        }
    }

    /**
     * 匹配黑白名单、自定义规则zkSource
     *
     * @param operateType
     * @param filterStrategy
     * @param data
     * @param matchMap
     */
    public void initStrategyMatch(int operateType, String filterStrategy, String data, Map<Integer, StrategyMatch> matchMap) {
        StrategyMatch strategyMatch = parsingZkSource.parsingZkJson(data);
        if (filterStrategy.equals(strategyMatch.getStrategy())) {
            if (operateType == CommonConstants.OperateType.ADD.getVal() || operateType == CommonConstants.OperateType.UPDATE.getVal()) {
                matchMap.put(strategyMatch.getId(), strategyMatch);
            } else if (operateType == CommonConstants.OperateType.DELETE.getVal()) {
                matchMap.remove(strategyMatch.getId());
            }

        }
    }


    /**
     * 匹配应用id开关zkSource
     *
     * @param operateType
     * @param data
     * @param appIdMap
     */
    public void modifyAppIdConfig(int operateType, String data, Map<Long, StrategyConfig> appIdMap) {
        StrategyConfig strategyConfig = ParsingZkConfigSource.parsingZkConfigSource(data);
        if (operateType == CommonConstants.OperateType.ADD.getVal() || operateType == CommonConstants.OperateType.UPDATE.getVal()) {
            appIdMap.put(strategyConfig.getAppId(), strategyConfig);
        } else if (operateType == CommonConstants.OperateType.DELETE.getVal()) {
            appIdMap.remove(strategyConfig.getAppId());
        }
    }


    public <T extends BaseBroadcastProcessFunction.Context>
    void strategyBroadcastElement(Tuple4<Integer, Integer, String, String> value,
                                                                            T ctx,
                                                                            String filterStrategy,
                                                                            MapStateDescriptor<Tuple2<String, Integer>,
                                                                                    Tuple2<StrategyMatch, StrategyConfig>> vlBroacetCastState) throws Exception {
        int globalInit = CommonConstants.ZkDataType.STRATEGY_CONFIG.getVal();

        if (value.f0 == CommonConstants.ZkDataType.RISK_TYPE.getVal()) {
            StrategyMatch strategyMatch = parsingZkSource.parsingZkJson(value.f3);
            if (filterStrategy.equals(strategyMatch.getStrategy())) {
                StrategyConfig strategyConfig = ParsingZkConfigSource.parsingZkConfigSource(value.f3);
                BroadcastState<Tuple2<String, Integer>, Tuple2<StrategyMatch, StrategyConfig>> broadcastState = ctx.getBroadcastState(vlBroacetCastState);
                broadcastState.put(new Tuple2<>(strategyMatch.getName(), globalInit), new Tuple2<>(strategyMatch, strategyConfig));
            }
        }
    }
}
