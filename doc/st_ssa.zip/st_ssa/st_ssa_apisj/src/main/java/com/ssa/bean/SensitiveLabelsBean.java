package com.ssa.bean;

import java.util.List;

/**
 * @author admin
 * kafka敏感数据bean
 */
public class SensitiveLabelsBean {

    private List<SensitiveLabel> sensitiveLabels;
    private Long interfaceId;
    private Long appId;

    public List<SensitiveLabel> getSensitiveLabels() {
        return sensitiveLabels;
    }

    public void setSensitiveLabels(List<SensitiveLabel> sensitiveLabels) {
        this.sensitiveLabels = sensitiveLabels;
    }

    public Long getInterfaceId() {
        return interfaceId;
    }

    public void setInterfaceId(Long interfaceId) {
        this.interfaceId = interfaceId;
    }

    public Long getAppId() {
        return appId;
    }

    public void setAppId(Long appId) {
        this.appId = appId;
    }
}
