package com.ssa.source;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ssa.ApisjMain;
import com.ssa.bean.OfflineData;
import com.ssa.utils.CuratorOperator;
import com.ssa.sensitive.constants.CommonConstants;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.CuratorFramework;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.recipes.cache.PathChildrenCache;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.recipes.cache.PathChildrenCacheEvent;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.recipes.cache.PathChildrenCacheListener;
import org.apache.flink.streaming.api.functions.source.RichSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;

/**
 * @author Administrator
 * @sole ClickHouseZk离线数据源
 */
public class ClickHouseZkSource extends RichSourceFunction<OfflineData> {

    private static final Logger logger = LoggerFactory.getLogger(ClickHouseZkSource.class);
    CuratorOperator curatorOperator = null;
    SourceContext<OfflineData> sourceContext = null;
    ParameterTool parameterTool;

    @Override
    public void open(Configuration parameters) throws Exception {
         parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig()
                                                                         .getGlobalJobParameters();
        curatorOperator = new CuratorOperator(parameterTool.get("zookeeper.url"));
        Class.forName("ru.yandex.clickhouse.ClickHouseDriver");
    }

    @Override
    public void run(SourceContext<OfflineData> ctx) throws Exception {
        sourceContext = ctx;
        final PathChildrenCache pathChildrenCache = new PathChildrenCache(curatorOperator.client,parameterTool.get("zookeeper.risk.data.path"), true);

        childrenListen(pathChildrenCache, parameterTool.get("zookeeper.risk.data.path"));

        while (true) {
            Thread.sleep(10000);
        }
    }

    @Override
    public void cancel() {

    }

    public void childrenListen(PathChildrenCache pathChildrenCache, String nodepath) throws Exception {
        pathChildrenCache.start(PathChildrenCache.StartMode.POST_INITIALIZED_EVENT);
        pathChildrenCache.getListenable().addListener(new PathChildrenCacheListener() {
            @Override
            public void childEvent(CuratorFramework curatorFramework, PathChildrenCacheEvent event) throws Exception {

                if (event.getType().equals(PathChildrenCacheEvent.Type.INITIALIZED)) {
                    logger.info("初始化zookeeper监听完成.........");
                } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_ADDED)) {
                    jdbcConnectChilld(event);
                } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_REMOVED)) {
                } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_UPDATED)) {
                    jdbcConnectChilld(event);
                }
            }
        });
    }

    public void jdbcConnectChilld(PathChildrenCacheEvent event) {
        String zkData = new String(event.getData().getData());
        JSONObject obj = JSON.parseObject(zkData);
        String table = obj.getString("tableName");
        int status = obj.getInteger("status");
        if (status == 1) {

            String address = "jdbc:clickhouse://" + parameterTool.get("clickHouse.Url") + "/" +parameterTool.get("clickHouse.Database");

            try (Connection connection = DriverManager.getConnection(address, parameterTool.get("clickHouse.User"), parameterTool.get("clickHouse.Password"));
                 Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery("select * from " + table)) {
                while (resultSet.next()) {
                    OfflineData offlineData = new OfflineData();
                    if (CommonConstants.OfflineTableType.SENSITIVE_VISIT.getVal().equals(table)) {
                        offlineData.setOfflineTableType(CommonConstants.OfflineTableType.SENSITIVE_VISIT.getVal());
                        setSensitiveVisitTable(resultSet, offlineData);
                    } else if (CommonConstants.OfflineTableType.SENSITIVE_OPERTOR.getVal().equals(table)) {
                        offlineData.setOfflineTableType(CommonConstants.OfflineTableType.SENSITIVE_OPERTOR.getVal());
                        setSensitiveOpertorTable(resultSet, offlineData);
                    }
                    sourceContext.collect(offlineData);
                }
            } catch (Exception e) {
                logger.error("query error", e);
            }
        }
    }

    public void setSensitiveVisitTable(ResultSet resultSet, OfflineData offlineData) throws SQLException {
        offlineData.setAppId(resultSet.getLong("app_id"));
        offlineData.setInterfaceId(resultSet.getLong("interface_id"));
        offlineData.setUserName(resultSet.getString("user_name"));
    }

    public void setSensitiveOpertorTable(ResultSet resultSet, OfflineData offlineData) throws SQLException {
        offlineData.setAppId(resultSet.getLong("app_id"));
        offlineData.setInterfaceId(resultSet.getLong("interface_id"));
        offlineData.setSensitiveLabelField(resultSet.getString("sensitive_label_field"));
    }
}
