package com.ssa.sensitive.urlmatch;

/**
 * @author qsj
 * @since 2021/1/19
 */
public class UrlNode {
    private UrlNode nextNode;
    private String value;
    private int depth;
    private boolean endFlag;
    private boolean wildcardFlag;
    private boolean allWildcardFlag;
    private Long interfaceId;

    private String startWith;
    private String endWith;


    public UrlNode(String value,int depth,boolean endFlag,boolean wildcardFlag,boolean allWildcardFlag,Long interfaceId){
        this.value = value;
        this.depth = depth;
        this.endFlag = endFlag;
        this.wildcardFlag = wildcardFlag;
        this.allWildcardFlag = allWildcardFlag;
        this.interfaceId = interfaceId;
    }


    public Long getInterfaceId() {
        return interfaceId;
    }

    public void setInterfaceId(Long interfaceId) {
        this.interfaceId = interfaceId;
    }

    public boolean isAllWildcardFlag() {
        return allWildcardFlag;
    }

    public void setAllWildcardFlag(boolean allWildcardFlag) {
        this.allWildcardFlag = allWildcardFlag;
    }

    public UrlNode getNextNode() {
        return nextNode;
    }

    public void setNextNode(UrlNode nextNode) {
        this.nextNode = nextNode;
    }


    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public int getDepth() {
        return depth;
    }

    public void setDepth(int depth) {
        this.depth = depth;
    }

    public boolean isEndFlag() {
        return endFlag;
    }

    public void setEndFlag(boolean endFlag) {
        this.endFlag = endFlag;
    }

    public boolean isWildcardFlag() {
        return wildcardFlag;
    }

    public void setWildcardFlag(boolean wildcardFlag) {
        this.wildcardFlag = wildcardFlag;
    }
}
