package com.ssa.strategy;

import lombok.Data;

/**
 * @author Administrator
 */
@Data
public class WrokingTimeToday {
    private String timeBegin;
    private String timeEnd;
}
