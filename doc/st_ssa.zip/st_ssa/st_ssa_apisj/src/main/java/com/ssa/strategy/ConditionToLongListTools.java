package com.ssa.strategy;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;


@Data
public class ConditionToLongListTools {

    private List<Long> longList = new ArrayList<>();
    private Integer Include;
}