package com.ssa.strategy;

import lombok.Data;

/**
 * @author Administrator
 */
@Data
public class UrlContent {
    /**
     * urlneir
     */
    private String content;
    /**
     * 是否正则 0非正则 1正则
     */
    private Integer reg;

    public UrlContent(String content, Integer reg) {
        this.content = content;
        this.reg = reg;
    }


}