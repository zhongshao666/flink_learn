package com.ssa.strategy;

import lombok.Data;

@Data
public class ConditionToStrategyTools {
    private Integer time;
    private String unit;
    private Integer relation;
}
