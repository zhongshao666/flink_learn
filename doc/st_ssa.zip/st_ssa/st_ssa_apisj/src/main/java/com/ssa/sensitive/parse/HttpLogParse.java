package com.ssa.sensitive.parse;

import com.google.common.collect.ImmutableMap;
import com.ssa.sensitive.to.HttpHeader;
import com.ssa.sensitive.to.HttpLog;
import com.ssa.sensitive.util.GzipUtils;
import com.ssa.sensitive.util.HttpParseUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.Base64;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;

/**
 * @author qsj
 * @since 2021/1/13
 */
public class HttpLogParse {

    private static final Logger logger = LoggerFactory.getLogger(HttpLogParse.class);


    /**
     * 流式解析
     */
    public static HttpLog streamParse(InputStream in, Long logId) {
        try {
            HttpLog httpLog = parseHttpLog(in);

            Optional.ofNullable(httpLog.getRequestHeader())
                    .filter(StringUtils::isNotBlank)
                    .ifPresent(header -> setReqHeader(httpLog, header));

            Optional.ofNullable(httpLog.getResponseHeader())
                    .filter(StringUtils::isNotBlank)
                    .ifPresent(header -> httpLog.setResHeader(new HttpHeader(header)));

            Optional.ofNullable(httpLog.getStatusCode())
                    .ifPresent(item -> setRequestStatus(httpLog, item));

            reqBodyDecode(httpLog);

            resBodyUncompress(httpLog);

            handleRequestUrl(httpLog);

            httpLog.setLogId(logId);
            httpLog.setCreateTime(System.currentTimeMillis());
            httpLog.setIsnewInterface(false);
            httpLog.setHasSensitive(false);
            return httpLog;
        } catch (Exception e) {
            logger.error("http log parse error", e);
        }

        return null;
    }


    /**
     * 转换为request status
     *
     * @param httpLog
     * @param item
     */
    private static void setRequestStatus(HttpLog httpLog, Integer item) {
        if (item < 200) {
            httpLog.setRequestStatus(1);
        }
        if (item >= 200 & item < 300) {
            httpLog.setRequestStatus(2);
        }
        if (item >= 300 & item < 400) {
            httpLog.setRequestStatus(3);
        }
        if (item >= 400 & item < 500) {
            httpLog.setRequestStatus(4);
        }
        if (item >= 500) {
            httpLog.setRequestStatus(5);
        }
    }

    /**
     * 设置请求头
     *
     * @param httpLog
     * @param header
     */
    private static void setReqHeader(HttpLog httpLog, String header) {
        HttpHeader httpHeader = new HttpHeader(header);
        httpLog.setReqHeader(httpHeader);
        if (StringUtils.isNotBlank(httpHeader.getUserAgent())) {
            httpLog.setClientTool(HttpParseUtils.getBrowserFamily(httpHeader.getUserAgent()));
        }
    }

    /**
     * 解析http stream
     *
     * @param in
     * @return
     */
    private static HttpLog parseHttpLog(InputStream in) throws IOException {
        HttpLog httpLog = new HttpLog();
        try (InputStreamReader inputStreamReader = new InputStreamReader(in); BufferedReader bufferedReader = new BufferedReader(inputStreamReader)) {
            char[] lengthBuffer = new char[10];
            int lenCount = 0;
            int fieldIndex = 0;
            int current;
            while ((current = bufferedReader.read()) != -1) {
                char currentChar = (char) current;
                if (currentChar == ',') {
                    int length = getLength(lengthBuffer, lenCount);
                    lengthBuffer = new char[10];
                    lenCount = 0;
                    char[] bodyChar = new char[length];
                    int bodyReach = bufferedReader.read(bodyChar);
                    if (length != 0) {
                        httpLog.setIndex(fieldIndex, new String(bodyChar));
                    }
                    if (bodyReach != -1) {
                        //跳过分割符
                        bufferedReader.read();
                    }
                    fieldIndex++;
                } else {
                    lengthBuffer[lenCount] = currentChar;
                    lenCount++;
                }
            }
        }
        return httpLog;
    }

    /**
     * 处理请求体
     *
     * @param httpLog
     */
    private static void reqBodyDecode(HttpLog httpLog) {
        Optional.ofNullable(httpLog.getRequestBody())
                .filter(StringUtils::isNotBlank)
                .map(HttpLogParse::base64Decode)
                .ifPresent(bytes -> httpLog.setRequestBody(new String(bytes)));

    }


    /**
     * 处理请求url
     *
     * @param httpLog
     */
    private static void handleRequestUrl(HttpLog httpLog) {
        String requestUrl = httpLog.getRequestUrl();
        if (StringUtils.isNotBlank(requestUrl)) {
            int index = requestUrl.indexOf("://");
            if (index != -1) {
                String left = requestUrl.substring(index + 3);
                int first = left.indexOf("/");
                if (first != -1) {
                    int param = left.indexOf("?");
                    if (param == -1) {
                        httpLog.setInterfaceUrl(left.substring(first));
                    } else {
                        httpLog.setInterfaceUrl(left.substring(first, param));
                    }
                } else {
                    httpLog.setInterfaceUrl("/");
                }
            }
        }
    }

    /**
     * 支持的解压缩算法
     */
    private static final Map<String, Function<byte[], byte[]>> COMPRESS_MAP = ImmutableMap.of("gzip", GzipUtils::uncompress, "deflate", GzipUtils::deflateUnCompress, "br", GzipUtils::brotliUnCompress);

    /**
     * 解压resbody
     *
     * @param httpLog
     */
    private static void resBodyUncompress(HttpLog httpLog) {
        boolean validContentEncoding = Optional.ofNullable(httpLog.getResHeader())
                                               .filter(item -> Objects.nonNull(item.getContentEncoding()))
                                               .isPresent();
        String responseBody = httpLog.getResponseBody();
        if (StringUtils.isBlank(responseBody)) {
            return;
        }
        byte[] decodeRes = base64Decode(responseBody);
        if (decodeRes == null) {
            return;
        }
        if (validContentEncoding) {
            String contentEncoding = httpLog.getResHeader()
                                            .getContentEncoding();

            Optional.ofNullable(COMPRESS_MAP.get(contentEncoding))
                    .map(func -> {
                        byte[] apply = func.apply(decodeRes);
                        return Objects.nonNull(apply) ? apply : decodeRes;
                    })
                    .map(String::new)
                    .ifPresent(httpLog::setResponseBody);

        } else {
            httpLog.setResponseBody(new String(decodeRes));
        }
    }

    /**
     * base64解码
     *
     * @param str
     * @return
     */
    private static byte[] base64Decode(String str) {
        try {

            return Base64.getDecoder()
                         .decode(str);
        } catch (Exception e) {
            logger.error("base64 decode error data:" + str, e);
        }
        return null;
    }


    /**
     * 获取长度
     *
     * @param lengthBuffer
     * @param lenCount
     * @return
     */
    private static int getLength(char[] lengthBuffer, int lenCount) {
        String s = new String(lengthBuffer, 0, lenCount);
        return Integer.parseInt(s);
    }


}
