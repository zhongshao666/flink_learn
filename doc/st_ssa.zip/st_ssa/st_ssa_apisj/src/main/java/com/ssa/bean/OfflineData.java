package com.ssa.bean;

import lombok.Data;

/**
 * @author Administrator
 */
@Data
public class OfflineData {

    private String offlineTableType;
    private Long appId;
    private String clientIp;
    private String userName;
    private Long interfaceId;
    private String sensitiveLabelField;
    private Double userCountPercent;
    private Integer eventType;
    private String requestTime;
    private Integer appIdPos;
    private Integer clientIpPos;
    private Integer eventTypePos;
    private Integer requestTimePos;
    /**
     * 数据类别 01数审 02API
     */
    private String dataType;
    /**
     * 模型类别
     */
    private String modelType;
    /**
     * 黑名单类别
     */
    private String blackType;
    /**
     * 黑名单值
     */
    private String typeValue;

    public OfflineData() {
    }



    public String getOfflineTableType() {
        return offlineTableType;
    }

    public void setOfflineTableType(String offlineTableType) {
        this.offlineTableType = offlineTableType;
    }

    public Long getAppId() {
        return appId;
    }

    public void setAppId(Long appId) {
        this.appId = appId;
    }

    public String getClientIp() {
        return clientIp;
    }

    public void setClientIp(String clientIp) {
        this.clientIp = clientIp;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Long getInterfaceId() {
        return interfaceId;
    }

    public void setInterfaceId(Long interfaceId) {
        this.interfaceId = interfaceId;
    }

    public String getSensitiveLabelField() {
        return sensitiveLabelField;
    }

    public void setSensitiveLabelField(String sensitiveLabelField) {
        this.sensitiveLabelField = sensitiveLabelField;
    }

    public Double getUserCountPercent() {
        return userCountPercent;
    }

    public void setUserCountPercent(Double userCountPercent) {
        this.userCountPercent = userCountPercent;
    }

    public Integer getEventType() {
        return eventType;
    }

    public void setEventType(Integer eventType) {
        this.eventType = eventType;
    }

    public String getRequestTime() {
        return requestTime;
    }

    public void setRequestTime(String requestTime) {
        this.requestTime = requestTime;
    }

    public Integer getAppIdPos() {
        return appIdPos;
    }

    public void setAppIdPos(Integer appIdPos) {
        this.appIdPos = appIdPos;
    }

    public Integer getClientIpPos() {
        return clientIpPos;
    }

    public void setClientIpPos(Integer clientIpPos) {
        this.clientIpPos = clientIpPos;
    }

    public Integer getEventTypePos() {
        return eventTypePos;
    }

    public void setEventTypePos(Integer eventTypePos) {
        this.eventTypePos = eventTypePos;
    }

    public Integer getRequestTimePos() {
        return requestTimePos;
    }

    public void setRequestTimePos(Integer requestTimePos) {
        this.requestTimePos = requestTimePos;
    }
}
