package com.ssa.strategy;

import lombok.Data;

/**
 * @author Administrator
 */
@Data
public class DateTime {
    /**
     * min
     */
    private Long min;
    /**
     * max
     */
    private Long max;
}
