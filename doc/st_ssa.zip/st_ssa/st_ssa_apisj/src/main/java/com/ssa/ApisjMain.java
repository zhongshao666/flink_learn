package com.ssa;

import com.ssa.bean.AccountBean;
import com.ssa.bean.OfflineData;
import com.ssa.keys.HttpKeySelector;
import com.ssa.map.HighFrequencyAlarmKeySelector;
import com.ssa.map.VerticlKeySelector;
import com.ssa.source.ClickHouseZkSource;
import com.ssa.source.SecZookeeperSourceUpdate;
import com.ssa.strategy.StrategyConfig;
import com.ssa.strategy.StrategyMatch;
import com.ssa.utils.CuratorOperator;
import com.ssa.utils.KafkaSinkProp;
import com.ssa.utils.KafkaSourceProp;
import com.ssa.sensitive.to.HttpLog;
import com.ssa.transformation.*;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.tuple.Tuple5;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.api.GetDataBuilder;
import org.apache.flink.streaming.api.datastream.*;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer011;
import org.apache.flink.util.OutputTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.ivi.opensource.flinkclickhousesink.ClickHouseSink;
import ru.ivi.opensource.flinkclickhousesink.model.ClickHouseSinkConst;

import java.io.ByteArrayInputStream;
import java.util.Map;
import java.util.Properties;

public class ApisjMain {
    private static final Logger logger = LoggerFactory.getLogger(ApisjMain.class);

    public static OutputTag<HttpLog> apptags = new OutputTag<HttpLog>("apptags") {
    };
    public static OutputTag<HttpLog> interfacetags = new OutputTag<HttpLog>("interfacetags") {
    };
    public static OutputTag<AccountBean> usertags = new OutputTag<AccountBean>("usertags") {
    };
    public static OutputTag<String> sensitivedata = new OutputTag<String>("sensitivedata") {
    };
    public static OutputTag<String> sensitivelabels = new OutputTag<String>("sensitivelabels") {
    };
    public static OutputTag<HttpLog> nonUserEmpty = new OutputTag<HttpLog>("nonUserEmpty") {
    };
    public static OutputTag<HttpLog> loginStreamRound = new OutputTag<HttpLog>("loginStreamRound") {
    };
    public static OutputTag<HttpLog> blackList = new OutputTag<HttpLog>("blackList") {
    };
    public static OutputTag<HttpLog> whiteList = new OutputTag<HttpLog>("whiteList") {
    };
    public static OutputTag<HttpLog> nonSentitive = new OutputTag<HttpLog>("nonSentitive") {
    };
    public static OutputTag<HttpLog> nonAppid = new OutputTag<HttpLog>("nonAppid") {
    };
    public static OutputTag<Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig>> filterVertical = new OutputTag<Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig>>("filterVertical") {
    };


    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment streamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment();

        ParameterTool map = ParameterTool.fromArgs(args);
        Properties properties = new Properties();
        CuratorOperator mcto = new CuratorOperator(map.get("zkAddr"));
//        mcto = new CuratorOperator("192.168.24.73:2181");
        GetDataBuilder data = mcto.client.getData();
//        properties.load(new ByteArrayInputStream(data.forPath("/dbsj_audit/dbsj/job/config/riskflinkjob")));
        properties.load(new ByteArrayInputStream(data.forPath(map.get("zkPath"))));
        ParameterTool parameterTool = ParameterTool.fromMap((Map) properties);
        streamExecutionEnvironment.getConfig().setGlobalJobParameters(parameterTool);

        streamExecutionEnvironment.setParallelism(map.get("p") == null ? 5 : Integer.parseInt(parameterTool.get("p")));


        //设置重启策略
        if(parameterTool.getBoolean("flink.auto.restart.flag")) {
            streamExecutionEnvironment.setRestartStrategy(RestartStrategies.fixedDelayRestart(1000, Time.seconds(10)));
        }

        //创建datasource消费者 从kafka 消费数据
        FlinkKafkaConsumer011<String> stringFlinkKafkaConsumer011 = new FlinkKafkaConsumer011<>(parameterTool.get("kafka.topic.collect.http"), new SimpleStringSchema(), getKafkaSourceProp(parameterTool).getProp());


        //创建datasink生产者 将新的应用推送给rt_app_audit_appres
        FlinkKafkaProducer011<String> appFlinkSinkProducer = new FlinkKafkaProducer011<>(parameterTool.get("kafka.topic.new.app"), new SimpleStringSchema(), getKafkaSinkProp(parameterTool).getProp2());

        //创建datasink生产者，将新的用户推送给rt_app_audit_accountres
        FlinkKafkaProducer011<String> accountFlinkSinkProducer = new FlinkKafkaProducer011<>(parameterTool.get("kafka.topic.new.account"), new SimpleStringSchema(), getKafkaSinkProp(parameterTool).getProp2());

        //创建datasink生产者，将新的接口推送给rt_app_audit_interfaceres
        FlinkKafkaProducer011<String> interfaceFlinkSinkProducer = new FlinkKafkaProducer011<>(parameterTool.get("kafka.topic.new.interface"), new SimpleStringSchema(), getKafkaSinkProp(parameterTool).getProp2());

        //创建datasink生产者，将敏感数据标签列表推送给rt_app_audit_sensitivelabels
        FlinkKafkaProducer011<String> sensitiveLabelsFlinkSinkProducer = new FlinkKafkaProducer011<>(parameterTool.get("kafka.topic.new.sensitive.label"), new SimpleStringSchema(), getKafkaSinkProp(parameterTool).getProp2());

        MapStateDescriptor<String, Tuple4<Integer, Integer, String, String>> zookeeperconfig = new MapStateDescriptor<>("zookeeperconfig", BasicTypeInfo.STRING_TYPE_INFO, Types.TUPLE(BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO));

        DataStreamSource<Tuple4<Integer, Integer, String, String>> tuple2DataStreamSource = streamExecutionEnvironment.addSource(new SecZookeeperSourceUpdate())
                                                                                                                      .setParallelism(1);

        //zookeeper的配置广播流配置
        BroadcastStream<Tuple4<Integer, Integer, String, String>> broadcast = tuple2DataStreamSource.broadcast(zookeeperconfig);

        //从kafka获取数据
        DataStreamSource<String> stringDataStreamSourceKafka = streamExecutionEnvironment.addSource(stringFlinkKafkaConsumer011)
                                                                                         .setParallelism(16);

        SingleOutputStreamOperator<String> stringDataStreamSource = stringDataStreamSourceKafka.process(new TokenProcess(parameterTool.getInt("dataflow.maxsize")))
                                                                                               .name("数据令牌桶限流");
        //join 数据广播流
        BroadcastConnectedStream<String, Tuple4<Integer, Integer, String, String>> broadcastConnectedStream = stringDataStreamSource.connect(broadcast);
        //应用发现
        SingleOutputStreamOperator<HttpLog> appDiscovery = broadcastConnectedStream.process(new AppTagProcess())
                                                                                   .name("应用发现");
        //应用写入到kafka中
        appDiscovery.getSideOutput(apptags)
                    .map(new AppBean2StringMap())
                    .addSink(appFlinkSinkProducer)
                    .name("应用写入到kafka中");
        //http分组识别，发现新用户，用户打标，新接口标记
        SingleOutputStreamOperator<HttpLog> httpTagLater = appDiscovery.keyBy(new HttpKeySelector())
                                                                       .connect(broadcast)
                                                                       .process(new UserTagProcess())
                                                                       .name("http分组识别，发现新用户，用户打标，新接口标记");

        //新用户写入kafka中
        httpTagLater.getSideOutput(usertags)
                    .map(new AccountBean2StringMap())
                    .addSink(accountFlinkSinkProducer)
                    .name("新用户写入kafka中");

        //敏感数据识别标记
        SingleOutputStreamOperator<HttpLog> sensitiveAnallyLater = httpTagLater.connect(broadcast)
                                                                               .process(new SensitiveAnalysisProcess())
                                                                               .name("敏感数据识别标记");

        //处理黑白名单以及自定义规则
        Tuple3<SingleOutputStreamOperator<HttpLog>, SingleOutputStreamOperator<HttpLog>, SingleOutputStreamOperator<HttpLog>> dealRules = dealRules(sensitiveAnallyLater, broadcast);

        //处理策略事件
        SingleOutputStreamOperator<HttpLog> httpLogSingleOutputStream = dealStrategy(streamExecutionEnvironment, dealRules.f2, broadcast);

        //流合并
        DataStream<HttpLog> whiteListStreamSideOutput = dealRules.f0.getSideOutput(whiteList);
        DataStream<HttpLog> blackListStreamSideOutput = dealRules.f1.getSideOutput(blackList);
        DataStream<HttpLog> endUnionAllDataStream = httpLogSingleOutputStream.union(whiteListStreamSideOutput)
                                                                             .union(blackListStreamSideOutput);

        //数据分组写入kafka
        SingleOutputStreamOperator<String> lastAnallyLater = endUnionAllDataStream.process(new SensitiveBean2StringProcess())
                                                                                  .name("数据分组写入kafka");


        //将敏感数据标签写入kafka中
        sensitiveAnallyLater.getSideOutput(sensitivelabels)
                            .addSink(sensitiveLabelsFlinkSinkProducer)
                            .name("将敏感数据标签写入kafka中");

        //新接口写入kafka中
        sensitiveAnallyLater.getSideOutput(interfacetags)
                            .map(new InterfaceBean2StringMap())
                            .addSink(interfaceFlinkSinkProducer)
                            .name("新接口写入kafka中");

        lastAnallyLater.getSideOutput(sensitivedata)
                       .addSink(new ClickHouseSink(getHttpSensitiveRecordCkProp(parameterTool.get("clickHouse.Database"),parameterTool.get("clickHouse.Table.httpLog"),parameterTool)))
                       .name("http_sensitive_record clickhouse sink");
        lastAnallyLater.addSink(new ClickHouseSink(getHttpSensitiveRecordCkProp(parameterTool.get("clickHouse.Database"),parameterTool.get("clickHouse.Table.httpLog.sensitive"),parameterTool)))
                       .name("http_log clickhouse sink");

        //执行任务
        streamExecutionEnvironment.execute("api_audit_flink_job");
    }


    /**
     * 获取 kafka consumer配置
     *
     * @return
     */
    public static KafkaSourceProp getKafkaSourceProp(ParameterTool parameterTool) {
        KafkaSourceProp kafkaSourceProp = new KafkaSourceProp();
        kafkaSourceProp.setBOOTSTRAP_SERVERS_CONFIG(parameterTool.get("kafka.url"));
        return kafkaSourceProp;
    }

    /**
     * 获取 kafka producer配置
     *
     * @return
     */
    public static KafkaSinkProp getKafkaSinkProp(ParameterTool parameterTool) {
        KafkaSinkProp kafkaSinkProp = new KafkaSinkProp();
        kafkaSinkProp.setBOOTSTRAP_SERVERS_CONFIG(parameterTool.get("kafka.url"));

        return kafkaSinkProp;
    }


    /**
     *  ck config
     *
     * @return
     */
    private static Properties getHttpSensitiveRecordCkProp(String ckDatabase,String ckTable,ParameterTool parameterTool) {
        Properties properties = new Properties();
        properties.put(ClickHouseSinkConst.TARGET_TABLE_NAME, ckDatabase + "."+ ckTable);
        properties.put(ClickHouseSinkConst.MAX_BUFFER_SIZE, parameterTool.get("clickhouse.sink.max-buffer-size"));
        return properties;
    }

    /**
     * 处理黑白名单以及自定义策略
     *
     * @param sensitiveAnallyLater
     * @param broadcast
     * @return
     */
    private static Tuple3<SingleOutputStreamOperator<HttpLog>, SingleOutputStreamOperator<HttpLog>, SingleOutputStreamOperator<HttpLog>> dealRules(SingleOutputStreamOperator<HttpLog> sensitiveAnallyLater,
                                                                                                                                                   BroadcastStream<Tuple4<Integer, Integer, String, String>> broadcast) {

        //黑白名单过滤
        SingleOutputStreamOperator<HttpLog> whiteListStream = sensitiveAnallyLater
                                                                                  .connect(broadcast)
                                                                                  .process(new WhiteListProcess())
                                                                                  .name("白名单过滤");
        SingleOutputStreamOperator<HttpLog> blackListStream = whiteListStream
                                                                             .connect(broadcast)
                                                                             .process(new BlackListProcess())
                                                                             .name("黑名单过滤");

        //自定义规则
        SingleOutputStreamOperator<HttpLog> customRuleStream = blackListStream
                                                                              .connect(broadcast)
                                                                              .process(new CustomRuleProcess())
                                                                              .name("自定义规则");
        return new Tuple3(whiteListStream, blackListStream, customRuleStream);
    }

    /**
     * 处理策略类需求，如告警打标类
     *
     * @param streamExecutionEnvironment
     * @param customRuleStream
     * @param broadcast
     * @return
     */
    private static SingleOutputStreamOperator<HttpLog> dealStrategy(StreamExecutionEnvironment streamExecutionEnvironment,
                                                                    SingleOutputStreamOperator<HttpLog> customRuleStream,
                                                                    BroadcastStream<Tuple4<Integer, Integer, String, String>> broadcast) {
        //获取ck数据
        DataStreamSource<OfflineData> offlineDataDataStreamSource = streamExecutionEnvironment.addSource(new ClickHouseZkSource())
                                                                                              .setParallelism(1);


        //获取访问事件
        SingleOutputStreamOperator<HttpLog> eventTypeSingleOutputStreamOperator = customRuleStream.process(new EventTypeProcessFunction());

        //处理暴力登录破解
        SingleOutputStreamOperator<HttpLog> loginDataStreamStream = eventTypeSingleOutputStreamOperator.keyBy(HttpLog::getUserName)
                                                                                                       .connect(broadcast)
                                                                                                       .process(new LoginCrackProcess())
                                                                                                       .name("处理暴力登录破解");

        //无用户侧输出流
        SingleOutputStreamOperator<HttpLog> loginOutputDataStream = eventTypeSingleOutputStreamOperator.getSideOutput(loginStreamRound)
                                                                                                       .process(new OutputNonUserProcess());
        DataStream<HttpLog> httpLogDataStream = loginOutputDataStream.union(loginDataStreamStream);

        //默认高权限用户
        SingleOutputStreamOperator<HttpLog> highPrivilegeDataStream = httpLogDataStream.connect(broadcast)
                                                                                       .process(new HighPrivilegeProcess())
                                                                                       .name("默认高权限用户");

        //垂直越权访问
        SingleOutputStreamOperator<Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig>> tuple3SingleOutputStreamOperator = offlineDataDataStreamSource.connect(broadcast)
                                                                                                                                                                    .process(new VerticalConnectZkCoProcess())
                                                                                                                                                                    .name("垂直越权访问zk流合并");
        ConnectedStreams<HttpLog, Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig>> httpLogTuple5ConnectedStreams = highPrivilegeDataStream.keyBy(HttpLog::getAppId)
                                                                                                                                                            .connect(tuple3SingleOutputStreamOperator.keyBy(new VerticlKeySelector()));
        SingleOutputStreamOperator<HttpLog> verticalUnauthorizedDataStream = httpLogTuple5ConnectedStreams.process(new VerticalUnauthorizedProcess())
                                                                                                          .name("垂直越权访问");

        //过滤没敏感数据的httplog
        SingleOutputStreamOperator<HttpLog> hasSensitiveDataStream = verticalUnauthorizedDataStream.process(new FilterNonSensitiveProcess())
                                                                                                   .name("过滤没敏感数据的httplog");

        //敏感数据高频访问
        KeyedStream<HttpLog, Tuple2<Long, String>> highFrequencyAlarmKeyedStream = hasSensitiveDataStream.keyBy(new HighFrequencyAlarmKeySelector());
        SingleOutputStreamOperator<HttpLog> httpLogSingleOutputStream = highFrequencyAlarmKeyedStream.connect(broadcast)
                                                                                                     .process(new HighFrequencyAccessProcess())
                                                                                                     .name("敏感数据高频访问");

        //策略流全合并
        DataStream<HttpLog> unionNonUserDataStream = loginOutputDataStream.getSideOutput(nonUserEmpty)
                                                                          .union(httpLogSingleOutputStream);

        //处理敏感数据异常操作
        DataStream<Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig>> vertivalOutputDataStream = tuple3SingleOutputStreamOperator.getSideOutput(filterVertical);
        ConnectedStreams<HttpLog, Tuple5<OfflineData, Integer, Long, StrategyMatch, StrategyConfig>> logTuple3ConnectedStreams = unionNonUserDataStream.keyBy(HttpLog::getAppId)
                                                                                                                                                       .connect(vertivalOutputDataStream.keyBy(item -> item.f2));
        SingleOutputStreamOperator<HttpLog> abnormalDataStream = logTuple3ConnectedStreams.process(new SensitiveAbnormalProcess())
                                                                                          .name("处理敏感数据异常操作");

        DataStream<HttpLog> unionNonSensitiveDataStream = hasSensitiveDataStream.getSideOutput(nonSentitive)
                                                                                .union(abnormalDataStream);

        //处理非工作时间访问
        return unionNonSensitiveDataStream
                                          .connect(broadcast)
                                          .process(new NonWorkingTimeProcess())
                                          .name("非工作时间访问");
    }
}
