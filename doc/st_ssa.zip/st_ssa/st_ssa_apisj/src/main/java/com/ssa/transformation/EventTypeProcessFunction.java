package com.ssa.transformation;

import com.ssa.ApisjMain;
import com.ssa.sensitive.to.HttpLog;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Administrator
 * @role 获取用户登录事件processfuntion
 */
public class EventTypeProcessFunction extends ProcessFunction<HttpLog, HttpLog> {
    private static final Logger logger = LoggerFactory.getLogger(EventTypeProcessFunction.class);

    @Override
    public void processElement(HttpLog value, Context ctx, Collector<HttpLog> out) throws Exception {
        if (StringUtils.isNotBlank(value.getUserName()) && value.getEventType() != null && value.getEventType() == 1) {
            logger.info("http log logid: {},eventType: {}", value.getLogId(), value.getEventType());
            out.collect(value);
        } else {
            ctx.output(ApisjMain.loginStreamRound, value);
            logger.info("http log output logid: {},eventType: {}", value.getLogId(), value.getEventType());
        }
    }
}
