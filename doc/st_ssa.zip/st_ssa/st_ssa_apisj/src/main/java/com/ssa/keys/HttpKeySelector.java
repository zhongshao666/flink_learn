package com.ssa.keys;


import com.ssa.sensitive.to.HttpLog;
import com.ssa.sensitive.util.IdWorker;
import org.apache.flink.api.java.functions.KeySelector;

public class HttpKeySelector implements KeySelector<HttpLog,String> {

    @Override
    public String getKey(HttpLog o) throws Exception {
        if(o.getSessionId()==null){
            o.setSessionId(String.valueOf(IdWorker.getInstance().nextId()));
        }
        return o.getSessionId();
    }
}
