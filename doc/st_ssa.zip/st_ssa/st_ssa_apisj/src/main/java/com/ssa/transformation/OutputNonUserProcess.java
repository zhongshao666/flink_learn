package com.ssa.transformation;

import com.ssa.ApisjMain;
import com.ssa.sensitive.to.HttpLog;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;

/**
 * @author Administrator
 * @role 获取用户非空log
 */
public class OutputNonUserProcess extends ProcessFunction<HttpLog,HttpLog> {
    @Override
    public void processElement(HttpLog value, Context ctx, Collector<HttpLog> out) throws Exception {
        if (StringUtils.isNotBlank(value.getUserName())){
            out.collect(value);
        }else {
            ctx.output(ApisjMain.nonUserEmpty,value);
        }
    }
}