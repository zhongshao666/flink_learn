package com.ssa.transformation;


import com.ssa.ApisjMain;
import com.ssa.bean.OfflineData;
import com.ssa.sensitive.constants.CommonConstants;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.CoProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class ZkCkOutputProcess extends CoProcessFunction<OfflineData, Tuple4<Integer, Integer, String, String>, Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> {
    Tuple4<Integer, Integer, String, String> tuple4;
    private  final Logger logger = LoggerFactory.getLogger(ZkCkOutputProcess.class);
    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);

        tuple4  = new Tuple4<>(0,0,null,null);
    }

    @Override
    public void processElement1(OfflineData value, Context ctx, Collector<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> collector) throws Exception {

        String offlineTableType = value.getOfflineTableType();
        if (CommonConstants.OfflineTableType.MACHINE_OFFLINE_TABLE.getVal().equals(offlineTableType)){
            logger.info("processElement11111111111111"+value);
            ctx.output(ApisjMain.machineOutputTag,new Tuple2<>(value,tuple4));
        }
    }

    @Override
    public void processElement2(Tuple4<Integer, Integer, String, String> value, Context ctx, Collector<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> collector) throws Exception {

        if (value.f0 == CommonConstants.ZkDataType.MACHINE_REQUEST.getVal()) {
            logger.info("processElement222222"+value);
            ctx.output(ApisjMain.machineOutputTag,new Tuple2<>(null,value));
        }
    }
}
