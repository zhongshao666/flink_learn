package com.ssa.source;


import com.ssa.sensitive.constants.CommonConstants;
import com.ssa.utils.CuratorOperator;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.CuratorFramework;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.recipes.cache.*;
import org.apache.flink.streaming.api.functions.source.RichSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SecZookeeperSourceUpdate extends RichSourceFunction<Tuple4<Integer, Integer, String, String>> {

    private static final Logger logger = LoggerFactory.getLogger(SecZookeeperSourceUpdate.class);

    CuratorOperator cto = null;
    // tuple4<策略类型，增删改，zk路径，内容>
    SourceContext<Tuple4<Integer, Integer, String, String>> sourceContextGlobal = null;
    private ParameterTool parameterTool;



    @Override
    public void open(Configuration parameters) throws Exception {
        System.setProperty("zookeeper.sasl.client", "false");
        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig()
                .getGlobalJobParameters();
        cto = new CuratorOperator(parameterTool.get("zookeeper.url"));
    }

    private void nodeListen(NodeCache nodeCache, int zkType, String path) throws Exception {
        nodeCache.start(true);
        if (nodeCache.getCurrentData() != null) {
            sourceContextGlobal.collect(new Tuple4<>(zkType, CommonConstants.OperateType.UPDATE.getVal(), path, new String(nodeCache.getCurrentData().getData())));
        }

        nodeCache.getListenable().addListener(new NodeCacheListener() {
            @Override
            public void nodeChanged() throws Exception {
                if (nodeCache.getCurrentData() != null) {
                    sourceContextGlobal.collect(new Tuple4<>(zkType, CommonConstants.OperateType.UPDATE.getVal(), path, new String(nodeCache.getCurrentData().getData())));
                }
            }
        });
    }

    private void childrenListen(PathChildrenCache pathChildrenCache, int type, String nodepath) throws Exception {
        pathChildrenCache.start(PathChildrenCache.StartMode.POST_INITIALIZED_EVENT);
        pathChildrenCache.getListenable().addListener(new PathChildrenCacheListener() {


            @Override
            public void childEvent(CuratorFramework curatorFramework, PathChildrenCacheEvent event) throws Exception {
                if (event.getType().equals(PathChildrenCacheEvent.Type.INITIALIZED)) {
                    logger.info("初始化zookeeper监听完成.........");
                } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_ADDED)) {
                    String path = event.getData().getPath();
                    if (path.startsWith(nodepath)) {
                        sourceContextGlobal.collect(new Tuple4<>(type, CommonConstants.OperateType.ADD.getVal(), path, new String(event.getData().getData())));
                        logger.info("create " + path + "----" + new String(event.getData().getData()));
                    }
                } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_REMOVED)) {
                    sourceContextGlobal.collect(new Tuple4<>(type, CommonConstants.OperateType.DELETE.getVal(), event.getData().getPath(), new String(event.getData().getData())));
                    logger.info("remove " + event.getData().getPath() + "----" + new String(event.getData().getData()));
                } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_UPDATED)) {
                    sourceContextGlobal.collect(new Tuple4<>(type, CommonConstants.OperateType.UPDATE.getVal(), event.getData().getPath(), new String(event.getData().getData())));
                    logger.info("update " + event.getData().getPath());
                }
            }
        });

    }

    @Override
    public void run(SourceContext<Tuple4<Integer, Integer, String, String>> sourceContext) throws Exception {
        sourceContextGlobal = sourceContext;


        final NodeCache machine_request = new NodeCache(cto.client,parameterTool.get("zookeeper.model.apisj.machine.path"));


        //机器请求行为配置
        nodeListen(machine_request,CommonConstants.ZkDataType.MACHINE_REQUEST.getVal(),parameterTool.get("zookeeper.model.apisj.machine.path"));

        //对zookeeper的接口的路径监听

        //childrenListen(childrenRisk, CommonConstants.ZkDataType.RISK_TYPE.getVal(), parameterTool.get("zookeeper.risk.data.path"));


        while (true) {
            Thread.sleep(50000);
        }
    }

    @Override
    public void cancel() {

    }

}
