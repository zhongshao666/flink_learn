package com.ssa.source;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ssa.ApisjMain;
import com.ssa.bean.OfflineData;
import com.ssa.sensitive.constants.CommonConstants;
import com.ssa.utils.CuratorOperator;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.CuratorFramework;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.recipes.cache.PathChildrenCache;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.recipes.cache.PathChildrenCacheEvent;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.recipes.cache.PathChildrenCacheListener;
import org.apache.flink.streaming.api.functions.source.RichSourceFunction;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.Optional;

import static com.ssa.sensitive.util.SystemConfig.*;

/**
 * @author Administrator
 * @sole ClickHouseZk离线数据源
 */
public class ClickHouseZkSource extends RichSourceFunction<OfflineData> {

    private static final Logger logger = LoggerFactory.getLogger(ClickHouseZkSource.class);
    CuratorOperator curatorOperator = null;
    SourceContext<OfflineData> sourceContext = null;
    ParameterTool parameterTool = null;

    @Override
    public void open(Configuration parameters) throws Exception {
        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig()
                .getGlobalJobParameters();
        ApisjMain.setConfig(parameterTool);
        curatorOperator = new CuratorOperator(parameterTool.get("zookeeper.url"));
        Class.forName("ru.yandex.clickhouse.ClickHouseDriver");
    }

    @Override
    public void run(SourceContext<OfflineData> ctx) throws Exception {
        sourceContext = ctx;
        String nodePath = parameterTool.get("zookeeper.model.apisj.machine.listen.path");
        String childPath = nodePath.substring(0, nodePath.lastIndexOf("/"));
        final PathChildrenCache pathChildrenCacheOffline = new PathChildrenCache(curatorOperator.client, childPath, true);

        childrenListen(pathChildrenCacheOffline);

        while (true) {
            Thread.sleep(10000);
        }
    }

    @Override
    public void cancel() {

    }

    public void childrenListen(PathChildrenCache pathChildrenCache) throws Exception {
        pathChildrenCache.start(PathChildrenCache.StartMode.POST_INITIALIZED_EVENT);
        pathChildrenCache.getListenable().addListener(new PathChildrenCacheListener() {
            @Override
            public void childEvent(CuratorFramework curatorFramework, PathChildrenCacheEvent event) throws Exception {

                if (event.getType().equals(PathChildrenCacheEvent.Type.INITIALIZED)) {
                    logger.info("初始化zookeeper监听完成.........");
                } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_ADDED)) {
                    jdbcConnectChilld(event);
                } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_REMOVED)) {
                } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_UPDATED)) {
                    jdbcConnectChilld(event);
                }
            }
        });
    }    public void jdbcConnectChilld(PathChildrenCacheEvent event) {
        String zkData = new String(event.getData().getData());
        JSONObject obj = JSON.parseObject(zkData);

        String table = obj.getString("tableName");

        if (Optional.ofNullable(obj.getInteger("status")).orElse(0) == 1) {
            String address = "jdbc:clickhouse://" + parameterTool.get("clickhouse.access.hosts") + "/" + parameterTool.get("clickhouse.dm.database");

            try (Connection connection = DriverManager.getConnection(address, parameterTool.get("clickhouse.access.user"), parameterTool.get("clickhouse.access.password"));

                 Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery("select * from " + table)) {
                while (resultSet.next()) {
                    OfflineData offlineData = new OfflineData();

                    offlineData.setOfflineTableType(table);
                    if (CommonConstants.OfflineTableType.MACHINE_OFFLINE_TABLE.getVal().equals(table)) {
                        setModelDown(resultSet, offlineData);
                    }
                    sourceContext.collect(offlineData);
                }
            } catch (Exception e) {
                logger.error("query error", e);
            }
        }
    }

    public void setModelDown( ResultSet resultSet,OfflineData offlineData) throws SQLException {
        offlineData.setClientMac(resultSet.getString("client_mac"));
        offlineData.setRarity(resultSet.getDouble("rarity"));

    }

}
