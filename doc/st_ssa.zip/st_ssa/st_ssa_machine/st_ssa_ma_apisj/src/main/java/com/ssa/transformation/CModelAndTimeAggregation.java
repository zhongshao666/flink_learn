package com.ssa.transformation;

import com.ssa.sensitive.to.HttpLog;
import org.apache.flink.api.common.functions.AggregateFunction;
import org.apache.flink.api.java.tuple.Tuple6;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashSet;

/**
 *  @author : cjj
 *  @Date ： 2021/4/27
 *  @Time :
 *  @role ：
 */
public class CModelAndTimeAggregation implements AggregateFunction<HttpLog, Tuple6<ArrayList<Long>,ArrayList<Long>, HashSet<String>, HashSet<String>, HashSet<String>, ArrayList<HttpLog>>, Tuple6<ArrayList<Long>, Integer, Integer, Integer, Integer, ArrayList<HttpLog>>> {
    private  final Logger logger = LoggerFactory.getLogger(CModelAndTimeAggregation.class);

    //初始化缓存
    @Override
    public Tuple6<ArrayList<Long>, ArrayList<Long>, HashSet<String>, HashSet<String>, HashSet<String>, ArrayList<HttpLog>> createAccumulator() {

        return new Tuple6<ArrayList<Long>, ArrayList<Long>, HashSet<String>, HashSet<String>, HashSet<String>, ArrayList<HttpLog>>(new ArrayList<>(), new ArrayList<>(), new HashSet<>(), new HashSet<>(), new HashSet<>(), new ArrayList<>());
    }

    @Override
    public Tuple6<ArrayList<Long>, ArrayList<Long>, HashSet<String>, HashSet<String>, HashSet<String>, ArrayList<HttpLog>> add(HttpLog httpLog, Tuple6<ArrayList<Long>, ArrayList<Long>, HashSet<String>, HashSet<String>, HashSet<String>, ArrayList<HttpLog>> accumulator) {
        logger.info("agg 数据输入");

        Long requestTime = httpLog.getRequestTime();
        accumulator.f0.add(requestTime);

        Long logId = httpLog.getLogId();
        accumulator.f1.add(logId);

        String clientIp = httpLog.getClientIp();
        accumulator.f2.add(clientIp);

        String clientPort = httpLog.getClientPort();
        accumulator.f3.add(clientPort);

        String serverPort = httpLog.getServerPort();
        accumulator.f4.add(serverPort);

        accumulator.f5.add(httpLog);

        return accumulator;
    }

    @Override
    public Tuple6<ArrayList<Long>, Integer, Integer, Integer, Integer, ArrayList<HttpLog>> getResult(Tuple6<ArrayList<Long>,ArrayList<Long>, HashSet<String>, HashSet<String>, HashSet<String>, ArrayList<HttpLog>> accumulator) {

        ArrayList<Long> timeList = accumulator.f0;
        int logIdCount = accumulator.f1.size();
        int clientIpCount = accumulator.f2.size();
        int clientPortCount = accumulator.f3.size();
        int serverPortCount = accumulator.f4.size();
        ArrayList<HttpLog> logList = accumulator.f5;


        return new Tuple6<ArrayList<Long>, Integer, Integer, Integer, Integer, ArrayList<HttpLog>>(timeList, logIdCount,clientIpCount, clientPortCount, serverPortCount, logList);


    }

    @Override
    public Tuple6<ArrayList<Long>,ArrayList<Long>, HashSet<String>, HashSet<String>, HashSet<String>, ArrayList<HttpLog>> merge(Tuple6<ArrayList<Long>, ArrayList<Long>, HashSet<String>, HashSet<String>, HashSet<String>, ArrayList<HttpLog>> a, Tuple6<ArrayList<Long>, ArrayList<Long>, HashSet<String>, HashSet<String>, HashSet<String>, ArrayList<HttpLog>> acc1) {
        return null;
    }


}

