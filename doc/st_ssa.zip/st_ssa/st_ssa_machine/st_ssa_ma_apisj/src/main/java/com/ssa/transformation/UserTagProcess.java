package com.ssa.transformation;

import com.alibaba.fastjson.JSON;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.collect.LinkedHashMultimap;
import com.google.common.collect.Maps;
import com.google.common.collect.SetMultimap;
import com.ssa.ApisjMain;
import com.ssa.bean.AccountBean;
import com.ssa.bean.InterfaceBean;
import com.ssa.sensitive.constants.CommonConstants;
import com.ssa.sensitive.match.RequestBodyParse;
import com.ssa.sensitive.to.HttpLog;
import com.ssa.sensitive.urlmatch.UrlMatch;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.KeyedBroadcastProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

/**
 * @author admin
 */
public class UserTagProcess extends KeyedBroadcastProcessFunction<String, HttpLog, Tuple4<Integer, Integer, String, String>, HttpLog> {

    private static final Logger logger = LoggerFactory.getLogger(UserTagProcess.class);

    Map<Long, InterfaceBean> interfaceBeanMap;
    Cache<String, String> sessionNameCache;
    SetMultimap<Long,String> userNameCache;
    Map<Long, UrlMatch> urlMatchMap;
    RequestBodyParse requestBodyParse;

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        requestBodyParse = new RequestBodyParse();
        sessionNameCache = CacheBuilder.newBuilder()
                .maximumSize(100000)
                .expireAfterWrite(2, TimeUnit.HOURS)
                .build();
        urlMatchMap = Maps.newHashMap();
        userNameCache = LinkedHashMultimap.create();
        interfaceBeanMap = Maps.newHashMap();
    }

    @Override
    public void processElement(HttpLog httplog, ReadOnlyContext readOnlyContext, Collector<HttpLog> collector) throws Exception {
        Long interfaceId = Optional.ofNullable(urlMatchMap.get(httplog.getAppId()))
                .map(item -> item.match(httplog.getInterfaceUrl()))
                .orElse(null);

        if (Objects.nonNull(interfaceId)) {
            logger.info("http log logId:{},interface id:{}", httplog.getLogId(), interfaceId);
            httplog.setInterfaceId(interfaceId);
            InterfaceBean interfaceBean = interfaceBeanMap.get(interfaceId);

            if (!CommonConstants.Status.ENABLE.getVal()
                    .equals(interfaceBean.getEnable())) {
                logger.info("http log logId:{},interface id:{},interface not enable", httplog.getLogId(), interfaceId);
                return;
            }

            Optional.ofNullable(interfaceBean.getUrl())
                    .ifPresent(httplog::setInterfaceUrl);
            Optional.ofNullable(interfaceBean.getName())
                    .ifPresent(httplog::setInterfaceName);
            Optional.ofNullable(interfaceBean.getDomain())
                    .ifPresent(httplog::setAppDomain);

            if (Optional.ofNullable(interfaceBean.getTypes())
                    .filter(list -> list.contains(CommonConstants.InterfaceType.LOGIN.getVal()))
                    .isPresent()) {
                // 打标为登入接口
                httplog.setEventType(CommonConstants.EventType.LOGIN.getVal());
                // 获取username，写入到本地缓存（这里需要再做处理）
                handleUserName(httplog, readOnlyContext, interfaceId, interfaceBean);
            } else {
                httplog.setUserName(sessionNameCache.getIfPresent(httplog.getSessionId()));
                httplog.setEventType(CommonConstants.EventType.ACCESS.getVal());
            }
        } else {
            logger.info("http log logId:{}  can not find interface will add,requestUrl: {}", httplog.getLogId(), httplog.getRequestUrl());
            //新的接口发现
            httplog.setIsnewInterface(true);
        }

        //数据返回到下一个流
        collector.collect(httplog);
    }

    /**
     * 处理获取用户名,并将新用户发送给管理段
     * @param httplog
     * @param readOnlyContext
     * @param interfaceId
     * @param interfaceBean
     */
    private void handleUserName(HttpLog httplog, ReadOnlyContext readOnlyContext, Long interfaceId, InterfaceBean interfaceBean) {
        String username = getUserName(interfaceBean, httplog);
        logger.info("http log logId:{},interface id:{},parse login username is:{}", httplog.getLogId(), interfaceId, username);
        if (username != null) {
            httplog.setUserName(username);
            sessionNameCache.put(httplog.getSessionId(), username);
            //如果username不在用户缓存里，则打标为新的用户
            if (!userNameCache.get(httplog.getAppId()).contains(username)) {
                httplog.setIsnewUser(true);
                AccountBean accountBean = new AccountBean();
                accountBean.setPwd(getPassWord(interfaceBean, httplog));
                accountBean.setAccount(username);
                accountBean.setAppId(httplog.getAppId());
                accountBean.setInterfaceId(interfaceBean.getId());
                accountBean.setAccountParam(interfaceBean.getAccountParam());
                accountBean.setPwdParam(interfaceBean.getPwdParam());
                accountBean.setAccountLocation(interfaceBean.getAccountLocation());
                accountBean.setMethod(interfaceBean.getMethod());
                readOnlyContext.output(ApisjMain.usertags, accountBean);
                userNameCache.put(httplog.getAppId(),username);
            }
        }
    }

    /**
     * 获取用户名
     *
     * @param interfaceBean
     * @param httpLog
     * @return
     */
    private String getUserName(InterfaceBean interfaceBean, HttpLog httpLog) {
        if (CommonConstants.AccountLocation.REQ_BODY.getVal()
                .equals(interfaceBean.getAccountLocation())) {
            Map<String, String> map = requestBodyParse.parseMapData(httpLog.getRequestBody());
            return map.get(interfaceBean.getAccountParam());
        }

        if (CommonConstants.AccountLocation.REQ_HEADER.getVal()
                .equals(interfaceBean.getAccountLocation())) {
            Map<String, String> map = httpLog.getReqHeader()
                    .getSourceMap();
            return map.get(interfaceBean.getAccountParam());
        }
        return null;
    }

    private String getPassWord(InterfaceBean interfaceBean, HttpLog httpLog) {
        if (CommonConstants.AccountLocation.REQ_BODY.getVal()
                .equals(interfaceBean.getPwdLocation())) {
            Map<String, String> map = requestBodyParse.parseMapData(httpLog.getRequestBody());
            return map.get(interfaceBean.getPwdParam());
        }

        if (CommonConstants.AccountLocation.REQ_HEADER.getVal()
                .equals(interfaceBean.getPwdLocation())) {
            Map<String, String> map = httpLog.getReqHeader()
                    .getSourceMap();
            return map.get(interfaceBean.getPwdParam());
        }
        return null;
    }

    @Override
    public void processBroadcastElement(Tuple4<Integer, Integer, String, String> stringStringTuple4, Context context, Collector<HttpLog> collector) throws Exception {
        if (stringStringTuple4.f0 == CommonConstants.ZkDataType.INTERFACE_TYPE.getVal()) {
            String value = stringStringTuple4.f3;


            InterfaceBean interfaceBean = JSON.parseObject(value, InterfaceBean.class);


            if (stringStringTuple4.f1 == CommonConstants.OperateType.ADD.getVal()||stringStringTuple4.f1 == CommonConstants.OperateType.UPDATE.getVal()) {

                interfaceBeanMap.put(interfaceBean.getId(), interfaceBean);
                urlMatchOperate(interfaceBean, true);

            }else{
                urlMatchOperate(interfaceBean, false);
                interfaceBeanMap.remove(interfaceBean.getId());
            }

        }
    }

    /**
     * urlmatch 操作
     *
     * @param interfaceBean
     * @param opFlag
     */
    private void urlMatchOperate(InterfaceBean interfaceBean, boolean opFlag) {
        if (interfaceBean.getUrl() == null || interfaceBean.getId() == null || interfaceBean.getAppId() == null) {
            System.out.println("interface error data:" + JSON.toJSONString(interfaceBean));
            return;
        }
        if (opFlag) {
            if (!urlMatchMap.containsKey(interfaceBean.getAppId())) {
                urlMatchMap.put(interfaceBean.getAppId(), new UrlMatch());
            }
            UrlMatch urlMatch = urlMatchMap.get(interfaceBean.getAppId());
            urlMatch.addInterface(interfaceBean.getUrl(), interfaceBean.getId());

        } else {
            UrlMatch urlMatch = urlMatchMap.get(interfaceBean.getAppId());
            urlMatch.removeInterface(interfaceBean.getId());
        }
    }
}
