package com.ssa.transformation;


import com.ssa.ApisjMain;
import com.ssa.sensitive.to.CkHttpSensitiveRecord;
import com.ssa.sensitive.to.HttpHeader;
import com.ssa.sensitive.to.HttpLog;
import com.ssa.sensitive.util.CsvUtils;
import org.apache.commons.compress.utils.Lists;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.ssa.sensitive.constants.CommonConstants.REQUEST_TIME_FORMAT;

/**
 * @author qsj
 */
public class SensitiveBean2StringProcess extends ProcessFunction<HttpLog, String> {
    private static final Logger logger = LoggerFactory.getLogger(SensitiveBean2StringProcess.class);

    @Override
    public void processElement(HttpLog httpLog, Context context, Collector<String> collector) throws Exception {
        logger.info("insert data logId:{},AppId:{},interface id:{}", httpLog.getLogId(), httpLog.getAppId(), httpLog.getInterfaceId());
        String httpLogCsv = getCkHttpCsvLine(httpLog);
        collector.collect(httpLogCsv);

        List<String> sensitiveCsvLines = getCkHttpSensitiveCsvLines(httpLog);
        Optional.ofNullable(sensitiveCsvLines)
                .ifPresent(list -> list.forEach(sensitive -> context.output(ApisjMain.sensitivedata, sensitive)));
    }


    /**
     * 获取httpLog csv format
     *
     * @return
     */
    public String getCkHttpCsvLine(HttpLog httpLog) {
        List<String> genList = getBaseHttpLogList(httpLog);

        reqHeaderHandler(httpLog.getReqHeader(), genList);
        resHeaderHandler(httpLog.getResHeader(), genList);

        return CsvUtils.convertToCkCsvFormatByList(genList);
    }

    /**
     * 获取基础http log 列表
     *
     * @param httpLog
     * @return
     */
    private List<String> getBaseHttpLogList(HttpLog httpLog) {
        List<String> genList = Lists.newArrayList();
        genList.add(Optional.ofNullable(httpLog.getLogId())
                .map(String::valueOf)
                .orElse("0"));
        genList.add(Optional.ofNullable(httpLog.getRequestTime())
                .map(time -> DateFormatUtils.format(time, REQUEST_TIME_FORMAT))
                .orElse(null));
        genList.add(Optional.ofNullable(httpLog.getCostTime())
                .map(String::valueOf)
                .orElse("0"));
        genList.add(httpLog.getUserName());
        genList.add(httpLog.getSessionId());
        genList.add(httpLog.getHostName());
        genList.add(httpLog.getRequestUrl());
        genList.add(httpLog.getSensitiveLabelField());
        genList.add(httpLog.getSensitiveLevel());
        genList.add(httpLog.getClientMac());
        genList.add(httpLog.getClientIp());
        genList.add(httpLog.getClientPort());
        genList.add(httpLog.getServerMac());
        genList.add(httpLog.getServerIp());
        genList.add(httpLog.getServerPort());
        //referrer_policy
        genList.add("");
        genList.add(httpLog.getRequestHeader());
        genList.add(httpLog.getRequestBody());
        genList.add(httpLog.getResponseHeader());
        genList.add(httpLog.getResponseBody());
        genList.add(httpLog.getHttpVersion());
        genList.add(httpLog.getHttpMethod());
        genList.add(Optional.ofNullable(httpLog.getStatusCode())
                .map(String::valueOf)
                .orElse("409"));
        genList.add(Optional.ofNullable(httpLog.getRequestStatus())
                .map(String::valueOf)
                .orElse("4"));
        //remote_address
        genList.add("");
        genList.add(Optional.ofNullable(httpLog.getCreateTime())
                .map(String::valueOf)
                .orElse(null));
        genList.add(Optional.ofNullable(httpLog.getHasSensitive())
                .filter(item -> item)
                .map(item -> "1")
                .orElse("0"));
        //riskType
        genList.add(httpLog.getRiskType());
        //riskLevel
        genList.add(Optional.ofNullable(httpLog.getRiskLevel())
                .map(String::valueOf)
                .orElse("2"));

        genList.add(Optional.ofNullable(httpLog.getEventType())
                .map(String::valueOf)
                .orElse("2"));
        //strategy_name
        genList.add(httpLog.getStrategyName());
        //strategy_id
        genList.add(httpLog.getStrategyId());
        genList.add(Optional.ofNullable(httpLog.getAppId())
                .map(String::valueOf)
                .orElse("0"));
        genList.add(httpLog.getAppName());
        genList.add(httpLog.getAppDomain());
        genList.add(Optional.ofNullable(httpLog.getInterfaceId())
                .map(String::valueOf)
                .orElse("0"));
        genList.add(httpLog.getInterfaceName());
        genList.add(httpLog.getInterfaceUrl());
        genList.add(httpLog.getClientTool());
        //reviewed
        genList.add("0");
        //reviewed_comment
        genList.add("");
        genList.add(Optional.ofNullable(httpLog.getHttpTraffic())
                .map(String::valueOf)
                .orElse("0"));
        genList.add(Optional.ofNullable(httpLog.getIsModelLabel())
                .map(String::valueOf)
                .orElse("0"));
        return genList;
    }

    /**
     * 响应头处理
     *
     * @param genList
     */
    public void resHeaderHandler(HttpHeader resHeader, List<String> genList) {
        if (resHeader != null) {
            genList.add(resHeader.getAcceptRanges());
            genList.add(resHeader.getCacheControl());
            genList.add(resHeader.getContentSecurityPolicy());
            genList.add(resHeader.getContentLength());
            genList.add(resHeader.getContentType());
            genList.add(resHeader.getDate());
            genList.add(resHeader.getEtag());
            genList.add(resHeader.getServer());
            genList.add(resHeader.getExpires());
            genList.add(resHeader.getLastModified());
            genList.add(resHeader.getPragma());
            genList.add(resHeader.getSetCookie());
            genList.add(resHeader.getStrictTransportSecurity());
            genList.add(resHeader.getTransferEncoding());
            genList.add(resHeader.getXcontentTypeOptions());
            genList.add(resHeader.getFrameOptions());
            genList.add(resHeader.getXxssProtection());
        } else {
            addEmptyItem(genList, 17);
        }
    }


    /**
     * 请求头处理
     *
     * @param genList
     */
    public void reqHeaderHandler(HttpHeader reqHeader, List<String> genList) {
        if (reqHeader != null) {
            genList.add(reqHeader.getAccept());
            genList.add(reqHeader.getAcceptEncoding());
            genList.add(reqHeader.getAcceptLanguage());
            genList.add(reqHeader.getCacheControl());
            genList.add(reqHeader.getConnection());
            genList.add(reqHeader.getContentType());
            genList.add(reqHeader.getContentLength());
            genList.add(reqHeader.getTransferEncoding());
            genList.add(reqHeader.getCookie());
            genList.add(reqHeader.getOrigin());
            genList.add(reqHeader.getHost());
            genList.add(reqHeader.getPragma());
            genList.add(reqHeader.getReferer());
            genList.add(reqHeader.getSecFetchDest());
            genList.add(reqHeader.getSecFetchMode());
            genList.add(reqHeader.getSecFetchSite());
            genList.add(reqHeader.getSecFetchUser());
            genList.add(reqHeader.getToken());
            genList.add(reqHeader.getUserAgent());
            genList.add(reqHeader.getxRequestedWith());
            genList.add(reqHeader.getxClientData());
        } else {
            addEmptyItem(genList, 21);
        }
    }

    /**
     * 添加指定次数空元素
     *
     * @param genList
     * @param count
     */
    private void addEmptyItem(List<String> genList, int count) {
        for (int i = 0; i < count; i++) {
            genList.add("");
        }
    }

    /**
     * 获取敏感数据csvLines
     *
     * @return
     */
    public List<String> getCkHttpSensitiveCsvLines(HttpLog httpLog) {
        return Optional.ofNullable(httpLog.getHasSensitive())
                .filter(flag -> flag)
                .map(flag -> httpLog.getSensitiveRecords()
                        .stream()
                        .map(this::processHttpSensitiveRecordCsv)
                        .collect(Collectors.toList()))
                .orElse(null);
    }

    /**
     * 敏感数据转csv
     *
     * @param record
     * @return
     */
    private String processHttpSensitiveRecordCsv(CkHttpSensitiveRecord record) {
        List<String> genList = getHttpSensitiveCustomProp(record);
        getHttpSensitiveExtraProp(record, genList);

        return CsvUtils.convertToCkCsvFormatByList(genList);
    }

    /**
     * 获取内置敏感数据
     *
     * @param record
     * @return
     */
    private List<String> getHttpSensitiveCustomProp(CkHttpSensitiveRecord record) {
        List<String> genList = Lists.newArrayList();
        genList.add(Optional.ofNullable(record.getSensitiveId())
                .map(String::valueOf)
                .orElse(null));
        genList.add(Optional.ofNullable(record.getLogId())
                .map(String::valueOf)
                .orElse(null));
        genList.add(Optional.ofNullable(record.getAppId())
                .map(String::valueOf)
                .orElse(null));
        genList.add(Optional.ofNullable(record.getRequestTime())
                .map(time -> DateFormatUtils.format(time, REQUEST_TIME_FORMAT))
                .orElse(null));
        genList.add(Optional.ofNullable(record.getCreateTime())
                .map(String::valueOf)
                .orElse(null));
        genList.add(record.getCellPhone());
        genList.add(Optional.ofNullable(record.getInterfaceId())
                .map(String::valueOf)
                .orElse(null));
        genList.add(record.getBankAccount());
        genList.add(record.getBusinessName());
        genList.add(record.getBusNumber());
        genList.add(record.getChinaName());
        genList.add(record.getChineseAddress());
        genList.add(record.getEmail());
        genList.add(record.getIdCard());
        genList.add(record.getMtpForHkmacao());
        genList.add(record.getMtpForTaiwai());
        genList.add(record.getOfficerNumber());
        genList.add(record.getPassportCode());
        genList.add(record.getPhoneNumber());
        genList.add(record.getPostCode());
        genList.add(record.getThreeInOne());
        genList.add(record.getVicNumber());
        genList.add(Optional.ofNullable(record.getSensitiveLocation())
                .map(String::valueOf)
                .orElse(null));
        return genList;
    }

    /**
     * 获取自定义敏感属性
     *
     * @param record
     * @param genList
     */
    private void getHttpSensitiveExtraProp(CkHttpSensitiveRecord record, List<String> genList) {
        genList.add(record.getCode_201());
        genList.add(record.getCode_202());
        genList.add(record.getCode_203());
        genList.add(record.getCode_204());
        genList.add(record.getCode_205());
        genList.add(record.getCode_206());
        genList.add(record.getCode_207());
        genList.add(record.getCode_208());
        genList.add(record.getCode_209());
        genList.add(record.getCode_210());
        genList.add(record.getCode_211());
        genList.add(record.getCode_212());
        genList.add(record.getCode_213());
        genList.add(record.getCode_214());
        genList.add(record.getCode_215());
        genList.add(record.getCode_216());
        genList.add(record.getCode_217());
        genList.add(record.getCode_218());
        genList.add(record.getCode_219());
        genList.add(record.getCode_220());
        genList.add(record.getCode_221());
        genList.add(record.getCode_222());
        genList.add(record.getCode_223());
        genList.add(record.getCode_224());
        genList.add(record.getCode_225());
        genList.add(record.getCode_226());
        genList.add(record.getCode_227());
        genList.add(record.getCode_228());
        genList.add(record.getCode_229());
        genList.add(record.getCode_230());
        genList.add(record.getCode_231());
        genList.add(record.getCode_232());
        genList.add(record.getCode_233());
        genList.add(record.getCode_234());
        genList.add(record.getCode_235());
        genList.add(record.getCode_236());
        genList.add(record.getCode_237());
        genList.add(record.getCode_238());
        genList.add(record.getCode_239());
        genList.add(record.getCode_240());
        genList.add(record.getCode_241());
        genList.add(record.getCode_242());
        genList.add(record.getCode_243());
        genList.add(record.getCode_244());
        genList.add(record.getCode_245());
        genList.add(record.getCode_246());
        genList.add(record.getCode_247());
        genList.add(record.getCode_248());
        genList.add(record.getCode_249());
        genList.add(record.getCode_250());
    }
}
