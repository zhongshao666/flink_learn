package com.ssa;


import com.google.common.collect.Maps;
import com.ssa.bean.AccountBean;
import com.ssa.bean.OfflineData;
import com.ssa.keys.HttpKeySelector;
import com.ssa.sensitive.to.HttpLog;
import com.ssa.sensitive.util.SystemConfig;
import com.ssa.source.ClickHouseZkSource;
import com.ssa.source.SecZookeeperSourceUpdate;
import com.ssa.transformation.*;
import com.ssa.utils.CuratorOperator;
import com.ssa.utils.KafkaSinkProp;
import com.ssa.utils.KafkaSourceProp;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.tuple.Tuple6;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.api.GetDataBuilder;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.*;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer011;
import org.apache.flink.util.OutputTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.ivi.opensource.flinkclickhousesink.ClickHouseSink;
import ru.ivi.opensource.flinkclickhousesink.model.ClickHouseClusterSettings;
import ru.ivi.opensource.flinkclickhousesink.model.ClickHouseSinkConst;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Map;
import java.util.Properties;

import static com.ssa.sensitive.util.SystemConfig.*;

/**
 * @author : hld
 * @Date ： 2021/4/8
 * @Time : 15:56
 * @role ：
 */
public class ApisjMain {
    private static final Logger logger = LoggerFactory.getLogger(ApisjMain.class);

    public static OutputTag<HttpLog> apptags = new OutputTag<HttpLog>("apptags") {
    };
    public static OutputTag<HttpLog> interfacetags = new OutputTag<HttpLog>("interfacetags") {
    };
    public static OutputTag<AccountBean> usertags = new OutputTag<AccountBean>("usertags") {
    };
    public static OutputTag<String> sensitivedata = new OutputTag<String>("sensitivedata") {
    };
    public static OutputTag<String> sensitivelabels = new OutputTag<String>("sensitivelabels") {
    };

    public static OutputTag<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> machineOutputTag = new OutputTag<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>>("machineOutputTag"){};
    private static MapStateDescriptor<String, Tuple4<Integer, Integer, String, String>> zookeeperConfig = new MapStateDescriptor<>("zookeeperConfig", BasicTypeInfo.STRING_TYPE_INFO, Types.TUPLE(BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO));


    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment streamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment();


        ParameterTool map = ParameterTool.fromArgs(args);
        Properties properties = new Properties();
        CuratorOperator mcto = null;
        mcto = new CuratorOperator(map.get("zkAddr"));
        GetDataBuilder data = mcto.client.getData();
        properties.load(new ByteArrayInputStream(data.forPath(map.get("zkPath"))));
        ParameterTool parameterTool = ParameterTool.fromMap((Map) properties);

        streamExecutionEnvironment.getConfig()
                .setGlobalJobParameters(parameterTool);

        streamExecutionEnvironment.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);




        //创建datasource消费者 从kafka 消费数据
        FlinkKafkaConsumer011<String> stringFlinkKafkaConsumer011 = new FlinkKafkaConsumer011<>(parameterTool.get("kafka.config.apisj.topic"), new SimpleStringSchema(), getKafkaSourceProp(parameterTool).getProp());


        DataStreamSource<Tuple4<Integer, Integer, String, String>> tuple2DataStreamSource = streamExecutionEnvironment.addSource(new SecZookeeperSourceUpdate())
                .setParallelism(1);
        //zookeeper的配置广播流配置
        BroadcastStream<Tuple4<Integer, Integer, String, String>> broadcast = tuple2DataStreamSource.broadcast(zookeeperConfig);

        //从kafka获取数据
        DataStreamSource<String> stringDataStreamSource = streamExecutionEnvironment.addSource(stringFlinkKafkaConsumer011)
                .setParallelism(4);
        //获取click house数据源
        DataStreamSource<OfflineData> offlineDataDataStreamSource = streamExecutionEnvironment.addSource(new ClickHouseZkSource());

        //将离线数据和zookeeper配置合并，并用process做成广播流
        SingleOutputStreamOperator<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> offlineConnectZkStream = offlineDataDataStreamSource
                .connect(tuple2DataStreamSource).process(new ZkCkOutputProcess());

        //join 数据广播流
        BroadcastConnectedStream<String, Tuple4<Integer, Integer, String, String>> broadcastConnectedStream = stringDataStreamSource.connect(broadcast);
        //应用发现
        SingleOutputStreamOperator<HttpLog> appDiscovery = broadcastConnectedStream.process(new AppTagProcess())
                .name("应用发现")
                .setParallelism(4);

        //http分组识别，发现新用户，用户打标，新接口标记
        SingleOutputStreamOperator<HttpLog> httpTagLater = appDiscovery.keyBy(new HttpKeySelector())
                .connect(broadcast)
                .process(new UserTagProcess())
                .name("http分组识别，发现新用户，用户打标，新接口标记");



        //敏感数据识别标记
        SingleOutputStreamOperator<HttpLog> sensitiveAnallyLater = httpTagLater.connect(broadcast)
                .process(new SensitiveAnalysisProcess())
                .name("敏感数据识别标记");

        //老大的机器请求识别
        BroadcastStream<Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>> zkAndckbroadcast = offlineConnectZkStream.getSideOutput(machineOutputTag).broadcast(MachHavProcess.dqlClientIpMap);
        SingleOutputStreamOperator<Tuple6<ArrayList<Long>, Integer, Integer, Integer, Integer, ArrayList<HttpLog>>> aggregateStream = sensitiveAnallyLater.filter(item -> item.getClientMac() != null)
                .keyBy(HttpLog::getClientMac)
                .timeWindow(Time.seconds(20))
                .aggregate(new CModelAndTimeAggregation());

        SingleOutputStreamOperator<HttpLog> machineProcess = aggregateStream.connect(zkAndckbroadcast).process(new MachHavProcess());


        //将数据写入clickhouse中
        machineProcess.process(new SensitiveBean2StringProcess())
                .addSink(new ClickHouseSink(getHttpLogCkProp(parameterTool.get("clickhouse.dw.database"),parameterTool.get("clickhouse.apisj.table"),parameterTool)));


        //执行任务
        streamExecutionEnvironment.execute("api_audit_machineflink_job");
    }

    /**
     * 获取kafka sink配置
     *
     * @return
     */
    private static KafkaSinkProp getKafkaSinkProp() {
        KafkaSinkProp kafkaSinkProp = new KafkaSinkProp();
        kafkaSinkProp.setBOOTSTRAP_SERVERS_CONFIG(SystemConfig.kafkaUrl);
        return kafkaSinkProp;
    }

    /**
     * 获取 kafka consumer配置
     *
     * @return
     */
    public static KafkaSourceProp getKafkaSourceProp(ParameterTool parameterTool) {
        KafkaSourceProp kafkaSourceProp = new KafkaSourceProp(parameterTool);
        kafkaSourceProp.setBOOTSTRAP_SERVERS_CONFIG(parameterTool.get("kafka.url"));
        return kafkaSourceProp;
    }

    /**
     * 设置传入配置
     *
     * @param parameterTool
     */
    public static void setConfig(ParameterTool parameterTool) {

        String kafkaAddr = parameterTool.get("kafkaAddr");
        if (kafkaAddr != null) {
            SystemConfig.kafkaUrl = kafkaAddr;
        }
        String zkAddr = parameterTool.get("zkAddr");
        if (zkAddr != null) {
            zookeeperUrl = zkAddr;
        }

        String ckAddr = parameterTool.get("ckAddr");
        if (ckAddr != null) {
            clickHouseUrl = ckAddr;
        }

        String ckUser = parameterTool.get("ckUser");
        if (ckUser != null) {
            clickHouseUser = ckUser;
        }

        String ckPassword = parameterTool.get("ckPassword");
        if (ckPassword != null) {
            clickHousePassword = "__NO_VALUE_KEY".equals(ckPassword) ? "" : ckPassword;
        }

        String ckdb = parameterTool.get("ckdb");
        if (ckdb != null) {
            database = ckdb;
        }

        logger.info("config kafka addr {} init zk addr {} clickhouse addr {} clickHouseUser {} clickHousePassword {} database {}", kafkaUrl, zookeeperUrl, clickHouseUrl, clickHouseUser, clickHousePassword, database);
    }

    /**
     * 设置clickhouse的sink参数
     *
     * @param host
     * @param user
     * @param password
     */
    private static ParameterTool getClickHouseSinkGlobalParam(String host, String user, String password) {
        Map<String, String> globalParameters = Maps.newHashMap();
        globalParameters.put(ClickHouseClusterSettings.CLICKHOUSE_HOSTS, host);
        globalParameters.put(ClickHouseClusterSettings.CLICKHOUSE_USER, user);
        globalParameters.put(ClickHouseClusterSettings.CLICKHOUSE_PASSWORD, password);
        globalParameters.put(ClickHouseSinkConst.TIMEOUT_SEC, clickHouseTimeoutSec);
        globalParameters.put(ClickHouseSinkConst.NUM_WRITERS, clickHouseNumWriters);
        globalParameters.put(ClickHouseSinkConst.NUM_RETRIES, clickHouseNumRetries);
        globalParameters.put(ClickHouseSinkConst.QUEUE_MAX_CAPACITY, clickHouseMaxQueueSize);
        globalParameters.put(ClickHouseSinkConst.IGNORING_CLICKHOUSE_SENDING_EXCEPTION_ENABLED, clickHouseIgnoreExceptionEnable);
        globalParameters.put(ClickHouseSinkConst.FAILED_RECORDS_PATH, clickHouseFailRecordPath);

        return ParameterTool.fromMap(globalParameters);
    }

    /**
     * http_log ck config
     *
     * @return
     */
    private static Properties getHttpLogCkProp(String ckDb, String ckTb, ParameterTool parameterTool) {
        Properties properties = new Properties();
        properties.put(ClickHouseSinkConst.TARGET_TABLE_NAME, ckDb + "." + ckTb);
        properties.put(ClickHouseSinkConst.MAX_BUFFER_SIZE, parameterTool.get("clickhouse.maxBufferSize"));
        return properties;
    }

    /**
     * http_sensitive_record ck config
     *
     * @return
     */
    private static Properties getHttpSensitiveRecordCkProp(String ckDb) {
        Properties properties = new Properties();
        properties.put(ClickHouseSinkConst.TARGET_TABLE_NAME, ckDb + ".http_sensitive_record");
        properties.put(ClickHouseSinkConst.MAX_BUFFER_SIZE, clickHouseMaxBufferSize);
        return properties;
    }

}