package com.ssa.sensitive.util;

import org.apache.commons.lang3.StringUtils;

import java.util.ResourceBundle;

/**
 * @author qsj
 * @since 2021/2/4
 */
public class SystemConfig {
    /**
     * zookeeper 配置地址
     */
    public static String zookeeperUrl;

    /**
     * zookeeper timeout
     */
    public static int zookeeperTimeout;

    /**
     * zookeeper 应用发现路径
     */
    public static String zookeeperAppDiscoveryPath;

    /**
     * zookeeper 应用数据路径
     */
    public static String zookeeperAppDataPath;

    /**
     * zookeeper 接口数据路径
     */
    public static String zookeeperInterfaceDataPath;

    /**
     * zookeeper 敏感标签接口路径
     */
    public static String zookeeperSensitiveLabelDataPath;


    public static String zookeeperBWListDataPath;

    public static String zookeeperUserDefineDataPath;

    public static String zookeeperRiskDataPath;

    public static String zookeeperStrategyConfigDataPath;

    /**
     * kafka配置地址
     */
    public static String kafkaUrl;
    /**
     * kafka topic 采集端收集的http数据
     */
    public static String kafkaTopicCollectHttp;

    /**
     * kafka topic 发现的新应用
     */
    public static String kafkaTopicNewApp;

    /**
     * kafka topic 发现的新账号
     */
    public static String kafkaTopicNewAccount;

    /**
     * kafka topic 发现的新接口
     */
    public static String kafkaTopicNewInterface;

    /**
     * kafka topic 发现的新敏感标签
     */
    public static String kafkaTopicNewSensitiveLabel;

    /**
     * kafka topic clickhouse http_log表
     */
    public static String kafkaTopicCkHttpLog;

    /**
     * kafka topic clickhouse http_sensitive_record表
     */
    public static String kafkaTopicCkHttpSensitiveRecord;

    /**
     * ck配置地址
     */
    public static String clickHouseUrl;

    /**
     * ck库名
     */
    public static String database;

    /**
     * ck 用户名
     */
    public static String clickHouseUser;

    /**
     * ck 密码
     */
    public static String clickHousePassword;

    /**
     * ck sink最大缓存
     */
    public static String clickHouseMaxBufferSize;

    /**
     * ck sink 最大队列长度
     */
    public static String clickHouseMaxQueueSize;

    /**
     * ck 超时时间
     */
    public static String clickHouseTimeoutSec;

    /**
     * ck 并发写入数量
     */
    public static String clickHouseNumWriters;

    /**
     * ck 重试次数
     */
    public static String clickHouseNumRetries;

    /**
     * ck ignore exception
     */
    public static String clickHouseIgnoreExceptionEnable;

    /**
     * ck fail record path
     */
    public static String clickHouseFailRecordPath;

    /**
     * ck的zk路径
     */
    public static String clickHousePathInZookeeper;


    /**
     * 机器请求zk节点
     */
    public static String machineZookeeperNode;


    static {
        ResourceBundle resource = ResourceBundle.getBundle("application");
        zookeeperUrl = resource.getString("zookeeper.url");
        String zkTimeout = resource.getString("zookeeper.timeout");
        if (StringUtils.isNotBlank(zkTimeout)) {
            zookeeperTimeout = Integer.parseInt(zkTimeout);
        }
        zookeeperAppDiscoveryPath = resource.getString("zookeeper.app.discovery.path");
        zookeeperAppDataPath = resource.getString("zookeeper.app.data.path");
        zookeeperInterfaceDataPath = resource.getString("zookeeper.interface.data.path");
        zookeeperSensitiveLabelDataPath = resource.getString("zookeeper.sensitive.label.data.path");

        zookeeperBWListDataPath = resource.getString("zookeeper.bw.list.data.path");
        zookeeperUserDefineDataPath = resource.getString("zookeeper.userdefine.data.path");
        zookeeperRiskDataPath = resource.getString("zookeeper.risk.data.path");
        zookeeperStrategyConfigDataPath = resource.getString("zookeeper.strategy.config.data.path");

        kafkaUrl = resource.getString("kafka.url");
        kafkaTopicCollectHttp = resource.getString("kafka.topic.collect.http");
        kafkaTopicNewApp = resource.getString("kafka.topic.new.app");
        kafkaTopicNewAccount = resource.getString("kafka.topic.new.account");
        kafkaTopicNewInterface = resource.getString("kafka.topic.new.interface");
        kafkaTopicNewSensitiveLabel = resource.getString("kafka.topic.new.sensitive.label");
        kafkaTopicCkHttpLog = resource.getString("kafka.topic.ck.http.log");
        kafkaTopicCkHttpSensitiveRecord = resource.getString("kafka.topic.ck.http.sensitive.record");

        clickHouseUrl = resource.getString("clickHouse.Url");
        database=resource.getString("clickHouse.Database");
        clickHouseUser = resource.getString("clickHouse.User");
        clickHousePassword = resource.getString("clickHouse.Password");
        clickHouseMaxBufferSize = resource.getString("clickHouse.maxBufferSize");
        clickHouseMaxQueueSize = resource.getString("clickHouse.maxQueueSize");
        clickHouseTimeoutSec = resource.getString("clickHouse.timeoutSec");
        clickHouseNumWriters = resource.getString("clickHouse.numWriters");
        clickHouseNumRetries = resource.getString("clickHouse.numRetries");
        clickHouseIgnoreExceptionEnable = resource.getString("clickHouse.ignore.exception.enable");
        clickHouseFailRecordPath = resource.getString("clickHouse.fail.record.path");
        clickHousePathInZookeeper= resource.getString("zookeeper.offline.data.path");

        machineZookeeperNode = resource.getString("machine.zookeeper.node.path");
    }
}