package com.ssa.mapfun;

import com.alibaba.fastjson.JSON;
import com.ssa.bean.AssetLog;
import org.apache.flink.api.common.functions.MapFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author : hld
 * @Date ： 2021/4/9
 * @Time : 10:51
 * @role ：
 */
public class SourceMapFunction implements MapFunction<String, AssetLog> {
    private final Logger logger = LoggerFactory.getLogger(SourceMapFunction.class);
    @Override
    public AssetLog map(String value) throws Exception {
        try {
            AssetLog assetLog = JSON.parseObject(value, AssetLog.class);
            assetLog.setRequestTime(assetLog.getRequestTime()*1000);
            return assetLog;
        }catch (Exception e){
            e.printStackTrace();
        }

        return null;
    }
}
