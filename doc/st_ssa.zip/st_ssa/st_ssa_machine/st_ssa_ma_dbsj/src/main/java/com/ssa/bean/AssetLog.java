package com.ssa.bean;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : hld
 * @Date ： 2021/4/8
 * @Time : 17:00
 * @role ：
 */

@Data
public class AssetLog {
    /**
     * first_id和second_id 和起来成为主键
     */
    private Long firstId;
    private Long secondId;
    /**
     * 标识服务的分组关系。
     */
    private Integer assetId;

    private Integer instanceId;

    private String tableSchema;

    private Integer tableId;

    private Integer databaseType;

    private Integer sourceTableCode;

    private String categoryLabelSourceSetJson;

    private Integer levelLabelId;

    private Integer isSensitiveTable;

    /**
     * 日志格式版本
     */
    private Integer logVersion;
    /**
     * 会话id
     */
    private String sessionId;
    /**
     * 事件类型 1 -登录 2 - 访问
     */
    private Integer eventType;
    /**
     * 客户端mac
     */
    private String clientMac;
    /**
     * 客户端ip
     */
    private String clientIp;
    /**
     * 客户端端口
     */
    private Integer clientPort;
    /**
     * 服务端mac
     */
    private String serverMac;
    /**
     * 服务端ip
     */
    private String serverIp;
    /**
     * 服务端端口
     */
    private Integer serverPort;
    /**
     * 请求时间
     */
    private Long requestTime;
    /**
     * 用户请求时间
     */
    private Integer requestTimeUsec;
    /**
     * 请求时间（分钟）
     */
    private Integer minuteTime;
    /**
     * 请求时间（微秒）
     */
    private Long requestMicrosecond;
    /**
     * 执行时长
     */
    private Long executeTime;
    /**
     * 请求状态码
     */
    private Integer requestStatus;
    /**
     * 数据库账号
     */
    private String account;
    /**
     * 客户端账号
     */
    private String osUserName;
    /**
     * 风险类型
     */
    private String riskType;
    /**
     * 匹配规则
     */
    private List<String> matchedRules = new ArrayList<>();
    /**
     * 风险等级
     */
    private Integer riskLevel;
    /**
     * 保护手段
     */
    private Integer protectOperate;
    /**
     * 请求库名
     */
    private String instanceName;
    /**
     * 客户端工具
     */
    private String clientApp;
    /**
     * 客户端地址
     */
    private String clientHost;
    /**
     * 业务语句
     */
    private String operationStatement;
    /**
     * 绑定变量
     */
    private List<List<String>> bindingVariables = new ArrayList<>();
    /**
     * sql模板
     */
    private String statementPattern;
    /**
     * 响应结果
     */
    private List<List<String>> reply = new ArrayList<>();
    /**
     * 错误sql
     */
    private String errorReply;
    /**
     * 响应行数
     */
    private Integer rowsAffected;
    /**
     * 操作类型
     */
    private Integer operationType;
    /**
     * 操作命令
     */
    private String operationCommand;
    /**
     * 操作对象
     */
    private String operandType;
    /**
     * 操作对象类
     */
    private List<String> operandName = new ArrayList<>();
    /**
     * 二级操作对象
     */
    private List<String> secondOperandName = new ArrayList<>();
    /**
     * web请求用户名
     */
    private String webUserName;
    /**
     * web请求地址
     */
    private String webUrl;
    /**
     * 三层关联时web客户端的IP地址（三层关联
     * 是将数据库信息，数据库客户端信息，web客户端信息关联起来，数据库客户端为web系统场景时使用。
     * 每个sql语句会关联触发sql请求的url请求、web系统账号、客户端IP）
     */
    private String webIp;

    private String webSessionId;

    private Integer reviewed;

    private String comment;

    private Integer sent;
    /**
     * 敏感表名称,逗号分隔
     */
    private List<String> sensitiveTables= new ArrayList<>();
    /**
     * 敏感字段名称,逗号分隔
     */
    private List<String> sensitiveColumns= new ArrayList<>();
    /**
     * 风险类型实时打标，（风险等级）
     */
    private Integer riskTypeAi;
    /**
     *@功能描述 流计算打标
     */
    private List<String> flowLabel= new ArrayList<>();
    /**
     * 告警编号标签
     */
    private List<String> alarmLabel= new ArrayList<>();

    private Integer isModelLabel;

    private String dateInfo;
}