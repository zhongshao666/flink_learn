package com.ssa.transformation;

import com.alibaba.fastjson.JSON;
import com.ssa.bean.AssetLog;
import com.ssa.bean.MachineRequestIdentify;
import com.ssa.bean.OfflineData;
import com.ssa.constants.CommonConstants;
import com.ssa.utils.VariUtils;
import org.apache.flink.api.common.state.BroadcastState;
import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.state.ReadOnlyBroadcastState;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.common.typeutils.TypeSerializer;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.tuple.Tuple6;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.BroadcastProcessFunction;
import org.apache.flink.streaming.api.functions.co.KeyedBroadcastProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author : cjj
 * @Date ： 2021/4/27
 * @Time :
 * @role ：
 */
public class MachHavProcess extends BroadcastProcessFunction<Tuple6<ArrayList<Long>, Integer, Integer, Integer, Integer, ArrayList<AssetLog>>, Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>>, AssetLog> {
    private  final Logger logger = LoggerFactory.getLogger(MachHavProcess.class);

    public static MapStateDescriptor<String, Double> dqlClientIpMap = new MapStateDescriptor<String, Double>("dqlClientIpMap", BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.DOUBLE_TYPE_INFO);

    private MachineRequestIdentify machReqIdent;
    private Map<String, Double> aDouble;

    @Override
    public void open(Configuration parameters) throws Exception {
        machReqIdent = new MachineRequestIdentify();
        aDouble = new HashMap<>();
    }

    @Override
    public void processElement(Tuple6<ArrayList<Long>, Integer, Integer, Integer, Integer, ArrayList<AssetLog>> in, ReadOnlyContext context, Collector<AssetLog> out) throws Exception {
        //获取时间，对时间进行排序
        List<Long> list = in.f0.stream().distinct().collect(Collectors.toList());
        if (list.size() > 3) {
            logger.info("Tuple6 in---------");
            if (this.aDouble.get(in.f5.get(0).getClientMac()) != null) {
                logger.info("rar--------is not null");

                if (this.aDouble.get(in.f5.get(0).getClientMac()) < machReqIdent.getRarityThr()) {
                    //List<Long> list =longList.stream().sorted().collect(Collectors.toList());
                    list.sort((v1,v2)->v1.compareTo(v2));
                    //获取时间差放到新的list
                    ArrayList<Long> timeList = new ArrayList<Long>();
                    for (int i = 0; i < list.size(); i++) {
                        if (i > 0) {
                            long l = list.get(i) - list.get(i - 1);
                            timeList.add(l);
                        }
                    }

                    //计算最大值
                    Long max = timeList.stream()
                            .collect(Collectors.summarizingLong(Long::longValue))
                            .getMax();
                    System.out.println("max = " + max);
                    System.out.println("timeList = " + timeList);

                    //归一化计算时间差的平均值
                    Double average = VariUtils.average(timeList, max);
                    System.out.println("平均值average = " + average);

                    //计算方差
                    Double variance = VariUtils.variance(timeList, average, max);
                    System.out.println("方差variance = " + variance);

                    //mac请求的总数量，ip数量，port数量，serPort数量
//                    Integer eveNum = in.f1;
//                    Integer ipNum = in.f2;
//                    Integer portNum = in.f3;
//                    Integer serPortNum = in.f4;

                    //稀有度风险分值计算
                    Double rarScore = 1 - this.aDouble.get(in.f5.get(0).getClientMac());
                    //方差风险分值计算
                    Double varScore = 1 - variance;
                    //总请求风险分值计算
                    double eveScore = in.f1 / machReqIdent.getEveNumThr();
                    if (eveScore > 1) {
                        eveScore = 1;
                    }
                    //请求不同IP风险分值计算
                    double ipNumScore = in.f2 / machReqIdent.getIpNumThr();
                    if (ipNumScore > 1) {
                        ipNumScore = 1;
                    }
                    //请求不同的port风险分值计算
                    double portNumScore = in.f3 / machReqIdent.getPortNumThr();
                    if (portNumScore > 1) {
                        portNumScore = 1;
                    }
                    //server端不同port风险分值计算
                    double serPortNumScore = in.f4 / machReqIdent.getSerPortNumThr();

                    if (serPortNumScore > 1) {
                        serPortNumScore = 1;
                    }
                    logger.info("稀有度风险："+rarScore+"方差风险："+ varScore+"总请求风险"+eveScore+"请求不同IP风险"+ipNumScore+"请求不同的port风险"+portNumScore+"server端不同port风险"+serPortNumScore);
                    //计算最终分值
                    double abnormalScore = machReqIdent.getRarityWeight() * rarScore + machReqIdent.getVarWeight() * varScore +
                            machReqIdent.getEveNumWeight() * eveScore + machReqIdent.getIpNumWeight() * ipNumScore +
                            machReqIdent.getPortNumWeight() * portNumScore + machReqIdent.getSerPortNumWeight() * serPortNumScore;
                    System.out.println("最终分值*****************************" + abnormalScore);
                    //最终逻辑判断
                    if (abnormalScore > machReqIdent.getAbnormalThreshold()) {
                        logger.info("assetlog打标---");
                        ArrayList<AssetLog> assetLogs = in.f5;
                        for (AssetLog assetLog : assetLogs) {
                            List<String> alarmLabel = assetLog.getAlarmLabel();
                            alarmLabel.add("050201");
                            assetLog.setAlarmLabel(alarmLabel);

                            assetLog.setRiskTypeAi(4);

                            List<String> flowLabel = assetLog.getFlowLabel();
                            flowLabel.add("05020101");
                            assetLog.setFlowLabel(flowLabel);

                            assetLog.setIsModelLabel(1);
                            out.collect(assetLog);
                        }

                    }
                }
            }
        }

    }

    @Override
    public void processBroadcastElement(Tuple2<OfflineData, Tuple4<Integer, Integer, String, String>> value, Context ctx, Collector<AssetLog> collector) throws Exception {
        if (value.f0 != null) {
            this.aDouble.put(value.f0.getClientMac(), value.f0.getRarity());
        } else {
            machReqIdent = JSON.parseObject(value.f1.f3, MachineRequestIdentify.class);
        }
    }

}
