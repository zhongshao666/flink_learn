package com.ssa.transformation;

import com.ssa.bean.AssetLog;
import org.apache.flink.api.common.functions.AggregateFunction;
import org.apache.flink.api.java.tuple.Tuple6;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.stream.Collectors;

/**
 *  @author : cjj
 *  @Date ： 2021/4/27
 *  @Time :
 *  @role ：
 */
public class CModelAndTimeAggregation implements AggregateFunction<AssetLog, Tuple6<ArrayList<Long>,ArrayList<Long>, HashSet<String>, HashSet<Integer>, HashSet<Integer>, ArrayList<AssetLog>>, Tuple6<ArrayList<Long>, Integer, Integer, Integer, Integer, ArrayList<AssetLog>>> {
    private  final Logger logger = LoggerFactory.getLogger(CModelAndTimeAggregation.class);

    @Override
    public Tuple6<ArrayList<Long>, ArrayList<Long>, HashSet<String>, HashSet<Integer>, HashSet<Integer>, ArrayList<AssetLog>> createAccumulator() {
        return new Tuple6<>(new ArrayList<>(), new ArrayList<>(), new HashSet<>(), new HashSet<>(), new HashSet<>(), new ArrayList<>());
    }

    @Override
    public Tuple6<ArrayList<Long>, ArrayList<Long>, HashSet<String>, HashSet<Integer>, HashSet<Integer>, ArrayList<AssetLog>> add(AssetLog assetLog, Tuple6<ArrayList<Long>, ArrayList<Long>, HashSet<String>, HashSet<Integer>, HashSet<Integer>, ArrayList<AssetLog>> accumulator) {

        logger.info("add Tuple6 ");
            Long time = assetLog.getRequestTime();
            accumulator.f0.add(time);

            Long logId = assetLog.getSecondId();
            accumulator.f1.add(logId);

            String clientIp = assetLog.getClientIp();
            accumulator.f2.add(clientIp);

            Integer clientPort = assetLog.getClientPort();
            accumulator.f3.add(clientPort);

            Integer serverPort = assetLog.getServerPort();
            accumulator.f4.add(serverPort);

            accumulator.f5.add(assetLog);

        return accumulator;
    }

    @Override
    public Tuple6<ArrayList<Long>, Integer, Integer, Integer, Integer, ArrayList<AssetLog>> getResult(Tuple6<ArrayList<Long>, ArrayList<Long>, HashSet<String>, HashSet<Integer>, HashSet<Integer>, ArrayList<AssetLog>> accumulator) {
        ArrayList<Long> time = accumulator.f0;
        Integer logIdCount = accumulator.f1.size();
        Integer clientIpCount = accumulator.f2.size();
        Integer  clientPortCount = accumulator.f3.size();
        Integer  serverPortCount = accumulator.f4.size();
        ArrayList<AssetLog> logList = accumulator.f5;
        //logger.info(" get Result -------");
        return new Tuple6<>(time, logIdCount,clientIpCount, clientPortCount, serverPortCount, logList);
    }

    @Override
    public Tuple6<ArrayList<Long>, ArrayList<Long>, HashSet<String>, HashSet<Integer>, HashSet<Integer>, ArrayList<AssetLog>> merge(Tuple6<ArrayList<Long>, ArrayList<Long>, HashSet<String>, HashSet<Integer>, HashSet<Integer>, ArrayList<AssetLog>> a, Tuple6<ArrayList<Long>, ArrayList<Long>, HashSet<String>, HashSet<Integer>, HashSet<Integer>, ArrayList<AssetLog>> acc1) {
        //logger.info("Merger-------");
        return null;
    }
}

