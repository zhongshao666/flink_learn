package com.ssa.transformation;

import com.ssa.bean.AssetLog;
import com.ssa.utils.CsvUtils;
import org.apache.commons.compress.utils.Lists;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Optional;

/**
 * @author : hld
 * @Date ： 2021/4/19
 * @Time : 15:43
 * @role ：
 */
public class AssetLogToStringProcess extends ProcessFunction<AssetLog, String> {

    private static final Logger logger = LoggerFactory.getLogger(AssetLogToStringProcess.class);


    /**
     * 请求时间格式化-yyyy-MM-dd HH:mm:ss.SSS
     */
    public static final String REQUEST_TIME_FORMAT_MS = "yyyy-MM-dd HH:mm:ss";
    public static final String REQUEST_TIME_FORMAT_S= "yyyy-MM-dd";

    private static final Character CK_ARRAY_BEGIN = '[';
    private static final Character CK_ARRAY_END = ']';
    private static final Character CK_LINE_BEGIN = '(';
    private static final Character CK_LINE_END = ')';

    @Override
    public void processElement(AssetLog value, Context ctx, Collector<String> out) throws Exception {
        //logger.info("--value"+value);
        String httpLogCsv = getCkHttpCsvLine(value);

        out.collect(httpLogCsv);
    }


    /**
     * 获取assetLog csv format对象
     *
     * @param value
     * @return
     */
    public String getCkHttpCsvLine(AssetLog value) throws IllegalAccessException {

        List<String> ckAssetLogCsvList = getCkAssetLogCsvList(value);
        return CsvUtils.convertToCkCsvFormatByArray(ckAssetLogCsvList, CK_LINE_BEGIN, CK_LINE_END);
    }

    public List<String> getCkAssetLogCsvList(AssetLog value) throws IllegalAccessException {

        List<String> csvList = Lists.newArrayList();

        Field[] declaredFields = value.getClass().getDeclaredFields();

        for (Field declaredField : declaredFields) {


            declaredField.setAccessible(true);

            String name = declaredField.getType().getName();
            String columnName = declaredField.getName();
            Object columns = declaredField.get(value);

            if ("requestTime".equals(declaredField.getName())) {
                csvList.add(conversionTime(value.getRequestTime(),REQUEST_TIME_FORMAT_MS));
            } else if ("dateInfo".equals(declaredField.getName())) {
                csvList.add(conversionTime(value.getRequestTime(),REQUEST_TIME_FORMAT_S));
            } else if (Integer.class.getName().equals(name)) {
                csvList.add(conversionInteger(columns, columnName));
            } else if (Long.class.getName().equals(name)) {
                csvList.add(conversionLong(columns));
            } else if (String.class.getName().equals(name)) {
                csvList.add(conversionString(columns));
            } else if (List.class.getName().equals(name)) {
                csvList.add(conversionList(columns));
            } else {
                csvList.add("0");
            }
        }

        return csvList;
    }

    public String conversionInteger(Object column, String columnName) {
        return Optional.ofNullable(column)
                .map(String::valueOf)
                .orElse( "0");
    }

    public String conversionLong(Object column) {
        return Optional.ofNullable(column)
                .map(String::valueOf)
                .orElse("0");
    }

    public String conversionString(Object column) {
        return column == null ? null : column.toString();
    }

    public String conversionList(Object column) {
        List list = (List) column;
        if (list.size() > 0 && list.get(0) instanceof String) {
            return CsvUtils.convertToCkCsvFormatByArray(list, CK_ARRAY_BEGIN, CK_ARRAY_END);
        } else if (list.size() > 0 && list.get(0) instanceof List) {
            return CsvUtils.convertToCkCsvFormatByTwoArray(list);
        } else {
            return "[]";
        }
    }

    public String conversionTime(Object column,String dateMode) {
        return Optional.ofNullable(column)
                .map(time -> DateFormatUtils.format(Long.parseLong(time.toString()), dateMode))
                .orElse("");
    }
}
