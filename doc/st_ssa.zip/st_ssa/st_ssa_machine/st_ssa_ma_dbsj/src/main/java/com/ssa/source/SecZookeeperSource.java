package com.ssa.source;

import com.ssa.constants.CommonConstants;
import com.ssa.utils.CuratorOperator;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.CuratorFramework;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.recipes.cache.*;
import org.apache.flink.streaming.api.functions.source.RichSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SecZookeeperSource extends RichSourceFunction<Tuple4<Integer, Integer, String, String>> {

    private static final Logger logger = LoggerFactory.getLogger(SecZookeeperSource.class);

    CuratorOperator cto = null;
    // tuple4<策略类型，增删改，zk路径，内容>
    SourceContext<Tuple4<Integer, Integer, String, String>> sourceContextGlobal = null;
    private ParameterTool parameterTool;



    @Override
    public void open(Configuration parameters) throws Exception {
        System.setProperty("zookeeper.sasl.client", "false");
        parameterTool = (ParameterTool) getRuntimeContext().getExecutionConfig()
                .getGlobalJobParameters();
        cto = new CuratorOperator(parameterTool.get("zookeeper.url"));
    }

    private void nodeListen(NodeCache nodeCache, int zkType, String path) throws Exception {
        nodeCache.start(true);
        if (nodeCache.getCurrentData() != null) {
            sourceContextGlobal.collect(new Tuple4<>(zkType, CommonConstants.OperateType.UPDATE.getVal(), path, new String(nodeCache.getCurrentData().getData())));
        }

        nodeCache.getListenable().addListener(new NodeCacheListener() {
            @Override
            public void nodeChanged() throws Exception {
                if (nodeCache.getCurrentData() != null) {
                    sourceContextGlobal.collect(new Tuple4<>(zkType, CommonConstants.OperateType.UPDATE.getVal(), path, new String(nodeCache.getCurrentData().getData())));
                }
            }
        });
    }

    private void childrenListen(PathChildrenCache pathChildrenCache, int type, String nodepath) throws Exception {
        pathChildrenCache.start(PathChildrenCache.StartMode.POST_INITIALIZED_EVENT);
        pathChildrenCache.getListenable().addListener(new PathChildrenCacheListener() {


            @Override
            public void childEvent(CuratorFramework curatorFramework, PathChildrenCacheEvent event) throws Exception {
                if (event.getType().equals(PathChildrenCacheEvent.Type.INITIALIZED)) {
                    logger.info("初始化zookeeper监听完成.........");
                } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_ADDED)) {
                    String path = event.getData().getPath();
                    if (path.startsWith(nodepath)) {
                        sourceContextGlobal.collect(new Tuple4<>(type, CommonConstants.OperateType.ADD.getVal(), path, new String(event.getData().getData())));
                        logger.info("create " + path + "----" + new String(event.getData().getData()));
                    }
                } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_REMOVED)) {
                    sourceContextGlobal.collect(new Tuple4<>(type, CommonConstants.OperateType.DELETE.getVal(), event.getData().getPath(), new String(event.getData().getData())));
                    logger.info("remove " + event.getData().getPath() + "----" + new String(event.getData().getData()));
                } else if (event.getType().equals(PathChildrenCacheEvent.Type.CHILD_UPDATED)) {
                    sourceContextGlobal.collect(new Tuple4<>(type, CommonConstants.OperateType.UPDATE.getVal(), event.getData().getPath(), new String(event.getData().getData())));
                    logger.info("update " + event.getData().getPath());
                }
            }
        });

    }

    @Override
    public void run(SourceContext<Tuple4<Integer, Integer, String, String>> sourceContext) throws Exception {
        sourceContextGlobal = sourceContext;

       // final PathChildrenCache childrenRisk = new PathChildrenCache(cto.client, parameterTool.get("zookeeper.risk.data.path"), true);

       /* final NodeCache risk_status = new NodeCache(cto.client, parameterTool.get("zookeeper.strategy.config.riskstatu.path"));
        final NodeCache auth4a_ip = new NodeCache(cto.client, parameterTool.get("zookeeper.strategy.config.auth4aip.path"));
        final NodeCache foreign_ip = new NodeCache(cto.client, parameterTool.get("zookeeper.strategy.config.foreignip.path"));
        final NodeCache intranet_ip = new NodeCache(cto.client, parameterTool.get("zookeeper.strategy.config.intranetip.path"));
        final NodeCache threat_ip = new NodeCache(cto.client, parameterTool.get("zookeeper.strategy.config.threatip.path"));
        final NodeCache common_ip = new NodeCache(cto.client, parameterTool.get("zookeeper.strategy.config.commonip.path"));
        final NodeCache common_time = new NodeCache(cto.client, parameterTool.get("zookeeper.strategy.config.commontime.path"));
        final NodeCache common_account = new NodeCache(cto.client, parameterTool.get("zookeeper.strategy.config.commonaccount.path"));*/
        final NodeCache machine_request = new NodeCache(cto.client,parameterTool.get("zookeeper.model.dbsj.machine.path"));

        //添加对节点的风险状态监听
        //nodeListen(risk_status, CommonConstants.ZkDataType.RISK_STATU.getVal(), parameterTool.get("zookeeper.strategy.config.riskstatu.path"));
        //添加节点的4A绕行配置
        //nodeListen(auth4a_ip, CommonConstants.ZkDataType.AUTH4A_IP.getVal(), parameterTool.get("zookeeper.strategy.config.auth4aip.path"));
        //添加节点的跨境ip配置
       // nodeListen(foreign_ip, CommonConstants.ZkDataType.FOREIGN_IP.getVal(), parameterTool.get("zookeeper.strategy.config.foreignip.path"));
        //添加节点的内网ip配置
       // nodeListen(intranet_ip, CommonConstants.ZkDataType.INTRANET_IP.getVal(), parameterTool.get("zookeeper.strategy.config.intranetip.path"));
        //添加威胁情报ip配置
       // nodeListen(threat_ip, CommonConstants.ZkDataType.THREAT_IP.getVal(), parameterTool.get("zookeeper.strategy.config.threatip.path"));
        //添加常用IP和IP段配置
       // nodeListen(common_ip, CommonConstants.ZkDataType.COMMON_IP.getVal(), parameterTool.get("zookeeper.strategy.config.commonip.path"));
        //添加访问时间配置
       // nodeListen(common_time, CommonConstants.ZkDataType.COMMON_TIME.getVal(), parameterTool.get("zookeeper.strategy.config.commontime.path"));
        //添加常用用户配置
       // nodeListen(common_account, CommonConstants.ZkDataType.COMMON_ACCOUNT.getVal(), parameterTool.get("zookeeper.strategy.config.commonaccount.path"));
        //机器请求行为配置
        nodeListen(machine_request,CommonConstants.ZkDataType.MACHINE_REQUEST.getVal(),parameterTool.get("zookeeper.model.dbsj.machine.path"));

        //对zookeeper的接口的路径监听

        //childrenListen(childrenRisk, CommonConstants.ZkDataType.RISK_TYPE.getVal(), parameterTool.get("zookeeper.risk.data.path"));


        while (true) {
            Thread.sleep(50000);
        }
    }

    @Override
    public void cancel() {

    }

}
