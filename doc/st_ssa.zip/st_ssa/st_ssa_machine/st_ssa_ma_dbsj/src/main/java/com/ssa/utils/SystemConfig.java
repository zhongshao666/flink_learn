package com.ssa.utils;

import org.apache.commons.lang3.StringUtils;

import java.util.ResourceBundle;

/**
 * @author qsj
 * @since 2021/2/4
 */
public class SystemConfig {
    /**
     * zookeeper 配置地址
     */
    public static String zookeeperUrl;

    /**
     * zookeeper timeout
     */
    public static int zookeeperTimeout;

    /**
     * kafka配置地址
     */
    public static String kafkaUrl;
    /**
     * kafka topic 采集端收集的Asset数据
     */
    public static String kafkaTopicCollectAsset;


    public static String kafkaStatistics;


    /**
     * ck配置地址
     */
    public static String clickHouseUrl;

    /**
     * ck库名
     */
    public static String database;

    /**
     * ck 用户名
     */
    public static String clickHouseUser;

    /**
     * ck 密码
     */
    public static String clickHousePassword;

    /**
     * ck sink最大缓存
     */
    public static String clickHouseMaxBufferSize;

    /**
     * ck sink 最大队列长度
     */
    public static String clickHouseMaxQueueSize;

    /**
     * ck 超时时间
     */
    public static String clickHouseTimeoutSec;

    /**
     * ck 并发写入数量
     */
    public static String clickHouseNumWriters;

    /**
     * ck 重试次数
     */
    public static String clickHouseNumRetries;

    /**
     * ck ignore exception
     */
    public static String clickHouseIgnoreExceptionEnable;

    /**
     * ck fail record path
     */
    public static String clickHouseFailRecordPath;

    /**
     * ck的zk路径
     */
    public static String clickHousePathInZookeeper;

    public static String zookeeperStrategyRiskStatus;
    public static String zookeeperStrategyAuth4aIP;
    public static String zookeeperStrategyForeignIP;
    public static String zookeeperStrategyIntranetIP;
    public static String zookeeperStrategyThreatIP;
    public static String zookeeperStrategyCommonIP;
    public static String zookeeperStrategyCommonTime;
    public static String zookeeperStrategyCommonAccount;

    public static  String zookeeperRiskDataPath;

    public static String zookeeperStrategyOffline;

    public static String zookeeperAppCommonPath;

    public static String mysqlClass;
    public static String mysqlUrl;
    public static String mysqlUser;
    public static String mysqlPasswd;


    /**
     * 默认列
     */
    public static String modelSuffixtreeFiltercolumn;

    /**
     * 默认连续统计次数
     */
    public  static Integer modelSuffixtreeWindowcount;

    /**
     * 模型的zk配
     */
    public static String modelZkConfig;

    /**
     * 模型的hdfs配置zk路径
     */
    public static String modelHdfsConfig;

    static {
        ResourceBundle resource = ResourceBundle.getBundle("application");

        mysqlClass = resource.getString("mysql.class");
        mysqlUrl = resource.getString("mysql.url");
        mysqlUser = resource.getString("mysql.user");
        mysqlPasswd = resource.getString("mysql.passwd");

        zookeeperUrl = resource.getString("zookeeper.url");
        String zkTimeout = resource.getString("zookeeper.timeout");
        if (StringUtils.isNotBlank(zkTimeout)) {
            zookeeperTimeout = Integer.parseInt(zkTimeout);
        }
        zookeeperStrategyRiskStatus = resource.getString("zookeeper.strategy.config.riskstatu.path");
        zookeeperStrategyAuth4aIP = resource.getString("zookeeper.strategy.config.auth4aip.path");
        zookeeperStrategyForeignIP = resource.getString("zookeeper.strategy.config.foreignip.path");
        zookeeperStrategyIntranetIP = resource.getString("zookeeper.strategy.config.intranetip.path");
        zookeeperStrategyThreatIP = resource.getString("zookeeper.strategy.config.threatip.path");
        zookeeperStrategyCommonIP = resource.getString("zookeeper.strategy.config.commonip.path");
        zookeeperStrategyCommonTime = resource.getString("zookeeper.strategy.config.commontime.path");
        zookeeperStrategyCommonAccount = resource.getString("zookeeper.strategy.config.commonaccount.path");




        zookeeperRiskDataPath = resource.getString("zookeeper.risk.data.path");

        zookeeperStrategyOffline = resource.getString("zookeeper.strategy.config.offlinetask.path");

        zookeeperAppCommonPath = resource.getString("zookeeper.app.common.path");

        kafkaUrl = resource.getString("kafka.url");
        kafkaTopicCollectAsset = resource.getString("kafka.topic.collect.asset");
        kafkaStatistics = resource.getString("kafka.topic.send.statistics");

        clickHouseUrl = resource.getString("clickHouse.Url");
        database=resource.getString("clickHouse.Database");
        clickHouseUser = resource.getString("clickHouse.User");
        clickHousePassword = resource.getString("clickHouse.Password");
        clickHouseMaxBufferSize = resource.getString("clickHouse.maxBufferSize");
        clickHouseMaxQueueSize = resource.getString("clickHouse.maxQueueSize");
        clickHouseTimeoutSec = resource.getString("clickHouse.timeoutSec");
        clickHouseNumWriters = resource.getString("clickHouse.numWriters");
        clickHouseNumRetries = resource.getString("clickHouse.numRetries");
        clickHouseIgnoreExceptionEnable = resource.getString("clickHouse.ignore.exception.enable");
        clickHouseFailRecordPath = resource.getString("clickHouse.fail.record.path");
        clickHousePathInZookeeper= resource.getString("zookeeper.offline.data.path");

        modelSuffixtreeFiltercolumn=resource.getString("model.suffixtree.filtercolumn");
        modelSuffixtreeWindowcount=Integer.parseInt(resource.getString("model.suffixtree.windowcount"));
        modelZkConfig=resource.getString("model.zookeeper.config.path");
        modelHdfsConfig= resource.getString("model.zookeeper.listen.path");
    }
}