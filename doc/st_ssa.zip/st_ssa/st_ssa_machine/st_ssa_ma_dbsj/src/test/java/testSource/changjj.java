package testSource;

import com.ssa.bean.AssetLog;
import org.junit.Ignore;
import org.junit.Test;

public class changjj {
    @Test
    public void addSou(){
        AssetLog assetLog = new AssetLog();
        System.out.println("12345");

    }
}
