package cn.secsmart.easy_dlma

import java.nio.charset.Charset

import org.I0Itec.zkclient.serialize.ZkSerializer

class MyZkSerializer extends ZkSerializer {
  /**
   * 序列化,将对象转化为字节数组
   */
  override def serialize(obj: Any): Array[Byte] = String.valueOf(obj).getBytes(Charset.forName("UTF-8"))

  /**
   * 反序列化,将字节数组转化为UTF-8字符串
   */
  override def deserialize(bytes: Array[Byte]): AnyRef = new String(bytes, Charset.forName("UTF-8"))

}
