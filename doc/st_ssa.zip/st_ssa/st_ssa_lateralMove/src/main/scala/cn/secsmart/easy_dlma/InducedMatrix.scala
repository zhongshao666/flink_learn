package cn.secsmart.easy_dlma

import cn.secsmart.easy_dlma.louvian.VertexState
import org.apache.spark.graphx.Graph
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession, functions}


object InducedMatrix{
//  case class VertexState(community: Long,communitySigmaTot: Long, internalWeight: Long,nodeWeight: Long ,
//                         changed: Boolean,vertexSet: mutable.Set[Long])
  case class ccRes(group_id: Integer, node_id: String)

  val spark: SparkSession = SparkSession.builder().appName("DLMA")
    .master("local[*]").enableHiveSupport().getOrCreate()
  import spark.implicits._

  def get_groupNode(lvGraph:Graph[VertexState, Long]) = {
    val group = lvGraph.vertices.map(line => (Array(line.toString.split(',')(0).replace("(", ""),
      line.toString.split('(')(3).replace(")))", ""))))
    val groupRDD: RDD[ccRes] = group.map(row => ccRes(row(0).toInt, row(1)))
    val df_group = groupRDD.toDF("groupID", "nodeID")
    val df_group_node = df_group.withColumn("nodeID", functions.explode(functions.split($"nodeID", ", ")))
    val df_groupNode = df_group_node.withColumn("nodeID", df_group_node.col("nodeID").cast(IntegerType))
    df_groupNode
  }

  def get_node(df_node_id: DataFrame, df_groupNode: DataFrame) = {
    val cols_1 = Seq("nodeID", "nodeType")
    val df_node_type = df_node_id.select(cols_1.head, cols_1.tail: _*)
    val cols_2 = Seq("groupID", "nodeID", "nodeType")
    val df_groupNodeType = df_groupNode.join(df_node_type, Seq("nodeID"), "left").select(cols_2.head, cols_2.tail: _*)
    df_groupNodeType
  }

  def get_groupPair(df_relation: DataFrame, df_groupUser: DataFrame, df_groupServer: DataFrame) ={
    val df_relationU = df_relation.join(df_groupUser, Seq("userID"), "left")
    val df_relationUS = df_relationU.join(df_groupServer, Seq("serverID"), "left")
    val df_matrix = df_relationUS.groupBy("user_group_id", "server_group_id").sum("edgeWeight")
    val df_group_pair = df_matrix.map(row => ((row.getAs[Int]("user_group_id"), row.getAs[Int]("server_group_id")).toString(),
      row.getAs[Long]("sum(edgeWeight)"))).toDF("group_pair_id", "sum_weight")
    df_group_pair
  }

  /**
   *
   *
   * @param df_groupCount: groupID, count
   * @param df_group_pair: group_pair_id, sum_weight
   * */
  def compute(df_groupCount: DataFrame, df_group_pair: DataFrame):Array[Array[Double]] = {
    //定义空二维数组，元素默认为0
    val com_num = df_groupCount.count().toInt
    val matrix_M: Array[Array[Double]] = Array.ofDim[Double](com_num, com_num)
    //根据分组修改数组元素
    for (i <- 0 until (com_num)) {
      for (j <- 0 until (com_num)) {
        val lst = df_groupCount.select("groupID").collect().map(_(0)).toList
        val group_id_1 = lst(i).toString.toInt
        val group_id_2 = lst(j).toString.toInt
        val single_df = df_group_pair.filter($"group_pair_id" === "(%d,%d)".format(group_id_1, group_id_2))
        if (single_df.count() != 0) {
          val single_list = single_df.select("sum_weight").collect().map(_(0)).toList
          val single_value = single_list.head.toString.toInt
          if (i == j) {
            matrix_M(i)(j) += single_value
          }
          else {
            matrix_M(i)(j) += single_value
            matrix_M(j)(i) += single_value
          }
        }
      }
    }
    //将0元素加一个小数值，方便后续log计算
    for (i <- 0 until com_num) {
      for (j <- 0 until com_num) {
        if (matrix_M(i)(j) == 0) {
          matrix_M(i)(j) = math.pow(10, -10)
        }
      }
    }
    matrix_M
  }
}

























