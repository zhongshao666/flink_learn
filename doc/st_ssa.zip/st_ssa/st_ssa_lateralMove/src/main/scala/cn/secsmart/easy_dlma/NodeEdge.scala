package cn.secsmart.easy_dlma

import org.apache.spark.sql.{DataFrame, functions}

object NodeEdge {

  def get_allNode(event_record_pre: DataFrame) = {
    val df_userPre = event_record_pre.dropDuplicates(Seq("user"))
    val df_userPre2 = df_userPre.na.drop(Seq("user"))
    val df_userPre3 = df_userPre2.drop("server")
    val df_userPre4 = df_userPre3.withColumnRenamed("user", "nodeName")
    val df_user_pre = df_userPre4.withColumn("nodeType", functions.typedLit("user"))

    val df_serverPre = event_record_pre.dropDuplicates(Seq("server"))
    val df_serverPre2 = df_serverPre.na.drop(Seq("server"))
    val df_serverPre3 = df_serverPre2.drop("user")
    val df_serverPre4 = df_serverPre3.withColumnRenamed("server", "nodeName")
    val df_server_pre = df_serverPre4.withColumn("nodeType", functions.typedLit("server"))

    val df_node_pre = df_user_pre.union(df_server_pre)
    df_node_pre
  }

  def get_newNode(df_node_pre: DataFrame, df_node_id: DataFrame) = {
    val cols = Seq("nodeID", "nodeName")
    val df_node_name = df_node_id.select(cols.head, cols.tail: _*)
    val df_newNode = df_node_pre.select("nodeName").except(df_node_name.select("nodeName"))
    val df_new_node = df_newNode.join(df_node_pre, Seq("nodeName"))
    df_new_node
  }

  def get_oldNode(df_node_pre: DataFrame, df_node_id: DataFrame) = {
    val cols = Seq("nodeID", "nodeName", "nodeType")
    val df_node_name = df_node_id.select(cols.head, cols.tail: _*)
    val df_oldNode = df_node_pre.select("nodeName").intersect(df_node_name.select("nodeName"))
    val df_old_node = df_oldNode.join(df_node_name, Seq("nodeName"))
//    println("----------------对比语句结果----------------------")
//    df_old_node.show()
//    val df_old_node1 = df_node_pre.join(df_node_id, Seq("nodeName"))
//    df_old_node1.show()
    df_old_node
  }

  def get_newEdge(event_record_pre: DataFrame, df_old_user_pre: DataFrame, df_old_server_pre: DataFrame, df_groupUser: DataFrame, df_groupServer: DataFrame) ={
    val df_edge_pre = event_record_pre.groupBy("user", "server").count().toDF("userName", "serverName", "count")
    //添加user和server的id
    val df_edge_user_pre = df_edge_pre.join(df_old_user_pre, Seq("userName"), "left")
    val df_edge_user_server_pre = df_edge_user_pre.join(df_old_server_pre, Seq("serverName"), "left")
    //去空
    val df_edge_user_server_pre2 = df_edge_user_server_pre.na.drop(Seq("userID", "serverID"))
    //加节点所属的group_id
    val df_relationPre = df_edge_user_server_pre2.join(df_groupUser, Seq("userID"), "left")
    val df_relationPre2 = df_relationPre.join(df_groupServer, Seq("serverID"), "left")
    val df_relation_pre = df_relationPre2.select("userName", "userID", "user_group_id", "serverName", "serverID", "server_group_id").toDF()
    df_relation_pre
  }


}
