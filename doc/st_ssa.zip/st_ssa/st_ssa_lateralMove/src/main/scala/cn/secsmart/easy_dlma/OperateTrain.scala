package cn.secsmart.easy_dlma

import java.io.ByteArrayInputStream
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.util.{Date, Properties}

import com.alibaba.fastjson.{JSON, JSONObject}
import org.I0Itec.zkclient.ZkClient
import org.apache.log4j.{Level, Logger}
import org.apache.spark.graphx.{Edge, Graph}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Row, SaveMode, SparkSession, functions}
import org.apache.spark.sql.functions.{col, desc, hash, lit}
import org.apache.spark.sql.types._


/**
 * Author: Evie
 * Desc: Detection of Lateral Movement Attacks 横向移动攻击检测
 * Version: v1.0
 * Create_date: 2021-01-29
 * Update_date: 2021-02-08
 */


object OperateTrain {
  //屏蔽日志
  Logger.getLogger("org.apache.spark").setLevel(Level.WARN)
  Logger.getLogger("org.eclipse.jetty.server").setLevel(Level.OFF)

  def main(args: Array[String]): Unit = {
    //从命令行读关于业务类型的参数，来自天枢参数配置
    val parParse = new ParameterParse()
    val parMap = parParse.fromArgs(args)
    val zkServer = parMap("zkServer")  // zk host
    val zkPath = parMap("configPath")  // 配置地址
    val appName = parMap("appName")  // 数据来源
    var dataSource = ""    // 数据来源 01表示数据库审计  02表示api审计
    if (appName == "dbsj") {
      dataSource = "01"
    }else if(appName=="apisj"){
      dataSource = "02"
    }else{
      println(s"=========不存在名称为 $appName 的横向移动攻击检测应用=============")
    }


    val operationParaDetail =
      s"""
         |部分参数说明：
         |
         |user: 代表user的字段
         |server：代表server的字段
         |dataSource: 01表示数据来源于数据库审计，02表示数据来源于api审计
         |blackType: 黑名单类型 01:ip，02:账号，03:MAC，04:HOST
         |""".stripMargin
    println(operationParaDetail)


    //    从zk读取公共properties参数
    //    val zkPath = "/dbsj_audit/dbsj/job/config/model_config"
    val zkClient = new ZkClient(zkServer)
    zkClient.setZkSerializer(new MyZkSerializer)
    val zkServerPar = zkClient.readData(zkPath).toString
    //    println(zkServerPar)


    val dataComProps = new Properties()
    dataComProps.load(new ByteArrayInputStream(zkServerPar.getBytes()))
    //    val ckServer = dataComProps.getProperty("clickhouse.access.hosts")
    //    val ckUser = dataComProps.getProperty("clickhouse.access.user")
    var ckServer = dataComProps.getProperty("clickhouse.host")
    val ckPort = dataComProps.getProperty("clickhouse.port")
    ckServer = ckServer + ":" + ckPort
    val ckUser = dataComProps.getProperty("clickhouse.access.user")
    val ckPassword = dataComProps.getProperty("clickhouse.access.password")
    val ckDatabase = dataComProps.getProperty("clickhouse.dw.database")
    val dbType = "01"  // 数据输出位置的数据库类型, "01"表示mysql
    val mysqlHost = dataComProps.getProperty("mysql.host")
    val mysqlPort = dataComProps.getProperty("mysql.port")
    val mysqlUser = dataComProps.getProperty("mysql.user")
    val mysqlPassword = dataComProps.getProperty("mysql.password")
    val mysqlDatabase = dataComProps.getProperty("mysql.dm.database")
    val mysqlTable = dataComProps.getProperty("mysql.blacklist.table")

    val zkServerPutPathPrefix = dataComProps.getProperty("zookeeper.model.blacklist.listen.path")

    val modelCode = "02"

    //    val zkServer = "192.168.24.250:2181"

    val zkClientGet = new ZkClient(zkServer)
    zkClientGet.setZkSerializer(new MyZkSerializer)

    var zkServerGetPath = ""
    var inputTable = ""
    if(dataSource=="01"){
      zkServerGetPath = dataComProps.getProperty("zookeeper.model.dbsj.dlma.path")
      inputTable = dataComProps.getProperty("clickhouse.dbsj.table")

    }else if(dataSource=="02"){
      zkServerGetPath = dataComProps.getProperty("zookeeper.model.dbsj.dlma.path")
      inputTable = dataComProps.getProperty("clickhouse.apisj.table")
    }
    val zkParas = zkClientGet.readData(zkServerGetPath).toString
    //    println("zooKeeper读取参数为：" + zkParas)

    val jsonParse = JSON.parseObject(zkParas)
    val modelReadJson = jsonParse.getJSONObject("data_config")
    val modelParJson = jsonParse.getJSONObject("judge_suspicion_config")

    val T:Int = modelReadJson.get("use_data_range").toString.toInt
    val t:Int = modelReadJson.get("detect_date_from_now").toString.toInt
    val n:Int = modelParJson.get("path_length").toString.toInt
    val W:Double = modelParJson.get("threshold").toString.toDouble
    val minProgress:Int = modelParJson.get("min_progess").toString.toInt
    val progressCounter:Int = modelParJson.get("progress_counter").toString.toInt
    val blackType = modelReadJson.get("blackType").toString
    val user = modelReadJson.get("user").toString
    val server = modelReadJson.get("server").toString
    //根据读取的参数合成新的参数
    println("=========================================================")
    val inputDBJdbcUrl = s"jdbc:clickhouse://$ckServer/$ckDatabase"
    println(inputDBJdbcUrl)
    val indexID = dataSource + modelCode + blackType  // 作业编号，用于向zk做记录

    val selectedField = user + ", "  + server
    val dbUrl = s"jdbc:mysql://$mysqlHost:$mysqlPort/$mysqlDatabase?useSSL=false&useUnicode=true&characterEncoding=UTF-8&serverTimeZone=UTC"


    val spark = SparkSession.builder().appName("easy_dlma").getOrCreate()
    //    val spark = SparkSession.builder().appName("DLMA").master("local[*]").getOrCreate()
    //    val spark = SparkSession.builder().appName("easy_dlma").master("local[*]").enableHiveSupport().getOrCreate()
    import spark.implicits._

    //     从clickhouse读取数据
    //    println(ckUser, ckServer, ckPassword)
    val sparkSessionWithSet = spark.read.format(source="jdbc")
      .option("driver", "ru.yandex.clickhouse.ClickHouseDriver")
      .option("url", inputDBJdbcUrl)
      .option("user", ckUser)
      .option("password", ckPassword)

    val myObj = new DataRead()
    val p = myObj.getDataFromAssign(spark, tableName = inputTable, selectFields = selectedField,
      timeField="request_time", trainDays = T, detectDay=t, dfReader=sparkSessionWithSet)
    val trainDF = p._1
    //    trainDF.show()
    val rawDF = p._2
    if (trainDF.count() == 0 || rawDF.count() == 0){
      println("------没有训练数据或待检测数据，请更新数据源后再进行检测--------")

    }else {
      val trainRelationDF = myObj.processTrainData(spark, trainDF)
      //      trainRelationDF.show()

      /**
       * 构图，Louvian分组
       */
      val df_relation = trainRelationDF.select("userID", "serverID", "edgeWeight")
        .withColumn("userID", $"userID".cast(LongType))
        .withColumn("serverID", $"serverID".cast(LongType))
        .withColumn("edgeWeight", $"edgeWeight".cast(LongType))
      //      df_relation.show(50)
      // 构图
      val relation: RDD[Row] = df_relation.rdd
      val relationRDD: RDD[Edge[Long]] = relation.map(r => Edge(r.getLong(0), r.getLong(1), r.getLong(2)))
      val trainGraph: Graph[Null, Long] = Graph.fromEdges(relationRDD, null)
      //分组
      println("========================开始执行louvain算法=============================")
      val lvGraph = louvian.run(spark.sparkContext, trainGraph, minProgress, progressCounter)
      println("----------------graph segment is complete----------------------")

      //获取各节点所属的group_id
      val df_groupNode = InducedMatrix.get_groupNode(lvGraph)
      //      df_groupNode.show()
      val userTypeDF = trainRelationDF.select("userID", "user").dropDuplicates().withColumn("nodeType", lit("user"))
        .toDF("nodeID", "nodeName", "nodeType")
      val serverTypeDF = trainRelationDF.select("serverID", "server").dropDuplicates().withColumn("nodeType", lit("server"))
        .toDF("nodeID", "nodeName", "nodeType")
      val df_node_id = userTypeDF.union(serverTypeDF)
      //    df_node_id.show()
      val df_groupNodeType = InducedMatrix.get_node(df_node_id, df_groupNode)
      val df_groupUser = df_groupNodeType.filter($"nodeType" === "user").toDF("user_group_id", "userId", "userType")
      val df_groupServer = df_groupNodeType.filter($"nodeType" === "server").toDF("server_group_id", "serverID", "serverType")
      //群组对的出现频率
      val df_group_pair = InducedMatrix.get_groupPair(df_relation, df_groupUser, df_groupServer)

      //群组大小
      val df_groupCount = df_groupNode.groupBy("groupID").count().orderBy(desc("count"))

      //计算矩阵
      println("==================================开始生成诱导矩阵=====================================================")
      val startTime = LocalDateTime.now().toString
      println(startTime)

      val matrix_M = InducedMatrix.compute(df_groupCount, df_group_pair)

      val endTime = LocalDateTime.now().toString
      println(endTime)
      println("==================================诱导矩阵已经生成====================================================")


      //生成节点DataFrame，包括node_id, node_name, node_weight, node_type四列

      val event_record_pre = rawDF
      //提取所有节点
      val df_node_pre = NodeEdge.get_allNode(event_record_pre)

      //提取预测节点(交集)
      val df_old_node = NodeEdge.get_oldNode(df_node_pre, df_node_id)
      //    df_old_node.show()
      //提取边
      val df_old_user_pre = df_old_node.filter($"nodeType" === "user")

      val df_old_user_pre2 = df_old_user_pre.select("nodeID", "nodeName").toDF("userId", "userName")
      val df_old_server_pre = df_old_node.filter($"nodeType" === "server")

      val df_old_server_pre2 = df_old_server_pre.select("nodeID", "nodeName").toDF("serverID", "serverName")
      val df_relation_pre = NodeEdge.get_newEdge(event_record_pre, df_old_user_pre2, df_old_server_pre2, df_groupUser, df_groupServer)
      //      df_relation_pre.show()

      //生成边DataFrame，包括user_id, server_name, server_id, server_name, edge_weight五列

      //为边添加权重
      println("=================================开始计算各个边的权重====================================================")
      val groupList: List[String] = df_groupCount.select("groupId").rdd.map(_.mkString(",")).collect().toList

      def get_weight(row: Row): Double = {
        val index_i = groupList.indexOf(row.getAs[Int]("user_group_id").toString)
        val index_j = groupList.indexOf(row.getAs[Int]("server_group_id").toString)
        val M = matrix_M(index_i)(index_j)
        val lambda = math.BigDecimal(M) / (math.BigDecimal(T) / math.BigDecimal(1))  //默认检测范围数据为1天
        val p = 1 - math.pow(math.E, -lambda.toDouble)
        val weight = -math.log(p)
        weight
      }

      val df_weight_pre = df_relation_pre.map(row => get_weight(row)).toDF("edgeWeight")
      val df_weight_pre2 = df_weight_pre.withColumn("Index", functions.monotonically_increasing_id)
      val df_relation_pre2 = df_relation_pre.withColumn("Index", functions.monotonically_increasing_id)
      val df_relation_weight_pre = df_relation_pre2.join(df_weight_pre2, Seq("Index"), joinType = "left")


      /**
       * 构建横向移动图
       */

      val relation_pre: RDD[Row] = df_relation_weight_pre.rdd
      val relationRddC_pre: RDD[Edge[Double]] = relation_pre.map(r => Edge(r.getAs[Int]("userID"),
        r.getAs[Int]("serverID"), r.getAs[Double]("edgeWeight")))
      val graphC_pre: Graph[Null, Double] = Graph.fromEdges(relationRddC_pre, null)

      /**
       * 寻找可疑路径
       */

      //遍历所有路径
      val allPaths = AbnormalRoad.all_Paths(graphC_pre, n)
      //    allPaths.show()
      val df_allPaths = allPaths.toDF("road")


      val df_allPaths_2 = df_allPaths.withColumn("Index", functions.monotonically_increasing_id)
      //    df_allPaths_2.show(20)
      //计算路径的权重和
      val weights = AbnormalRoad.all_weights(allPaths, graphC_pre)
      val df_weights = weights.toDF("total_weight")
      val df_weights_2 = df_weights.withColumn("Index", functions.monotonically_increasing_id)
      //    df_weights_2.show(20)

      val df_allPaths_weight = df_allPaths_2.join(df_weights_2, usingColumns=Seq("Index"), joinType="left")
        .select("Index", "road", "total_weight")

      //      df_allPaths_weight.show()
      val abnormalRoad = df_allPaths_weight.filter(_.getDouble(2) > W)
      //      abnormalRoad.show()

      // n为路径长度,将路径上的每个节点生成一列
      val nodeSplitDF = abnormalRoad.select(
        (0 until n).map(i => col("road")(i).alias(s"col$i")): _*
      )
      //      nodeSplitDF.show()
      val nodeColNames = nodeSplitDF.columns.toList
      var nodeInitCol = nodeSplitDF.select(nodeColNames.head)
      for (i <- 1 until n) {
        nodeInitCol = nodeInitCol.union(nodeSplitDF.select(nodeColNames(i)))
      }
      val abnormalNodeDF = nodeInitCol.dropDuplicates().toDF("NodeID")
      //      abnormalNodeDF.show()

      val userDF = event_record_pre.withColumn("NodeID", hash($"user"))
      val abnormalUser = abnormalNodeDF.join(userDF, "NodeID").dropDuplicates("NodeID")
      //      abnormalUser.show()


      // =====================构造输出数据==================================
      val todayFormat = "yyyy-MM-dd"
      val DateObj = new SimpleDateFormat(todayFormat)
      val todayString = DateObj.format(new Date())
      val suspiciousNodeDF = abnormalUser.select("user").toDF("typeValue")
        .withColumn("updateDate", lit(todayString))
        .withColumn("modelType", lit(modelCode)) // "02"表示横向移动攻击检测模型
        .withColumn("dataType", lit(dataSource)) // "02"表示API审计
        .withColumn("blackType", lit(blackType)) // "02"表示账号

      // 将结果黑名单写入指定的数据库
      val suspiciousNum = suspiciousNodeDF.count()
      println("嫌疑对象数量为：" + suspiciousNum)
      println("开始将结果写入数据库")
      val prop = new Properties()
      prop.put("user", mysqlUser)
      prop.put("password", mysqlPassword)
      //      suspiciousNodeDF.write.mode(SaveMode.Append).jdbc(dbUrl, outputTable, prop)
      suspiciousNodeDF.write.format("jdbc")
        .option("url", dbUrl)
        .option("dbtable", mysqlTable)
        .option("driver", "com.mysql.jdbc.Driver")
        .option("user", mysqlUser)
        .option("password", mysqlPassword)
        .mode(SaveMode.Append)
        .save()
      println("数据库写入完成")
      // ===========================================================================

      /**
       * 完成后发送消息给zk告知已经完成
       * */
      val zkPathPut = zkServerPutPathPrefix + "/" +indexID
      val currentTime = new Date().getTime
      val zkClientPut = new ZkClient(zkServer)
      zkClientPut.setZkSerializer(new MyZkSerializer)
      val msgJsonObj = new JSONObject()
      msgJsonObj.put("indexID", indexID)
      msgJsonObj.put("dateTime", currentTime)
      msgJsonObj.put("state", 1)  //状态1表示成功
      msgJsonObj.put("dbtype", dbType)
      val msgJsonString = msgJsonObj.toJSONString
      println(msgJsonString)
      if (!zkClientPut.exists(zkPathPut)) {
        zkClientPut.createPersistent(zkPathPut, true)
      }
      zkClientPut.writeData(zkPathPut, msgJsonString)

    }


  }
}

