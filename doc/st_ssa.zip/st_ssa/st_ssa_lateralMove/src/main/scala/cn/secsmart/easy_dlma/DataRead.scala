package cn.secsmart.easy_dlma

import org.apache.spark.sql.functions.{count, hash}
import java.time.LocalDate

import org.apache.spark.sql.{DataFrame, DataFrameReader, SparkSession}


class DataRead {
  /**
   * 读取前一天的数据生成等待处理的关系数据, 读取昨天之前的n天的数据生成关系数据用来划分类别和生成诱导矩阵
   * @param ss: SparkSession
   * @param tableName: 表名，xxx.yyy
   * @param selectFields: sql语句中选择的两个字段组成的字符串，例如："account, client_mac"
   * @param timeField: sql语句中筛选时间范围的字段
   * @param trainDays: 指定用多少天数据进行训练
   * @param detectDay: 指定检测哪一天的数据（距离当前时间多少天）
   * @param dfReader: 带配置的DataFrameReader，用来执行sql语句读取数据
   * @return a tuple，第一个元素是处理好的训练数据DataFrame，第二个元素是待检测数据DataFrame
   * */
  def getDataFromAssign(ss: SparkSession, tableName:String, selectFields:String, timeField:String, trainDays:Int,
                        detectDay:Int, dfReader: DataFrameReader):(DataFrame, DataFrame)={  //, dfReader: DataFrameReader
    val today = LocalDate.now()
    val detectDate = today.minusDays(detectDay).toString
    val startDate = today.minusDays(detectDay+trainDays).toString
    val endDate = today.minusDays(detectDay-1).toString
    val trainDataSql =
      s"""select $selectFields from $tableName where $timeField < '$detectDate' and $timeField >=
         |'$startDate'""".stripMargin
//    val trainDF = ss.sql(trainDataSql).toDF(colNames = "user", "server")
    val trainDF = dfReader.option("query", trainDataSql).load().toDF(colNames = "user", "server")
    val rawDataSql =
      s"""select $selectFields from $tableName where $timeField >= '$detectDate' and $timeField
         |< '$endDate'""".stripMargin
//    val rawDF = ss.sql(rawDataSql).toDF(colNames = "user", "server")
    val rawDF = dfReader.option("query", rawDataSql).load().toDF(colNames = "user", "server")
    (trainDF, rawDF)
  }

  /**
   *  统计边的权重，并对user、server节点分别添加节点id
   * */
  def processTrainData(ss: SparkSession, df:DataFrame): DataFrame = {

    var edgeDF = df.groupBy("user", "server").agg(count("user").as("edgeWeight"))

    import ss.implicits._
    edgeDF = edgeDF.withColumn("userID", hash($"user"))
      .withColumn("serverID", hash(edgeDF("server")))
    edgeDF
  }



}
