package cn.secsmart.easy_dlma

import org.apache.spark.graphx.{EdgeDirection, Graph, VertexId}

import scala.collection.mutable.ArrayBuffer

object AbnormalRoad {
  def findPaths(G: Graph[Null, Double], node: VertexId, n: Int): ArrayBuffer[ArrayBuffer[VertexId]] = {
    if (n == 0) {
      val paths = ArrayBuffer[ArrayBuffer[VertexId]]()
      paths.append(ArrayBuffer(node))
      paths
    }
    else {
      val paths = ArrayBuffer[ArrayBuffer[VertexId]]()
      val all_neighbors = G.collectNeighborIds(edgeDirection = EdgeDirection.Either)
      val neighbors = all_neighbors.filter(_._1 == node)
      neighbors.take(1)(0)._2.foreach(k => {
        for (path <- findPaths(G, k, n - 1)) {
          if (!path.contains(node)) {
            paths.append(ArrayBuffer(node).++=(path))
          }
        }
      })
      paths
    }
  }

  def all_Paths(graphC_pre: Graph[Null, Double], n: Int): ArrayBuffer[ArrayBuffer[VertexId]] = {
    var allPaths = ArrayBuffer[ArrayBuffer[VertexId]]()
    val nodes = graphC_pre.vertices.collect()
    for (node <- nodes) {
      for (path <- findPaths(graphC_pre, node._1, n)) {
        if (!allPaths.contains(path.reverse)) {
          allPaths.+=(path)
        }
      }
    }
    allPaths
  }

  def computeWeight(graphC_pre: Graph[Null, Double], path: ArrayBuffer[VertexId]): Double = {
    if (path.length <= 1) {
      val totalWeight = 0
      totalWeight
    }
    else {
      val allEdges = graphC_pre.edges.collect()
      var my_weight = allEdges.filter(_.srcId == path(0)).filter(_.dstId == path(1))
      if (my_weight.isEmpty) {
        my_weight = allEdges.filter(_.srcId == path(1)).filter(_.dstId == path(0))
      }
      var totalWeight = my_weight.take(1)(0).attr
      totalWeight += computeWeight(graphC_pre, path.slice(1, path.length))
      totalWeight
    }
  }

  def all_weights(allPaths: ArrayBuffer[ArrayBuffer[VertexId]], graphC_pre: Graph[Null, Double]): ArrayBuffer[Double] = {
    val weights = ArrayBuffer[Double]()
    for (path <- allPaths) {
      weights.+=(AbnormalRoad.computeWeight(graphC_pre, path))
    }
    weights
  }


}
