package com.secsmart.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * @author : hld
 * @Date ： 2021/4/19
 * @Time : 17:23
 * @role ：
 */
public class CsvUtils {

    private static final Character CK_QUOTE_CHAR = '\'';
    private static final Character CK_ESCAPE_CHAR = '\\';
    private static final Character CK_LINE_BEGIN = '(';
    private static final Character CK_LINE_END = ')';
    private static final Character SEPARATOR = ',';
    private static final Character QUOTE_CHAR = '"';
    private static final Character ESCAPE_CHAR = '"';
    private static final Character LINE_END = '\n';
    private static final Character CARRIAGE_RETURN = '\r';
    private static final Character CK_ARRAY_BEGIN = '[';
    private static final Character CK_ARRAY_END = ']';

    /**
     * Array转换为String
     */

    public static String convertToCkCsvFormatByArray(List<String> value, Character begin, Character end) {
        StringBuilder builder = new StringBuilder();

        builder.append(begin);
        for (int i = 0; i < value.size(); i++) {
            if (i != 0) {
                builder.append(SEPARATOR);
            }

            if (value.get(i) != null && value.get(i).startsWith("[") && value.get(i).length() > 2) {
            }
            if (value.get(i) == null || !value.get(i).startsWith("[")) {
                builder.append(CK_QUOTE_CHAR);
            }
            Optional.ofNullable(value.get(i))
                    .ifPresent(item -> {
                        if (item.indexOf(CK_QUOTE_CHAR) != -1 || item.indexOf(CK_ESCAPE_CHAR) != -1 ) {
                            if (item.startsWith(CK_ARRAY_BEGIN.toString())){
                                builder.append(item);
                            }else {
                                processCkLine(item, builder);
                            }
                        } else {
                            builder.append(item);
                        }
                    });
            if (value.get(i) == null || !value.get(i).startsWith("[")) {
                builder.append(CK_QUOTE_CHAR);
            }
        }

        builder.append(end);
        return builder.toString();
    }

    /**
     * 双层list处理
     */
    public static String convertToCkCsvFormatByTwoArray(List<List<String>> value) {
        ArrayList<String> arrayList = new ArrayList<>();

        for (List<String> list : value) {
            if (list.size() > 0) {
                arrayList.add(convertToCkCsvFormatByArray(list, CK_ARRAY_BEGIN, CK_ARRAY_END));
            }
        }
        return convertToCkCsvFormatByArray(arrayList, CK_ARRAY_BEGIN, CK_ARRAY_END);
    }

    /**
     * 处理ck line
     *
     * @param nextElement
     * @param appendable
     */
    private static void processCkLine(String nextElement, StringBuilder appendable) {
        for (int j = 0; j < nextElement.length(); ++j) {
            char nextChar = nextElement.charAt(j);
            if (checkCkCharactersToEscape(nextChar)) {
                appendable.append(CK_ESCAPE_CHAR);
            }

            appendable.append(nextChar);
        }
    }

    /**
     * 检查是否需要转义
     *
     * @param nextChar
     * @return
     */
    protected static boolean checkCkCharactersToEscape(char nextChar) {
        return nextChar == CK_QUOTE_CHAR || nextChar == CK_ESCAPE_CHAR;
    }

    /**
     * 循环单条Columns
     */

    private static StringBuilder coverToCkCsvStringList(StringBuilder builder, List<String> value) {
        for (int i = 0; i < value.size(); i++) {
            if (i != 0) {
                builder.append(SEPARATOR);
            }

            Optional.ofNullable(value.get(i))
                    .ifPresent(item -> {
                        if (!item.startsWith(CK_ARRAY_BEGIN.toString())) {
                            builder.append(CK_QUOTE_CHAR);
                        }

                        if ((item.indexOf(CK_QUOTE_CHAR) != -1 || item.indexOf(CK_ESCAPE_CHAR) != -1) && !item.startsWith(CK_ARRAY_BEGIN.toString())) {
                            processCkLine(item, builder);
                        } else {
                            builder.append(item);
                        }
                        if (!item.startsWith(CK_ARRAY_BEGIN.toString())) {
                            builder.append(CK_QUOTE_CHAR);
                        }
                    });

        }
        return builder;
    }
}
