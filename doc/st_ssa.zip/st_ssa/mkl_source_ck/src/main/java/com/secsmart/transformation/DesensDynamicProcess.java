package com.secsmart.transformation;

import com.secsmart.utils.CsvUtils;
import com.secsmart.utils.IdWorker;
import com.secsmart.utils.SplitUtils;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DesensDynamicProcess extends ProcessFunction<String, String> {

    private static final Character CK_LINE_BEGIN = '(';
    private static final Character CK_LINE_END = ')';
    private SplitUtils splitUtils;

    ArrayList<String> list;


    @Override
    public void open(Configuration parameters) throws Exception {
        list = new ArrayList<>();
        splitUtils = new SplitUtils();
    }

    @Override
    public void processElement(String value, Context ctx, Collector<String> out) throws Exception {
        try {

            if (value.startsWith("<")) {


                long id = IdWorker.getInstance().nextId();

                String[] split = value.split(":\\s+");

                List<String> strings = Arrays.asList(split[1].split("\\s+"));


                list.clear();
                list.addAll(strings);

                splitUtils.splitList(list, 1);

                list.add(0, String.valueOf(id));

                list.set(list.size() - 2, list.get(list.size() - 2) + " " + list.get(list.size()-1));
                list.remove(list.size()-1);

                out.collect(CsvUtils.convertToCkCsvFormatByArray(list, CK_LINE_BEGIN, CK_LINE_END));

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
