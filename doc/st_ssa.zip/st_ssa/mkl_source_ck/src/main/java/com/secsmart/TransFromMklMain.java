package com.secsmart;

import com.secsmart.transformation.AssetsProcess;
import com.secsmart.utils.CuratorOperator;
import com.secsmart.utils.KafkaSinkProp;
import com.secsmart.utils.KafkaSourceProp;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.api.GetDataBuilder;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer;
import org.apache.flink.util.OutputTag;
import ru.ivi.opensource.flinkclickhousesink.ClickHouseSink;
import ru.ivi.opensource.flinkclickhousesink.model.ClickHouseSinkConst;

import java.io.ByteArrayInputStream;
import java.util.Map;
import java.util.Properties;

public class TransFromMklMain {

    public static OutputTag<String> assetLog = new OutputTag<String>("assetLog"){
    };
    public static OutputTag<String> desensStatic = new OutputTag<String>("desensStatic"){
    };
    public static OutputTag<String> desensDynamic = new OutputTag<String>("desensDynamic"){
    };
    public static OutputTag<String> encrypt = new OutputTag<String>("encrypt"){
    };
    public static OutputTag<String> assetSorting = new OutputTag<String>("assetSorting"){
    };
    public static OutputTag<String> controlSystem = new OutputTag<String>("controlSystem"){
    };
    public static OutputTag<String> traceability = new OutputTag<String>("traceability") {
    };

    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment environment = StreamExecutionEnvironment.getExecutionEnvironment();
        environment.setRestartStrategy(RestartStrategies.fixedDelayRestart(1000, Time.seconds(3)));

        ParameterTool map = ParameterTool.fromArgs(args);
        Properties properties = new Properties();
        CuratorOperator mcto = null;
//        mcto = new CuratorOperator("192.168.24.73:2181");
        mcto = new CuratorOperator(map.get("zkAddr"));
        GetDataBuilder data = mcto.client.getData();
//        properties.load(new ByteArrayInputStream(data.forPath("/dbsj_audit/dbsj/job/config/riskflinkjob")));
        properties.load(new ByteArrayInputStream(data.forPath(map.get("zkPath"))));
        ParameterTool parameterTool = ParameterTool.fromMap((Map) properties);

        environment.getConfig().setGlobalJobParameters(parameterTool);

        KafkaSinkProp kafkaSinkProp = new KafkaSinkProp();
        kafkaSinkProp.setBOOTSTRAP_SERVERS_CONFIG(parameterTool.get("kafka.url"));

        KafkaSourceProp kafkaSourceProp = new KafkaSourceProp();

        kafkaSourceProp.setBOOTSTRAP_SERVERS_CONFIG(parameterTool.get("kafka.url"));
        kafkaSourceProp.setGROUP_ID_CONFIG(parameterTool.get("kafka.source.groupId"));

        FlinkKafkaConsumer<String> assets = new FlinkKafkaConsumer<String>(parameterTool.get("kafka.source.topic"), new SimpleStringSchema(), kafkaSourceProp.getProp());



        SingleOutputStreamOperator<String> assetsStream = environment.addSource(assets).process(new AssetsProcess());


       assetsStream.getSideOutput(desensStatic).addSink(new ClickHouseSink(getHttpLogCkProp(parameterTool, parameterTool.get("clickHouse.Table.desensstatic"))));
        assetsStream.getSideOutput(desensDynamic).addSink(new ClickHouseSink(getHttpLogCkProp(parameterTool, parameterTool.get("clickHouse.Table.desensdynamic"))));
        assetsStream.getSideOutput(encrypt) .addSink(new ClickHouseSink(getHttpLogCkProp(parameterTool, parameterTool.get("clickHouse.Table.encrypt"))));
        assetsStream.getSideOutput(assetSorting).addSink(new ClickHouseSink(getHttpLogCkProp(parameterTool, parameterTool.get("clickHouse.Table.assetsorting"))));
        assetsStream.getSideOutput(controlSystem).addSink(new ClickHouseSink(getHttpLogCkProp(parameterTool, parameterTool.get("clickHouse.Table.control.system"))));
        assetsStream.getSideOutput(traceability).addSink(new ClickHouseSink(getHttpLogCkProp(parameterTool, parameterTool.get("clickHouse.Table.traceability"))));


        environment.execute("asset log encrypt");
    }


    /**
     * Asset_log ck config
     *
     * @return
     */
    public static Properties getHttpLogCkProp(ParameterTool parameterTool, String table) {

        Properties properties = new Properties();
        properties.put(ClickHouseSinkConst.TARGET_TABLE_NAME, parameterTool.get("clickHouse.Database") + "." + table);
        properties.put(ClickHouseSinkConst.MAX_BUFFER_SIZE, parameterTool.get("clickhouse.sink.max-buffer-size"));
        return properties;
    }
}
