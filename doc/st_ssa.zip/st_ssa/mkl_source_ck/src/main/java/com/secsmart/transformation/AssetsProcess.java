package com.secsmart.transformation;

import com.alibaba.fastjson.JSON;
import com.secsmart.TransFromMklMain;
import com.secsmart.bean.AssetLog;
import com.secsmart.utils.CsvUtils;
import com.secsmart.utils.IdWorker;
import com.secsmart.utils.SplitUtils;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

public class AssetsProcess extends ProcessFunction<String, String> {

    private static final Character CK_LINE_BEGIN = '(';
    private static final Character CK_LINE_END = ')';

    private SplitUtils splitUtils;

    private Context context;
    private Map<String, String> tableMap;

    @Override
    public void open(Configuration parameters) throws Exception {
        splitUtils = new SplitUtils();
        tableMap = new HashMap<>();
    }

    @Override
    public void processElement(String value, Context ctx, Collector<String> out) throws Exception {

        try {

            long id = IdWorker.getInstance().nextId();

            List<String> collect = Arrays.stream(value.split("(\")?,?(field[0-9]{2}=)[\"]?")).collect(Collectors.toList());
            String strColl = collect.get(collect.size() - 1);
            collect.set(collect.size()-1, strColl.substring(0,strColl.length()-1));

            collect.set(0, String.valueOf(id));

            if ("数据加解密".equals(collect.get(1))) {
                boolean bool = splitUtils.splitList(collect, 3);
                String array = CsvUtils.convertToCkCsvFormatByArray(collect, CK_LINE_BEGIN, CK_LINE_END);
                if (bool) {
                    ctx.output(TransFromMklMain.encrypt, array);
                }
            } else if ("动态脱敏".equals(collect.get(1))) {
                boolean bool = splitUtils.splitList(collect, 2);
                String array = CsvUtils.convertToCkCsvFormatByArray(collect, CK_LINE_BEGIN, CK_LINE_END);
                if (bool) {
                    ctx.output(TransFromMklMain.desensDynamic, array);
                }
            } else if ("静态脱敏".equals(collect.get(1))) {
                boolean bool = splitUtils.splitList(collect, 3);
                boolean bool2 = splitUtils.splitList(collect, 2);
                tableMap.clear();
                context = ctx;
                splitDesensStatic(collect, bool && bool2);
            } else if (collect.size() == 9) {
                String array = CsvUtils.convertToCkCsvFormatByArray(collect, CK_LINE_BEGIN, CK_LINE_END);
                ctx.output(TransFromMklMain.assetSorting, array);
            } else if (collect.size() == 22) {
                String str = transFormationAssetLog(collect);
                ctx.output(TransFromMklMain.assetLog, str);
            } else if (collect.size() == 13) {
                String array = CsvUtils.convertToCkCsvFormatByArray(collect, CK_LINE_BEGIN, CK_LINE_END);
                ctx.output(TransFromMklMain.controlSystem, array);
            } else if (collect.size() == 10) {
                boolean bool = splitUtils.splitList(collect, 5);
                boolean bool2 = splitUtils.splitList(collect, 3);
                String array = CsvUtils.convertToCkCsvFormatByArray(collect, CK_LINE_BEGIN, CK_LINE_END);
                if (bool && bool2) {
                    ctx.output(TransFromMklMain.traceability, array);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void splitDesensStatic(List<String> collect, Boolean bool) {

        Arrays.stream(collect.get(10).split(",")).forEach(item -> {
            tableMap.put(item.split("->")[0].split("\\.")[1], item);
        });

        Arrays.stream(collect.get(11).split(",")).forEach(item -> {
            String tableMap = this.tableMap.get(item.split("\\.")[0]);
            collect.set(10, tableMap);
            collect.set(11, item);
            String array = CsvUtils.convertToCkCsvFormatByArray(collect, CK_LINE_BEGIN, CK_LINE_END);
            if (bool) {
                context.output(TransFromMklMain.desensStatic, array);
            }
        });
    }

    private String transFormationAssetLog(List<String> strings) {

        try {
            AssetLog assetLog = new AssetLog();

            assetLog.setSessionId(strings.get(0));
            assetLog.setClientIp(strings.get(1));
            assetLog.setClientPort(Integer.parseInt(strings.get(2)));
            assetLog.setClientMac(strings.get(3));
            assetLog.setClientHost(strings.get(4));
            assetLog.setOsUserName(strings.get(5));
            assetLog.setServerIp(strings.get(6));
            assetLog.setServerPort(Integer.parseInt(strings.get(7)));
            assetLog.setServerMac(strings.get(8));
            assetLog.setRequestTime(LocalDateTime.parse(strings.get(9), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());
            assetLog.setAccount(strings.get(10));
            assetLog.setOperandType(strings.get(11));
            assetLog.setOperationType(switchOperationType(strings.get(12)));
            assetLog.setOperationCommand(strings.get(13));
            assetLog.setOperandName(setOperandName(strings.get(14)));
            assetLog.setSecondOperandName(setSecondOperandName(strings.get(15)));
            assetLog.setRequestStatus(Integer.parseInt(strings.get(16)) == 1 ? 1803 : 1804);
            assetLog.setExecuteTime(Long.parseLong(strings.get(17)));
            assetLog.setRowsAffected(Integer.parseInt(strings.get(18)));
            assetLog.setOperationStatement(strings.get(19));
            assetLog.setReply(setReply(strings.get(20)));

            return JSON.toJSONString(assetLog);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private Integer switchOperationType(String str) {
        switch (str) {
            case "LOGIN":
                return 1;
            case "LOGOUT":
                return 2;
            case "DDL":
                return 3;
            case "DML":
                return 4;
            case "DCL":
                return 5;
            case "TCL":
                return 6;
            case "RCL":
                return 7;
            case "PPL":
                return 8;
            case "AD":
                return 9;
            case "UT":
                return 10;
            case "PRIVILEGE":
                return 11;
            case "OTHER":
                return 12;
            default:
                return 0;
        }
    }

    private List<String> setOperandName(String str) {
        ArrayList<String> strings = new ArrayList<>();
        String[] strings1 = str.split("、");
        for (String s : strings1) {
            String[] split = s.split("\\.");
            strings.add(split[split.length - 1]);

        }
        return strings;
    }

    private List<String> setSecondOperandName(String str) {
        ArrayList<String> strings = new ArrayList<>();
        String[] strings1 = str.split("、");
        for (String s : strings1) {
            String[] split = s.split("\\.");
            strings.add(split[split.length - 2] + "." + split[split.length - 1]);

        }
        return strings;
    }

    private List<List<String>> setReply(String str) {
        ArrayList<List<String>> lists = new ArrayList<>();
        for (String s : str.split(":")) {
            lists.add(new ArrayList<>(Arrays.asList(s.split("、"))));
        }
        return lists;
    }
}
