package com.secsmart.constants;

/**
 * @author : hld
 * @Date ： 2021/4/10
 * @Time : 11:20
 * @role ：
 */
public class AssetLogConstants {

    /**
     * 模型类别
     */
    public enum modelType{
        /**
         * 复杂网络
         */
        FZWL("01"),
        /**
         * 横向移动
         */
        HXYD("02"),
        SJXL("03"),
        SJXLSEN("04"),
        FALLACCOUNT("05");

        private String values;

        modelType(String values) {
            this.values = values;
        }

        public String getValues() {
            return this.values;
        }
    }

    /**
     * 黑名单类别
     */
    public enum blackType{
        IP("01"),
        ACCOUNT("02"),
        MAC("03"),
        HOST("04");

        private String values;

        blackType(String values) {
            this.values = values;
        }

        public String getValues() {
            return this.values;
        }
    }

    /**
     * 保护手段
     */
    public enum protectOperate {
        /**
         * 通过，允许数据库操作通过防火墙发送到数据库上执行
         */
        OPPASS(1401),
        /***
         * 不记日志
         */
        OPNOTLOG(1402),
        /**
         * 丢弃，仅拦截该请求，模拟数据库返回没有权限的错误
         */
        OPDROP(-1),
        /**
         * 阻断，断开该绘画，使得后续不能再执行操作，暂时不支持
         */
        OPBLOCK(-1),
        /**
         * 禁止，禁止该客户端/账号不能再连接数据库，暂时不支持
         */
        OPBAN(-1);

        private Integer values;

        protectOperate(Integer values) {
            this.values = values;
        }

        public Integer getValues() {
            return this.values;
        }
    }

    /**
     *请求状态码
     */
    public enum requestStatus {
        /**
         * 未知
         */
        SSUNKNOWN(1801),
        /**
         * 未应答
         */
        SSQUEST(1802),
        /**
         * 成功
         */
        SSSUCCESS(1803),
        /**
         * 失败
         */
        SSFAIL(1804),
        /**
         * 超时
         */
        SSTIMEOUT(1805),
        /**
         * 无效请求
         */
        SSINVAILD(1806),
        /**
         * 会话断开
         */
        SSEND(1807);

        private Integer values;

        requestStatus(Integer values) {
            this.values = values;
        }

        public Integer getValues() {
            return this.values;
        }
    }

    /**
     * 敏感数据标签
     */
    public enum eSensitiveType {
        /**
         * 敏感数据库标签
         */
        TABLELABEL(1),
        /**
         * 敏感COLUMN标签
         */
        COLUMNLABEL(2);

        private Integer values;

        eSensitiveType(Integer values) {
            this.values = values;
        }

        public Integer getValues() {
            return this.values;
        }
    }
    /**
     * 标签枚举类
     */
    public enum strategyLabelType {
        /**
         * 非工作时间
         */
        NONWORKING("02040101"),
        /**
         * 威胁情报ip
         */
        THREAT_IP("06010101"),
        /**
         * 模型黑名单
         */
        FZWL_IP("06010102"),
        FZWL_ACCOUNT("06010103"),
        FZWL_MAC("06010104"),
        FZWL_HOST("06010105"),
        HXYD_IP("06010106"),
        HXYD_ACCOUNT("06010107"),
        HXYD_MAC("06010108"),
        HXYD_HOST("06010109"),
        SJXL_IP("0601010a"),
        SJXL_ACCOUNT("0601010b"),
        SJXL_MAC("0601010c"),
        SJXL_HOST("0601010d"),
        SJXL_SENSITIVE_IP("0601010e"),
        SJXL_SENSITIVE_ACCOUNT("0601010f"),
        SJXL_SENSITIVE_MAC("06010111"),
        SJXL_SENSITIVE_HOST("06010112"),
        FALL_ACCOUNT("06010113"),
        /**
         * 异地登陆
         */
        DIFFERENT_ADDRESS_LOGIN("02010101"),

        /**
         * 4A 认证绕行
         */
        CERTIFICATION_BYPASS("02090101"),
        /**
         * 撞库攻击，登录密码连续错误(账号)
         */
        PASSWORD_INCORRECT_ACCOUNT("02080101"),
        /**
         * 撞库攻击，登录密码连续错误(IP)
         */
        PASSWORD_INCORRECT_IP("02070101"),
        /**
         * 账号共享
         */
        ACCOUNT_SHARING("02060101"),

        /**
         * 初次下载敏感数据离线查询
         */
        SENSITIVE_FIRST_DOWNLOAD("01030101"),
        /**
         * 异常终端下载敏感数据（账号)
         */
        SENSITIVE_ABNORMAL_CLIENTMAC("01040101"),
        /**
         * 下载非常用敏感表
         */
        SENSITIVE_NONUSE_TABLE("01060101"),
        /**
         * 下载非常用敏感库
         */
        SENSITIVE_NONUSE_DATABASE("01070101"),
        /**
         * 来自恶意源的敏感数据下载
         */
        SENSITIVE_MALICIOUS_DOWNLOAD("01010101"),
        /**
         * 非工作时间下载敏感数据
         */
        SENSITIVE_DOWNLOAD_NONWORKTIME("01050101"),
        /**
         * 沉默账号下载敏感数据
         */
        SENSITIVE_SILENCEACCOUNT_DOWNLOAD("01080101"),
        /**
         * 后台变更敏感数据字段
         */
        SENSITIVE_ABNORMAL_OPERATION("05010101"),
        /**
         * 敏感数据下载量异常
         */
        SENSITIVE_DOWN_MORE_IP("01090101"),
        SENSITIVE_DOWN_MORE_ACCOUNT("01090102"),

        /**
         * 僵尸账号复活
         */
        ZOMBIE_ACCOUNT_ACTIVE("020a0101"),
        /**
         * 多次访问不存在的文件
         */
        MUTILE_NON_FILE_IP("02020101"),
        MUTILE_NON_FILE_ACCOUNT("02020102"),

        /**
         * 多次尝试访问没有权限的文件
         */
        MUTILE_NON_AUTH_IP("02030101"),
        MUTILE_NON_AUTH_ACCOUNT("02030102"),

        /**
         * 执行SQL语句异常
         */
        OPERATE_SQL_IP("02050101"),
        OPERATE_SQL_ACCOUNT("02050102"),
        /**
         * 数据库高危操作
         */
        DB_DROP("04010101"),
        /**
         * 异常地理位置下载敏感数据
         */
        FOREIGN_IP_DOWN("010a0101"),
        /**
         * 外网ip下载敏感数据
         */
        INTRANET_IP_DOWN("01020101"),
        /**
         * sql注入
         */
        SQL_INJECTION("03010101");



        private String values;
        strategyLabelType(String val){
            this.values = val;
        }
        public String getVal(){
            return this.values;
        }
    }

    /**
     * 数据库操作类型operationType
     */
    public enum operationTypeCatalog{
        /**
         * 未知
         */
        CTUNKNOWN (0),
        /**
         * 登录
         */
        CTLOGIN    (1),
        /**
         *登出
         */
        CTLOGOUT  (2),
        /**
         *数据定义，包括create,alter,drop,truncate,comment,rename等
         */
        CTDDL      (3),
        /**
         *数据操作，包括select,insert,update,delete,mgeer,call,explain, plan,lock table等
         */
        CTDML     (4),
        /**
         *数据控制，包括grant,revoke
         */
        CTDCL        (5),
        /**
         * transaction_statement,    包括savepoint,rollback,set transaction
         */
        CTTCL       (6),
        /**
         * replication_statement，如主从相关操作
         */
        CTRCL       ( 7),
        /**
         *  prepared_statement
         */
        CTPPL        (8),
        /**
         *  administration_statement,管理操作
         */
        CTAD         (9),
        /**
         * utility_statement
         */
        CTUT        (10),
        CTPRIVILEGE  (11),
        CTOTHER     (12);
        private Integer values;

        operationTypeCatalog(Integer values) {
            this.values = values;
        }

        public Integer getValues() {
            return this.values;
        }
    }
}