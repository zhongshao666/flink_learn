package com.secsmart.utils;


import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SplitUtils {

    public boolean splitList(List<String> strList, Integer index){
        String str = strList.get(index);


        Matcher matcher = Pattern.compile("((2(5[0-5]|[0-4]\\d))|[0-1]?\\d{1,2})(\\.((2(5[0-5]|[0-4]\\d))|[0-1]?\\d{1,2})){3}.*").matcher(str);
        if (matcher.find()) {

            setUrl(strList, str.substring(matcher.start()),index);
            return true;
        }

        return false;
    }

    private void setUrl(List<String> strList,String str, Integer index){

        strList.add(index+1,str.substring(str.indexOf("/")));
        strList.add(index+1,str.substring(str.indexOf(":") +1 ,str.indexOf("/")));
        strList.add(index+1,str.substring(0 ,str.indexOf(":")));

        strList.remove(index.intValue());

    }
}
