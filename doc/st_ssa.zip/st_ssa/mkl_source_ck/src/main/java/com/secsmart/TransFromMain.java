package com.secsmart;

import com.secsmart.transformation.AssetSortingProcess;
import com.secsmart.transformation.DesensDynamicProcess;
import com.secsmart.transformation.DesensStaticProcess;
import com.secsmart.transformation.EncryptProcess;
import com.secsmart.utils.CuratorOperator;
import com.secsmart.utils.KafkaSinkProp;
import com.secsmart.utils.KafkaSourceProp;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.shaded.curator4.org.apache.curator.framework.api.GetDataBuilder;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer;
import ru.ivi.opensource.flinkclickhousesink.ClickHouseSink;
import ru.ivi.opensource.flinkclickhousesink.model.ClickHouseSinkConst;

import java.io.ByteArrayInputStream;
import java.util.Map;
import java.util.Properties;

public class TransFromMain {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment environment = StreamExecutionEnvironment.getExecutionEnvironment();
        environment.setRestartStrategy(RestartStrategies.fixedDelayRestart(1000, Time.seconds(3)));

        ParameterTool map = ParameterTool.fromArgs(args);
        Properties properties = new Properties();
        CuratorOperator mcto = null;
//        mcto = new CuratorOperator("192.168.24.73:2181");
        mcto = new CuratorOperator(map.get("zkAddr"));
        GetDataBuilder data = mcto.client.getData();
//        properties.load(new ByteArrayInputStream(data.forPath("/dbsj_audit/dbsj/job/config/riskflinkjob")));
        properties.load(new ByteArrayInputStream(data.forPath(map.get("zkPath"))));
        ParameterTool parameterTool = ParameterTool.fromMap((Map) properties);

        environment.getConfig().setGlobalJobParameters(parameterTool);

        KafkaSinkProp kafkaSinkProp = new KafkaSinkProp();
        kafkaSinkProp.setBOOTSTRAP_SERVERS_CONFIG(parameterTool.get("kafka.url"));

        KafkaSourceProp kafkaSourceProp = new KafkaSourceProp();

        kafkaSourceProp.setBOOTSTRAP_SERVERS_CONFIG(parameterTool.get("kafka.url"));
        kafkaSourceProp.setGROUP_ID_CONFIG(parameterTool.get("kafka.source.groupId"));

        FlinkKafkaConsumer<String> desensStatic = new FlinkKafkaConsumer<String>(parameterTool.get("kafka.source.topic.desensstatic"), new SimpleStringSchema(), kafkaSourceProp.getProp());
        FlinkKafkaConsumer<String> desensDynamic = new FlinkKafkaConsumer<String>(parameterTool.get("kafka.source.topic.desensdynamic"), new SimpleStringSchema(), kafkaSourceProp.getProp());
        FlinkKafkaConsumer<String> encrypt = new FlinkKafkaConsumer<String>(parameterTool.get("kafka.source.topic.encrypt"), new SimpleStringSchema(), kafkaSourceProp.getProp());
        FlinkKafkaConsumer<String> assetSorting = new FlinkKafkaConsumer<String>(parameterTool.get("kafka.source.topic.assetsorting"), new SimpleStringSchema(), kafkaSourceProp.getProp());

        environment.addSource(desensStatic).process(new DesensStaticProcess()).addSink(new ClickHouseSink(getHttpLogCkProp(parameterTool, parameterTool.get("clickHouse.Table.desensstatic"))));
        environment.addSource(desensDynamic).process(new DesensDynamicProcess()).addSink(new ClickHouseSink(getHttpLogCkProp(parameterTool, parameterTool.get("clickHouse.Table.desensdynamic"))));
        environment.addSource(encrypt).process(new EncryptProcess()).addSink(new ClickHouseSink(getHttpLogCkProp(parameterTool, parameterTool.get("clickHouse.Table.encrypt"))));
        environment.addSource(assetSorting).process(new AssetSortingProcess()).addSink(new ClickHouseSink(getHttpLogCkProp(parameterTool, parameterTool.get("clickHouse.Table.assetsorting"))));


        environment.execute("nanas transform");
    }


    /**
     * Asset_log ck config
     *
     * @return
     */
    public static Properties getHttpLogCkProp(ParameterTool parameterTool, String table) {

        Properties properties = new Properties();
        properties.put(ClickHouseSinkConst.TARGET_TABLE_NAME, parameterTool.get("clickHouse.Database.sg") + "." + table);
        properties.put(ClickHouseSinkConst.MAX_BUFFER_SIZE, parameterTool.get("clickhouse.sink.max-buffer-size"));
        return properties;
    }
}
