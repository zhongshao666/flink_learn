package com.secsmart.transformation;


import com.secsmart.utils.CsvUtils;
import com.secsmart.utils.IdWorker;
import com.secsmart.utils.SplitUtils;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;

import java.util.*;
import java.util.stream.Stream;

public class DesensStaticProcess extends ProcessFunction<String, String> {

    private static final Character CK_LINE_BEGIN = '(';
    private static final Character CK_LINE_END = ')';
    private SplitUtils splitUtils;

    private Map<String, String> tableMap;

    ArrayList<String> list;


    @Override
    public void open(Configuration parameters) throws Exception {
        list = new ArrayList<>();
        splitUtils = new SplitUtils();
        tableMap = new HashMap<>();
    }

    @Override
    public void processElement(String value, Context ctx, Collector<String> out) throws Exception {

        try {

            if (value.startsWith("<")) {

                String[] split = value.split(":\\s+");

                List<String> strings = Arrays.asList(split[1].split("\\s+"));

                list.clear();
                list.addAll(strings);
                tableMap.clear();


                splitUtils.splitList(list, 2);
                splitUtils.splitList(list, 1);

                list.add(0, "11");

                list.set(list.size() - 2, list.get(list.size() - 2) + " " + list.get(list.size() - 1));
                list.remove(list.size() - 1);

                Stream<String> tableMappings = Arrays.stream(strings.get(5).split(","));

                tableMappings.forEach(t -> {
                    tableMap.put(t.split("->")[0], t);
                });

                Stream<String> algorithms = Arrays.stream(strings.get(6).split(","));

                algorithms.forEach(s -> {
                    String table = s.split("\\.")[0];
                    if (s.contains(table)) {
                        list.set(10, tableMap.get(table));
                    }
                    list.set(11, s);
                    long id = IdWorker.getInstance().nextId();

                    list.set(0, String.valueOf(id));

                    out.collect(CsvUtils.convertToCkCsvFormatByArray(list, CK_LINE_BEGIN, CK_LINE_END));

                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
